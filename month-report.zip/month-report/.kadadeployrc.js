const path = require('path')
const glob = require('glob')

const env = process.env.NODE_ENV || 'development'

const pagesDir = path.resolve('./dist')
const pagePaths = glob.sync('**/*.html', {
  cwd: pagesDir
})

let entries = pagePaths.filter(item => !!item)

module.exports = {
  entries,
  headers: entries.map(item => {
    const rules = `${item.replace(/\./g, '\\.')}$`
    return {
      rules,
      headers: {
        'cache-control': 'no-cache'
      }
    }
  })
}
