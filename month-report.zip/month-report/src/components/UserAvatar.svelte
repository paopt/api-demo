<div class="user-avatar">
  <img class="user-avatar__icon" src="" alt="">
  <!-- <img class="user-avatar__vip" src="" alt=""> -->
</div>

<script lang="ts">
 export let userInfo = {
  
 }
</script>

<style lang="scss" scoped>
  @import "../styles/variables";
  @import "../styles/mixins";


</style>