import Dialog from './Dialog.svelte'

let dialog = null
function createDialog (props) {
  if (dialog) {
    dialog.$destroy()
  }

  dialog = new Dialog({
    target: document.body,
    props
  })

  dialog.$on('destroy', () => {
    dialog.$destroy()
  })

  return dialog.promise
}

export function showDialog (props) {
  return createDialog(props)
}

Dialog.showDialog = showDialog

export default Dialog
