<!-- 进入页面弹框 -->
<Popup class="read-history {className}" {maskClickHide} bind:this={popupEl}>
  <div class="read-history__body" on:touchmove|stopPropagation|preventDefault>
    <div class="read-history__title">{historyData.date}加入KaDa大家庭</div>
    <div class="read-history__list">
      <div class="read-board">
        <div class="read-board__label">坚持阅读</div>
        <div>
          <span class="read-board__val">
            {historyData?.readDays}
          </span>
          天
        </div>
      </div>
      <div class="read-board">
        <div class="read-board__label">累计阅读</div>
        <div >
          <span class="read-board__val">{historyData?.readNums}</span>
          <span>{historyData?.unit}</span>
        </div>
      </div>
    </div>
    <div class="read-history__time">
      总时长
        {#if historyData?.timeObj.h > 0}
            <span class="read-board__val">{historyData?.timeObj.h}</span>
            <span>小时</span>
        {/if}
        {#if historyData?.timeObj.m > 0}
          <span class="read-board__val">{historyData?.timeObj.m}</span>
          <span>分钟</span>
        {/if}
        {#if historyData?.timeObj.h == 0 && historyData?.timeObj.m == 0}
        <span class="read-board__val">0</span>
        <span>小时</span>
        {/if}
    </div>

    <!-- <div class="read-history__rule" on:click={openRuleModal}>数据统计说明</div> -->

    <div class="read-history__close" on:click={close}></div>
  </div>
</Popup>

<script lang="ts">
  // @ts-nocheck
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  import { showDialog as showRuleDialog } from '@/components/RuleDialog'
  import { sendReportBehavior } from '@/lib/analytics'
  import URLParser from '@/lib/urlParser'
  import { formatDate } from "@kada/library/utils/datetime";

  const url = location.href
  const parsed = new URLParser(url)
  const { date, channelId } = parsed.query

  const dispatch = createEventDispatcher()
  //组件样式
  let className = ''

  //组件
  let popupEl

  export { className as class }

  //是否支持点击mask关闭弹窗
  export let maskClickHide = true

  //点击关闭按钮回调
  export let onClose = null

  //是否自动关闭弹框
  export let autoClose = false

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  let timerId

  export let historyData

  function close() {
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
    clearTimeout(timerId)
  }

  onMount(async () => {
    popupEl && popupEl.show()
    if (autoClose) {
      timerId = setTimeout(() => { close() }, 4000)
    }

    sendReportBehavior('pgv_100102', {
      date: formatDate(date, 'YYYYMM'),
      channelId,
      type: 1
    })
  })

  onDestroy(() => {
    clearTimeout(timerId)
    timerId = null
  })

  function openRuleModal() {
    showRuleDialog()
  }
</script>

<style lang="scss" scoped>
    @import "../../styles/variables";
  @import "../../styles/mixins";

:global {
  .read-history {
    z-index: 999;
    &__body {
      position: absolute;
      width: 6.4rem;
      height: 4.64rem;
      z-index: 999;
      background-color: #fff;
      border-radius: 0.32rem;

      @media #{$pad_landscape_query} {
            width: 10rem;
      }
    }
    &__list {
      display: flex;
      justify-content: space-between;
      margin-top: 0.48rem;
      padding: 0 0.8rem;

      @media #{$pad_landscape_query} {
        padding: 0 2.2rem;
      }
    }
    &__close {
      position: absolute;
      top: 5.2rem;
      left: 2.8rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/b6f10733-4321-50a6-8af0-3c2365457c6c.png);
      width: 0.8rem;
      height: 0.8rem;
      background-repeat: no-repeat;
      background-size: cover;

      @media #{$pad_landscape_query} {
        left: 4.52rem;
      }
    }
    &__title {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 5.84rem;
      height: 0.96rem;
      margin: 0 auto;
      background-image: url(//cdn.hhdd.com/frontend/as/i/ae980510-7cf9-5f7a-8f2e-3d58f6ba5768.png);
      background-repeat: no-repeat;
      background-size: cover;

      font-size: 0.4rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FFFF00;
      line-height: 0.56rem;

      @media #{$pad_landscape_query} {
            width: 6.24rem;
            background-image: url(//cdn.hhdd.com/frontend/as/i/6353273d-7d62-54dd-8dcb-f68191f24b7a.png);
      }
    }
    &__time {
      margin-top: 0.24rem;
      text-align: center;
    }
    &__rule {
      margin-top: 0.48rem;
      text-align: center;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #666666;
      line-height: 0.34rem;
      font-size: 0.24rem;
      text-decoration: underline;
    }
  }
  .read-board {
    font-size: 0.28rem;
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #333333;
    line-height: 0.4rem;
    text-align: center;

    &__label {
    }
    &__val {
      font-size: 0.72rem;
      font-family: PingFangSC-Semibold, PingFang SC;
      font-weight: 600;
      color: #287AE3;
      line-height: 1rem;
    }
  }
}

</style>
