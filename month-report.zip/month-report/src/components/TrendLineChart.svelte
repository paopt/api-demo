<div id="trendChart"></div>
{#if trendInfo?.length > 1}
  <div class="chart-mark {isUp ? 'up' : ''} {isEqual ? 'equal' : ''}" style={`left: ${pos[0]}px;top: ${pos[1] - 20}px`}>
    <div class="chart-mark__content">{tip}</div>
    <div class="chart-mark__arrow"></div>
  </div>
{/if}

<script lang="ts">
  // @ts-nocheck
  import { onMount } from 'svelte';
  import type { ITotalInfo, ITrendItem } from "@/services/report";
  import * as echarts from 'echarts';
  import type { IUser } from '@/services/user';
  import { deviceInfo } from '@kada/library/src/device'
  const rem2px = window.kadaRemLayout && window.kadaRemLayout.rem2px ? window.kadaRemLayout.rem2px : (rem) => rem * 50

  type EChartsOption = echarts.EChartsOption;

  export let trendInfo: ITrendItem[] = []

  export let date: string

  // 提示信息位置
  let pos = [0, 0]

  // 提示信息
  let tip = ''

  // 是否超出目标
  let isUp = false;

  let isEqual = false

  onMount(() => {
      init()
  })

  function init() {
    const chartDom = document.getElementById('trendChart');
    const myChart = echarts.init(chartDom);
    let option: EChartsOption = null;

    let categoryArr = [];
    let valueArr = [];
    let max = 0

    if (trendInfo?.length) {
      trendInfo.forEach((item, index) => {
        const {totalTime, yearMonth } = item;
        const label = (new Date(yearMonth)).getMonth() + 1 + '月'
        const value = (totalTime / 3600)
        if (value > max) {
          max = value
        }
        console.log('阅读时间:', value)
        categoryArr.push(label)

        // if (index === 0) {
        //   valueArr.push({
        //     value,
        //     // itemStyle: {
        //     //   color: 'red'
        //     // }
        //   })
        // } else {
        //   valueArr.push(value)
        // }
        valueArr.push(value)
      })
    }

    // 默认显示六条数据
    // const len = 6
    // if (categoryArr.length < len) {
    //   let now = trendInfo?.length ? trendInfo[0].yearMonth : new Date(date)
    //   let d = new Date(now)
    //   let arr = []
    //   for (let i = 0; i < len; i++) {
    //     let month = d.getMonth()
    //     arr.push(`${month + 1}月`)
    //     d = new Date(d.setMonth(month  - 1))
    //   }
    //   categoryArr = arr
    // }

    // for (let i = valueArr.length; i < len; i++) {
    //   valueArr.push(null)
    // }


    console.log(valueArr)

    categoryArr.reverse()
    valueArr.reverse()

    let color = '#287AE3'
    let minute = 0
    if (trendInfo?.length) {
      let { totalTime, lastMonthTotalTime } = trendInfo[0]
      lastMonthTotalTime = lastMonthTotalTime || 1
      minute = (totalTime - lastMonthTotalTime) / 60
      let percent = Math.ceil((totalTime / lastMonthTotalTime) * 100)
      console.log('分钟:', minute)
      if (minute < 0) {
        tip = `较上月${formateMinute(minute)}，↓ ${100 - percent}%`
        color = '#999'
      } else if (minute == 0) {
        tip = '和上月持平'
        color = '#999'
        isUp = true
        isEqual = true
      } else {
        tip = `较上月+${formateMinute(minute)}，↑ ${percent - 100}%`
        color = '#287AE3'
        isUp = true
      }
    }

    option = {
      title: {
        text: '单位：h',
        textStyle: {
          fontSize: deviceInfo.isPad ? 14 : 12,
          fontFamily: 'PingFangSC-Regular, PingFang SC',
          color: '#3F3F3F'
        },
        top: 10,
        left: 20,
        padding: 0
      },
      grid: {
        show: false,
        left: deviceInfo.isPad ? 70 : 55,
        top: 40,
        right: 20,
        bottom: 35
      },
      xAxis: {
        type: 'category',
        data: categoryArr,
        splitLine: {
          show: true
        },
        axisLabel: {
          fontSize: deviceInfo.isPad ? 14 : 12,
          fontFamily: 'FZLANTY_JW--GB1',
          margin: deviceInfo.isPad ? 15 : 16,
          formatter: function (value, index) {
            if (value === categoryArr[categoryArr.length-1]) {
              return `{a|${value}}`
            } else {
              return `{b|${value}}`
            }
          },
          rich: {
            a: {
              color: '#287AE3',
              fontFamily: 'FZLANTY_ZHONGCUJW--GB1'
            },
            b: {
              color: '#333333',
              fontFamily: 'FZLANTY_JW--GB1'
            },
          }
        },
        axisLine: {
          show: false,
          lineStyle: {
            opacity: 0.7,
            color: '#E3E7EC'
          },
        },
        axisTick: {
          show: true,
          alignWithLabel: true
        },
        boundaryGap: false
      },
      yAxis: {
        type: 'value',
        splitNumber: 5,
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#3f3f3f',
          fontSize: deviceInfo.isPad ? 14 : 12,
          margin: deviceInfo.isPad ? 25 : 17,
          fontFamily: 'PingFangSC-Semibold, PingFang SC',
          formatter: (value) => {
            return formateNum(value)
          }
        }
      },
      series: [
        {
          smooth: true,
          data: valueArr,
          type: 'line',
          lineStyle: {
            color: '#287AE3',
            width: 3
          },
          symbolSize: (value) => {
            if (value === valueArr[valueArr.length-1]) {
              return 8
            } else {
              return 6
            }
          },
          itemStyle: {
          },
          areaStyle: {
            opacity: 0.2,
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                  offset: 0, color: '#287AE3' // 0% 处的颜色
              }, {
                  offset: 1, color: '#ffffff' // 100% 处的颜色
              }],
              global: false // 缺省为 false
            }
          }
        }
      ]
    };

    option && myChart.setOption(option);

    pos = myChart.convertToPixel({
        xAxisIndex: 0,
        yAxisIndex: 0
    },[categoryArr.length - 1, valueArr[valueArr.length - 1]])
  }

  function formateNum(num: number): string {
    if (num < 10000) {
      return num + ''
    } else {
      return (num / 10000).toFixed(1) + '万'
    }
  }

  function formateMinute(minute): string {
    let sign = ''
    if (minute < 0) {
      sign = '-'
    }
    minute = Math.ceil(Math.abs(minute))
    const h = parseInt(String(minute / 60), 10);
    const m = parseInt(String(minute % 60), 10);
    let str = ''
    if (h) {
      str += `${h}小时`
    }
    if (m) {
      str += `${m}分钟`
    }
    return sign + str
  }
</script>

<style lang="scss" scoped>
 @import "../styles/variables";
  @import "../styles/mixins";

  #trendChart {
    position: relative;
    width: 100%;
    height: 100%;
    // @media #{$pad_landscape_query} {
    //   width: 0.48;
    //   width: calc(100% - 0.48rem);
    // }
    // border: 1px solid black;
  }

  .chart-mark {
    position: absolute;
    z-index: 100;
    // padding: 0.04rem 0.24rem 0.06rem 0.24rem;
    border-radius: 2rem;
    // transform: translate(calc(-100% + 0.48rem), -100%);
    // font-size: 0.24rem;
    background-color: #eee;
    font-family: FZLANTY_ZHONGCUJW--GB1;
    color: #333333;
    // line-height: 0.34rem;
    transform: translate(calc(-100% + 0.64rem), -100%);
    padding: 0.12rem 0.34rem 0.12rem 0.36rem;
    line-height: 0.32rem;
    font-size: 0.26rem;
    @media #{$pad_landscape_query} {
      transform: translate(calc(-100% + 0.64rem), -100%);
      padding: 0.12rem 0.34rem 0.12rem 0.36rem;
      line-height: 0.32rem;
      font-size: 0.28rem;
    }
    &.up {
      background-color: #D6E8FF;
      color: #287AE3;

      .chart-mark__arrow {
        background-image: url(//cdn.hhdd.com/frontend/as/i/97cdb126-41c2-536a-a447-89c8ae4eea29.png);
      }
    }

    &.equal {
      transform: translate(calc(-100% + 0.3rem), -100%);
      @media #{$pad_landscape_query} {
        transform: translate(calc(-100% + 0.3rem), -100%);
      }
    }

    &__content {
      white-space: nowrap;
    }

    &__arrow {
      position: absolute;
      top: 100%;
      left: 70%;
      width: 0.3rem;
      height: 0.14rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/f19ea462-21f3-5220-80f3-518a24c918aa.png);
      background-repeat: no-repeat;
      background-size: cover;
    }
  }
</style>
