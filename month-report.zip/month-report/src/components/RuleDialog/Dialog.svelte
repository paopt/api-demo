<!-- 进入页面弹框 -->
<Popup class="read-rule {className}" {maskClickHide} bind:this={popupEl}>
  <div class="read-rule__body" on:touchmove|stopPropagation|preventDefault>
    <div class="read-rule__title">数据统计说明</div>
    <div class="read-rule__info">
      <div>1. 本阅读报告基于用户在KaDa阅读APP内阅读行为统计，并于次月1日生成新一期月度报告</div>
      <div>2. 阅读本数：以图书为范围，包含站内绘本、漫画、电子书，其中绘本以单本计算，漫画和电子书以整本书计算</div>
      <div>3. 阅读字数：以图书为范围，包含站内绘本、漫画、电子书</div>
      <div>4. 阅读时长：统计用户所有内容阅读时长，包含绘本、听书、课程、漫画、电子书</div>
      <div>5. 阅读目标：学龄前用户以阅读本数为目标，根据KaDa阅读用户平均阅读水平、参考《3-6岁儿童学习与发展指南》制定；学龄段用户以阅读字数为目标，根据新课标对小学语文课外阅读量要求制定</div>
      <div>6. 所有报告以北京时间为准</div>
      <div>7.  KaDa阅读拥有对本阅读报告数据的最终解释权</div>
    </div>
    <div class="read-rule__close" on:click={close}>
      <img src="//cdn.hhdd.com/frontend/as/i/154a4c24-ed8e-58e9-966c-c867df6ec712.png" alt="">
    </div>
  </div>
</Popup>

<script lang="ts">
  // @ts-nocheck
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  import { sendReportBehavior } from '@/lib/analytics'
  import URLParser from '@/lib/urlParser'
  import { formatDate } from "@kada/library/utils/datetime";

  const url = location.href
  const parsed = new URLParser(url)
  const { date, channelId } = parsed.query

  const dispatch = createEventDispatcher()
  //组件样式
  let className = ''

  //组件
  let popupEl

  export { className as class }

  //是否支持点击mask关闭弹窗
  export let maskClickHide = false

  //点击关闭按钮回调
  export let onClose = null

  //是否自动关闭弹框
  export let autoClose = false

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  let timerId

  function close() {
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
    clearTimeout(timerId)
  }

  onMount(() => {
    popupEl && popupEl.show()
    if (autoClose) {
      timerId = setTimeout(() => { close() }, 4000)
    }

    sendReportBehavior('pgv_100102', {
      channelId,
      type: 2
    })
  })

  onDestroy(() => {
    clearTimeout(timerId)
    timerId = null
  })
</script>

<style lang="scss" scoped>
:global {
  .read-rule {
    z-index: 999;
    &__body {
      position: absolute;
      width: 7.5rem;
      height: 12rem;
      z-index: 999;
      background-image: url(//cdn.hhdd.com/frontend/as/i/f0e7ae85-e6b9-51c8-aae6-d44f65ba97a5.png);
      background-size: cover;
      background-repeat: no-repeat;
      // //cdn.hhdd.com/frontend/as/i/f0e7ae85-e6b9-51c8-aae6-d44f65ba97a5.png
    }
    &__title {
      position: absolute;
      top: 0.96rem;
      width: 7.5rem;
      font-size: 0.4rem;
      font-family: FZLanTingYuanS-DB1-GB;
      font-weight: 400;
      color: #FFFFFF;
      line-height: 0.34rem;
      text-shadow: 0px 0.02rem 0.03rem #FF8827;
      text-align: center;
    }
    &__info {
      position: absolute;
      left: 1.37rem;
      top: 2.76rem;
      width: 4.78rem;
      height: 7.06rem;
      overflow: auto;
      font-family: FZLANTY_ZHONGCUJW--GB1-0;
      font-size: 0.24rem;
      color: #7F584C;
      line-height: 0.34rem;
    }
    &__close {
      position: absolute;
      left: 3.31rem;
      top: 10.86rem;
      width: 0.88rem;
      height: 0.88rem;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>
