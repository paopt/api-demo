<!-- 进入页面弹框 -->
<Popup class="code-modal{className}" {maskClickHide} bind:this={popupEl}>
  <div class="code-modal__header">
    <img class="img1" src="//cdn.hhdd.com/frontend/as/i/5f0e4cda-0da3-5dcd-96d1-99e86e906a07.png" alt="">
  </div>
  <div class="code-modal__body">
    <img class="close" src="//cdn.hhdd.com/frontend/as/i/b6f10733-4321-50a6-8af0-3c2365457c6c.png" alt="" on:click={close}>
    <div class="title">您的礼盒兑换码为</div>
    <div class="code">{code}</div>
    <div class="copy" on:click={copy}>复制兑换码</div>
    <div class="btn" on:click={goRedeem}>去兑换</div>
    <div class="desc">
      <div class="label">兑换规则：</div>
      <div class="label">·本兑换码仅限首购季卡和首购年卡到期用户使用，一人一码不得转赠。</div>
      <div class="label">·如出现兑换码转卖或刷礼盒情况，KaDa阅读有权不发货</div>
      <div class="label">·礼盒将在领取成功后7个工作日内通过中通快递完成寄送，请注意查收短信。</div>
      <div class="label">·寄出后可通过KaDa阅读-我的-兑换中心查看物流信息，如有任何问题请添加客服微信咨询。</div>
    </div>
  </div>
</Popup>

<script lang="ts">
  // @ts-nocheck
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup, toast } from '@kada/svelte-activity-ui'
  import { getCode } from '@/services/report'
  import { userIdStr, channelId } from '@/app'
  import config from '@/lib/config'
  import { sendReportBehavior } from '@/lib/analytics'

  const dispatch = createEventDispatcher()

  //组件样式
  let className = ''

  //组件
  let popupEl

  export { className as class }

  //是否支持点击mask关闭弹窗
  export let maskClickHide = true

  //点击关闭按钮回调
  export let onClose = null

  //是否自动关闭弹框
  export let autoClose = false

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  let timerId

  // 兑换码
  let code = ''

  init()

  async function init() {
    sendReportBehavior('pgv_100203', {
      type: 6,
      channelId: channelId,
      status: 1
    }, null, false)
    code  = await getCode(userIdStr)
  }

  onMount(async () => {
    popupEl && popupEl.show()
    if (autoClose) {
      timerId = setTimeout(() => { close() }, 4000)
    }
  })

  onDestroy(() => {
    clearTimeout(timerId)
    timerId = null
  })

  function close() {
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
    clearTimeout(timerId)
  }

  /**
   * 复制兑换码
   */
  function copy() {
    const inputNode = document.createElement('input');
    inputNode.value = code;
    document.body.appendChild(inputNode);
    inputNode.select();
    document.execCommand('copy');
    document.body.removeChild(inputNode);
    toast({
      text: '复制成功',
    })
  }

  /**
   * 去兑换
   */
  function goRedeem() {
    sendReportBehavior('ac_100203', {
      type: 1,
      channelId: channelId,
      status: 1
    }, null, false)
    console.log(config)
    location.href = `kada://openurl?url=${config.redeemUrl}`
  }
</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/mixins";

:global {
  .sui-toast {
    z-index: 10000 !important;
  }
  .code-modal {
    &__header {
      .img1 {
        width: 100%;
      }
    }
    &__body {
      position: relative;
      width: 7.5rem;
      height: 12.64rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/5f0e4cda-0da3-5dcd-96d1-99e86e906a07.png);
      background-size: 100%;
      background-repeat: no-repeat;

      .close {
        position: absolute;
        right: 0;
        top: 0;
        width: 0.96rem;
        right: 0.5rem;
        top: 1rem;
      }

      .title {
        margin-top: 5.3rem;
        font-size: 0.32rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 36px;
        text-align: center;
      }

      .code {
        margin-top: 0.5rem;
        font-size: 0.4rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        text-align: center;
        text-align: center;
      }
      .copy {
        margin-top: 0.62rem;
        font-size: 0.28rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #3398FF;
        text-align: center;
      }
      .btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 5.2rem;
        height: 0.96rem;
        margin: 0.4rem auto 0 auto;
        background: linear-gradient(84deg, #FF5E02 0%, #FE3001 100%);
        border-radius: 0.48rem;
        font-size: 0.4rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #FFFFFF;
        letter-spacing: 0.01;
      }
      .desc {
        margin-top: 0.36rem;
        padding: 0 0.94rem;
        .label {
          font-size: 0.22rem;
          font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
          font-weight: normal;
          color: #666666;
          line-height: 0.32rem;
        }
      }
    }
  }
}

</style>
