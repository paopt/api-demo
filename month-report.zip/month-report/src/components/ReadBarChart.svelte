<div id="readChart">
</div>
{#if totalInfo?.items?.length}
<div class="chart-mark {isUp ? 'up' : ''}" style={`left: ${pos[0]}px;top: ${pos[1] - 25}px`}>
  <div class="chart-mark__content">{tip}</div>
  <div class="chart-mark__arrow"></div>
</div>
{/if}

<script lang="ts">
  // @ts-nocheck
  import { onMount } from 'svelte';
  import type { ITotalInfo } from "@/services/report";
  import * as echarts from 'echarts';
  import type { IUser } from '@/services/user';
  import { ageTypeMap } from '@/services/read';
  import { deviceInfo } from '@kada/library/src/device'
  const rem2px = window.kadaRemLayout && window.kadaRemLayout.rem2px ? window.kadaRemLayout.rem2px : (rem) => rem * 50

  type EChartsOption = echarts.EChartsOption;

  export let totalInfo: ITotalInfo
  export let userInfo: IUser
  export let date: string;

  // 提示信息位置
  let pos = [0, 0]

  // 提示信息
  let tip = ''

  // 是否超出目标
  let isUp = false;

  onMount(() => {
    if (totalInfo) {
      init()
    }
  })

  /**
   * 初始化echart
   */
  function init() {
    const chartDom = document.getElementById('readChart');
    const myChart = echarts.init(chartDom);
    let option: EChartsOption = null;
    let categoryArr = [];
    let valueArr = [];
    let { items = [] } = totalInfo
    
    let max = 0
    let num = 0
    if (items?.length) {
      items.forEach((item, index) => {
        const {readNum, readWords, yearMonth } = item;
        const label = (new Date(yearMonth)).getMonth() + 1 + '月'
        const value = userInfo.ageType < 7 ? readNum : readWords
        if (value > max) {
          max = value
        }
        if (index === 0) {
          num = value
        }
        categoryArr.push(label)
        valueArr.push(value)
      })
    }
    
    // 默认显示六条数据
    // const len = 6
    // if (categoryArr.length < len) {
    //   let now = items?.length ? items[0].yearMonth : new Date(date)
    //   let d = new Date(now)
    //   let arr = []
    //   for (let i = 0; i < len; i++) {
    //     let month = d.getMonth()
    //     arr.push(`${month + 1}月`)
    //     d = new Date(d.setMonth(month  - 1))
    //   }
    //   categoryArr = arr
    // }

    // for (let i = valueArr.length; i < len; i++) {
    //   valueArr.push(null)
    // }

    console.log(categoryArr)
    console.log(valueArr)

    categoryArr.reverse()
    valueArr.reverse()

    const unit = userInfo.ageType < 7 ? '本数' : '字数'
    const { target } = ageTypeMap[userInfo.ageType]

    max = max > target ? max : target
    let percent = num / target;
    let color: any = {
      type: 'linear',
      x: 0,
      y: 0,
      x2: 0,
      y2: 1,
      colorStops: [{
          offset: 0, color: '#FF8A27' // 0% 处的颜色
      }, {
          offset: 1, color: '#FF5500' // 100% 处的颜色
      }],
      global: false // 缺省为 false
    }
    if (percent < 0.9) {
      tip = '阅读量未达标，本月别落下啦'
      color = '#999'
    } else if (percent < 1) {
      tip = '差一点就完成目标喽'
      color = '#999'
    } else if (percent == 1) {
      tip = '目标完成100%'
      isUp = true
    } else {
      isUp = true
      tip = `超出目标${Math.round((percent - 1) * 100)}%`
    }

    let yMax = Math.ceil(Math.max(max, target) * 1.2)

    option = {
      title: {
        text: `${unit}`,
        textStyle: {
          fontSize: deviceInfo.isPad ? 14 : 12,
          fontFamily: 'PingFangSC-Regular, PingFang SC',
          color: '#666666'
        },
        top: 0,
        left: 15,
        padding: 0
      },
      grid: {
        show: false,
        left: deviceInfo.isPad ? 60 : 45,
        top: 29,
        right: deviceInfo.isPad ? 40 : 20,
        bottom: 25
      },
      xAxis: {
        type: 'category',
        data: categoryArr,
        axisLabel: {
          interval: 0,
          show: true,
          margin: 6,
          fontSize: deviceInfo.isPad ? 14 : 12,
          formatter: function (value, index) {
            if (value === categoryArr[categoryArr.length-1]) {
              return percent >= 1 ? `{a|${value}}` : `{b|${value}}`
            } else {
              return `{c|${value}}`
            }
          },
          rich: {
            a: {
              color: '#FF8217',
              fontFamily: 'FZLANTY_ZHONGCUJW--GB1'
            },
            b: {
              color: '#333333',
              fontFamily: 'FZLANTY_ZHONGCUJW--GB1',
            },
            c: {
              color: '#333333',
              fontFamily: 'FZLANTY_JW--GB1'
            }
          }
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#D7D7D7',
            width: 2
          },
          symbol: ['none', 'arrow'],
          symbolOffset: 8,
          symbolSize: [10, 10]
        },
        splitLine: {
          show: false
        },
        axisTick: {
          show: false
        }
      },
      yAxis: {
        type: 'value',
        splitNumber: 5,
        max: yMax,
        axisTick: {
          show: false
        },
        axisLabel: {
          // interval: (index, value) => {
          //   return yMax != value
          // },
          color: (value) => {
            if (value == target) {
              return '#FF6317'
            } else {
              return deviceInfo.isPad ? '#333333' : '#666'
            }
          },
          fontSize: deviceInfo.isPad ? 14 : 12,
          margin: deviceInfo.isPad ? 10 : 7,
          fontFamily: 'PingFangSC-Semibold, PingFang SC',
          formatter: (value) => {
            return formateNum(value)
          }
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#D7D7D7',
            width: 2
          },
          symbol: ['none', 'arrow'],
          symbolOffset: 8,
          symbolSize: [10, 10]
        },
        splitLine: {
          show: false
        }
      },
      series: [
        {
          data: valueArr,
          type: 'bar',
          zlevel: 1,
          barWidth: deviceInfo.isPad ? 32 : 24,
          label: {
            show: true,
            color: '#333',
            fontSize: deviceInfo.isPad ? 12 : 10,
            position: 'top',
            fontFamily: 'PingFangSC-Medium, PingFang SC',
            distance: deviceInfo.isPad ? 3 : 2,
            formatter: (obj) => {
              console.log(obj, typeof obj.value)
              return computeReadNum(obj.value)
            }
          },
          itemStyle: {
            borderRadius: [6, 6, 0, 0],
            color: ({data, name}) => {
              if (name === categoryArr[categoryArr.length - 1]) {
                return color
              } else {
                return '#3771E2'
              }
            }
          },
          markLine: {
            silent: true,
            symbol: 'none',
            lineStyle: {
              color: '#FF6317',
              type: [5, 5],
              // opacity: 0.7,
              dashOffset: 5,
              width: 1.5
            },
            data: [
              {
                yAxis: target
              }
            ],
            label: {
              show: true,
              position: 'insideEnd',
              formatter: '目标',
              color: '#ffffff',
              distance: deviceInfo.isPad ? [0, 0] : [-20, 0],
              fontSize: deviceInfo.isPad ? 12 : 10,
              fontFamily: 'FZLANTY_ZHONGCUJW--GB1',
              backgroundColor: '#FF6317',
              padding: deviceInfo.isPad ? [4, 6] : [4, 5],
              borderRadius: deviceInfo.isPad ? [4, 4, 4, 4] : [4, 0, 0, 4],
            },
          },
        }
      ],
    };

    option && myChart.setOption(option);

    pos = myChart.convertToPixel({
        xAxisIndex: 0,
        yAxisIndex: 0
    },[categoryArr.length - 1, num])
  }

  /**
   * 格式化数字，超过10000显示单位为：万
   * @param num
   */
  function formateNum(num: number): string {
    if (num < 10000) {
      return num + ''
    } else {
      return (num / 10000).toFixed(1) + '万'
    }
  }

  function computeReadNum(val) {
    val = Number(val)
    if (val < 10000) {
      return val
    } else {
      const count = (val / 10000).toFixed(2)
      return count + '万'
    }
  }
</script>

<style lang="scss" scoped>
   @import "../styles/variables";
  @import "../styles/mixins";

  #readChart {
    position: relative;
    height: 100%;
    width: 100%;
    // border: 1px solid black;
  }

  .chart-mark {
    position: absolute;
    z-index: 100;
    // padding: 0.04rem 0.24rem 0.06rem 0.26rem;
    border-radius: 2rem;
    // transform: translate(calc(-100% + 0.48rem), -100%);
    // font-size: 0.24rem;
    // line-height: 0.34rem;
    // font-family: FZLANTY_ZHONGCUJW--GB1;
    background-color: #eee;
    color: #333333;
    transform: translate(calc(-100% + 0.64rem), -100%);
    font-size: 0.26rem;
    font-family: FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    line-height: 0.4rem;
    padding: 0.04rem 0.34rem 0.08rem 0.34rem;

    @media #{$pad_landscape_query} {
      transform: translate(calc(-100% + 0.64rem), -100%);
      font-size: 0.28rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      line-height: 0.4rem;
      padding: 0.04rem 0.34rem 0.08rem 0.34rem;
    }

    &.up {
      background-color: #FFF2E7;
      color: #FF6317;

      .chart-mark__arrow {
        background-image: url(//cdn.hhdd.com/frontend/as/i/c2a58358-9cf4-5f23-a5c2-fcb725423bdc.png);
      }
    }

    &__content {
      white-space: nowrap;
    }

    &__arrow {
      position: absolute;
      top: 100%;
      left: 70%;
      width: 0.3rem;
      height: 0.14rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/f19ea462-21f3-5220-80f3-518a24c918aa.png);
      background-repeat: no-repeat;
      background-size: cover;
   }
  }
</style>
