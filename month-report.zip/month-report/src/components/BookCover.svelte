  <div>
    <div class="c-card {card.bgClass}" on:click={onCardClick}>
      <div class="c-card__content">
        <img class="c-card__cover" src={item.imgUrl} alt="">
        {#if card.showVideoIcon}
          <img class="c-card__video" alt="" src="//cdn.hhdd.com/frontend/as/i/b0f01ec8-2534-513e-b7dd-3ff62e4d06ab.png">
        {/if}
        {#if card.tag}         
          <span class="c-card__tag {card.tagClass}">
            <span class="c-card__tag--name">{ card.tag }</span>
            {#if card.showVolumeIcon}
              <img class="c-card__tag--volume" alt="" src="//cdn.hhdd.com/frontend/as/i/37cd6e22-a4bd-5b17-aab3-93f348d4693d.png">
            {/if}
            {#if card.showHeadsetIcon}  
              <img class="c-card__tag--headset" alt="" src="//cdn.hhdd.com/frontend/as/i/9791602c-d642-5d46-8d23-cb8834357bd2.png">
            {/if}
          </span>
        {/if}
      </div>
    </div>
  </div>

<script lang="ts">

export let item: any

const tagMap = {
  1: {
    tag: '绘本',
    showVolumeIcon: true, // 音量图标
    tagClass: 'c-card__tag--book'
  },
  2: {
    tag: '听书',
    showHeadsetIcon: true, // 耳机图标
    tagClass: 'c-card__tag--story'
  },
  4: {
    tag: '听书合辑',
    showHeadsetIcon: true, // 耳机图标
    bgClass: 'c-card__bg--storyalbum', // 合辑层叠效果
    tagClass: 'c-card__tag--storyalbum'
  },
  5: {
    tag: '绘本合辑',
    showVolumeIcon: true, // 音量图标
    bgClass: 'c-card__bg--bookalbum', // 合辑层叠效果
    tagClass: 'c-card__tag--bookalbum'

  },
  8: {
    showVideoIcon: true // 视频图标
  },
  14: {
    tag: '漫画',
    tagClass: 'c-card__tag--comic'
  },
  15: {
    tag: '电子书',
    tagClass: 'c-card__tag--ebook'
  }
}

let card

$: if (item) {
  const type = item.sourceType
  if (!tagMap[type]) {
    card =  {}
  } else {
    const data = { ...tagMap[type] }
    if (type === 14 || type === 15) {
      data.tag = ''
    }
    card = data
  }
}

function onCardClick () {
  console.log('点击封面')
}
</script>

<style lang="scss">
$borderRadius: 0.12rem;
.c-card {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  border-radius: $borderRadius;

  &__content {
    position: relative;
    height: 100%;
    width: 100%;
    background-color: #fff;
    border-radius: $borderRadius;
  }

  &__bg--bookalbum {
    background-color: #66B3FF;
  }

  &__bg--storyalbum {
    background-color: #FFD072;
  }

  &__bg--storyalbum, &__bg--bookalbum {
    width: calc(100% - 0.08rem) !important;
    height: calc(100% - 0.1rem) !important;
    .c-card__content {
      transform: translate(0.08rem, 0.1rem);
    }
    .c-card__delete {
      top: -0.16rem;
      right: -0.16rem;
    }
  }

  &__cover {
    width: 100%;
    height: 100%;
    border-radius: $borderRadius;
  }

  &__delete {
    position: absolute;
    top: -0.08rem;
    right: -0.08rem;
    z-index: 1;
    width: 0.48rem;
    height: 0.48rem;
    pointer-events: auto;
  }

  &__video {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 0.76rem;
    height: 0.7rem;
  }

  &__tag {
    position: absolute;
    display: flex;
    align-items: center;
    bottom: 0;
    right: 0;
    width: 1.3rem;
    height: 0.36rem;
    background-size: 1.3rem 0.36rem;

    &--book,  &--comic, &--ebook {
      width: 1.2rem;
      height: 0.32rem;
      padding-left: 0.50rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/92e28d8e-21b4-513b-8f5f-95d68aee1727.png);
      background-repeat: no-repeat;
      background-size: 1.24rem 0.34rem;
    }

    &--story {
      width: 1.3rem;
      height: 0.36rem;
      padding-left: 0.56rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/549bec06-a23e-5981-9181-a856dbd51b08.png);
    }

    &--storyalbum {
      width: 1.3rem;
      height: 0.36rem;
      padding-left: 0.18rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/f9f28af5-db43-56c5-997b-9a63da7eae52.png);
      background-position: 0.01rem 0;
    }

    &--bookalbum {
      width: 1.3rem;
      height: 0.36rem;
      padding-left: 0.18rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/199ddebf-4e17-5f77-baaa-2e3786a47921.png);
    }

    &--name {
      padding-right: 0.04rem;
      font-size: 0.2rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FFFFFF;
      line-height: 1;
    }

    &--volume,
    &--headset {
      width: 0.2rem;
      height: 0.2rem;
      font-size: 0;
    }
  }
}</style>
