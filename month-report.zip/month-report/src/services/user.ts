import { getApi, fetch } from '@/lib/fetch'

export interface IUser {
  headUrl: string;
  nick: string;
  ageType: number;
  joinVip: number;
  [propName: string]: any;
}

// 用户信息缓存
let userInfoCache: ServerResponse<IUser> = null

/**
 * 获取用户信息
 * @param userIdStr 用户id，浏览器访问，使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getUserInfo (userIdStr: string) {
  let url = 'report/getUserInfo.json'
  if (userIdStr) {
    url += `?userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)

  let res: ServerResponse<IUser> = null
  try {
    console.log(api)
    res = await fetch.get(api)
    userInfoCache = res
  } catch (error) {
    console.error('getUserInfo Error: ', error)
  }

  return userInfoCache
}
