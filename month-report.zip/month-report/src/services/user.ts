import { getApi, fetch } from '@/lib/fetch'

export interface IUser {
  headUrl: string;
  nick: string;
  ageType: number;
  joinVip: number;
  isSvip: number;
  isVip: number;
  [propName: string]: any;
}

/**
 * 获取用户信息
 * @param userIdStr 用户id，浏览器访问，使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getUserInfo (userIdStr: string) {
  let url = 'report/getUserInfo.json'
  if (userIdStr) {
    url += `?userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)
  let res: ServerResponse<IUser> = null
  try {
    res = await fetch.get(api)
  //   res = {
  //     "msg": "成功",
  //     "data": {
  //         "headUrl": "http://image.hhdd.com/user/systemHead/0/2/0/geometry1.png",
  //         "nick": "小读者",
  //         "ageType": 2,
  //         "joinVip": 1688362677000
  //     },
  //     "code": 200
  // }
    return res
  } catch (error) {
    console.error('getUserInfo fetch Error::', error)
  }
}

/**
 * 获取用户id用于打点
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 */
export async function getUserId(userIdStr: string) {
  const api = getApi('openApi', `report/getUserId.json?userIdStr=${userIdStr}`)
  let res: ServerResponse<number> = null
  try {
    res = await fetch.get(api)
    // res = {"msg":"成功","data":60061419,"code":200}
    return res.data
  } catch (error) {
    console.error('getUserId fetch Error::', error)
    throw error
  }
}

