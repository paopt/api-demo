import { getApi, fetch } from '@/lib/fetch'
import { deviceInfo } from "@kada/library/src/device"

export interface IUser {
  headUrl: string;
  nick: string;
  ageType: number;
  joinVip: number;
  isSvip: number;
  isVip: number;
  totalMonth: number;
  remainDays: number;
  endTime: number;
  [propName: string]: any;
}

/**
 * 获取用户信息
 * @param userIdStr 用户id，浏览器访问，使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getUserInfo (userIdStr: string) {
  let url = 'report/getUserInfo.json'
  if (!deviceInfo.isKadaClient && userIdStr) {
    url += `?userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)
  let res: ServerResponse<IUser> = null
  try {
    res = await fetch.get(api)
    return res
  } catch (error) {
    console.error('getUserInfo fetch Error::', error)
  }
}

/**
 * 获取用户信息
 * @param userIdStr 用户id，浏览器访问，使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getUserInfo2 (userIdStr: string) {
  let url = 'reportActivity/getUserInfo.json'
  if (!deviceInfo.isKadaClient && userIdStr) {
    url += `?userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)
  let res: ServerResponse<IUser> = null
  try {
    res = await fetch.get(api)
    return res
  } catch (error) {
    console.error('getUserInfo fetch Error::', error)
  }
}

/**
 * 获取用户id用于打点
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 */
export async function getUserId(userIdStr: string) {
  const api = getApi('openApi', `report/getUserId.json?userIdStr=${userIdStr}`)
  let res: ServerResponse<number> = null
  try {
    res = await fetch.get(api)
    return res.data
  } catch (error) {
    console.error('getUserId fetch Error::', error)
    throw error
  }
}

