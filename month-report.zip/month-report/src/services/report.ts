// @ts-nocheck

import { getApi, fetch } from '@/lib/fetch'
import { toast } from '@kada/svelte-activity-ui'
import { deviceInfo } from "@kada/library/src/device"

export interface ITotalInfo {
  current?: ITotalInfoItem; // 当前月数据
  items: ITotalInfoItem[];
  provinceRank: number; // 省排行
  lastRank: number; // 上月排行
  province: string; // 省份
  wholeRank: number; // 全国排名
  wholeNumber: number; // 全国人数
  [propName: string]: any
}

export interface ITotalInfoItem {
  readDays: number; // 总阅读天数
  readWords: number; //总阅读字数
  readNum: number; // 总阅读本数
  yearMonth: string; // 阅读日期
  [propName: string]: any
}

export interface ITrendItem {
  totalTime: number; // 总阅读时长(单位：秒)
  bookReadTime: number; // 绘本阅读时长(单位：秒)
  courseReadTime: number; // 课程阅读时长(单位：秒)
  storyReadTime: number; // 听书合辑阅读时长(单位：秒)
  comicReadTime: number; //漫画阅读时长(单位：秒)
  ebookReadTime: number; //电子书阅读时长(单位：秒)
  yearMonth: string; // 日期
  lastMonthTotalTime: number; // 总阅读时长，环比上月(单位：秒)
  [propName: string]: any
}

export interface IFavoriteInfo {
  items: IFavoriteItem[];
  categoryNames: string[];
}

export interface IFavoriteItem {
  sourceId: number;
  sourceType: number;
  name: string;
  imgUrl: string;
  readTimes: number;
  readTime: number;
  categoryNames: string[];
  [propName: string]: any
}

export interface IRecommendInfo {
  title: string; // 阅读推荐标题
  items: IRecommendItem[]
}

export interface IRecommendItem {
  sourceId: number;
  sourceType: number;
  name: string;
  imgUrl: string;
  categoryNames: string[];
  readTimes: number;
  score: string;
  subNum: number;
  [propName: string]: any
}

export interface ITotalHistory {
  readDays: number; // 总阅读天数
  readWords: number; // 总阅读字数
  readNum: number; // 总阅读本数
  totalTime: number; // 总阅读时间（秒）
  joinVip: number; // 加入svip时间戳
  [propName: string]: any
}

/**
 * 本月阅读总数据
 * @param yearMonth 查询日期
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getTotalInfo(yearMonth: string, userIdStr: string) {
  let url = `report/getTotalInfo.json?yearMonth=${yearMonth}`
  if (!deviceInfo.isKadaClient && userIdStr) {
    url += `&userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)

  let res: ServerResponse<ITotalInfo> = null
  try {
    res = await fetch.get(api);
    return res.data;
  } catch (err) {
    console.error('getTotalInfo Error: ', err)
  }
}

/**
 * 阅读趋势
 * @param yearMonth 查询日期
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getTrendInfo(yearMonth: string, userIdStr: string) {
  let url = `report/getTrendInfo.json?yearMonth=${yearMonth}`
  if (!deviceInfo.isKadaClient && userIdStr) {
    url += `&userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)

  let res: ServerResponse<ITrendItem[]> = null
  try {
    res = await fetch.get(api);
    return res.data;
  } catch (err) {
    console.error('getTotalInfo Error: ', err)
  }
}

/**
 * 本月最爱阅读
 * @param yearMonth 查询日期
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getFavoriteInfo(yearMonth: string, userIdStr: string) {
  let url = `report/getFavoriteInfo.json?yearMonth=${yearMonth}`
  if (!deviceInfo.isKadaClient && userIdStr) {
    url += `&userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url);

  let res: ServerResponse<IFavoriteInfo> = null
  try {
    res = await fetch.get(api);
    return res.data;
  } catch (err) {
    console.error('getTotalInfo Error: ', err)
  }
}

/**
 * 阅读推荐
 * @param yearMonth 查询日期
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getRecommendInfo(yearMonth: string, userIdStr: string) {
  let url = `report/getRecommend.json?yearMonth=${yearMonth}`
  if (!deviceInfo.isKadaClient && userIdStr) {
    url += `&userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)

  let res: ServerResponse<IRecommendInfo> = null
  try {
    res = await fetch.get(api);
    return res.data;
  } catch (err) {
    console.error('getRecommend Error: ', err)
  }
}


/**
 * 一键加入书架
 * @param sourceList 加入书架资源列表json字符串
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 */
export async function saveBookShelf(sourceList: string, userIdStr: string) {
  let url = `report/saveBookShelf.json?sourceList=${encodeURI(sourceList)}`
  if (!deviceInfo.isKadaClient && userIdStr) {
    url += `&userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)

  let res: ServerResponse<IRecommendInfo> = null
  try {
    res = await fetch.get(api)
    if (res.code === 200) {
      toast('添加成功')
    }
  } catch (error) {
    toast('添加失败')
    console.error('saveBookShelf err: ', error)
  }
}

/**
 * 查看历史累计
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 * @returns 
 */
export async function getTotalHistory(userIdStr: string) {
  let url = `report/getTotalHistory.json`;
  if (!deviceInfo.isKadaClient && userIdStr) {
    url += `?userIdStr=${userIdStr}`
  }
  const api = getApi('openApi', url)

  let res: ServerResponse<ITotalHistory> = null
  try {
    res = await fetch.get(api)
    return res.data
  } catch (error) {
    console.error('saveBookShelf err: ', error)
    throw error
  }
}

/**
 * 获取用户id用于打点
 * @param userIdStr 用户id加密字符串，浏览器访问使用userIdStr识别用户；客户端使用cookie
 */
export async function getUserId(userIdStr: string) {
  const api = getApi('openApi', `report/getUserId.json?userIdStr=${userIdStr}`)
  let res: ServerResponse<number> = null
  try {
    res = await fetch.get(api)
    return res.data
  } catch (error) {
    console.error('saveBookShelf err: ', error)
    throw error
  }
}

