export type AgeType = {
  [propName: string]: {
    label: string;
    target: number;
    max?: number;
    maxLabel?: string;
    maxPercent?: string;
  }
}

/**
 * 不同年龄段对应的阅读目标
 */
export let ageTypeMap: AgeType = {
  1: {
    label: '0~1岁',
    target: 5
  },
  2: {
    label: '2岁',
    target: 10
  },
  3: {
    label: '3岁',
    target: 15
  },
  4: {
    label: '小班',
    target: 20
  },
  5: {
    label: '中班',
    target: 20
  },
  6: {
    label: '大班',
    target: 20
  },
  7: {
    label: '一年级',
    target: 4000,
    max: 30000,
    maxLabel: '30000+',
    maxPercent: '500%'
  },
  8: {
    label: '二年级',
    target: 4000,
    max: 30000,
    maxLabel: '30000+',
    maxPercent: '500%'
  },
  9: {
    label: '三年级',
    target: 30000,
    max: 80000,
    maxLabel: '80000+',
    maxPercent: '260%'
  },
  10: {
    label: '四年级',
    target: 30000,
    max: 80000,
    maxLabel: '80000+',
    maxPercent: '260%'
  },
  11: {
    label: '五年级',
    target: 80000,
    max: 160000,
    maxLabel: '80000+',
    maxPercent: '完成目标260%'
  },
  12: {
    label: '六年级',
    target: 80000,
    max: 160000,
    maxLabel: '160000+',
    maxPercent: '完成目标260%'
  },
  13: {
    label: '初一',
    target: 80000,
    max: 160000,
    maxLabel: '160000+',
    maxPercent: '完成目标200%'
  },
  14: {
    label: '初二',
    target: 80000,
    max: 160000,
    maxLabel: '160000+',
    maxPercent: '完成目标200%'
  },
  15: {
    label: '初三及以上',
    target: 80000,
    max: 160000,
    maxLabel: '160000+',
    maxPercent: '完成目标200%'
  }
}

/**
 * 根据百分比转换为对应的星星
 * @param percent 百分比
 */
export function convertToStars(percent: number) {
  let img1 = "//cdn.hhdd.com/frontend/as/i/2fcd5b10-3167-565c-8d7d-b57fdbd1ee04.png";
  let img2 = "//cdn.hhdd.com/frontend/as/i/762cf2a1-800b-58bb-9505-93d007c629df.png";
  let img3 = "//cdn.hhdd.com/frontend/as/i/598e1252-c104-5fab-ae87-03e10497d1e1.png";
  let stars = [img1, img1, img1, img1, img1];
  let starNum = 0;
  if (percent > 0 && percent < 0.2) {
    starNum = 0.5;
    stars = [img2, img1, img1, img1, img1];
  } else if (percent >= 0.2 && percent < 0.3) {
    starNum = 1;
    stars = [img3, img1, img1, img1, img1];
  } else if (percent >= 0.3 && percent < 0.4) {
    starNum = 1.5;
    stars = [img3, img2, img1, img1, img1];
  } else if (percent >= 0.4 && percent < 0.5) {
    starNum = 2;
    stars = [img3, img3, img1, img1, img1];
  } else if (percent >= 0.5 && percent < 0.6) {
    starNum = 2.5;
    stars = [img3, img3, img2, img1, img1];
  } else if (percent >= 0.6 && percent < 0.7) {
    starNum = 3;
    stars = [img3, img3, img3, img1, img1];
  } else if (percent >= 0.7 && percent < 0.8) {
    starNum = 3.5;
    stars = [img3, img3, img3, img2, img1];
  } else if (percent >= 0.8 && percent < 0.9) {
    starNum = 4;
    stars = [img3, img3, img3, img3, img1];
  } else if (percent >= 0.9 && percent < 1.0) {
    starNum = 4.5;
    stars = [img3, img3, img3, img3, img2];
  } else if (percent >= 1) {
    starNum = 1;
    stars = [img3, img3, img3, img3, img3];
  }
  return stars
}

//默认关键字
// 小于7岁
const smallWords = ['识字启蒙', '经典国学', '习惯养成', '情绪管理', '情商培养', '安全知识']
// 大于7岁
const bigWords = ['传统国学', '经典名著', '校园文学', '名人传记', '逻辑推理', '阅读写作']
/**
 * 默认显示六个关键字，数量不够使用默认关键字
 * @param ageType 年龄
 * @param words 关键字
 */
export function getKeywords(ageType, words) {
  const defaultWords = ageType < 7 ? smallWords : bigWords
  return Array.from(new Set([...words, ...defaultWords])).slice(0, 6)
}

/**
 * 时间戳转化为小时、分钟
 * @param time 秒
 */
export function parseTime(time: number) {
  const minutes = Math.ceil(time / 60)
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  return {
    h,
    m,
  };
}

/**
 * 返回月份
 * @param date 日期字符串
 * @returns 
 */
export function getMonth(date: string | number) {
  const d = new Date(date)
  return d.getMonth() + 1
}

/**
 * 格式化数量：超过万显示万
 * @param val 
 * @param needInteger 是否返回整数
 * @returns 
 */
export function formateNum(val, needInteger) {
  val = Number(val)
  if (val < 10000) {
    return val
  } else {
    if (needInteger) {
      const count = Math.ceil(val / 10000)
      return count + '万+'
    } else {
      const count = (val / 10000).toFixed(2)
      return count + '万'
    }
  }
}

export function formateReportDate(yearMonth: string) {
  const now = new Date()
  const d  = new Date(yearMonth)

  const month = d.getMonth() + 1
  const year = d.getFullYear()

  if (now.getFullYear() === year) {
    return `${month}月`
  } else {
    return `${year}年${month}月`
  }
}

