import type { ITotalInfoItem, ITrendItem } from "./report";
import type { IUser } from "./user";

export type AgeType = {
  [propName: string]: {
    label: string;
    target: number;
    max?: number;
    maxLabel?: string;
    maxPercent?: string;
  }
}

// 不同年龄段对应的阅读目标
export let ageTypeMap: AgeType = {
  1: {
    label: '0~1岁',
    target: 5
  },
  2: {
    label: '2岁',
    target: 10
  },
  3: {
    label: '3岁',
    target: 15
  },
  4: {
    label: '小班',
    target: 20
  },
  5: {
    label: '中班',
    target: 20
  },
  6: {
    label: '大班',
    target: 20
  },
  7: {
    label: '一年级',
    target: 4000,
    max: 30000,
    maxLabel: '30000+',
    maxPercent: '500%'
  },
  8: {
    label: '二年级',
    target: 4000,
    max: 30000,
    maxLabel: '30000+',
    maxPercent: '500%'
  },
  9: {
    label: '三年级',
    target: 30000,
    max: 80000,
    maxLabel: '80000+',
    maxPercent: '260%'
  },
  10: {
    label: '四年级',
    target: 30000,
    max: 80000,
    maxLabel: '80000+',
    maxPercent: '260%'
  },
  11: {
    label: '五年级',
    target: 80000,
    max: 160000,
    maxLabel: '80000+',
    maxPercent: '完成目标260%'
  },
  12: {
    label: '六年级',
    target: 80000,
    max: 160000,
    maxLabel: '160000+',
    maxPercent: '完成目标260%'
  },
  13: {
    label: '初一',
    target: 80000,
    max: 160000,
    maxLabel: '160000+',
    maxPercent: '完成目标200%'
  },
  14: {
    label: '初二',
    target: 80000,
    max: 160000,
    maxLabel: '160000+',
    maxPercent: '完成目标200%'
  },
  15: {
    label: '初三及以上',
    target: 80000,
    max: 160000,
    maxLabel: '160000+',
    maxPercent: '完成目标200%'
  }
}
