import { getApi, fetch } from '@/lib/fetch'
import config from '@/lib/config'

const { loginType } = config.wechat

/**
 * 获取签名数据
 * @param {String} url 当前网页的URL，不包含hash部分
 * @see http://note.youdao.com/noteshare?id=a8db729f722c9879a81f5e063d018417&sub=ED166E6A07644FEC8A062F72443940C4
 */
export function getWechatConfig (url: string): Promise<ServerResponse<any>> {
  if (!url) {
    throw Error('请求参数[url]不存在！')
  }
  const params = {
    url,
    loginType
  }

  return fetch.post(getApi('partner', 'js/ticket/wechat.json'), params)
}
