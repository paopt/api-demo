<div class="report">
  feedback
</div>

<script lang="ts">
 
</script>

<style lang="scss" scoped>
  @import "../styles/variables";
  @import "../styles/mixins";
</style>