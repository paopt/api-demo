<div class="feedback">
  <div class="feedback__header">
    {#if !deviceInfo.isKadaClient && $router.query.from}
      <img class="back" src="{backIcon}" alt="" on:click={onBack}>
    {:else}
      <span class="back"></span>
    {/if}
    <span class="title">反馈</span>
    <span class="back"></span>
  </div>
  <div class="feedback__content">
    <div class="form-row reason">
      <div class="form-row__label">
        <img class="icon" src="//cdn.hhdd.com/frontend/as/i/4a4519d6-1843-5052-a677-ac3046c6ed32.png" alt="">
        <span>反馈意见</span>
      </div>
      <div class="form-row__content">
        <textarea class="textarea" placeholder="{model.reason.placeholder}" bind:value={model.reason.value}></textarea>
      </div>
    </div>
    <div class="form-row phone">
      <div class="form-row__label">
        <img class="icon" src="//cdn.hhdd.com/frontend/as/i/4a4519d6-1843-5052-a677-ac3046c6ed32.png" alt="">
        <span>手机号码</span>
      </div>
      <div class="form-row__content">
        <input class="input" type="text" placeholder="{model.phone.placeholder}" bind:value={model.phone.value}>
      </div>
    </div>
  </div>
  <div class="feedback__footer">
    <div class="btn {model.reason.value ? '' : 'disabled'}" on:click={save}>反馈</div>
  </div>
</div>

<script lang="ts">
    import { deviceInfo } from "@kada/library/src/device";
  import { debounce } from "@/utils/throttle";
  import { toast } from "@kada/svelte-activity-ui"
  import { saveFeedback } from '@/services/report'
  import { userIdStr } from '@/app'
  import { router, navigateTo } from '@kada/yrv'

  let model = {
    reason: {
      placeholder: '请详细描述反馈理由（不少于10字）',
      value: ''
    },
    phone: {
      placeholder: '请输入手机号方便于联系（非必填）',
      value: ''
    }
  }

  let backIcon = deviceInfo.isPad ? '//cdn.hhdd.com/frontend/as/i/51c01641-5d13-5702-b5e4-ca5a590791fe.png'
    : '//cdn.hhdd.com/frontend/as/i/79996cd2-f062-5195-9f6b-827cda649c47.png'

  const save = debounce(() => {
    const { reason, phone} = model
    // 反馈理由必填
    if (!reason.value) {
      // @ts-nocheck
      toast('请填写反馈意见')
      return
    }

    // 校验手机号码
    if (phone.value) {
      if (!validatePhone(phone.value)) {
        toast('请输入合法的手机号码')
        return
      }
    }

    saveFeedback(userIdStr, phone.value, reason.value).then(res => {
      toast('反馈成功，我们会认真处理您的反馈')
    }).catch(err => {
      toast(err.message)
    })
  }, 1000, true)

  /**
   * 校验手机格式
   * @param number
   */
  function validatePhone(number: string): boolean {
    return /^1(3[0-9]|4[01456879]|5[0-35-9]|6[2567]|7[0-8]|8[0-9]|9[0-35-9])\d{8}$/.test(number);
  }

  function onBack() {
    const path = $router.query.from ? '/' + $router.query.from : '/summary'
    const params = {...$router.query}
    Reflect.deleteProperty(params, 'from')
    navigateTo(path, {
      queryParams: params
    })
  }

</script>

<style lang="scss" scoped>
  @import "../styles/variables";
  @import "../styles/mixins";

  .feedback {
    display: flex;
    flex-direction: column;
    height: 100vh;
    padding-bottom: 1.14rem;

    @media #{$pad_landscape_query} {
      padding-bottom: 0.72rem;
    }
    &__header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 0.88rem;
      padding: 0 0.16rem;
      background: #FFFFFF;
      box-shadow: inset 0 -0.01rem 0 0 #E7E7E7;
      text-align: center;
      @media #{$pad_landscape_query} {
        height: 1.36rem;
        padding: 0 0.26rem;
        border-radius: 0.04rem;
      }

      .back {
        width: 0.72rem;
        height: 0.72rem;

        @media #{$pad_landscape_query} {
          width: 0.96rem;
          height: 0.96rem;
        }
      }
      .title {
        font-size: 0.36rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #3F3F3F;
        line-height: 0.4rem;

        @media #{$pad_landscape_query} {
          font-size: 0.44rem;
          line-height: 0.52rem;
        }
      }
    }
    &__content {
      flex: 1;
      padding: 0 0.4rem;

      @media #{$pad_landscape_query} {
        padding: 0 6.56rem;
      }
    }
    &__footer {
      padding: 0 0.4rem;
      @media #{$pad_landscape_query} {
        padding: 0 6.56rem;
      }
    }
  }

  .btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 0.96rem;
    background: #3398FF;
    border-radius: 0.49rem;
    font-size: 0.32rem;
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #FFFFFF;
    line-height: 0.36rem;

    @media #{$pad_landscape_query} {
      height: 1.12rem;
      border-radius: 0.54rem;
      font-size: 0.36rem;
    }

    &.disabled {
      opacity: 0.5;
    }
  }

  .form-row {
    margin-top: 0.56rem;
    &.reason {
      @media #{$pad_landscape_query} {
        margin-top: 0.32rem;
      }
    }
    &.phone {
      @media #{$pad_landscape_query} {
        margin-top: 0.64rem;
      }
    }
    &__label {
      display: flex;
      align-items: center;
      font-size: 0.32rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #333333;
      line-height: 0.36rem;

      @media #{$pad_landscape_query} {
        font-size: 0.36rem;
        line-height: 0.42rem;
      }

      .icon {
        width: 0.32rem;
        height: 0.28rem;
        margin-right: 0.12rem;

        @media #{$pad_landscape_query} {
          width: 0.36rem;
          height: 0.32rem;
          margin-right: 0.12rem;
        }
      }
    }
    &__content {
      .textarea {
        width: 100%;
        height: 3rem;
        margin-top: 0.4rem;
        padding: 0.24rem;
        border-radius: 0.16rem;
        border: 0.02rem solid #D7D7D7;
        font-size: 0.28rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.34rem;
        outline: none;

        @media #{$pad_landscape_query} {
          height: 3.3rem;
          font-size: 0.31rem;
          border-radius: 0.18rem;
        }

        
        &::placeholder {
          font-size: 0.28rem;
          font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
          font-weight: normal;
          color: rgba(0,0,0,0.2);
          line-height: 0.34rem;

          @media #{$pad_landscape_query} {
              font-size: 0.31rem;
              line-height: 0.36rem;
          }
        }
      }
      .input {
        width: 100%;
        height: 0.96rem;
        margin-top: 0.24rem;
        padding: 0.32rem 0.4rem 0.3rem 0.4rem;
        border-radius: 0.16rem;
        border: 0.02rem solid #D7D7D7;
        font-size: 0.28rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.34rem;
        outline: none;

        @media #{$pad_landscape_query} {
          height: 1.04rem;
          border-radius: 0.18rem;
          font-size: 0.32rem;
        }

        &::placeholder {
          font-size: 0.28rem;
          font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
          font-weight: normal;
          color: rgba(0,0,0,0.2);
          line-height: 0.34rem;

          @media #{$pad_landscape_query} {
            font-size: 0.32rem;
          }
        }
      }
    }
  }
</style>