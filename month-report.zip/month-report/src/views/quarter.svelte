<div class="container">
  {#if !showPage}
    <div class="guide-page">
      <img class="img1" src="//cdn.hhdd.com/frontend/as/i/a00fed7f-c592-5d6e-96c8-537104bc404b.png" alt="">
      <img class="img2" src="//cdn.hhdd.com/frontend/as/i/bd4e721f-8916-51e2-a203-f99bb1f7e535.png" alt="">
      <div class="guide-page__header">
        <img class="logo" src="//cdn.hhdd.com/frontend/as/i/1531b574-a87c-59a2-b861-e5e3815eb0ff.png" alt="">
        <div class="nick">@{userInfo.nick}</div>
        <img class="title" src="//cdn.hhdd.com/frontend/as/i/7c366fa4-ccd1-5e98-888e-0ff85f4031b8.png" alt="">
      </div>
      <div class="guide-page__footer">
        <div class="btn-wrapper" on:click={handleView}>
          <div class="btn">立即查看本季度表现</div>
        </div>
        <div class="input" on:click={handleProtol}>
          <img class="input__icon" src="{selected ? SELECTED_ICON : NO_SELECTED_ICON}" alt="">
          <span class="input__label">勾选同意KaDa阅读获取《数据协议》</span>
        </div>
      </div>
      <!-- <img class="img1" src="//cdn.hhdd.com/frontend/as/i/fe4cfeb5-73de-5cca-a304-76afd9a5f67e.png" alt="">
      <img class="img2" src="//cdn.hhdd.com/frontend/as/i/4ff75fc4-9ab9-52a3-b033-700b02aace23.png" alt="">
      <img class="img3" src="//cdn.hhdd.com/frontend/as/i/7cee9824-19ec-57d2-967a-ad0e178b6d57.png" alt="">
      <img class="img4" src="//cdn.hhdd.com/frontend/as/i/d063ca54-05be-5b59-9732-78b7888ef516.png" alt="">
      <img class="img5" src="//cdn.hhdd.com/frontend/as/i/2d79523a-ce17-599f-b5f3-7984dced5cf8.png" alt="">
      <img class="img6" src="//cdn.hhdd.com/frontend/as/i/9a4b0753-fead-53ce-be23-95d7970e3618.png" alt=""> -->
    </div>
  {/if}
  <div class="pages-wrap" style={`display: ${showPage ? 'block' : 'none'}`}>
    <div class="pages-up">
      <img class="pages-up__icon" src="//cdn.hhdd.com/frontend/as/i/57037b11-4dda-5a70-b1b6-acaccd6974a5.png" alt="">
      {#if page === 0}
        <span class="pages-up__label">上滑继续查看</span>
      {/if}
    </div>
    <div class="pages" id="pages">
      <div class="page pages__1">
        <div class="info1">
          <div>
            <span class="nick">{userInfo.nick}</span>
            <span class="label">小朋友</span>
          </div>
          <div class="label">{userInfo.joinVipDate}</div>
          <div class="label">你成为KaDa阅读的会员</div>
          <div class="label">不知不觉，我们已互相陪伴{userInfo.totalMonth}个月</div>
        </div>
        <div class="info2">
          <div class="label">人生有很多很多“{userInfo.totalMonth}个月”</div>
          <div class="label">这特别的“{userInfo.totalMonth}个月”</div>
          <div class="label">你在书的世界中度过</div>
          <div class="label">看看你的表现吧</div>
        </div>
        <img class="img1" src="//cdn.hhdd.com/frontend/as/i/2c0f678a-334f-59f1-a876-75eed1a1732f.png" alt="">
        <img class="img2" src="//cdn.hhdd.com/frontend/as/i/101c0af4-ab40-5138-8ecb-ba9785adeebf.png" alt="">
        <!-- <img class="img1" src="//cdn.hhdd.com/frontend/as/i/e24415c5-f58c-58df-8212-6c56e02baf48.png" alt="">
        <img class="img2" src="//cdn.hhdd.com/frontend/as/i/ede4e784-31e6-5f87-983c-6433925b210a.png" alt="">
        <img class="img3" src="//cdn.hhdd.com/frontend/as/i/ba0dfc94-dd87-5a19-8fea-3e3928010e90.png" alt="">
        <img class="img4" src="//cdn.hhdd.com/frontend/as/i/a2521450-8324-5fb8-b950-50f087338958.png" alt="">
        <img class="img5" src="//cdn.hhdd.com/frontend/as/i/9de6d1d6-23eb-5768-88bb-85530bd4d990.png" alt=""> -->
      </div>
      <div class="page pages__2">
        <img class="img1" src="//cdn.hhdd.com/frontend/as/i/cd2bb1da-0d98-5b58-bf79-0ebe2033eb78.png" alt="">
        <img class="img2" src="//cdn.hhdd.com/frontend/as/i/dbbc5f55-3423-5f6d-8057-32ce02fefe95.png" alt="">
        <div class="info1">
          <div>
            <span class="label">你一共坚持阅读</span>
            <span class="number">{readInfo.readDays}</span>
            <span class="label">天</span>
          </div>
          <div>
            <span class="label">读完了</span>
            {#if userInfo.ageType < 7}
              <span class="number">{readInfo.readNum}</span>
              <span class="label">本书</span>
            {:else}
              <span class="number">{readInfo.readNum}</span>
              <span class="label">本书，共</span>
              <span class="number">{readInfo.computeReadWords}</span>
              <span class="label">字</span>
            {/if}
          </div>
          <div>
            <span class="label">总价值超</span>
            <span class="number">{readInfo.price}</span>
            <span class="label">元</span>
          </div>
        </div>
        <div class="info2">
          <div class="label">原来坚持阅读</div>
          <div class="label">可以为爸爸妈妈省下这么多购书费呀</div>
        </div>
      </div>
      <div class="page pages__3">
        <div class="info1">
          <div class="label">你读过的书</div>
          <div class="label">遍布各个领域</div>
          <div class="label">读的最多的是</div>
          <div>
            <span class="category">{maxCategory}类</span>
            <span class="label">书籍</span>
          </div>
          <div class="label">是该领域名副其实的小专家</div>
        </div>
        <div class="chart">
          <div class="circle"></div>
          <canvas id="pie"></canvas>
        </div>
        <img class="img1" src="//cdn.hhdd.com/frontend/as/i/7d9e48bc-c9ee-5f13-89ea-eb9d3b44b9fa.png" alt="">
        <img class="img2" src="//cdn.hhdd.com/frontend/as/i/917ee345-39f6-50a4-b0d4-91a0907d29ac.png" alt="">
        <img class="img3" src="//cdn.hhdd.com/frontend/as/i/de5f1046-e2fa-5ce0-a81c-ec7b025d95cf.png" alt="">
      </div>
      <div class="page pages__4">
        <img class="img1" src="//cdn.hhdd.com/frontend/as/i/87ce1f37-7b8a-544f-870e-d1ee861d5222.png" alt="">
        <div class="info1">
          <div class="label">截止昨天</div>
          <div class="label">你的总阅读量</div>
          <div>
            <span class="label">在</span>
            <span class="province">{rankInfo.provinceAndAge}</span>
            <span class="label">小朋友中</span>
          </div>
          <div>
            <span class="label">已达第</span>
            <span class="number">{rankInfo.provinceRank}</span>
            <span class="label">名 (共{rankInfo.provinceNumber}人在使用)</span>
          </div>
        </div>
        <!-- <img class="img1" src="//cdn.hhdd.com/frontend/as/i/59116347-293d-578e-97f5-998aa723d3f2.png" alt="">
        <img class="img2" src="//cdn.hhdd.com/frontend/as/i/998e289b-3ed8-5cfe-8801-ea5eb302699e.png" alt="">
        <img class="img3" src="//cdn.hhdd.com/frontend/as/i/6082fcb0-51ab-571e-8a0b-a54b18e1759b.png" alt=""> -->
      </div>
      <div class="page pages__5">
        <img class="img1" src="//cdn.hhdd.com/frontend/as/i/c0ebb59a-cd00-5c5d-8110-3488c911f1b5.png" alt="">
        <div class="info1">
          {#if userInfo.remainDays < 0}
            <div class="label">你的会员已过期</div>
          {:else}
            <div>
              <span class="label">你的会员{userInfo.remainDays > 3 ? '剩' : '仅剩最后'}</span>
              <span class="number">{userInfo.remainDays + 1}</span>
              <span class="label">天</span>
            </div>
          {/if}
          <div class="label">小小成长礼盒</div>
          <div class="label">纪念{userInfo.totalMonth}个月来你的阅读坚持</div>
          <div class="label">期待今后每一天共同成长</div>
        </div>
        <div class="info2">礼盒内含宝贝的阅读荣誉奖状、荣誉勋章和精美日历</div>
        <!-- <img class="img1" src="//cdn.hhdd.com/frontend/as/i/af326d06-1096-58d7-a2ab-e7ab484fd372.png" alt="">
        <img class="img2" src="//cdn.hhdd.com/frontend/as/i/695f1d1c-0a4d-5b83-aa09-43f8dda256c9.png" alt="">
        <img class="img3" src="//cdn.hhdd.com/frontend/as/i/7050334c-9b62-56f2-a33a-031d00ce58d2.png?x-oss-process=image/quality,q_80" alt=""> -->
      </div>
    </div>
  </div>
  {#if showPage}
    <div class="receive-btn" on:click={handleGift}>
      <img src="//cdn.hhdd.com/frontend/as/i/8dbde811-7ea4-54a8-8471-e7954c81abbd.png" alt="">
    </div>
  {/if}
</div>

<script lang="ts">
  import { onMount } from 'svelte'
  import { router, navigateTo } from '@kada/yrv'
  import { formatDate } from "@kada/library/utils/datetime";
  import { date, channelId, userIdStr, userInfo, openApp, userId} from '../app'
  import { getReadInfo, getRankInfo, getCode, IReadInfo, IRankInfo, getCategoryInfo, ICategoryInfo } from '@/services/report'
  import { ageTypeMap, getCategoryArr } from '@/services/read'
  import { Carousel } from '@/utils/carousel'
  import { showDialog as showRedeemCodeDialog } from "@/components/RedeemCodeDialog";
  import {PieChart} from '@/utils/pie'
  import { toast } from '@kada/svelte-activity-ui'
  import { sendReportBehavior } from '@/lib/analytics'

  // 图片
  let SELECTED_ICON = '//cdn.hhdd.com/frontend/as/i/ef434a47-3766-5950-937a-5f966c3cac04.png'
  let NO_SELECTED_ICON = '//cdn.hhdd.com/frontend/as/i/35178e14-f928-571b-a5d8-e769b5b0d4a4.png'

  // 是否显示内容页
  let showPage = false
  // 当前页
  let page = 0
  // 是否勾选同意
  let selected = true

  let readInfo: IReadInfo = {} as any
  let rankInfo: IRankInfo = {} as any
  let categoryArr: ICategoryInfo[] = []
  // 阅读频率最高的关键字
  let maxCategory = ''

  init()

  onMount(() => {
    initCarousel()
    sendReportBehavior('pgv_100203', {
      type: 1,
      channelId: channelId
    }, null, false)
  })

  function init() {
    getPageData()
  }

  /**
   * 初始化滑屏分页逻辑
   */
  function initCarousel() {
    const ele: HTMLElement = document.querySelector('#pages')
    new Carousel({
      ele,
      callback: (num) => {
        page = num
        send()
        if (page === 2) {
          new PieChart({
            id: 'pie',
            width: 359,
            height: 244,
            data: categoryArr,
          })
        }
        console.log('当前页', num)
      }
    })
  }

  /**
   * 页面打点
   */
  function send() {
    sendReportBehavior('pgv_100203', {
      page: page + 2,
      channelId: channelId
    }, null, false)
  }

  /**
   * 点击查看按钮
   */
  function handleView() {
    sendReportBehavior('ac_100203', {
      type: 1,
      channelId: channelId
    }, null, false)

    send()
    if (!selected) {
      toast({
        text: '请先勾选同意'
      })
      return
    }
    showPage = true
  }

  /**
   * 勾选协议
   */
  function handleProtol() {
    selected = !selected
  }

  /**
   * 点击领取礼物按钮
   */
  function handleGift() {
    sendReportBehavior('ac_100203', {
      page: page + 2,
      channelId: channelId
    }, null, false)
    showRedeemCodeDialog()
  }

  /**
   * 查询阅读数据
   */
  async function getPageData() {
    [readInfo, rankInfo, categoryArr] = await Promise.all([getReadInfo(userIdStr), getRankInfo(userIdStr), getCategoryInfo(userIdStr)])
    console.log(readInfo, rankInfo, categoryArr)
    // 用户信息处理
    if (userInfo) {
      userInfo.joinVipDate = formatDate(userInfo.joinVip, 'YYYY年M月D日')
    }
    // 排行信息处理
    if (rankInfo && userInfo) {
      rankInfo.provinceAndAge = rankInfo.province + ageTypeMap[userInfo.ageType].label
    }
    // 阅读信息处理
    if (readInfo && userInfo) {
      readInfo.price = readInfo.readNum * 20
      readInfo.computeReadWords = formateNum(readInfo.readWords)
      if (userInfo.ageType < 7) {
        readInfo.value = readInfo.readNum
        readInfo.unit = '本书'
      } else {
        readInfo.value = readInfo.readWords
        readInfo.unit = '字'
      }
    }
    // 分类信息处理
    categoryArr = categoryArr || []
    if (categoryArr.length > 0) {
      categoryArr.sort((a, b) => a.count - b.count)
      maxCategory = categoryArr[categoryArr.length - 1].categoryName
      categoryArr = getCategoryArr(userInfo.ageType, categoryArr)
    } else {
      categoryArr = getCategoryArr(userInfo.ageType, categoryArr)
      categoryArr.sort((a, b) => a.count - b.count)
      maxCategory = categoryArr[categoryArr.length - 1].categoryName
    }

    new PieChart({
      id: 'pie',
      width: 359,
      height: 244,
      data: categoryArr,
    })
  }

  /**
   * 阅读字数格式化
   * @param val
   */
  function formateNum(val) {
    val = Number(val)
    if (val < 10000) {
      return val
    } else if (val < 1000000) {
      const count = (val / 10000).toFixed(1)
      return count + '万'
    } else {
      return '100万'
    }
  }
</script>

<style lang="scss" scoped>
  @import "../styles/variables";
  @import "../styles/mixins";

  .receive-btn {
    position: absolute;
    bottom: 4.8vh;
    width: 100%;
    height: 1.47rem;
    text-align: center;
    img {
      width: 6.86rem;
    }
  }

  .container {
    position: relative;
    width: 100%;
  }

  .guide-page {
    position: absolute;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    width: 100%;
    height: 100vh;
    background-image: url(//cdn.hhdd.com/frontend/as/i/29c68388-4d8e-571a-80d8-59fa9fec6d8c.png);
    background-repeat: no-repeat;
    overflow: hidden;
    z-index: 2;
    
    &__header {
      text-align: center;
      .logo {
        width: 2.26rem;
        height: 0.46rem;
        margin-top: 1.14rem;
      }
      .nick {
        margin-top: 0.82rem;
        font-size: 0.52rem;
        font-family: alibaba;
        color: #507AFD;
        line-height: 0.74rem;
        letter-spacing: 0.01rem;
      }
      .title {
        width: 5.88rem;
        height: 0.88rem;
        margin-top: 0.32rem;
      }
    }
    &__footer {
      position: absolute;
      top: 76.7vh;
      width: 100%;
      z-index: 2;
      // padding-bottom: 10.3vh;
      text-align: center;
      .btn-wrapper {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 6.08rem;
        height: 1.44rem;
        background: rgba(255,255,255,0.5);
        border-radius: 0.72rem;
      }
      .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 5.82rem;
        height: 1.2rem;
        background: linear-gradient(84deg, #FF5E02 0%, #FE3001 100%);
        border-radius: 0.72rem;
        font-size: 0.48rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #FFFFFF;
      }
      .input {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-top: 4vh;
        &__icon {
          width: 18px;
          height: 18px;
          height: 0.36rem;
          margin-right: 0.2rem;
        }
        &__label {
          font-size: 0.24rem;
          font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.24rem;
        }
      }
    }
    .img1 {
      position: absolute;
      top: 0.84rem;
      width: 100%;
      height: 13.44rem;
    }
    .img2 {
      position: absolute;
      top: 0.46rem;
      width: 100%;
      height: 15.78rem;
    }
    // .img1 {
    //   position: absolute;
    //   top: 1.22rem;
    //   right: 0;
    //   width: 1.2rem;
    //   height: 2.24rem;
    // }
    // .img2 {
    //   position: absolute;
    //   top: 4.04rem;
    //   right: 0;
    //   width: 2.04rem;
    //   height: 2.04rem;
    // }
    // .img3 {
    //   position: absolute;
    //   top: 4.1rem;
    //   left: 0;
    //   width: 1.02rem;
    //   height: 1.94rem;
    // }
    // .img4 {
    //   position: absolute;
    //   top: 7.44rem;
    //   left: 0;
    //   width: 1.84rem;
    //   height: 2.56rem;
    // }
    // .img5 {
    //   position: absolute;
    //   top: 0.84rem;
    //   left: 0;
    //   width: 7.5rem;
    //   height: 13.44rem;
    // }
    // .img6 {
    //   position: absolute;
    //   top: 9.36rem;
    //   left: 0;
    //   width: 7.5rem;
    //   height: 6.88rem;
    //   z-index: -1;
    // }
  }

  .pages-wrap {
    display: none;
    position: relative;
    width: 100%;
    height: 100vh;
    // height: 16.24rem;
    overflow: hidden;

    .pages-up {
      position: absolute;
      right: 0.44rem;
      bottom: 2.3rem;
      width: 0.4rem;
      z-index: 1;
      &__icon {
        animation: up 1.5s linear infinite;
        width: 0.4rem;
        height: 0.76rem;
      }
      &__label {
        display: block;
        text-align: center;
        width: 0.4rem;
        font-size: 0.28rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #666666;
        line-height: 0.34rem;
      }
    }
  }

  .pages {
    width: 100%;
    transition: transform 0.5s;

    .page {
      position: relative;
      width: 100%;
      height: 100vh;
      // height: 16.24rem;
      overflow: hidden;
      background-size: 100% 100%;
    }
    
    &__1 {
      background-image: url(//cdn.hhdd.com/frontend/as/i/b4bc881b-2500-5d82-8490-c485a7b8b202.png);
      .info1 {
        margin-top: 10.7vh;
        padding-left: 0.48rem;
      }
      .info2 {
        margin-top: 4.8vh;
        padding-left: 0.48rem;
      }
      .nick {
        font-size: 0.64rem;
        font-family: alibaba;
        line-height: 0.68rem;
        color: #333;
      }
      .label {
        color: #333;
        font-size: 0.32rem;
        font-family: FZLANTY_ZHONGCUJW--GB1;
        line-height: 0.68rem;
      }
      .img1 {
        // position: absolute;
        // top: ;
        display: block;
        width: 5.62rem;
        height: 5.62rem;
        margin: 0 auto;
        // width: ;
      }

      .img2 {
        position: absolute;
        top: 26.1vh;
        right: 0;
        width: 3.46rem;
        height: 3.48rem;

      }
      // .img1 {
      //   position: absolute;
      //   top: 1.7rem;
      //   right: 0;
      //   width: 1.96rem;
      //   height: 2.76rem;
      // }
      // .img2 {
      //   position: absolute;
      //   top: 4.45rem;
      //   right: 0;
      //   width: 1.98rem;
      //   height: 1.34rem;
      // }
      // .img3 {
      //   position: absolute;
      //   top: 4.74rem;
      //   right: 0.46rem;
      //   width: 2.74rem;
      //   height: 2.06rem;
      // }
      // .img4 {
      //   position: absolute;
      //   top: 8.88rem;
      //   left: 1.22;
      //   width: 4.96rem;
      //   height: 4.74rem;
      // }
      // .img5 {
      //   position: absolute;
      //   top: 10.9rem;
      //   left: 0;
      //   width: 1.56rem;
      //   height: 3.44rem;
      // }
    }
    &__2 {
      background-image: url(//cdn.hhdd.com/frontend/as/i/e3cb7ba8-3622-5781-b477-374bc01a5296.png);
      .img1 {
        position: absolute;
        top: 8.6vh;
        right: 1rem;
        width: 1.84rem;
        height: 1.27rem;
      }
      .img2 {
        position: absolute;
        top: 24.5vh;
        width: 100%;
      }
      .info1 {
        margin-top: 10.7vh;
        padding-left: 0.48rem;
      }
      .info2 {
        margin-top: 3.4vh;
        padding-left: 0.48rem;
      }
      .label {
        font-size: 0.32rem;
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.68rem;
      }
      .number {
        font-size: 0.8rem;
        font-family: DIN-Bold;
        font-weight: bold;
        color: #333333;
        line-height: 0.92rem;
      }
    }
    &__3 {
      background-image: url(//cdn.hhdd.com/frontend/as/i/2f4f5afe-6aa3-543f-a4a8-c7ad0b876f30.png);
      .info1 {
        margin-top: 9.2vh;
        padding-left: 0.48rem;
        .label {
          font-size: 0.32rem;
          font-family: FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.72rem;
        }
        .category {
          font-size: 0.64rem;
          font-family: alibaba;
          font-weight: normal;
          color: #333333;
          line-height: 0.72rem;
        }
      }
      .chart {
        position: absolute;
        height: 283px;
        padding: 0 0.16rem;
        // margin-top: 12.3vh;
        bottom: 20.2vh;
    width: 100%;

        .circle {
          position: absolute;
          right: -72px;
          width: 283px;
          height: 283px;
          border-radius: 100%;
          background: rgba(255,255,255,0.3);
        }

        #pie {
          position: absolute;
          top: 28px;
        }
      }
      .img1 {
        position: absolute;
        top: 7vh;
        right: 0;
        width: 3.38rem;
        height: 3.38rem;
        // animation: move 3s ease infinite alternate;
      }
      .img2 {
        position: absolute;
        top: 26.8vh;
        right: 0;
        width: 1.89rem;
        height: 2.07rem;
      }
      .img3 {
        position: absolute;
        top: 35.2vh;
        left: 0.9;
        width: 2.41rem;
        height: 2.11rem;
      }
    }
    &__4 {
      background-image: url(//cdn.hhdd.com/frontend/as/i/7d814e4c-d428-5825-ac2b-904d5da953c4.png);
      .info1 {
        margin-top: 9.2vh;
        padding-left: 0.48rem;
      }
      .label {
        font-size: 0.32rem;
        font-family:FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.68rem
      }
      .province {
        font-size: 0.64rem;
        font-family: alibaba;
        font-weight: normal;
        color: #333333;
        line-height: 0.68rem
      }
      .number {
        font-size: 0.72rem;
        font-family: DIN-Bold;
        font-weight: bold;
        color: #333333;
        line-height: 0.68rem
      }

      .img1 {
        position: absolute;
        top: 7.3vh;
        width: 100%;
      }

      // .img1 {
      //   position: absolute;
      //   top: 7.58rem;
      //   left: 1.68rem;
      //   width: 4.62rem;
      //   height: 4.66rem;
      //   z-index: 3;
      // }
      // .img2 {
      //   position: absolute;
      //   top: 5.22rem;
      //   left: 0.16rem;
      //   width: 7.34rem;
      //   height: 9.24rem;
      //   z-index: 2;
      // }
      // .img3 {
      //   position: absolute;
      //   top: 1.38rem;
      //   left: 0;
      //   width: 7.5rem;
      //   height: 14.26rem;
      //   z-index: 1;
      // }
    }
    &__5 {
      background-image: url(//cdn.hhdd.com/frontend/as/i/fb77807c-b086-57bc-8d89-4e49780cebf7.png);
      .info1 {
        margin-top: 1.42rem;
        padding-left: 0.48rem;
      }

      .info2 {
        position: absolute;
        width: 100%;
        bottom: 18.5vh;
        font-size: 0.24rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.28rem;
        text-align: center;
      }

      .label {
        font-size: 0.32rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.8rem;
      }

      .number {
        font-size: 0.8rem;
        font-family: DIN-Bold;
        font-weight: bold;
        color: #333333;
        line-height: 0.8rem;
      }
      .img1 {
        position: absolute;
        top: 16.8vh;
        width: 100%;
      }

      // .img1 {
      //   position: absolute;
      //   top: 3.38rem;
      //   right: 0;
      //   width: 1.72rem;
      //   height: 3.12rem;
      // }
      // .img2 {
      //   position: absolute;
      //   left: 0.16rem;
      //   top: 5.76rem;
      //   width: 1.6rem;
      //   height: 1.48rem;
      // }
      // .img3 {
      //   position: absolute;
      //   left: 0;
      //   top: 6.46rem;
      //   width: 7.5rem;
      //   height: 6.64rem;
      // }
    }
  }

  @keyframes move
  {
    from {
      transform: translateY(0);
    }
    to {
      transform: translateY(-1.14rem);
    }
  }

  @keyframes up
  {
    from {
      transform: translateY(0);
    }
    to {
      transform: translateY(-30px);
    }
  }
</style>