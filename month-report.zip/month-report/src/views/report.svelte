<div class="report">
  <!-- 头部：标题、会员信息展示 -->
  <div class="report__header">
    <div class="report__nav">
      <div class="report__nav--left"></div>
      {#if !deviceInfo.isPad}
        <div class="report__logo">
          <img src="//cdn.hhdd.com/frontend/as/i/64c77129-8442-5774-8e87-8f7f7269af14.png" alt="">
        </div>
      {/if}
      <div class="report__nav--right" on:click={showTotalReadModal}>
        累计阅读
      </div>
    </div>
    <div class="report__flex">
      {#if deviceInfo.isPad}
      <div class="report__title">KaDa阅读·{month}月成长报告</div>
      {:else}
      <div class="report__title">{month}月·阅读成长报告</div>
      {/if}
      <div class="user report__user">
        <div class="avatar user__avatar">
          <img class="avatar__img" src={userInfo.headUrl} alt="" />
        </div>
        <div>
            <div class="user__nickname">{userInfo.nickLabel}</div>
            <div class="user__date">
              <span>{userInfo.ageLabel}</span>
              <span>·</span>
              <span>{userInfo.joinVipDate} 加入会员</span>
            </div>
        </div>
      </div>
    </div>
  </div>
  <!-- 本月阅读 -->
  <div class="report-card read-month">
    <div class="read-month__rule" on:click={openRuleDialog}></div>
    <div class="report-card__header">
      <div class="report-card__dot" />
      <div class="report-card__title">
        本月阅读{totalInfo?.current?.readDays || 0}天
      </div>
      <div class="report-card__dot" />
    </div>
    <div class="read-count">
      <div class="read-count__stars">
        <img src={totalInfo.stars[0]} alt="" />
        <img src={totalInfo.stars[1]} alt="" />
        <img src={totalInfo.stars[2]} alt="" />
        <img src={totalInfo.stars[3]} alt="" />
        <img src={totalInfo.stars[4]} alt="" />
      </div>
      {#if totalInfo?.computeNum > 0}
        <div class="read-count__info">
          <span>共读</span>
          <span class="read-count__val">{totalInfo.computeVal}</span>
          <span>{totalInfo.computeUnit}</span>
        </div>
      {:else}
        <div class="read-count__info nodata">本月还没有阅读哦</div>
      {/if}
    </div>
    {#if totalInfo?.items.length}
      <div class="read-month__chart">
        <ReadBarChart {totalInfo} {userInfo} {date}/>
      </div>
    {/if}
    {#if totalInfo?.province}
      <div class="report-range">
        {#if !deviceInfo.isPad}
          <div class="report-range__border"></div>
        {/if}
        <div class="report-range__title">本月阅读排名·{userInfo.ageLabel}</div>
        <div class="report-range__card">
          <div class="report-range__left">
            <img src="//cdn.hhdd.com/frontend/as/i/df31f8bd-4b5b-5730-98aa-bf76dfe79a85.png" alt="">
          </div>
          <div>
            {#if !totalInfo.isOnlyChina}
              <div class="report-range__province">
                <span>{totalInfo?.province}第</span>
                <span class="number">{totalInfo?.computeProvinceRank}</span>
                <span>名</span>
                {#if totalInfo.provinceRank < 1000 && totalInfo.lastRank > 0}
                  <span class="compare__label">
                    <span style="margin-left: 0.08rem;">较上月</span>
                    <span class="compare__number {totalInfo.provinceRank < totalInfo.lastRank ? 'up' : ''}">
                      {totalInfo?.computeRank}
                    </span>
                    {#if totalInfo.provinceRank < totalInfo.lastRank}
                      <img class="compare__icon" src="//cdn.hhdd.com/frontend/as/i/ed1c24ba-e5bd-515a-91d0-85fb15d5ad1e.png" alt="">
                    {:else}
                      <img class="compare__icon" src="//cdn.hhdd.com/frontend/as/i/a7e05cb8-e645-5fa4-8208-ee1c4612c2e9.png" alt="">
                    {/if}
                  </span>
                {/if}
              </div>
            {/if}
            {#if !totalInfo?.isNotChina}
              <div class="report-range__country" style="margin-top: {totalInfo.isOnlyChina ? 0 : '0.24rem'}">
                <span class="rank">全国排名{totalInfo.computeWholeRank}</span>
                <span class="people">（共{totalInfo.wholeNumber}人）</span>
              </div>
            {/if}
          </div>
        </div>
      </div>
    {/if}
    <div class="read-month__desc">
      {#if userInfo.ageType < 7}
      <span>*本报告自2023年4月起统计，学龄前阅读目标参考《3-6岁儿童学习与发展指南》制定</span>
              {:else}
      <span>*本报告自2023年4月起统计，学龄段阅读目标参考新课标对小学语文课外阅读量要求制定</span>
      {/if}
    </div>
  </div>
  <!-- 阅读趋势 -->
  <div class="report-card read-trend">
    <div class="report-card__header">
      <div class="report-card__dot" />
      <div class="report-card__title">我的阅读趋势</div>
      <div class="report-card__dot" />
    </div>
    {#if trendInfo.length && trendInfo[0].totalTime > 0}
      <div class="read-trend__summary">
        <div class="read-trend__time">
          本月累计阅读
          {#if trendInfo[0].timeObj.h > 0}
            <span class="read-trend__val">
              {trendInfo[0].timeObj.h}
            </span>
            <span>小时</span>
          {/if}
          {#if trendInfo[0].timeObj.m > 0}
            <span class="read-trend__val">{trendInfo[0].timeObj.m}</span>
            <span>分钟</span>
          {/if}
        </div>
        {#if deviceInfo.isPad}
          <div class="read-trend__percent">{trendInfo[0].summary}{trendInfo[0].summary2}</div>
        {:else}
          <div class="read-trend__percent">{trendInfo[0].summary}</div>
          {#if trendInfo[0].summary2}
            <div class="read-trend__percent" style="margin-top: 0;">{trendInfo[0].summary2}</div>
          {/if}
        {/if}
      </div>
    {:else}
      <div class="read-trend__summary nodata">
        <div class="read-trend__time">
          本月累计阅读
          <span class="read-trend__val">0</span>
          <span>小时</span>
        </div>
        <div class="read-trend__percent">本月还没有阅读，要继续加油哦</div>
      </div>
    {/if}
    {#if trendInfo?.length}
      <div class="read-trend__chart">
        <TrendLineChart {trendInfo} {date}/>
      </div>
    {/if}
    <div class="read-trend__desc">
      *本报告自2023年4月开始统计，4月前暂无数据
    </div>
  </div>
  <!-- 本月最爱阅读 -->
  <div class="report-card read-favorite">
    <div class="report-card__header">
      <div class="report-card__dot" />
      <div class="report-card__title">本月我最爱读</div>
      <div class="report-card__dot" />
    </div>
    {#if favoriteInfo?.items?.length}
      <div class="read-favorite__list">
        {#each favoriteInfo.items as item}
          <div class="read-favorite__item">
            <div class="read-favorite__cover" on:click={viewBook(item)}>
              <BookCover {item} />
            </div>
            <div class="read-favorite__title text-overflow">{item.name}</div>
            <div class="read-favorite__detail">
              <div class="read-favorite__minutes">
                阅读{item.readTimeM}分钟
              </div>
              <div class="read-favorite__dot"></div>
              <div class="read-favorite__times">共{item.readTimes}次</div>
            </div>
          </div>
        {/each}
      </div>
      <div class="read-words">
        <div class="read-words__title">·我的收获·</div>
        <div class="read-words__list--wrap">
          <div class="read-words__list">
            <div class="read-words__item">{favoriteInfo?.categoryNames[0]}</div>
            <div class="read-words__item">{favoriteInfo?.categoryNames[1]}</div>
            <div class="read-words__item">{favoriteInfo?.categoryNames[2]}</div>
            <div class="read-words__item">{favoriteInfo?.categoryNames[3]}</div>
            <div class="read-words__item">{favoriteInfo?.categoryNames[4]}</div>
            <div class="read-words__item">{favoriteInfo?.categoryNames[5]}</div>
          </div>
        </div>
      </div>
    {:else}
    <div class="read-trend__summary nodata">
      <div class="read-trend__percent">本月还没有阅读，要继续加油哦</div>
    </div>
    {/if}
  </div>
  <!-- 阅读推荐 -->
  {#if recommendInfo?.items?.length}
  <div class="report-card read-recommend">
    <div class="report-card__header">
      <div class="report-card__dot" />
      <div class="report-card__title">{month + 1}月阅读推荐</div>
      <div class="report-card__dot" />
    </div>
    <div class="read-recommend__topic">
      <span style="margin-right: 0.1rem;">阅读主题:</span>
      {recommendInfo.title}
    </div>
    <div class="read-recommend__list">
      {#each recommendInfo.items as item}
        <div class="book">
          <div class="book__cover" on:click={viewBook(item)}>
            <BookCover {item} />
          </div>
          <div class="book__info">
            <div class="book__title">{item.name}</div>
            <div class="topics">
              {#each item.categoryNames as topic}
                <div class="topics__item">{topic}</div>
              {/each}
            </div>
            <div class="book__summary">
              <span class="book__score">{item.score}分</span>
              <span class="book__times">
                <span>{item.readTimesLabel}阅读</span>
                {#if item.sourceType !== 1 && item.sourceType !== 15 && item.sourceType !== 2}
                  <span class="dot">·</span>
                  <span>{item.subNum}本</span>
                {/if}
              </span>
            </div>
          </div>
        </div>
      {/each}
    </div>
    <div class="read-recommend__button" on:click={addBookToShelf}>
      一键加入孩子书架
    </div>
  </div>
  {/if}
</div>

<script lang="ts">
  // @ts-nocheck
  import type { PageData } from "@/app";
  import {
    IRecommendInfo,
    ITotalInfo,
    ITrendItem,
    IFavoriteInfo,
    saveBookShelf,
    getTotalHistory,
  } from "@/services/report";
  import { formatDate } from "@kada/library/utils/datetime";
  import ReadBarChart from "@/components/ReadBarChart.svelte";
  import TrendLineChart from "@/components/TrendLineChart.svelte";
  import { showDialog as showReadHistoryDialog } from "@/components/ReadHistoryDialog";
  import { showDialog as showRuleDialog } from "@/components/RuleDialog"
  import { debounce } from "@/utils/throttle";
  import BookCover from "@/components/BookCover.svelte";
  import { ageTypeMap } from "@/services/read";
  import { deviceInfo } from "@kada/library/src/device";
  import config from "@/lib/config";
  import { sendReportBehavior } from '@/lib/analytics'
  import { onMount } from 'svelte'
  import type { IUser } from "@/services/user"
  import { date, channelId, userIdStr } from '../app'
  import { toast } from "@kada/svelte-activity-ui"

  // @ts-nocheck
  // 页面数据
  export let pageData: PageData = null;

  // 页面是否加载完成
  export let pageLoaded: boolean = false;

  // 页面是否要重新加载
  export let reload: boolean = false;

  // 当前月份
  let month: number;

  // 用户信息
  let userInfo: IUser

  // 本月阅读数据
  let totalInfo: ITotalInfo

  // 阅读趋势
  let trendInfo: ITrendItem[]

  // 最爱阅读
  let favoriteInfo: IFavoriteInfo
  
  // 阅读推荐
  let recommendInfo: IRecommendInfo

  let userId = deviceInfo.isKadaClient ? null : userIdStr


  $: if (pageData) {
    init();
  }

  onMount(() => {
    // 进入页面打点
    sendReportBehavior('pgv_100102', {
      date: formatDate(date, 'YYYYMM'),
      channelId
    })
  })

  /**
   * 页面数据初始化
   */
  function init() {
    if (date) {
      const yearMonth = new Date(date);
      month = yearMonth.getMonth() + 1;
    }

    initUserInfo()
    initTotalInfo()
    initTrendInfo()
    initFavoriteInfo()
    initRecommendInfo()
  }

  /**
   * 用户信息处理
   */
  function initUserInfo() {
    userInfo = pageData.userInfo;
    userInfo.nickLabel = (userInfo.nick || "小读者");
    userInfo.ageLabel = (ageTypeMap[userInfo.ageType]?.label || '');
    userInfo.joinVipDate = formatDate(userInfo.joinVip, "YYYY-MM-DD");
  }

  /**
   * 本月阅读数据处理
   */
  function initTotalInfo() {
    totalInfo = pageData.totalInfo
    totalInfo.current = totalInfo.items[0] || {} as any
    const ageType = userInfo.ageType
    const { target } = ageTypeMap[ageType]
    const { readNum = 0, readWords = 0 } = totalInfo.current

    const { provinceRank, lastRank, wholeRank, province} = totalInfo

    let unit: string
    let num: number

    // 小龄使用本，大龄使用字数
    if (ageType < 7) {
      unit = "本"
      num = readNum
    } else {
      unit = "字"
      num = readWords
    }

    totalInfo.computeVal = computeReadNum(num)
    totalInfo.computeUnit = unit
    totalInfo.computeNum = num
    totalInfo.computeRank = (provinceRank < lastRank ? '+' : '') + (lastRank - provinceRank)
    totalInfo.computeWholeRank = wholeRank >= 10000 ? '9999+' : wholeRank
    totalInfo.computeProvinceRank = provinceRank >= 1000 ? '999+' : provinceRank
    totalInfo.isNotChina = province === '海外' // 海外数据
    totalInfo.isOnlyChina = province === '中国' // 只解析到中国，无法解析到省份

    const percent = num / target
    totalInfo.stars = initStars(percent)
  }

  /**
   * 初始化星星
   * @param percent 百分比
   */
  function initStars(percent: number) {
    let img1 = "//cdn.hhdd.com/frontend/as/i/2fcd5b10-3167-565c-8d7d-b57fdbd1ee04.png";
    let img2 = "//cdn.hhdd.com/frontend/as/i/762cf2a1-800b-58bb-9505-93d007c629df.png";
    let img3 = "//cdn.hhdd.com/frontend/as/i/598e1252-c104-5fab-ae87-03e10497d1e1.png";
    let stars = [img1, img1, img1, img1, img1];
    let starNum = 0;
    if (percent > 0 && percent < 0.2) {
      starNum = 0.5;
      stars = [img2, img1, img1, img1, img1];
    } else if (percent >= 0.2 && percent < 0.3) {
      starNum = 1;
      stars = [img3, img1, img1, img1, img1];
    } else if (percent >= 0.3 && percent < 0.4) {
      starNum = 1.5;
      stars = [img3, img2, img1, img1, img1];
    } else if (percent >= 0.4 && percent < 0.5) {
      starNum = 2;
      stars = [img3, img3, img1, img1, img1];
    } else if (percent >= 0.5 && percent < 0.6) {
      starNum = 2.5;
      stars = [img3, img3, img2, img1, img1];
    } else if (percent >= 0.6 && percent < 0.7) {
      starNum = 3;
      stars = [img3, img3, img3, img1, img1];
    } else if (percent >= 0.7 && percent < 0.8) {
      starNum = 3.5;
      stars = [img3, img3, img3, img2, img1];
    } else if (percent >= 0.8 && percent < 0.9) {
      starNum = 4;
      stars = [img3, img3, img3, img3, img1];
    } else if (percent >= 0.9 && percent < 1.0) {
      starNum = 4.5;
      stars = [img3, img3, img3, img3, img2];
    } else if (percent >= 1) {
      starNum = 1;
      stars = [img3, img3, img3, img3, img3];
    }
    return stars
  }

  /**
   * 处理阅读趋势数据
   */
  function initTrendInfo() {
    trendInfo = pageData.trendInfo || [];
    if (!trendInfo.length) {
      return
    }

    const {
      totalTime,
      bookReadTime,
      courseReadTime,
      storyReadTime,
      comicReadTime,
      ebookReadTime,
    } = trendInfo[0];
    const arr = [
      {
        val: bookReadTime,
        label: "的时间在阅读绘本，是名副其实的小书迷",
        label2: ''
      },
      {
        val: storyReadTime,
        label: "的时间在听故事，表现很棒！",
        label2: '建议增加图书阅读，更利于字词积累哦！'
      },
      {
        val: courseReadTime,
        label: "的时间在学课程，表现很棒！",
        label2: '建议增加图书阅读，更利于字词积累哦！'
      },
      {
        val: comicReadTime,
        label: "的时间在读漫画，表现很棒！",
        label2: '建议增加电子书阅读，更利于字词积累哦！'
      },
      {
        val: ebookReadTime,
        label: "的时间在读电子书，表现很棒！",
        label2: '继续坚持就能看到显著提升！'
      },
    ];

    // 计算阅读时间最多的资源类型
    arr.sort((a, b) => b.val - a.val);
    const { val, label, label2 } = arr[0];
    let percent = Math.round((val / totalTime) * 100);
    let summary = percent + "%" + label;

    // 转换为小时分钟显示
    let timeObj = formateTime(totalTime);

    trendInfo[0].summary = summary;
    trendInfo[0].summary2 = label2;
    trendInfo[0].timeObj = timeObj;
  }

  /**
   * 处理最爱阅读数据
   */
  function initFavoriteInfo() {
    favoriteInfo = pageData.favoriteInfo || { items: [], categoryNames: [] };
    favoriteInfo.items = favoriteInfo.items || []
    favoriteInfo.categoryNames = favoriteInfo.categoryNames || []
    // 本月最爱阅读，默认显示六个关键词
    const small = ['识字启蒙', '经典国学', '习惯养成', '情绪管理', '情商培养', '安全知识']
    const big = ['传统国学', '经典名著', '校园文学', '名人传记', '逻辑推理', '阅读写作']
    const words = userInfo.ageType < 7 ? small : big;
    let names = favoriteInfo.categoryNames;
    favoriteInfo.categoryNames = Array.from(new Set([...names, ...words])).slice(0, 6);
    favoriteInfo.items.forEach((item) => {
      // 时间转换为分钟显示
      item.readTimeM = Math.ceil(item.readTime / 60);
    });
  }

  /**
   * 处理阅读推荐数据
   */
  function initRecommendInfo() {
    recommendInfo = pageData.recommendInfo || { items: [], title: "" };
    recommendInfo.items = recommendInfo.items || []
    // 阅读推荐显示两个关键词
    recommendInfo.items.forEach((item) => {
      item.categoryNames = (item.categoryNames || []).slice(0, 2);
      let readTiems = item.readTimes;
      let label = "";
      if (readTiems > 10000) {
        label = (readTiems / 10000).toFixed(1) + "万次";
      } else {
        label = readTiems + "次";
      }
      item.readTimesLabel = label;
    });
  }

  // 累计阅读弹窗
  const  showTotalReadModal = debounce(async () => {
    try {
      let historyData = await getTotalHistory(deviceInfo.isKadaClient ? null : userId);
      const param = {
        date: "",
        readDays: 0,
        timeObj: null,
        readNums: 0,
        unit: "",
      };
      param.date = formatDate(historyData.joinVip, "YYYY年M月");
      param.readDays = historyData.readDays;
      param.timeObj = formateTime(historyData.totalTime);
      if (userInfo.ageType < 7) {
        param.unit = "本";
        param.readNums = historyData.readNum;
      } else {
        param.unit = "字";
        param.readNums = historyData.readWords;
      }

      showReadHistoryDialog({
        historyData: param,
      })
    } catch (e) {
      toast('查询历史数据失败')
    }
  }, 1000, true)

  /**
   * 时间戳转化为小时、分钟
   * @param time 时间戳
   */
  function formateTime(time: number) {
    const h = parseInt(String(time / 60 / 60), 10);
    const m = parseInt(String(Math.ceil((time / 60) % 60)), 10);

    return {
      h,
      m,
    };
  }

  /**
   * 保存阅读推荐到书架
   */
  const addBookToShelf = debounce(
    () => {
      const items = recommendInfo.items;
      if (!items.length) return;
      const sourceList = items.map((item) => {
        return {
          sourceType: item.sourceType,
          sourceId: item.sourceId,
        };
      });
      const str = JSON.stringify(sourceList);
      saveBookShelf(str, userId);

      sendReportBehavior('pgv_100102', {
        date: formatDate(date, 'YYYYMM'),
        channelId,
        type: 2
      })
    }, 1000, true);

  /**
   * 跳转到资源详情页面
  */
  const viewBook = debounce((item) => {
    console.log("跳转页面", item.sourceId, item.sourceType);

    const { sourceId, sourceType } = item;

    sendReportBehavior('pgv_100102', {
      date: formatDate(date, 'YYYYMM'),
      channelId,
      type: 1
    }, {
      sourceId,
      sourceType
    })

    if (!deviceInfo.isKadaClient) {
      openApp()
      return;
    }

    // 根据不同的资源跳转不同的页面
    if (sourceType === 1) {
      location.href = `kada://openbook?bookId=${sourceId}`;
    } else if (item.sourceType === 2) {
      location.href = `kada://openstory?storyId=${sourceId}`;
    } else if (item.sourceType === 4) {
      console.log(
        `kada://openstorycollection2?collectionId=${sourceId}&removeCookie=false`
      );
      location.href = `kada://openstorycollection2?collectionId=${sourceId}&removeCookie=false`;
    } else if (item.sourceType === 5) {
      console.log(
        `kada://openbookcollection2?collectionId=${sourceId}&removeCookie=false`
      );
      location.href = `kada://openbookcollection2?collectionId=${sourceId}&removeCookie=false`;
    } else if (item.sourceType === 8) {
      let baseUrl = config.entryBaseUrl || "http://10.0.10.61:38890/";
      let courseDetailUrl = `h5-course/course.html#/course-detail/${sourceId}?goBuy=0`;
      console.log(baseUrl + courseDetailUrl);
      location.href = baseUrl + courseDetailUrl;
    } else if (item.sourceType === 14) {
      location.href = `kada://opencartooncollection?comicId=${sourceId}`;
    } else if (item.sourceType === 15) {
      location.href = `kada://openebook?ebookId=${sourceId}`;
    }
  }, 1000, true)

  /**
   * 打开规则弹窗
   */
  const openRuleDialog = debounce(() => {
    showRuleDialog()
  }, 1000, true)

  /**
   * 打开app
   */
  const openApp = () => {
    // KaDa阅读下载地址
    const KADA_APP_DOWNLOAD_URL =
      "https://a.app.qq.com/o/simple.jsp?pkgname=com.hhdd.kada";
    const KADA_APP_OPEN_IN_APPSTORE =
      "itms-apps://itunes.apple.com/app/id990142347";

    if (deviceInfo.ios) {
      location.href = KADA_APP_OPEN_IN_APPSTORE;
    } else {
      location.href = KADA_APP_DOWNLOAD_URL;
    }
  };

  function computeReadNum(val) {
    val = Number(val)
    if (val < 10000) {
      return val
    } else {
      const count = (val / 10000).toFixed(2)
      return count + '万'
    }
  }
</script>

<style lang="scss" scoped>
  @import "../styles/variables";
  @import "../styles/mixins";

  .app__button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 6.06rem;
    height: 0.96rem;
    margin: 0.4rem auto 0 auto;
    background: linear-gradient(135deg, #FF8A27 0%, #FF5500 100%);
    border-radius: 0.48rem;
    font-size: 0.32rem;
    font-family: FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #ffffff;
  }

  .report {
    padding-top: 4.18rem;
    padding-bottom: 0.48rem;
    min-height: 100vh;
    background-color: #d0e5ff;

    @media #{$pad_landscape_query} {
      padding-top: 2.28rem;
    }

    @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          padding-top: 4.98rem;
    }

    &__logo {
      width: 1.38rem;
      height: 0.28rem;
    }

    &__h5 {
      font-size: .68rem;
      color: #fe6e41;
    }

    &__target {
      margin-top: 0.05rem;
      font-size: 0.2rem;
      font-family: FZLANTY_JW--GB1;
      font-weight: normal;
      color: #999999;
      line-height: 0.28rem;
      text-align: center;

      @media #{$pad_landscape_query} {
        font-size: 0.24rem;
      }
    }

    &__header {
      position: absolute;
      top: 0;
      width: 100%;
      height: 6.92rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/b0e41d0f-400a-54ac-a4e6-e4c8392ae842.png);
      background-position: left -0.88rem;
      background-repeat: no-repeat;
      background-size: cover;

      @media #{$pad_landscape_query} {
        padding-top: 0;
        height: 5.86rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/096ec07d-24bd-593f-b4c5-7198a8246d9b.png);
      }

      @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          padding-top: 0.88rem;
          height: 7.8rem;
          background-position: left top;
      }
    }

    &__flex {
      @media #{$pad_landscape_query} {
        display: flex;
        align-items: center;
        margin: 0 2.24rem 0 3.04rem;
        justify-content: space-between;
      }
    }

    &__nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 0.88rem;
      padding: 0 0.32rem;

      &--right {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 1.6rem;
        height: 0.56rem;
        background: #3380E2;
        border-radius: 0.28rem;
        font-size: 0.28rem;
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #ffffff;
      }
      &--left {
        width: 1.6rem;
      }

      @media #{$pad_landscape_query} {
        // display: none;
        width: 16rem;
        margin: 0 auto;
        padding: 0;
      }
    }

    &__title {
      height: 0.8rem;
      margin-top: 0.08rem;
      font-size: 0.64rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #ffff00;
      line-height: 0.8rem;
      text-shadow: 0 0.04rem 0.16rem #1d69c8;
      text-align: center;

      @media #{$pad_landscape_query} {
        display: inline-block;
        font-size: 0.56rem;
        // line-height: 0.6;
      }
    }

    &__user {
      margin-top: 0.4rem;

      @media #{$pad_landscape_query} {
        margin-top: 0;
      }
    }
  }

  .user {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 1.44rem;
    background: linear-gradient(
      90deg,
      rgba(50, 126, 222, 0) 0%,
      #327ede 51%,
      rgba(50, 126, 222, 0) 100%
    );

    @media #{$pad_landscape_query} {
      display: inline-flex;
      background: none;
    }
    &__avatar {
      margin-right: 0.24rem;
    }
    &__nickname {
      height: 0.4rem;
      font-size: 0.32rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #ffffff;
      line-height: 0.4rem;

      max-width: 6rem;
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
    }
    &__date {
      display: flex;
      align-items: center;
      height: 0.28rem;
      margin-top: 0.16rem;
      font-size: 0.24rem;
      font-family: FZLANTY_JW--GB1;
      font-weight: normal;
      color: #ffffff;
      line-height: 0.28rem;

      @media #{$pad_landscape_query} {
        margin-top: 0.14rem;
        font-size: 0.28rem;
        font-family: FZLANTY_JW--GB1;
        font-weight: normal;
        color: #FFFFFF;
        line-height: 0.28rem;
      }
    }

    &__dot {
      width: 0.05rem;
      height: 0.05rem;
      background: #fff;
      border-radius: 50%;
      margin: 0 0.1rem;
    }
  }

  .avatar {
    width: 0.96rem;
    height: 0.96rem;
    background: #B5D2F7;
    border: 0.05rem solid #B5D2F7;
    border-radius: 50%;
    overflow: hidden;
    &__img {
      width: 100%;
      height: 100%;
    }
  }

  .read-count {
    position: relative;
    height: 2.7rem;
    &__stars {
      position: relative;
      img:nth-child(1) {
        position: absolute;
        left: 1.34rem;
        top: 1.04rem;
        width: 0.86rem;
        height: 0.86rem;
        transform: rotate(-20deg);

        @media #{$pad_landscape_query} {
          left: 5.7rem;
          top: 1.1rem;
          width: 0.94rem;
          height: 0.94rem;
        }
      }
      img:nth-child(2) {
        position: absolute;
        left: 2.14rem;
        top: 0.58rem;
        width: 0.84rem;
        height: 0.86rem;
        transform: rotate(-10deg);

        @media #{$pad_landscape_query} {
          left: 6.58rem;
          top: 0.6rem;
          width: 0.92rem;
          height: 0.96rem;
        }
      }
      img:nth-child(3) {
        position: absolute;
        left: 3.02rem;
        top: 0.4rem;
        width: 0.84rem;
        height: 0.84rem;

        @media #{$pad_landscape_query} {
          left: 7.54rem;
          top: 0.4rem;
          width: 0.94rem;
          height: 0.94rem;
        }
      }
      img:nth-child(4) {
        position: absolute;
        left: 3.9rem;
        top: 0.58rem;
        width: 0.84rem;
        height: 0.86rem;
        transform: rotate(10deg);

        @media #{$pad_landscape_query} {
          left: 8.5rem;
        top: 0.6rem;
        width: 0.94rem;
        height: 0.96rem;
        }
      }
      img:nth-child(5) {
        position: absolute;
        left: 4.68rem;
        top: 1.04rem;
        width: 0.86rem;
        height: 0.86rem;
        transform: rotate(20deg);

        @media #{$pad_landscape_query} {
          left: 9.38rem;
          top: 1.1rem;
          width: 0.92rem;
          height: 0.94rem;
        }
      }
    }
    &__info {
      position: absolute;
      top: 1.7rem;
      width: 100%;
      text-align: center;
      font-size: 0.32rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #ff6317;
      line-height: 0.4rem;
      &.nodata {
        color: #333333;
        top: 1.86rem;
      }
      @media #{$pad_landscape_query} {
        top: 1.78rem;
      }
    }
    &__val {
      height: 0.72rem;
      font-size: 0.72rem;
      font-family: PingFangSC-Semibold, PingFang SC;
      font-weight: 600;
      color: #ff6317;
      line-height: 0.72rem;
    }
  }

  .report-card {
    width: 6.86rem;
    background: #ffffff;
    box-shadow: 0 0.04rem 0.32rem 0 rgba(69, 143, 237, 0.3);
    border-radius: 0.32rem;
    padding-bottom: 0.6rem;

    @media #{$pad_landscape_query} {
      width: 16rem;
    }

    &__header {
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto;
      width: 4.24rem;
      height: 0.88rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/19279219-83ca-53f2-a48c-364f1f91ef1d.png);
      background-size: cover;
      background-repeat: no-repeat;

      @media #{$pad_landscape_query} {
        width: 5.04rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/9a3892f0-10ff-58c9-8cd5-2db3393cad41.png);
      }
    }

    &__dot {
      width: 0.12rem;
      height: 0.12rem;
      background: #ffffff;
      border-radius: 50%;
    }

    &__title {
      margin: 0 0.24rem;
      font-size: 0.4rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #ffffff;
      line-height: 0.4rem;
    }
  }

  .read-month {
    position: relative;
    margin: 0 auto;

    &__chart {
      position: relative;
      height: 4rem;
      @media #{$pad_landscape_query} {
        margin: 0 1.6rem;
        height: 5rem;
      }
    }

    &__desc {
      margin: 0.35rem 0.4rem 0 0.4rem;
      font-size: 0.2rem;
      font-family: FZLANTY_JW--GB1;
      font-weight: normal;
      color: #999999;
      line-height: 0.28rem;
      text-align: left;

      @media #{$pad_landscape_query} {
        margin: 0.35rem 1.6rem 0 1.6rem;
        font-size: 0.24rem;
      }
    }

    &__rule {
      position: absolute;
      top: 0.24rem;
      right: 0.24rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/91c452b7-fcec-5d28-9331-aa64fb75c9f6.png);
      background-size: cover;
      background-repeat: no-repeat;
      width: 0.4rem;
      height: 0.4rem;

      @media #{$pad_landscape_query} {
        width: 0.48rem;
        height: 0.48rem;
        top: 0.28rem;
        right: 0.48rem;
      }
    }
  }

  .read-trend {
    margin: 0.48rem auto 0 auto;
    &__summary {
      width: 6.06rem;
      margin: 0.32rem auto 0 auto;
      padding: 0.28rem 0.48rem 0.36rem 0.48rem;
      background: #f6f8fb;
      border-radius: 0.16rem;
      text-align: center;

      @media #{$pad_landscape_query} {
        width: 12.8rem;
        margin: 0.4rem auto 0 auto;
        padding: 0.28rem 0.48rem 0.36rem 0.48rem;
      }

      &.nodata {
        // padding: 0.4rem;
        // div {
        //   display: flex;
        //   align-items: center;
        //   justify-content: center;
        //   height: 100%;
        //   background-color: #fff;
        // }
      }
    }
    &__time {
      font-size: 0.28rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #333333;
      line-height: 0.32rem;

      @media #{$pad_landscape_query} {
        font-size: 0.32rem;
      }
    }
    &__percent {
      margin-top: 0.22rem;
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #333333;
      line-height: 0.36rem;

      @media #{$pad_landscape_query} {
        font-size: 0.28rem;
      }
    }
    &__val {
      margin: 0 0.08rem;
      font-size: 0.64rem;
      font-family: PingFangSC-Semibold, PingFang SC;
      font-weight: 600;
      color: #287ae3;
      line-height: 0.64rem;
    }
    &__chart {
      position: relative;
      height: 4.68rem;
      margin: 0.4rem 0.32rem 0 0;

      @media #{$pad_landscape_query} {
        height: 5.38rem;
        margin: 0.4rem 3.02rem 0 3.02rem;
      }
    }
    &__desc {
      margin: 0.35rem 0.4rem 0 0.4rem;
      font-size: 0.2rem;
      font-family: FZLANTY_JW--GB1;
      font-weight: normal;
      color: #999999;
      line-height: 0.28rem;
      text-align: left;

      @media #{$pad_landscape_query} {
        margin: 0.35rem 3.02rem 0 3.02rem;
        font-size: 0.24rem;
      }
    }
  }

  .read-favorite {
    margin: 0.48rem auto 0 auto;

    @media #{$pad_landscape_query} {
      margin-top: 0.56rem;
    }

    &__list {
      display: flex;
      margin-top: 0.4rem;
      padding: 0 0.32rem;

      @media #{$pad_landscape_query} {
        padding: 0 2.84rem;
      }
    }
    &__item {
      width: 1.92rem;
      @media #{$pad_landscape_query} {
        width: 2.8rem;
      }

      &:not(:first-child) {
        margin-left: 0.22rem;

        @media #{$pad_landscape_query} {
          margin-left: 0.96rem;
        }
      }
    }
    &__cover {
      position: relative;
      width: 100%;
      height: 2.46rem;

      @media #{$pad_landscape_query} {
        height: 3.6rem;
      }
    }
    &__title {
      margin-top: 0.2rem;
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #333333;
      line-height: 0.28rem;
      @media #{$pad_landscape_query} {
        font-size: 0.32rem;
        line-height: 0.36rem;
      }
    }
    &__minutes {
      margin-top: 0.08rem;
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #287ae3;
      line-height: 0.36rem;

      @media #{$pad_landscape_query} {
        margin-top: 0;
        font-size: 0.28rem;
      }
    }
    &__times {
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #287ae3;
      line-height: 0.36rem;

      @media #{$pad_landscape_query} {
        font-size: 0.28rem;
      }
    }

    &__dot {
      display: none;
      width: 0.04rem;
      height: 0.04rem;
      background: #287ae3;
      border-radius: 50%;
      color: #287ae3;
      @media #{$pad_landscape_query} {
        display: block;
        margin: 0 0.1rem;
      }
    }

    &__detail {
      @media #{$pad_landscape_query} {
        display: flex;
        align-items: center;
        margin-top: 0.12rem;
      }
    }

    .read-words {
      margin-top: 0.64rem;

      &__title {
        height: 0.44rem;
        font-size: 0.4rem;
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.44rem;
        text-align: center;
      }
      &__list {
        position: relative;
        width: 5.54rem;
        height: 3.96rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/671c894b-5e6c-5ce4-8620-cfaf3054ba5d.png);
        background-repeat: no-repeat;
        background-size: cover;
        margin: 0.56rem auto 0 auto;

        @media #{$pad_landscape_query} {
          transform: scale(1.2);
          transform-origin: center top;
        }

        &--wrap {
          @media #{$pad_landscape_query} {
            width: 12.8rem;
            height: 5.54rem;
            margin: 0.32rem auto 0 auto;
            padding: 0.38rem 0;
            // margin: 0.32rem auto 0 auto;
            background-color: #f6f8fb;
            border-radius: 0.16rem;
          }
        }

        @media #{$pad_landscape_query} {
          margin-top: 0;
        }
      }
      &__item {
        display: flex;
        align-items: center;
        justify-content: center;
        position: absolute;
        width: 1.48rem;
        height: 1.48rem;
        font-size: 0.28rem;
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #ffffff;
        line-height: 0.28rem;
        border-radius: 50%;
      }
      &__item:nth-child(1) {
        top: 0.64rem;
        left: -0.06rem;
        background: linear-gradient(172deg, #79abff 0%, #5773ff 100%);
      }
      &__item:nth-child(2) {
        top: -0.08rem;
        left: 1.9rem;
        background: linear-gradient(135deg, #ff8a27 0%, #ff5500 100%);
      }
      &__item:nth-child(3) {
        top: 0.22rem;
        left: 3.86rem;
        background: linear-gradient(172deg, #79abff 0%, #5773ff 100%);
      }
      &__item:nth-child(4) {
        top: 2.62rem;
        left: 0.66rem;
        background: linear-gradient(135deg, #ff8a27 0%, #ff5500 100%);
      }
      &__item:nth-child(5) {
        top: 1.68rem;
        left: 2.2rem;
        background: linear-gradient(172deg, #79abff 0%, #5773ff 100%);
      }
      &__item:nth-child(6) {
        top: 2.46rem;
        left: 3.86rem;
        background: linear-gradient(135deg, #ff8a27 0%, #ff5500 100%);
      }
    }
  }

  .read-recommend {
    margin: 0.48rem auto 0 auto;
    &__topic {
      margin-top: 0.4rem;
      height: 0.4rem;
      font-size: 0.36rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #287ae3;
      line-height: 0.4rem;
      text-align: center;
    }
    &__list {
      display: flex;
      flex-wrap: wrap;
      margin-top: 0.4rem;
      padding: 0 0.4rem;

      @media #{$pad_landscape_query} {
        padding: 0 1.62rem;
      }
      .book {
        display: flex;
        margin-top: 0.32rem;
        flex-wrap: wrap;
        overflow: hidden;

        @media #{$pad_landscape_query} {
          width: 6rem;
          margin-right: 0.34rem;
        }

        &__cover {
          position: relative;
          width: 1.92rem;
          height: 2.46rem;
          margin-right: 0.24rem;
          img {
            width: 100%;
            height: 100%;
          }
        }
        &__info {
          display: flex;
          flex-direction: column;
          flex: 1;
        }
        &__title {
          font-size: 0.32rem;
          font-family: FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.4rem;
        }
        .topics {
          display: flex;
          flex: 1;
          margin-top: 0.2rem;
          flex-wrap: wrap;
          overflow: hidden;

          &__item {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 1.2rem;
            height: 0.4rem;
            margin-right: 0.12rem;
            margin-bottom: 0.2rem;
            background: rgba($color: #758295, $alpha: 0.15);
            border-radius: 0.08rem;
            font-size: 0.24rem;
            font-family: FZLANTY_JW--GB1;
            font-weight: normal;
            color: #333333;
            line-height: 0.28rem;
          }
        }
        &__score {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          line-height: 1;
          padding: 0.04rem 0.08rem;
          margin-right: 0.16rem;
          background: #ff6317;
          border-radius: 0.04rem;
          font-size: 0.24rem;
          font-family: FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #ffffff;
          // line-height: 0.24rem;
        }
        &__times {
          font-size: 0.24rem;
          font-family: FZLANTY_JW--GB1;
          font-weight: normal;
          color: #666666;
          line-height: 1;

          .dot {
            // margin: 0 0.2rem;
          }
        }

        &__summary {
          display: flex;
          align-items: center;
          height: 0.32rem;
        }
      }
    }
    &__button {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 6.06rem;
      height: 0.96rem;
      margin: 0.4rem auto 0 auto;
      background: #458fed;
      border-radius: 0.48rem;
      font-size: 0.32rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #ffffff;
    }
  }

  .text-overflow {
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .report-range {
    margin-top: 0.4rem;
    padding: 0 0.4rem;
    &__border {
      width: 6.06rem;
      margin: 0 auto;
      border: 0.02rem dashed #D7D7D7;
    }
    &__title {
      margin-top: 0.62rem;
      font-size: 0.32rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #333333;
      text-align: center;

      @media #{$pad_landscape_query} {
        font-size: 0.32rem;
      }

    }
    &__card {
      display: flex;
      align-items: center;
      justify-content: center;
      // padding: 0 0.32rem;
      margin: 0.24rem auto 0 auto;
      width: 6.06rem;
      height: 1.84rem;
      background: #F6F8FB;
      border-radius: 0.16rem;

      @media #{$pad_landscape_query} {
        width: 12.8rem;
      }
    }
    &__left {
      margin-right: 0.24rem;
      img {
        width: 1.12rem;
        height: 1.04rem;
      }
    }
    &__right {

    }
    &__province {
      display: flex;
      align-items: baseline;
      flex-wrap: wrap;
      font-size: 0.28rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #333333;
      .number {
        margin: 0 0.08rem;
        font-size: 0.48rem;
        font-family: PingFangSC-Semibold, PingFang SC;
        font-weight: 600;
        color: #FF6317;
        line-height: 1;
      }
      .compare__label {
        display: flex;
        align-items: center;
      }

      .compare__number {
        margin-left: 0.04rem;
        font-size: 0.28rem;
        font-family: PingFangSC-Semibold, PingFang SC;
        font-weight: 600;
        color: #999;
        &.up {
          color: #FF6317;
        }
      }
      .compare__icon {
        width: 0.24rem;
        height: 0.24rem;
      }
    }
    &__country {
      margin-top: 0.24rem;
      .rank {
        font-size: 0.28rem;
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
      }
      .people {
        font-size: 0.24rem;
        font-family: FZLANTY_JW--GB1;
        font-weight: normal;
        color: #333333;
        // line-height: 0.34rem;
      }
    }
  }
</style>
