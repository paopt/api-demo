<div>
  <div>{redeemCode}</div>
  <div>复制兑换码</div>
  <button on:click={goRedeem}>去兑换</button>
</div>

<script lang="ts">
  import { getCode } from '@/services/report'
  import { userIdStr } from '@/app'

  // 兑换码
  let redeemCode = ''

  init()

  function init() {
    getRedeemCode()
  }

  /**
   * 获取兑换码
   */
  async function getRedeemCode() {
    redeemCode = await getCode(userIdStr)
  }

  /**
   * 跳转到兑换页面
   */
  function goRedeem() {

  }
</script>

<style lang="scss"></style>