<div class="summary">
  <div class="summary__header">
    <!-- 导航栏 -->
    <div class="nav">
      <div class="nav__left"></div>
      {#if !deviceInfo.isPad}
        <img class="nav__logo" src="//cdn.hhdd.com/frontend/as/i/64c77129-8442-5774-8e87-8f7f7269af14.png" alt="">
      {/if}
      <div class="read-btn" on:click={showTotalReadModal}>
        累计阅读
      </div>
    </div>
    <!-- 用户信息 -->
    <div class="user">
      <div class="avatar">
        <img class="avatar__img" src={userInfo.headUrl} alt="" />
        {#if userInfo.isSvip}
          <img class="avatar__vip" src="//cdn.hhdd.com/frontend/as/i/44f74390-0be5-5f07-809a-9f7f461fbcc3.png" alt="">
        {/if}
        {#if userInfo.isVip}
          <img class="avatar__vip" src="//cdn.hhdd.com/frontend/as/i/44f74390-0be5-5f07-809a-9f7f461fbcc3.png" alt="">
        {/if}
      </div>
      <div class="user__info">
        <div>
          <span class="user__nick">{userInfo.nickLabel}</span>
          <span class="user__report">阅读报告</span>
        </div>
        <div class="user__row">
          <span class="user__age">{userInfo.ageTypeLabel}</span>
        </div>
      </div>
    </div>
  </div>
  <div class="summary__body">
    <div class="month">
      <div>
        <span class="month__label--1">6月累计阅读</span>
        <span class="number">23</span>
        <span class="month__label--2"></span>
      </div>
      <div class="report-btn">
        <span>查看详情报告</span>
        <img class="report-btn__icon" src="//cdn.hhdd.com/frontend/as/i/54a51ace-8750-52e0-bd3c-44aeab5abe4e.png" alt="">
      </div>
    </div>
    <div class="summary-read">
      <div>
        <span class="summary-read__label">累计阅读</span>
        <span>
          <img src="//cdn.hhdd.com/frontend/as/i/b7f42c74-f775-548d-b4a3-b7c5beb01958.png" alt="">
          <img src="//cdn.hhdd.com/frontend/as/i/c1c601d9-dcbb-56f0-94ae-bdad6261489e.png" alt="">
        </span>
      </div>
      <div>
        <span class="number">2345</span>
        <span class="unit">字</span>
      </div>
    </div>
    </div>
    <div class="summary__time">
      <div>阅读时长</div>
      <div>
        <span class="number">1234</span>
        <span>小时</span>
        <span class="number">12</span>
        <span class="unit">分钟</span>
      </div>
    </div>
    <div class="summary-keywords">

    </div>
  <div class="summary__footer"></div>
</div>

<script lang="ts">
   // @ts-nocheck
   import type { PageData } from "@/app";
  import {
    IRecommendInfo,
    ITotalInfo,
    ITrendItem,
    IFavoriteInfo,
    saveBookShelf,
    getTotalHistory,
  } from "@/services/report";
  import { formatDate } from "@kada/library/utils/datetime";
  import { showDialog as showReadHistoryDialog } from "@/components/ReadHistoryDialog";
  import { showDialog as showRuleDialog } from "@/components/RuleDialog"
  import { debounce } from "@/utils/throttle";
  import BookCover from "@/components/BookCover.svelte";
  import { ageTypeMap } from "@/services/read";
  import { deviceInfo } from "@kada/library/src/device";
  import config from "@/lib/config";
  import { sendReportBehavior } from '@/lib/analytics'
  import { onMount } from 'svelte'
  import type { IUser } from "@/services/user"
  import { date, channelId, userIdStr } from '../app'
  import { toast } from "@kada/svelte-activity-ui"

  let userInfo = {
    nick: '测测',
    headUrl: "http://image.hhdd.com/user/systemHead/0/2/0/geometry5.png",
    isSvip: 1,
    isVip: 0,
    ageType: 4
  }

  onMount(() => {
    init()
  })

  function init() {
    initUserInfo()
  }


  /**
   * 用户信息处理：昵称、头像、年龄、vip
   */
  function initUserInfo() {
    if (!userInfo) {
      return
    }
    userInfo.nickLabel = userInfo.nick || "小读者"
    const { nick, ageType } = userInfo

    if (nick.length > 6) {
      userInfo.nickLabel = nick.substring(0, 6) + '...'
    }

    userInfo.ageTypeLabel = ageTypeMap[ageType]?.label || '大班'
  }

  // 累计阅读弹窗
  const  showTotalReadModal = debounce(async () => {
    try {
      let historyData = await getTotalHistory(deviceInfo.isKadaClient ? null : userId);
      const param = {
        date: "",
        readDays: 0,
        timeObj: null,
        readNums: 0,
        unit: "",
      };
      param.date = formatDate(historyData.joinVip, "YYYY年M月");
      param.readDays = historyData.readDays;
      param.timeObj = formateTime(historyData.totalTime);
      if (userInfo.ageType < 7) {
        param.unit = "本";
        param.readNums = historyData.readNum;
      } else {
        param.unit = "字";
        param.readNums = historyData.readWords;
      }

      showReadHistoryDialog({
        historyData: param,
      })
    } catch (e) {
      toast('查询历史数据失败')
    }
  }, 1000, true)
</script>

<style lang="scss" scoped>
  @import "../styles/variables";
  @import "../styles/mixins";

  .read-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.6rem;
    height: 0.56rem;
    background: #3380E2;
    border-radius: 0.28rem;
    font-size: 0.28rem;
    font-family: FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #ffffff;
  }

  .report-btn {
    display: flex;
    align-items: center;
    width: 2.46rem;
    height: 0.64rem;
    padding-left: 0.2rem;
    border-radius: 0.16rem;
    background: #458FED;

    font-size: 0.28rem;
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #FFFFFF;

    &__icon {
      width: 0.4rem;
      height: 0.4rem;
    }
  }

  .summary {
    min-height: 100vh;
    padding-bottom: 0.48rem;
    background-color: #d0e5ff;

    @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          padding-top: 0.88rem;
    }

    &__header {
      position: absolute;
      top: 0;
      width: 100%;
      height: 6.92rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/b0e41d0f-400a-54ac-a4e6-e4c8392ae842.png);
      background-position: left -0.88rem;
      background-repeat: no-repeat;
      background-size: cover;

      @media #{$pad_landscape_query} {
        padding-top: 0;
        height: 5.86rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/096ec07d-24bd-593f-b4c5-7198a8246d9b.png);
      }

      @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          padding-top: 0.88rem;
          height: 7.8rem;
          background-position: left top;
      }
    }

    &__body {
      position: relative;
      width: 6.86rem;
      margin: 3.3rem auto 0 auto;
      padding: 0.44rem 0.36rem 0.68rem 0.48rem;
      background: #ffffff;
      box-shadow: 0 0.04rem 0.32rem 0 rgba(69, 143, 237, 0.3);
      border-radius: 0.32rem;

      @media #{$pad_landscape_query} {
        width: 16rem;
      }
    }
  }

  .nav {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 0.88rem;
    padding: 0 0.32rem;

    @media #{$pad_landscape_query} {
      // display: none;
      width: 16rem;
      margin: 0 auto;
      padding: 0;
    }

    &__left {
      width: 1.6rem;
    }

    &__logo {
      width: 1.38rem;
      height: 0.28rem;
    }
  }

  .user {
    display: flex;
    align-items: center;
    height: 1.64rem;
    padding-left: 0.8rem;
    background: linear-gradient(90deg, rgba(50,126,222,0) 0%, #327EDE 51%, rgba(50,126,222,0) 100%);

    &__info {
      margin-left: 0.19rem;
    }

    &__row {
      margin-top: 0.04rem;
    }

    &__nick {
      font-size: 0.48rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FFFFFF;
      line-height: 0.8rem;
      text-shadow: 0 0.04rem 0.16rem #1D69C8;
    }
    &__report {
      font-size: 0.48rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FFFF00;
      line-height: 0.8rem;
      text-shadow: 0 0.04rem 0.16rem #1D69C8;
    }
    &__age {
      font-size: 0.24rem;
      font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
      font-weight: normal;
      color: #FFFFFF;
      line-height: 0.28rem;
    }
  }

  .avatar {
    position: relative;
    width: 1.06rem;
    height: 1.06rem;
    background: #B5D2F7;
    border: 0.05rem solid #B5D2F7;
    border-radius: 50%;
    &__img {
      width: 0.96rem;
      height: 0.96rem;
      border-radius: 50%;
    }
    &__vip {
      position: absolute;
      top: 0.84rem;
      left: 0.15rem;
      width: 0.76rem;
      height: 0.27rem;
    }
  }

  .number {
    font-size: 0.72rem;
    font-family: DINAlternate-Bold, DINAlternate;
    font-weight: bold;
    color: #458FED;
  }
  .unit {
    font-size: 0.24rem;
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #666666;
  }
</style>