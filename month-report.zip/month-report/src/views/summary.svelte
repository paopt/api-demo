<div class="summary">
  <div class="summary__header">
    <!-- 导航栏 -->
    <div class="nav">
      <div class="nav__left"></div>
      {#if !deviceInfo.isPad}
        <img class="nav__logo" src="//cdn.hhdd.com/frontend/as/i/64c77129-8442-5774-8e87-8f7f7269af14.png" alt="">
      {/if}
      <div class="read-btn" on:click={showTotalReadModal}>
        累计阅读
      </div>
    </div>
    <!-- 用户信息 -->
    <div class="user">
      <div class="avatar">
        <img class="avatar__img" src={user.headUrl} alt="" />
        {#if userInfo.isSvip}
          <img class="avatar__vip" src="//cdn.hhdd.com/frontend/as/i/44f74390-0be5-5f07-809a-9f7f461fbcc3.png" alt="">
        {/if}
        {#if userInfo.isVip}
          <img class="avatar__vip" src="//cdn.hhdd.com/frontend/as/i/44f74390-0be5-5f07-809a-9f7f461fbcc3.png" alt="">
        {/if}
      </div>
      <div class="user__info">
        <div>
          <span class="user__nick">{user.nick}</span>
          <span class="user__report">阅读报告</span>
        </div>
        <div class="user__row">
          <span class="user__age">{user.ageLabel}</span>
        </div>
      </div>
    </div>
  </div>
  <div class="summary__body">
    <div class="day-block">
      <div>
        <span class="label">6月阅读</span>
        <span class="number">23</span>
        <span class="unit">天</span>
      </div>
      <div class="report-btn">
        <span>查看详情报告</span>
        <img class="report-btn__icon" src="//cdn.hhdd.com/frontend/as/i/54a51ace-8750-52e0-bd3c-44aeab5abe4e.png" alt="">
      </div>
    </div>
    <div class="read-block">
      <div class="read-block__header">
        <span class="label">累计阅读</span>
        <span class="stars">
          <img class="stars__item" src="//cdn.hhdd.com/frontend/as/i/b7f42c74-f775-548d-b4a3-b7c5beb01958.png" alt="">
          <img class="stars__item" src="//cdn.hhdd.com/frontend/as/i/b7f42c74-f775-548d-b4a3-b7c5beb01958.png" alt="">
          <img class="stars__item" src="//cdn.hhdd.com/frontend/as/i/c1c601d9-dcbb-56f0-94ae-bdad6261489e.png" alt="">
        </span>
      </div>
      <div class="read-block__content">
        <span class="number">2345</span>
        <span class="unit">字</span>
      </div>
    </div>
    <div class="time-block">
      <div class="time-block__header">阅读时长</div>
      <div class="time-block__content">
        <span class="number">1234</span>
        <span class="unit">小时</span>
        <span class="number">12</span>
        <span class="unit">分钟</span>
      </div>
    </div>
    <div class="keywords-block">
      <div class="keywords-block__header">我的收获</div>
      <div class="keywords-block__content">
        <div class="keywords-block__1">创意思维</div>
        <div class="keywords-block__2">幽默熏陶</div>
        <div class="keywords-block__3">性格养成</div>
        <div class="keywords-block__4">关键词一</div>
        <div class="keywords-block__5">关键词一</div>
        <div class="keywords-block__6">关键词一</div>
      </div>
    </div>
    <div class="line-block"></div>
    <div class="history-block">
      <div class="history-block__item">
        <span class="time">5月</span>
        <span class="label">阅读成长报告</span>
        <img class="right" src="//cdn.hhdd.com/frontend/as/i/853372ab-8ed8-5f13-83dd-3ba5882e61d4.png" alt="">
      </div>
      <div class="history-block__item">
        <span class="time">5月</span>
        <span class="label">阅读成长报告</span>
        <img class="right" src="//cdn.hhdd.com/frontend/as/i/853372ab-8ed8-5f13-83dd-3ba5882e61d4.png" alt="">
      </div>
      <div class="history-block__item">
        <span class="time">2022年12月</span>
        <span class="label">阅读成长报告</span>
        <img class="right" src="//cdn.hhdd.com/frontend/as/i/853372ab-8ed8-5f13-83dd-3ba5882e61d4.png" alt="">
      </div>
    </div>
  </div>

  <div class="summary__footer">
    <span class="label">意见反馈</span>
  </div>
</div>

<script lang="ts">
   // @ts-nocheck
   import type { PageData } from "@/app";
  import {
    IRecommendInfo,
    ITotalInfo,
    ITrendItem,
    IFavoriteInfo,
    saveBookShelf,
    getTotalHistory,
  } from "@/services/report";
  import { formatDate } from "@kada/library/utils/datetime";
  import { showDialog as showReadHistoryDialog } from "@/components/ReadHistoryDialog";
  import { debounce } from "@/utils/throttle";
  import { ageTypeMap } from "@/services/read";
  import { deviceInfo } from "@kada/library/src/device";
  import { onMount } from 'svelte'
  import { toast } from "@kada/svelte-activity-ui"
  import { userInfo, date, userIdStr } from '@/app'
  import { getIndexData } from '@/services/report'

  let user = {
    nick: '',
    headUrl: '',
    ageLabel: ''
  };

  onMount(() => {
    init()
  })

  function init() {
    initUserInfo()
    getSummaryData()
  }

  /**
   * 用户信息处理：昵称、头像、年龄、vip
   */
  function initUserInfo() {
    if (!userInfo) {
      return
    }

    const { nick, ageType } = userInfo

    if (nick?.length > 6) {
      user.nick = nick.substring(0, 6) + '...'
    } else {
      user.nick = '小读者'
    }

    user.ageLabel = ageTypeMap[ageType]?.label || '大班'
    user.headUrl = userInfo.headUrl
  }

  /**
   * 查询汇总数据
   */
  async function getSummaryData() {
    const list = await getIndexData(date, userIdStr)
    if (list) {
      const data = list.find
    }
  }

  // 累计阅读弹窗
  const  showTotalReadModal = debounce(async () => {
    try {
      let historyData = await getTotalHistory(deviceInfo.isKadaClient ? null : userId);
      const param = {
        date: "",
        readDays: 0,
        timeObj: null,
        readNums: 0,
        unit: "",
      };
      param.date = formatDate(historyData.joinVip, "YYYY年M月");
      param.readDays = historyData.readDays;
      param.timeObj = formateTime(historyData.totalTime);
      if (userInfo.ageType < 7) {
        param.unit = "本";
        param.readNums = historyData.readNum;
      } else {
        param.unit = "字";
        param.readNums = historyData.readWords;
      }

      showReadHistoryDialog({
        historyData: param,
      })
    } catch (e) {
      toast('查询历史数据失败')
    }
  }, 1000, true)
</script>

<style lang="scss" scoped>
  @import "../styles/variables";
  @import "../styles/mixins";

  .read-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.6rem;
    height: 0.56rem;
    background: #3380E2;
    border-radius: 0.28rem;
    font-size: 0.28rem;
    font-family: FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #ffffff;
  }

  .report-btn {
    display: flex;
    align-items: center;
    width: 2.46rem;
    height: 0.64rem;
    padding-left: 0.2rem;
    border-radius: 0.16rem;
    background: #458FED;

    font-size: 0.28rem;
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #FFFFFF;

    &__icon {
      width: 0.4rem;
      height: 0.4rem;
    }
  }

  .summary {
    min-height: 100vh;
    padding-bottom: 0.48rem;
    background-color: #d0e5ff;

    @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          padding-top: 0.88rem;
    }

    &__header {
      position: absolute;
      top: 0;
      width: 100%;
      height: 6.92rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/b0e41d0f-400a-54ac-a4e6-e4c8392ae842.png);
      background-position: left -0.88rem;
      background-repeat: no-repeat;
      background-size: cover;

      @media #{$pad_landscape_query} {
        padding-top: 0;
        height: 5.86rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/096ec07d-24bd-593f-b4c5-7198a8246d9b.png);
      }

      @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          padding-top: 0.88rem;
          height: 7.8rem;
          background-position: left top;
      }

      .nav {
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 0.88rem;
        padding: 0 0.32rem;

        @media #{$pad_landscape_query} {
          // display: none;
          width: 16rem;
          margin: 0 auto;
          padding: 0;
        }

        &__left {
          width: 1.6rem;
        }

        &__logo {
          width: 1.38rem;
          height: 0.28rem;
        }
      }

      .user {
        display: flex;
        align-items: center;
        height: 1.64rem;
        padding-left: 0.8rem;
        background: linear-gradient(90deg, rgba(50,126,222,0) 0%, #327EDE 51%, rgba(50,126,222,0) 100%);

        &__info {
          margin-left: 0.19rem;
        }

        &__row {
          margin-top: 0.04rem;
        }

        &__nick {
          font-size: 0.48rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #FFFFFF;
          line-height: 0.8rem;
          text-shadow: 0 0.04rem 0.16rem #1D69C8;
        }
        &__report {
          font-size: 0.48rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #FFFF00;
          line-height: 0.8rem;
          text-shadow: 0 0.04rem 0.16rem #1D69C8;
        }
        &__age {
          font-size: 0.24rem;
          font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
          font-weight: normal;
          color: #FFFFFF;
          line-height: 0.28rem;
        }
      }

      .avatar {
        position: relative;
        width: 1.06rem;
        height: 1.06rem;
        background: #B5D2F7;
        border: 0.05rem solid #B5D2F7;
        border-radius: 50%;
        &__img {
          width: 0.96rem;
          height: 0.96rem;
          border-radius: 50%;
        }
        &__vip {
          position: absolute;
          top: 0.84rem;
          left: 0.15rem;
          width: 0.76rem;
          height: 0.27rem;
        }
      }
    }

    &__body {
      position: relative;
      width: 6.86rem;
      margin: 3.3rem auto 0 auto;
      padding: 0.24rem 0.36rem 0.68rem 0.48rem;
      background: #ffffff;
      box-shadow: 0 0.04rem 0.32rem 0 rgba(69, 143, 237, 0.3);
      border-radius: 0.32rem;

      @media #{$pad_landscape_query} {
        width: 16rem;
      }

      .day-block {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0;
        .label {
          font-size: 0.36rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.32rem;
        }
        .number {
          margin: 0 0.08rem;
          line-height: 0.84rem;
        }
      }

      .read-block {
        margin-top: 0.48rem;
        font-size: 0;
        &__header {
          display: flex;
          align-items: center;
        }
        &__content {
          margin-top: 0.16rem;
        }

        .label {
          margin-right: 0.2rem;
          font-size: 0.28rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.32rem;
        }

        .stars {
          display: flex;
          &__item {
            width: 0.36rem;
            height: 0.36rem;
            margin-right: 0.04rem;
          }
        }

        .number {
          margin-right: 0.1rem;
          line-height: 0.84rem;
        }
      }
      .time-block {
        margin-top: 0.32rem;
        font-size: 0;
        &__header {
          font-size: 0.28rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.32rem;
        }
        &__content {
          margin-top: 0.16rem;
        }
        .unit {
          margin: 0 0.08rem;
        }
      }
      .keywords-block {
        position: absolute;
        top: 1.6rem;
        right: 0.4rem;
        width: 2.92rem;
        height: auto;
        &__header {
          font-size: 0.28rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.32rem;
          text-align: center;
        }
        &__content {
          // margin-top: 0.32rem;
        }
        &__1 {
          position: absolute;
          top: 0.68rem;
          right: 2.02rem;
          // width: 0.88rem;
          font-size: 0.22rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #999999;
          line-height: 0.22rem;
        }
        &__2 {
          position: absolute;
          top: 0.64rem;
          right: 0.68rem;
          // width: 1.28rem;
          font-size: 0.32rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #666666;
          line-height: 0.32rem;
        }
        &__3 {
          position: absolute;
          top: 0.7rem;
          right: 0;
          // width: 0.64rem;
          font-size: 0.16rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #999999;
          line-height: 0.16rem;
        }
        &__4 {
          position: absolute;
          top: 1.12rem;
          right: 0;
          // width: 2.88rem;
          font-size: 0.72rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.72rem;
        }
        &__5 {
          position: absolute;
          top: 1.94rem;
          right: 1.28rem;
          // width: 1.6rem;
          font-size: 0.4rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #999999;
          line-height: 0.41rem;
        }
        &__6 {
          position: absolute;
          top: 2.06rem;
          right: 0;
          // width: 1.04rem;
          font-size: 0.26rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #666666;
          line-height: 0.26rem;
        }
      }
      .line-block {
        width: 100%;
        margin: 0.48rem 0 0.46rem 0;
        border-top: 0.02rem dashed #D7D7D7;
      }
      .history-block {
        width: 100%;
        height: 3.08rem;
        padding: 0 0.18rem 0 0.24rem;
        background: #F6F8FB;
        border-radius: 0.16rem;


        &__item {
          display: flex;
          align-items: center;
          width: 100%;
          height: 1rem;
          border-bottom: 0.02rem solid #E3E7EC;

          .time, .label {
            font-size: 0.28rem;
            font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
            font-weight: normal;
            color: #333333;
            line-height: 0.32rem;
          }
          .label {
            flex: 1;
            padding-right: 1.66rem;
            text-align: right;
          }
          .right {
            width: 0.4rem;
            height: 0.4rem;
          }
        }
      }
    }

    &__footer {
      padding: 0.8rem 0 0.7rem 0;
      text-align: center;
      .label {
        font-size: 0.24rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #666666;
        line-height: 0.24rem;
        border-bottom: 0.02rem solid #666666;;
      }
    }

    .number {
      font-size: 0.72rem;
      font-family: DINAlternate-Bold, DINAlternate;
      font-weight: bold;
      color: #458FED;
    }
    .unit {
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #666666;
    }
  }
</style>