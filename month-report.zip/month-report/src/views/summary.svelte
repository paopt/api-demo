<div class="summary">
  <div class="summary__header">
    <!-- 导航栏 -->
    <div class="nav">
      <div class="nav__left"></div>
      {#if !deviceInfo.isPad}
        <img class="nav__logo" src="//cdn.hhdd.com/frontend/as/i/64c77129-8442-5774-8e87-8f7f7269af14.png" alt="">
      {/if}
      <div class="read-btn" on:click={showTotalReadModal}>
        累计阅读
      </div>
    </div>
    <!-- 用户信息 -->
    <div class="user">
      <div class="avatar">
        <img class="avatar__img" src={user.headUrl} alt="" />
        {#if userInfo.isSvip}
          <img class="avatar__vip" src="//cdn.hhdd.com/frontend/as/i/44f74390-0be5-5f07-809a-9f7f461fbcc3.png" alt="">
        {:else if userInfo.isVip}
          <img class="avatar__vip" src="//cdn.hhdd.com/frontend/as/i/4f807f83-55cd-5fe9-ac8b-71d0d65109c7.png" alt="">
        {/if}
      </div>
      <div class="user__info">
        <div>
          <span class="user__nick">{user.nick}</span>
          <span class="user__report">阅读报告</span>
        </div>
        <div class="user__row">
          <span class="user__age">{user.ageLabel}</span>
        </div>
      </div>
    </div>
  </div>
  <div class="summary__body">
    <div class="day-block">
      <div class="day-block__left {summaryData.days > 0 ? '' : 'nodata'}">
        {#if summaryData.days > 0}
          <span class="label">{summaryData.month}月阅读</span>
          <span class="number">{summaryData.days}</span>
          <span class="unit">天</span>
        {:else}
          <span class="label nodata">{summaryData.month}月</span>
        {/if}
      </div>
      <div class="report-btn" on:click={viewDetail}>
        <span>查看详情报告</span>
        <img class="report-btn__icon" src="//cdn.hhdd.com/frontend/as/i/54a51ace-8750-52e0-bd3c-44aeab5abe4e.png" alt="">
      </div>
    </div>
    {#if summaryData.days > 0}
      <div class="read-block">
        <div class="read-block__header">
          <span class="label">累计阅读</span>
          <span class="stars">
            <img class="stars__item" src="{summaryData.read.stars[0]}" alt="">
            <img class="stars__item" src="{summaryData.read.stars[1]}" alt="">
            <img class="stars__item" src="{summaryData.read.stars[2]}" alt="">
            <img class="stars__item" src="{summaryData.read.stars[3]}" alt="">
            <img class="stars__item" src="{summaryData.read.stars[4]}" alt="">
          </span>
        </div>
        <div class="read-block__content">
          <span class="number">{summaryData.read.formateCount}</span>
          <span class="unit">{summaryData.read.unit}</span>
        </div>
      </div>
      <div class="time-block">
        <div class="time-block__header">阅读时长</div>
        <div class="time-block__content">
          {#if summaryData.time.h > 0}
            <span class="number">{summaryData.time.h}</span>
            <span class="unit">小时</span>
          {/if}
          {#if summaryData.time.m > 0 || summaryData.time.h === 0}
            <span class="number">{summaryData.time.m}</span>
            <span class="unit">分钟</span>
          {/if}
        </div>
      </div>
      <div class="keywords-block">
        <div class="keywords-block__header">我的收获</div>
        {#if summaryData.words.length}
        <div class="keywords-block__content">
          <div class="keywords-block__1">{summaryData.words[0]}</div>
          <div class="keywords-block__2">{summaryData.words[1]}</div>
          <div class="keywords-block__3">{summaryData.words[2]}</div>
          <div class="keywords-block__4">{summaryData.words[3]}</div>
          <div class="keywords-block__5">{summaryData.words[4]}</div>
          <div class="keywords-block__6">{summaryData.words[5]}</div>
        </div>
        {/if}
      </div>
    {:else}
      <div class="nodata-block">
        <div class="label1">你当月还没有阅读哦</div>
        <div class="label2">继续加油吧！</div>
      </div>
    {/if}
    <div class="line-block"></div>
    {#if summaryData.history.length}
      <div class="history-block">
        {#each  summaryData.history as item, i}
          <div class="history-block__item {i === 0 ? '' : 'hasBorder'}" on:click={viewHistory(item)}>
            <span class="time">{item.date}</span>
            <span class="label">阅读成长报告</span>
            <img class="right" src="//cdn.hhdd.com/frontend/as/i/853372ab-8ed8-5f13-83dd-3ba5882e61d4.png" alt="">
          </div>
        {/each}
      </div>
      <div class="history-block__rule">
        {#if deviceInfo.isPad}
        <div class="label1">月度阅读报告从2023年5月开始统计记录，此处展示历史6个月有记录的统计信息。</div>
        {:else}
          <div class="label1">月度阅读报告从2023年5月开始统计记录</div>
          <div class="label2">此处展示历史6个月有记录的统计信息</div>
        {/if}
      </div>
    {/if}
  </div>

  <div class="summary__footer">
    <span class="label" on:click={openFeedback}>意见反馈</span>
  </div>
</div>

<script lang="ts">
   // @ts-nocheck
  import {
    getTotalHistory,
  } from "@/services/report";
  import { formatDate } from "@kada/library/utils/datetime";
  import { showDialog as showReadHistoryDialog } from "@/components/ReadHistoryDialog";
  import { debounce } from "@/utils/throttle";
  import { ageTypeMap } from "@/services/read";
  import { deviceInfo } from "@kada/library/src/device";
  import { onMount } from 'svelte'
  import { toast } from "@kada/svelte-activity-ui"
  import { userInfo, userIdStr, updateDate, channelId } from '@/app'
  import { getIndexData } from '@/services/report'
  import { router, navigateTo } from '@kada/yrv'
  import { parseTime, parseTime, getKeywords, convertToStars, ageTypeMap, formateNum, formateReportDate } from '@/services/read'
  import { sendReportBehavior } from '@/lib/analytics'
  
  let date = ''

  // 用户信息
  let user = {
    nick: '小读者',
    headUrl: '',
    ageLabel: ''
  };

  // 汇总数据
  let summaryData = {
    month: 0, // 月份
    days: 0, // 阅读天数
    read: { 
      count: 0, // 阅读数量
      formateCount: '',
      unit: '', // 阅读单位
      stars: convertToStars(0), // 阅读数量对应星星
    },
    time: { // 阅读时间
      h: 0, // 小时
      m: 0, // 分钟
    },
    words: [], // 关键词
    history: [],
  }

  console.log('summary:: init')
  init()

  onMount(() => {
    console.log('summary onMount')
    // 进入页面打点
    sendReportBehavior('pgv_100201', {
      channelId
    })
  })

  function init() {
    initDate()
    initUserInfo()
    getSummaryData()
  }

  /**
   * 显示上个月数据
   */
  function initDate() {
    const d = new Date()
    d.setMonth(d.getMonth() - 1)
    const year = d.getFullYear()
    let month = d.getMonth() + 1
    summaryData.month = month
    month = String(month).padStart(2, '0')
    date = `${year}-${month}`
    console.log('summary date', date, month)
  }

  /**
   * 用户信息处理：昵称、头像、年龄、vip
   */
  function initUserInfo() {
    if (!userInfo) {
      return
    }

    const { nick, ageType } = userInfo

    if (nick?.length > 6) {
      if (deviceInfo.isPad) {
        user.nick = nick.substring(0, 8) + '...'
      } else {
        user.nick = nick.substring(0, 5) + '...'
      }
    } else {
      user.nick = nick || user.nick
    }

    user.ageLabel = ageTypeMap[ageType]?.label
    user.headUrl = userInfo.headUrl
  }

  /**
   * 查询汇总数据
   */
  async function getSummaryData() {
    const list = await getIndexData(userIdStr)
    if (list?.length) {
      const data = list.find(item => item.yearMonth === date)
      //  没有数据
      if (!data) {
        return
      }
      const {readDays, readWords, readNum, totalTime, categoryNames} = data
      summaryData.days = readDays
      const {h, m} = parseTime(totalTime)
      summaryData.time.h = h
      summaryData.time.m = m
      summaryData.words = getKeywords(userInfo.ageType, categoryNames)
      if (userInfo.ageType < 7) {
        summaryData.read.unit = '本'
        summaryData.read.count = readNum
      } else {
        summaryData.read.unit = '字'
        summaryData.read.count = readWords
      }
      const percent = summaryData.read.count / ageTypeMap[userInfo.ageType].target
      summaryData.read.stars = convertToStars(percent)
      summaryData.read.formateCount = formateNum(summaryData.read.count)

      summaryData.history = list.slice(1).map(item => {
        return {
          date: formateReportDate(item.yearMonth),
          yearMonth: item.yearMonth
        }
      })
    }
  }

  // 累计阅读弹窗
  const  showTotalReadModal = debounce(async () => {
    try {
      let historyData = await getTotalHistory(userIdStr);
      const param = {
        date: "",
        readDays: 0,
        timeObj: null,
        readNums: 0,
        unit: "",
      };
      param.date = formatDate(historyData.joinVip, "YYYY年M月");
      param.readDays = historyData.readDays;
      param.timeObj = parseTime(historyData.totalTime);
      if (userInfo.ageType < 7) {
        param.unit = "本";
        param.readNums = historyData.readNum;
      } else {
        param.unit = "字";
        param.readNums = historyData.readWords;
      }

      sendReportBehavior('pgv_100201', {
        channelId,
        type: 1
      })

      showReadHistoryDialog({
        historyData: param,
      })
    } catch (e) {
      toast('查询历史数据失败')
    }
  }, 1000, true)

  // 打开反馈页面
  function openFeedback() {
    console.log($router)
    navigateTo('/feedback', {
      queryParams: {...$router.query, from: 'summary'}
    })
  }

  function viewDetail() {
    sendReportBehavior('ac_100201', {
      date: formatDate(date, 'YYYYMM'),
      channelId
    })
    updateDate(date)
    navigateTo('/report', {
      queryParams: {
        ...$router.query,
        date: date,
        from: 'summary'
      }
    })
  }

  function viewHistory(data) {
    sendReportBehavior('ac_100201', {
      date: formatDate(data.yearMonth, 'YYYYMM'),
      channelId
    })
    updateDate(data.yearMonth)
    navigateTo('/report', {
      queryParams: {
        ...$router.query,
        date: data.yearMonth,
        from: 'summary'
      }
    })
  }
</script>

<style lang="scss" scoped>
  @import "../styles/variables";
  @import "../styles/mixins";

  .read-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.6rem;
    height: 0.56rem;
    background: #3380E2;
    border-radius: 0.28rem;
    font-size: 0.28rem;
    font-family: FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #ffffff;
  }

  .report-btn {
    display: flex;
    align-items: center;
    width: 2.46rem;
    height: 0.64rem;
    padding-left: 0.2rem;
    border-radius: 0.16rem;
    background: #458FED;
    font-size: 0.28rem;
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #FFFFFF;

    @media #{$pad_landscape_query} {
      width: 2.8rem;
      padding-left: 0.22rem;
      font-size: 0.32rem;
    }

    &__icon {
      width: 0.4rem;
      height: 0.4rem;

      @media #{$pad_landscape_query} {
        width: 0.48rem;
        height: 0.48rem;
      }
    }
  }

  .summary {
    min-height: 100vh;
    background-color: #d0e5ff;
    padding-top: 3.3rem;

    @media #{$pad_landscape_query} {
      padding-top: 2.28rem;
    }

    @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          padding-top: 0.88rem;
    }

    &__header {
      position: absolute;
      top: 0;
      width: 100%;
      height: 6.92rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/b0e41d0f-400a-54ac-a4e6-e4c8392ae842.png);
      background-repeat: no-repeat;
      background-size: cover;
      background-position: left -0.88rem;

      @media #{$pad_landscape_query} {
        height: 5.86rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/096ec07d-24bd-593f-b4c5-7198a8246d9b.png);
        background-position: left top;
      }

      @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2),
        only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          padding-top: 0.88rem;
          height: 7.8rem;
          background-position: left top;
      }

      .nav {
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 0.88rem;
        padding: 0 0.32rem;

        @media #{$pad_landscape_query} {
          height: 1.32rem;
          padding: 0 0.8rem 0 0.4rem;
        }

        &__left {
          width: 1.6rem;
        }

        &__logo {
          width: 1.38rem;
          height: 0.28rem;
        }
      }

      .user {
        display: flex;
        align-items: center;
        height: 1.64rem;
        padding-left: 0.8rem;
        margin-top: 0.32rem;
        background: linear-gradient(90deg, rgba(50,126,222,0) 0%, #327EDE 51%, rgba(50,126,222,0) 100%);

        @media #{$pad_landscape_query} {
          height: auto;
          padding-left: 2.48rem;
          margin-top: -0.48rem;
          background: none;
        }
        
        &__info {
          margin-left: 0.19rem;
          @media #{$pad_landscape_query} {
            margin-left: 0.31rem;
          }
        }

        &__row {
          margin-top: 0.04rem;
          @media #{$pad_landscape_query} {
            margin-top: 0.14rem;
          }
        }

        &__nick {
          margin-right: 0.32rem;
          font-size: 0.48rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #FFFFFF;
          line-height: 0.8rem;
          text-shadow: 0 0.04rem 0.16rem #1D69C8;
          @media #{$pad_landscape_query} {
            margin-right: 0.48rem;
            font-size: 0.56rem;
            line-height: 0.6rem;
          }
        }
        &__report {
          font-size: 0.48rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #FFFF00;
          line-height: 0.8rem;
          text-shadow: 0 0.04rem 0.16rem #1D69C8;
          @media #{$pad_landscape_query} {
            font-size: 0.56rem;
            line-height: 0.6rem;
          }
        }
        &__age {
          font-size: 0.24rem;
          font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
          font-weight: normal;
          color: #FFFFFF;
          line-height: 0.28rem;
          @media #{$pad_landscape_query} {
            font-size: 0.28rem;
          }
        }
      }

      .avatar {
        display: flex;
        align-items: center;
        justify-self: center;
        position: relative;
        width: 1.06rem;
        height: 1.06rem;
        background: #B5D2F7;
        border: 0.05rem solid #B5D2F7;
        border-radius: 50%;
        &__img {
          width: 0.96rem;
          height: 0.96rem;
          border-radius: 50%;
        }
        &__vip {
          position: absolute;
          top: 0.84rem;
          left: 0.1rem;
          width: 0.76rem;
          height: 0.27rem;
        }
      }
    }

    &__body {
      position: relative;
      width: 6.86rem;
      margin: 0 auto;
      padding: 0.24rem 0.36rem 0.68rem 0.48rem;
      background: #ffffff;
      box-shadow: 0 0.04rem 0.32rem 0 rgba(69, 143, 237, 0.3);
      border-radius: 0.32rem;

      @media #{$pad_landscape_query} {
        width: 16rem;
        margin: 0 auto;
        padding: 0.64rem 1.6rem 0.7rem 1.6rem;
      }

      .day-block {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0;
        @media #{$pad_landscape_query} {
          justify-content: flex-start;
        }
        &__left {
          display: flex;
          @media #{$pad_landscape_query} {
            margin-right: 0.6rem;
            &.nodata {
              margin-right: 2.46rem;
            }
          }
        }
        .label {
          padding: 0.32rem 0 0.2rem 0;
          font-size: 0.36rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.32rem;
          @media #{$pad_landscape_query} {
            line-height: 0.36rem;
            padding: 0.3rem 0 0.18rem 0;
          }
        }
        .number {
          margin: 0 0.08rem;
          line-height: 0.84rem;
        }
      }

      .read-block {
        margin-top: 0.48rem;
        font-size: 0;

        @media #{$pad_landscape_query} {
          margin-top: 0.7rem;
        }
        &__header {
          display: flex;
          align-items: center;
        }
        &__content {
          display: flex;
          margin-top: 0.16rem;

          @media #{$pad_landscape_query} {
            margin-top: 0.1rem;
          }
        }

        .label {
          margin-right: 0.2rem;
          font-size: 0.28rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.32rem;

          @media #{$pad_landscape_query} {
            margin-right: 0.12rem;
            font-size: 0.32rem;
          }
        }

        .stars {
          display: flex;
          &__item {
            width: 0.36rem;
            height: 0.36rem;
            margin-right: 0.04rem;

            @media #{$pad_landscape_query} {
              width: 0.48rem;
              height: 0.48rem;
              margin-right: 0.06rem;
            }
          }
        }

        .number {
          margin-right: 0.1rem;
          line-height: 0.84rem;

          @media #{$pad_landscape_query} {
            margin-right: 0.08rem;
          }
        }
      }
      .time-block {
        margin-top: 0.32rem;
        font-size: 0;
        @media #{$pad_landscape_query} {
          margin-top: 0.7rem;
        }
        &__header {
          font-size: 0.28rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.32rem;

          @media #{$pad_landscape_query} {
            font-size: 0.32rem;
          }
        }
        &__content {
          display: flex;
          margin-top: 0.16rem;

          @media #{$pad_landscape_query} {
            margin-top: 0.18rem;
          }
        }
        .unit {
          margin: 0 0.08rem;
          line-height: 0.34rem;
        }
      }
      .keywords-block {
        position: absolute;
        top: 1.6rem;
        right: 0.4rem;
        width: 2.92rem;
        height: auto;

        @media #{$pad_landscape_query} {
          top: 0.8rem;
          right: 1.82rem;
          width: 4.96rem;
        }
        &__header {
          font-size: 0.28rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.32rem;
          text-align: center;

          @media #{$pad_landscape_query} {
            font-size: 0.32rem;
          }
        }
        &__content {
          // margin-top: 0.32rem;
        }
        &__1 {
          position: absolute;
          top: 0.68rem;
          right: 2.02rem;
          font-size: 0.22rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #999999;
          line-height: 0.22rem;
          @media #{$pad_landscape_query} {
            top: 1.3rem;
            right: 3.52rem;
            font-size: 0.36rem;
            line-height: 0.3rem;
          }
        }
        &__2 {
          position: absolute;
          top: 0.64rem;
          right: 0.68rem;
          // width: 1.28rem;
          font-size: 0.32rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #666666;
          line-height: 0.32rem;
          @media #{$pad_landscape_query} {
            top: 1.16rem;
            right: 1.2rem;
            font-size: 0.52rem;
            line-height: 0.55rem;
          }
        }
        &__3 {
          position: absolute;
          top: 0.7rem;
          right: 0;
          // width: 0.64rem;
          font-size: 0.16rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #999999;
          line-height: 0.16rem;
          @media #{$pad_landscape_query} {
            top: 1.22rem;
            right: 0;
            font-size: 0.26rem;
            line-height: 0.39rem;
          }
        }
        &__4 {
          position: absolute;
          top: 1.12rem;
          right: 0;
          // width: 2.88rem;
          font-size: 0.72rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.72rem;
          @media #{$pad_landscape_query} {
            top: 2rem;
            right: 0;
            font-size: 1.24rem;
            line-height: 1.26rem;
          }
        }
        &__5 {
          position: absolute;
          top: 1.94rem;
          right: 1.28rem;
          // width: 1.6rem;
          font-size: 0.4rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #999999;
          line-height: 0.41rem;
          @media #{$pad_landscape_query} {
            top: 3.54rem;
            right: 2.22rem;
            font-size: 0.68rem;
            line-height: 0.71rem;
          }
        }
        &__6 {
          position: absolute;
          top: 2.06rem;
          right: 0;
          // width: 1.04rem;
          font-size: 0.26rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #666666;
          line-height: 0.26rem;
          @media #{$pad_landscape_query} {
            top: 3.72rem;
            right: 0;
            font-size: 0.48rem;
            line-height: 0.47rem;
          }
        }
      }
      .line-block {
        width: 100%;
        margin: 0.48rem 0 0.46rem 0;
        border-top: 0.02rem dashed #D7D7D7;

        @media #{$pad_landscape_query} {
          margin: 0.64ren 0 0.62rem 0;
        }
      }
      .history-block {
        width: 100%;
        padding: 0 0.18rem 0 0.24rem;
        background: #F6F8FB;
        border-radius: 0.16rem;
        @media #{$pad_landscape_query} {
          padding: 0 0.48rem;
        }
        &__item {
          display: flex;
          align-items: center;
          width: 100%;
          height: 1.4rem;
          &.hasBorder {
            border-top: 0.02rem solid #E3E7EC;
          }

          .time, .label {
            font-size: 0.28rem;
            font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
            font-weight: normal;
            color: #333333;
            line-height: 0.32rem;
          }
          .time {
            width: 1.9rem;
            @media #{$pad_landscape_query} {
              width: 2.58rem;
            }
          }
          .label {
            flex: 1;
          }
          .right {
            width: 0.4rem;
            height: 0.4rem;
          }
        }
        &__rule {
          margin-top: 0.4rem;
          @media #{$pad_landscape_query} {
            margin-top: 0.48rem;
          }
          .label1, .label2 {
            font-size: 0.24rem;
            font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
            font-weight: normal;
            color: #333333;
            line-height: 0.24rem;
          }
          .label2 {
            margin-top: 0.16rem;
          }
        }
      }
      .nodata-block {
        margin-top: 0.48rem;
        @media #{$pad_landscape_query} {
          margin-top: 0.84rem;
        }
        
        .label1, .label2 {
          font-size: 0.28rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          line-height: 0.28rem;

          @media #{$pad_landscape_query} {
            font-size: 0.32rem;
            line-height: 0.32rem;
          }
        }
        .label2 {
          margin-top: 0.24rem;
          @media #{$pad_landscape_query} {
            margin-top: 0.32rem;
          }
        }
      }
    }

    &__footer {
      padding: 0.8rem 0 0.7rem 0;
      text-align: center;
      
      .label {
        font-size: 0.24rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #666666;
        line-height: 0.24rem;
        border-bottom: 0.02rem solid #666666;;
      }
      @media #{$pad_landscape_query} {
        padding: 0.48rem 0 1.1rem 0;
      }
    }

    .number {
      font-size: 0.72rem;
      font-family: DINAlternate-Bold, DINAlternate;
      font-weight: bold;
      color: #458FED;
      line-height: 0.84rem;
    }
    .unit {
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #666666;
      line-height: 0.28rem;
      padding: 0.4rem 0 0.16rem 0;

      @media #{$pad_landscape_query} {
        font-size: 0.28rem;
        line-height: 0.34rem;
        padding: 0.36rem 0 0.14rem 0;
      }
    }
  }
</style>