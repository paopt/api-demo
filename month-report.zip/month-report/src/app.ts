// @ts-nocheck 目前太多组件，暂时不检查
import { compareVersion, deviceInfo } from "@kada/library/src/device"
import { INNER_APP_NAME_ENUM } from "@kada/lib-ua-parser"
import { appDownload } from "@/utils/url"
import { showTypedDialog, DIALOG_TYPE, toast } from "@kada/svelte-activity-ui"
import URLParser from "@/lib/urlParser"
import { IUser, getUserInfo } from "@/services/user"
import {
  getTotalInfo,
  getFavoriteInfo,
  getRecommendInfo,
  getTrendInfo,
  ITotalInfo,
  ITrendItem,
  IRecommendInfo,
  IFavoriteInfo,
  getUserId
} from "@/services/report"
import { sendReportBehavior } from "@/lib/analytics"
import { onShow as onWebviewShow } from "@kada/jsbridge"

export type PageData = {
  userInfo: IUser
  totalInfo: ITotalInfo
  trendInfo: ITrendItem[]
  recommendInfo: IRecommendInfo
  favoriteInfo: IFavoriteInfo
  isLogin?: boolean
}

// 页面数据缓存
let pageDataCache: PageData

const url = location.href
const parsed = new URLParser(url)
// 阅读报告日期
export let date = parsed.query.date
// 渠道Id
export let channelId = parsed.query.channelId
// 用户id，浏览器使用
export let userIdStr = parsed.query.u || parsed.query.userIdStr
// 用户id，目前仅浏览器打点使用
export let userId = ''

console.log("页面参数：", date, channelId, userIdStr)

/**
 * 获取页面数据
 * @param refresh 是否强制刷新，否则使用缓存
 */
export async function getPageData(refresh: boolean = false): Promise<PageData> {
  if (pageDataCache && !refresh) {
    return pageDataCache
  }

  try {
    if (deviceInfo.isKadaClient) {
      // 客户端版本检查
      const shouldUpdate = compareVersion({
        [INNER_APP_NAME_ENUM.KADA]: {
          version: "8.7.0",
          operator: "<",
        },
      })
      if (shouldUpdate) {
        showTypedDialog({
          type: DIALOG_TYPE.APP_UPGRAGE,
          theme: "new2021",
          title: "版本过低",
          message: "请到应用市场更新您的应用",
          buttonText: "立即更新",
          onDone() {
            appDownload()
          },
        })
        return
      }
    }
    // 用户信息
    const arr = [getUserInfo(userIdStr)]
    // 浏览器根据userIdStr查询userId， app不用
    if (!deviceInfo.isKadaClient) {
      arr.push(getUserId(userIdStr))
    }
    const [res, id] = await Promise.all(arr)
    // 保存userId
    userId = id
    if (res?.code === 200) {
      const userInfo = res.data
      // 阅读报告数据
      let [totalInfo, trendInfo, recommendInfo, favoriteInfo] = await Promise.all([
        getTotalInfo(date, userIdStr),
        getTrendInfo(date, userIdStr),
        getRecommendInfo(date, userIdStr),
        getFavoriteInfo(date, userIdStr),
      ])

      // 设置缓存
      pageDataCache = {
        userInfo,
        totalInfo,
        trendInfo,
        favoriteInfo,
        recommendInfo,
      }
      return pageDataCache
    } else {
      // 打点
      sendReportBehavior('pgv_100102', {
        channelId,
        type: 3
      })

      // 非svip， 显示拦截弹窗
      showTypedDialog({
        type: DIALOG_TYPE.ENDED,
        theme: "new2021",
        title: "",
        message: "阅读报告为SVIP专属权益，开通SVIP可查看",
        buttonText: "立即开通",
        onDone: () => {
          if (deviceInfo.isKadaClient) {
            location.href = "kada://openvipcharge"
          } else {
            openApp()
          }
        },
      })

      // 返回阅读报告页面，重新刷新数据。webview会缓存页面
      let webviewShowedId = await onWebviewShow(() => {
        getPageData(true)
        removeWebviewEvent("onShow", webviewShowedId)
        webviewShowedId = 0
      })
    }
    return pageDataCache
  } catch (error) {
    console.log("获取信息失败, ERROR:", error)
  }
  return pageDataCache
}

const openApp = () => {
  // KaDa阅读下载地址
  const KADA_APP_DOWNLOAD_URL = "https://a.app.qq.com/o/simple.jsp?pkgname=com.hhdd.kada"
  const KADA_APP_OPEN_IN_APPSTORE = "itms-apps://itunes.apple.com/app/id990142347"

  if (deviceInfo.ios) {
    location.href = KADA_APP_OPEN_IN_APPSTORE
  } else {
    location.href = KADA_APP_DOWNLOAD_URL
  }
}
