// @ts-nocheck 目前太多组件，暂时不检查
import { compareVersion, deviceInfo } from "@kada/library/src/device"
import { INNER_APP_NAME_ENUM } from "@kada/lib-ua-parser"
import { appDownload } from "@/utils/url"
import { showTypedDialog, DIALOG_TYPE } from "@kada/svelte-activity-ui"
import URLParser from "@/lib/urlParser"
import { IUser, getUserInfo, getUserId } from "@/services/user"
import {
  getTotalInfo,
  getFavoriteInfo,
  getRecommendInfo,
  getTrendInfo,
} from "@/services/report"
import { sendReportBehavior } from "@/lib/analytics"
import { onShow as onWebviewShow, remove as removeWebviewEvent } from "@kada/jsbridge"

// 解析url参数
const parsed = new URLParser(location.href)
export let date = parsed.query.date
export let channelId = parsed.query.channelId
export let userIdStr = parsed.query.u || parsed.query.userIdStr
export let userId: number = null
export let userInfo: IUser = null

console.log("页面参数：", date, channelId, userIdStr)

export function updateDate(d: string) {
  date = d
}

/**
 * 打开 KaDa app
 */
export const openApp = () => {
  // KaDa阅读下载地址
  const KADA_APP_DOWNLOAD_URL = "https://a.app.qq.com/o/simple.jsp?pkgname=com.hhdd.kada"
  const KADA_APP_OPEN_IN_APPSTORE = "itms-apps://itunes.apple.com/app/id990142347"

  if (deviceInfo.ios) {
    location.href = KADA_APP_OPEN_IN_APPSTORE
  } else {
    location.href = KADA_APP_DOWNLOAD_URL
  }
}

/**
 * 获取用户信息
 */
export async function getUser() {
  console.log('app::getUser fetch')
  // 客户端版本检查
  if (deviceInfo.isKadaClient) {
    const shouldUpdate = compareVersion({
      [INNER_APP_NAME_ENUM.KADA]: {
        version: "8.7.0",
        operator: "<",
      },
    })
    if (shouldUpdate) {
      showTypedDialog({
        type: DIALOG_TYPE.APP_UPGRAGE,
        theme: "new2021",
        title: "版本过低",
        message: "请到应用市场更新您的应用",
        buttonText: "立即更新",
        onDone() {
          appDownload()
        },
      })
      return
    }
  }
  try {
    const arr = [getUserInfo(userIdStr)]
    // 浏览器根据userIdStr查询userId， app不用
    if (!deviceInfo.isKadaClient && userIdStr) {
      arr.push(getUserId(userIdStr))
    }
    const [res, id] = await Promise.all(arr)
    if (res.code === 200) {
      userInfo = res.data
      userId = id
      return true
    } else {
      // 打点
      let path = location.hash
      let key = path.includes('#/report') ? 'pgv_100202' : 'pgv_100201'
      sendReportBehavior(key, {
        channelId,
        type: 3
      })
      // 非svip， 显示拦截弹窗
      showTypedDialog({
        type: DIALOG_TYPE.ENDED,
        theme: "new2021",
        title: "",
        message: "阅读报告为SVIP专属权益，开通SVIP可查看",
        buttonText: "立即开通",
        onDone: () => {
          if (deviceInfo.isKadaClient) {
            location.href = "kada://openvipcharge"
          } else {
            openApp()
          }
        },
      })
      // 返回阅读报告页面，重新刷新数据。webview会缓存页面
      let webviewShowedId = await onWebviewShow(() => {
        getUser()
        removeWebviewEvent("onShow", webviewShowedId)
        webviewShowedId = 0
      })
    }
  } catch(err) {
    console.log('getUser fetch Error::', err)
  }
  return false
}

/**
 * 获取阅读报告数据
 * @returns 
 */
export async function getReportData() {
  // 阅读报告数据
  let [totalInfo7, totalInfo, trendInfo, recommendInfo, favoriteInfo] = await Promise.all([
    getTotalInfo('2023-07', userIdStr),
    getTotalInfo(date, userIdStr),
    getTrendInfo(date, userIdStr),
    getRecommendInfo(date, userIdStr),
    getFavoriteInfo(date, userIdStr),
  ])

  return {
    totalInfo7,
    totalInfo,
    trendInfo,
    recommendInfo,
    favoriteInfo
  }
}
