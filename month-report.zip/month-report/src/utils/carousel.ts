/**
 * 滑屏配置参数
 */
interface CarouselOptions {
  ele: HTMLElement;
  autoplay?: boolean; // 自动播放
  interval?: number; // 间隔时间，autoplay为true有效
  callback?: Function;
}

/**
 * 滑屏分页
 */
export class Carousel {
  // 滑屏配置参数
  options: CarouselOptions
  // 分页数量
  size: number
  // 是否正在滑动
  isTouching: boolean
  // 滑动开始位置
  touchY: number
  // 滑动距离
  disY: number

  constructor(options: CarouselOptions) {
    this.options = {
      autoplay: false,
      ...options
    }
    this.init()
  }

  init() {
    console.log(window.innerWidth, window.innerHeight)
    const { ele } = this.options
    if (!ele) {
      console.error('ele不能为空')
      return
    }
    this.size = ele.children.length
    this.disY = 0
    this.touchY = 0
    this.isTouching = false

    const touchstartFn = e => {
      this.isTouching = true
      this.touchY = e.changedTouches[0].clientY
    }
    ele.addEventListener('touchstart', touchstartFn)

    const touchmoveFn = e => {
      if (!this.isTouching) {
        return
      }
      const y = e.changedTouches[0].clientY
      const disY = y - this.touchY
      const dis = this.disY + disY
      if (this.check(dis, disY < 0)) {
        ele.style.transform = `translateY(${dis}px)`
      }
    }
    ele.addEventListener('touchmove', touchmoveFn)

    const touchendFn = e => {
      this.isTouching = false
      const y = e.changedTouches[0].clientY
      const disY = y - this.touchY
      const percent = disY / this.getPageHeight()
      if (Math.abs(percent) < 0.1) {
        this.goPage(0)
      } else {
        if (disY > 0) {
          this.goPage(-1)
        } else {
          this.goPage(1)
        }
      }

      // 移除事件
      // ele.removeEventListener('touchstart', touchstartFn)
      // ele.removeEventListener('touchmove', touchmoveFn)
    }

    ele.addEventListener('touchend', touchendFn)

    // ele.addEventListener('wheel', e => {
    //   console.log(e.deltaY)
    //   if (e.deltaY > 0) {
    //     this.goPage(1)
    //   } else {
    //     this.goPage(-1)
    //   }
    // })

    return () => {
      ele.removeEventListener('touchend', touchendFn)
    }
  }

  /**
   * 滚动页面
   * @param page：1、向下；-1、向上；0、不变
   */
  goPage(page: number) {
    const height = this.getPageHeight()
    const nowPage = this.getCurrentPage()
    const nextPage = nowPage + page
    const dis = -nextPage * height
    if (this.check(dis, page > 0)) {
      if (this.options.callback && nextPage !== nowPage) {
        this.options.callback(nextPage)
      }
      this.disY = dis
      this.options.ele.style.transform = `translateY(${dis}px)`
    }
    // requestAnimationFrame(() => {
    // })
  }

  /**
   * 返回一页高度
   */
  getPageHeight(): number {
    return Math.round(this.options.ele.offsetHeight / this.size)
  }

  /**
   * 返回当前页
   */
  getCurrentPage(): number {
    const height = this.getPageHeight()
    const num = Math.floor(Math.abs(this.disY) / height)
    return num;
  }

  /**
   * 检查滑动距离是否合理
   * @param dis 滑动距离
   * @param isUp 是否向上滑动 
   * @returns 
   */
  check(dis: number, isUp: boolean): boolean {
    console.log(dis, isUp)
    const height = this.getPageHeight() * (this.size - 1)
    if (dis > 0 || Math.abs(dis) > height) {
      return false
    }
    return true
  }
}