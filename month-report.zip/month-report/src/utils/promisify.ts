/**
 * 延迟执行任务
 */
export function promiseDelay (time: number = 0): Promise<number> {
  return new Promise<number>((resolve) => {
    return setTimeout(resolve, time)
  })
}

/**
 * 加载图片
 * @param url
 */
export function promiseLoadImage (url: string): Promise<HTMLImageElement> {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    let img: HTMLImageElement = new Image()
    img.onload = () => {
      resolve(img)
      img = null
    }
    img.crossOrigin = 'anonymous'
    img.onerror = reject

    img.src = url

    return img
  })
}
