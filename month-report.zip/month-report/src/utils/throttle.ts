export function debounce<T extends Function, P> (func: T, wait: number, immediate: boolean = false): <R extends T>(...args: P[]) => R {
  let timeout
  return (...args: P[]) => {
    const later = () => {
      timeout = null
      if (!immediate) {
        return func(...args)
      }
    }

    const callNow = immediate && !timeout
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)

    if (callNow) {
      return func(...args)
    }
  }
}

export function throttle<T extends Function, P> (func: T, delay: number): <R extends T> (this: void, ...args: P[]) => R {
  let lastCall = 0
  return (...args: P[]) => {
    const now = new Date().getTime()
    if (now - lastCall < delay) {
      return
    }
    lastCall = now
    return func(...args)
  }
}
