type Rect = {
  top: number;
  left: number;
  width: number;
  height: number;
};

/**
 * 矩形区域是否相交，用于检测区块在容器内是否可见
 * @param rect1 子版块区域
 * @param rect2 容器区域
 *
 * @returns 相对子版块显示比率
 */
export function getIntersectionRatio (rect1: Rect, rect2: Rect): number {
  const xMin = Math.max(rect1.left, rect2.left)
  const yMin = Math.max(rect1.top, rect2.top)
  const xMax = Math.min(rect1.left + rect1.width, rect2.left + rect2.width)
  const yMax = Math.min(rect1.top + rect1.height, rect2.top + rect2.height)

  const width = Math.min(xMax - xMin, rect1.width)
  const height = Math.min(yMax - yMin, rect1.height)

  if (width <= 0 || height <= 0) {
    return 0
  }

  const crossSquare = width * height

  return crossSquare / (rect1.width * rect1.height)
}

export function decimalAdjust (type, value, exp) {
  // If the exp is undefined or zero...
  if (typeof exp === 'undefined' || +exp === 0) {
    return Math[type](value);
  }
  value = +value;
  exp = +exp;
  // If the value is not a number or the exp is not an integer...
  if (isNaN(value) || !(typeof exp === 'number' && exp % 1 === 0)) {
    return NaN;
  }
  // Shift
  value = value.toString().split('e');
  value = Math[type](+(value[0] + 'e' + (value[1] ? (+value[1] - exp) : -exp)));
  // Shift back
  value = value.toString().split('e');
  return +(value[0] + 'e' + (value[1] ? (+value[1] + exp) : exp));
}