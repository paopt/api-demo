import { typeConvertor } from './string-type-convertor.js'

/**
 * 属性支持的数据类型
 * @typedef {("string"|"number"|"bigint"|"boolean"|"symbol"|"undefined"|"object"|"array"|"function")} PropType
 */
export const PropType = {
  string: 'string',
  number: 'number',
  bigint: 'bigint',
  boolean: 'boolean',
  symbol: 'symbol',
  undefined: 'undefined',
  object: 'object',
  array: 'array',
  function: 'function'
}

/**
 * 属性支持的数据类型列表
 * @typedef {PropType[]} PropTypeList
 */

/**
 * 检查基础数据类型
 * @param {*} value 数值
 * @param {("string"|"number"|"bigint"|"boolean"|"symbol"|"undefined")} type 数据类型
 * @returns {Boolean} 是否符合类型
 */
function testPrimitiveType (value, type) {
  const reg = new RegExp(`^${type}$`, 'i')

  return reg.test(typeof value)
}

/**
 * 检查复杂数据类型
 * @param {*} value
 * @param {*} valueTypes
 * @param {*} defaultValue
 * @returns
 */
function testComplexType (value, type) {
  if (typeof type === 'function') {
    return value instanceof type
  }

  if (typeof type === 'string') {
    if (['Array', 'array'].includes(type)) {
      return Array.isArray(value)
    }

    return Object.prototype.toString.call(value) === `[object ${type}]`
  }

  if (typeof type === 'object') {
    const proto = Object.getPrototypeOf ? Object.getPrototypeOf(type) : type.__proto__

    if (proto && proto.constructor && proto.constructor.name) {
      return Object.prototype.toString.call(value) === `[object ${proto.constructor.name}]`
    }

    return value === type
  }

  return false
}

/**
 * 将传入值转成指定
 * @param {*} value 属性值
 * @param {PropType|PropTypeList} valueTypes 支持数据类型
 * @param {*} defaultValue 转换类型失败后默认值
 * @returns {*}
 */
export function convertPropType (value, valueTypes, defaultValue) {
  const originType = typeof val
  const isPrimitiveType = ['string', 'number', 'bigint', 'boolean', 'symbol', 'undefined'].includes(originType)

  const typedValue = typeConvertor(value, [{
    test: (val) => {
      if (Array.isArray(valueTypes)) {
        return valueTypes.some(type => {

          if (isPrimitiveType) {
            return !testPrimitiveType(val, type)
          }

          return !testComplexType(val, type)
        })
      }

      if (isPrimitiveType) {
        return !testPrimitiveType(val, valueTypes)
      }

      return !testComplexType(val, valueTypes)
    },
    convert: (val) => {
      const type = Array.isArray(valueTypes) ? valueTypes[0] : valueTypes

      if (typeof type === 'function') {
        return type(val)
      }

      if (type === 'boolean') {
        return val !== void(0) && val !== null && val !== 'false'
      }

      if (type === 'string') {
        return val + ''
      }

      if (type === 'object') {
        let result = val
        try {
          result = JSON.parse(val)
        } catch (error) {}

        return result
      }

      return typeConvertor(val)
    }
  }])

  return (typeof typedValue !== 'undefined' || !isNaN(typedValue)) ? typedValue : defaultValue
}
