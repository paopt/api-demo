import { SvelteComponent } from 'svelte/internal'

/**
 * 判断是否为SvelteComponent
 */
export function isSvelteComponent (object: any): boolean {
  const proto = object && Object.getPrototypeOf(object)
  return !!((typeof object === 'function')
    && (
      Object.prototype.isPrototypeOf.call(SvelteComponent, object)
      || object.prototype instanceof SvelteComponent
      || (proto && /component/i.test(proto.name))
    )
  )
}

/**
 * 是否为Function
 */
export function isFunction (object: any): boolean {
  return typeof object === 'function'
}

/**
 * 是否为Promise
 */
export function isPromise (obj: any): boolean {
  return !!obj && (typeof obj === 'object' || isFunction(obj)) && isFunction(obj.then)
}
