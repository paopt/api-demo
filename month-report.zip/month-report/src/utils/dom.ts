/**
 * 获取所有匹配的父级DOM
 * @param el 目标元素
 * @param selector 父级选择器
 * @returns
 */
export function getAllParents (el: HTMLElement, selector: string): HTMLElement[] {
  const parents: HTMLElement[] = []
  let parent = el.parentElement
  while (parent) {
    if (parent.matches(selector)) {
      parents.push(parent)
    }
    parent = parent.parentElement
  }
  return parents
}

/**
 * 获取父级DOM
 * @param el 目标元素
 * @param selector 父级选择器
 * @returns
 */
export function getParent (el: HTMLElement, selector: string): HTMLElement {
  let parent = el.parentElement
  while (parent) {
    if (parent.matches(selector)) {
      return parent
    }
    parent = parent.parentElement
  }
  return null
}

/**
 * rem值转换为px值
 * @param rem 原始值
 * @returns
 */
export function rem2px (rem: number): number {
  if (window.kadaRemLayout && window.kadaRemLayout.rem2px) {
    return window.kadaRemLayout.rem2px(rem)
  }

  return rem * parseFloat(getComputedStyle(document.documentElement).fontSize)
}
