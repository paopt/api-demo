interface PieChartItem {
  categoryName: string;
  count: number;
  color?: string;
  percent?: number;
  [propName: string]: any;
}

interface PieChartOptions {
  id: string,
  width: number;
  height: number;
  data: PieChartItem[];
  valueColors?: string[][];
  labelColors?: string[];
}

export class PieChart {
  ctx: CanvasRenderingContext2D
  options: PieChartOptions
  // 动画相关
  index = 1
  num = 50
  speed = 15
  constructor(options: PieChartOptions) {
    const defaultOptions = {
      valueColors: [
        ['#FF0F42', '#FDADC9'],
        ['#FF496A', '#FE7D9B'],
        ['#F77F7F', '#FB86A2'],
        ['#FE9BA1', '#F49099'],
        ['#FFC8BC', '#FF96A2'],
        ['#FDE0DD', '#FECCC8'],
      ],
      labelColors: ['#FF194B', '#FE5576', '#F78080', '#FE9BA1', '#FFB8B3', '#FFDCD9']
    }
    this.options = { ...defaultOptions, ...options }
    this.init()
  }

  /**
   * canvas初始化
   */
  init() {
    const { id, width, height, data } = this.options
    const canvas: HTMLCanvasElement = document.querySelector(`#${id}`)
    if (!canvas) {
      console.error('canvas 不能为空')
      return 
    }
    this.ctx = canvas.getContext('2d')

    // 设置宽高
    canvas.style.width = `${width}px`
    canvas.style.height = `${height}px`
    // 高清屏处理
    const ratio = window.devicePixelRatio
    canvas.width = width * ratio
    canvas.height = height * ratio
    this.ctx.scale(ratio, ratio)

    // 设置透明背景颜色
    this.ctx.fillStyle = 'transparent'
    this.ctx.fillRect(0, 0, width, height)

    // 数据处理
    if (!data) {
      console.error('data不能为空')
      return
    }

    let sum = 0;
    data.forEach(item => {
      sum += item.count
    })
    data.forEach(item => {
      item.percent = Number((item.count / sum))
    })
    data.sort((a, b) => b.count - a.count)
    // 绘制
    this.drawPie()
    this.drawMarkers()
  }

  /**
   * 绘制饼图
   */
  drawPie() {
    const radius1 = 122
    const radius2 = 107
    const radius3 = 92
    const cx = 122
    const cy = 122
    let startAngle = 0
    let endAngle = 0

    this.ctx.save()
    this.ctx.translate(cx, cy)
    // 旋转动画
    this.ctx.rotate(Math.PI * this.index / this.num)

    // 绘制外圈
    this.ctx.beginPath()
    this.ctx.lineWidth = 1
    this.ctx.strokeStyle = 'rgba(255,255,255,0.6)'
    this.ctx.arc(0, 0, radius1 * this.index / this.num, 0, Math.PI * 2, false);
    this.ctx.stroke();
    // 绘制内圈
    this.ctx.beginPath()
    this.ctx.fillStyle = 'rgba(255,149,173,0.2)'
    this.ctx.arc(0, 0, radius2 * this.index / this.num, 0, Math.PI * 2, false);
    this.ctx.fill();
    // 绘制内圈扇形
    this.ctx.beginPath()
    const { data, width, height, valueColors } = this.options
    data.forEach((item, i) => {
      let radius = radius3
      // 最大值
      if (i === 0 && data[i].count > data[i + 1].count) {
        radius = radius2
      }
      endAngle = endAngle + (item.percent * this.index / this.num) * Math.PI * 2
      this.ctx.beginPath()
      this.ctx.moveTo(0, 0)
      this.ctx.arc(0, 0, radius * this.index / this.num, startAngle, endAngle)
      this.ctx.fillStyle = this.getColor2(valueColors[i], radius)
      this.ctx.closePath()
      this.ctx.fill()

      startAngle = endAngle
      if (i === data.length - 1) {
        startAngle = endAngle = 0
      }
    })
    this.ctx.restore()
    this.drawMarkers()

    // 绘制动画动画
    if (this.index < this.num) {
      this.index++
      requestAnimationFrame(() => {
        this.ctx.clearRect(0, 0, width, height)
        this.drawPie()
        this.drawMarkers()
      })
    }
  }

  /**
   * 绘制图例
   */
  drawMarkers() {
    const posX = 253
    const posY = 41
    const textX = 263
    const textY = 35
    const { data, labelColors } = this.options
    this.ctx.textBaseline = 'top'
    data.forEach((item, i) => {
      this.ctx.beginPath()
      this.ctx.fillStyle = labelColors[i]
      this.ctx.arc(posX, posY + 30 * i, 6, 0, Math.PI * 2, false)
      this.ctx.fill()
      this.ctx.moveTo(posX, posY + 30 * i)
      this.ctx.font = '14px FZLANTY_ZHONGCUJW--GB1'
      this.ctx.fillStyle = '#333'
      let label = item.categoryName + (item.percent * 100).toFixed(0) + '%'
      this.ctx.fillText(label, textX, textY + 30 * i)
    })
  }

  /**
   * 线性渐变
   * @param colors 
   * @returns 
   */
  getColor(colors: string[]) {
    const gradient = this.ctx.createLinearGradient(0,0,0,100);
    gradient.addColorStop(0, colors[0]);
    gradient.addColorStop(1, colors[1]);
    return gradient
  }

  /**
   * 径向渐变
   * @param colors 
   */
  getColor2(colors: string[], radius: number) {
    const gradient = this.ctx.createRadialGradient(0, 0, 0, 0, 0, radius * 1.2)
    gradient.addColorStop(0, colors[0])
    gradient.addColorStop(1, colors[1])
    return gradient
  }
}