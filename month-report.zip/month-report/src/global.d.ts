declare interface Window {
  _vconsole_: any;
  webkitDevicePixelRatio: number;
  kadaRemLayout: {
    clearEvents: () => {},
    dpr: number,
    px2rem: (px: number) => number,
    rem: number,
    rem2px: (rem: number) => number,
    setRemUnit: (rem: number) => void,
  }
}

declare const __APP_PACKAGE_NAME__: string;
declare const __APP_VERSION__: string;
declare const __APP_ENV_CONFIG__: any;

// 服务端接口返回数据格式
type ServerResponse<T> = {
  code: number;
  data: T;
  msg: string;
}
