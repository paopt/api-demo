// @ts-nocheck
import App from './App.svelte'
import { init as initJsbridge } from '@kada/jsbridge'
import { deviceInfo } from '@kada/library/src/device'
import '@kada/reset.css/scss/reset.scss'

const { isKadaClient, android, isPad } = deviceInfo
if (isKadaClient) {
  // 初始化jsbridge延长等待时间
  initJsbridge({
    safetyTimeout: 8000,
  })
}
// 修复在VIVO X21A 设备上面，导致初次remLayout获取宽度错误
if (typeof window.kadarem === 'function' && android && !isPad) {
  window.kadaRemLayout = window.kadarem({ designWidth: 750, maxClientWidth: 480 })
}

const app = new App({
  target: document.body,
})

export default app
