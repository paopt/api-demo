import 'svelte/register'
import App from './skeleton.svelte'

// @ts-ignore
const { html, css, head } = App.render()

module.exports = {
  html,
  css: css.code,
  head
}
