// @ts-nocheck
import { initAnalytics } from '@kada/library/src/analytics'
import config from './config'
import { getApi, fetch } from '@/lib/fetch'
import { compareVersion, deviceInfo } from "@kada/library/src/device"
import { formatDate } from '@/utils/timer'
import { userId } from '../app'

const { uwebId: siteId } = config
  // @ts-ignore
/**
 * 用户行为上报
 * @param trackName 上报事件名称
 * @param trackData 上报内容
 * @param isPageView 是否为页面展示
 */
let analyticsInstance = null
export const sendBehavior = (trackName: string, trackData?: any, isPageView?: boolean) => {
  if (!analyticsInstance) {
    analyticsInstance = initAnalytics({
      siteId,
      commitHabitApi: getApi('habit', 'commitUserHabit.json')
    })
  }
  setTimeout(() => analyticsInstance(trackName, trackData, isPageView))
}

/**
 * 阅读报告用户行为上报
 * @param trackName 事件名称
 * @param params 事件名称参数
 * @param trackData body参数
 * @param isPageView 是否为页面展示
 */
export function sendReportBehavior(trackName: string, trackParams: any, trackData: any, isPageView: boolean) {
  if (!trackName) {
    console.error('缺少打点事件名称')
    return
  }
  if (trackParams) {
    const arr = []
    Object.keys(trackParams).forEach(k => {
      const v = trackParams[k]
      if (v !== undefined || v!== null || v!== '') {
        arr.push(v)
      }
    })
    if (arr.length) {
      trackName += '_' + arr.join('_')
    }
  }

  // app
  if (deviceInfo.isKadaClient) {
    sendBehavior(trackName, trackData, isPageView)
  } else {
    // h5
    sendBehaviorH5(trackName, trackData, isPageView)
  }
}

  /**
   * 用户行为上报
   * @param {String} trackName 上报事件名称
   * @param {Object} trackData 上报内容
   * @param {Boolean} isPageView 是否为页面展示
   */
  function sendBehaviorH5 (trackName, trackData, isPageView = false)  {
    if (!trackName) {
      throw Error('trackName埋点名称为必填！')
    }

    trackData = trackData ? trackData : {}
    trackData.userId = userId

    // 客户端与友盟都仅支持'key1,key2,...'形式传递数据 这里做格式转换处理
    let trackContent = ''
    const trackKeys = trackData ? Object.keys(trackData) : []
    if (trackKeys.length !== 0) {
      const newTrackKeys = trackKeys.reduce((arr, key) => {
        arr.push(trackData[key])
        return arr
      }, [])
      trackContent = newTrackKeys.join(',')
    }

    const data = [{
      name: trackName,
      content: trackContent,
      triggerTime: formatDate(Date.now(), 'YYYY-MM-DD HH:mm:ss')
    }]

    const commitHabitApi = getApi('habit', 'h5/commit.json')
    fetch.post(commitHabitApi, data, {
      headers: {
        'Content-Type': 'application/json'
      }
    })
  }
  
