// @ts-ignore
import WechatJSSDK, { DEFAULT_API_LIST } from '@kada/wechat-jssdk'
// @ts-ignore
import config from '@/lib/config'
import { getWechatConfig } from '@/services/partner'

const wechat = new WechatJSSDK({
  title: 'KaDa故事',
  desc: '好故事都在这儿',
  link: location.href,
  imgUrl: 'https://cdn.hhdd.com/frontend/assets/img/icon-app-logo-square.png',
  type: 'link',
  dataUrl: '',
  success: function () {},
  fail: function () {},
  cancel: function () {},
  trigger: function () {},
  complete: function () {}
})

export async function initWechatConfig () {
  try {
    const { code, data = {} } = await getWechatConfig(location.href.split('#')[0])

    if (code === 200) {
      const { appId, timestamp, nonceStr, signature } = data

      wechat.initialize({
        debug: config.env === 'development', // 开启调试模式
        appId, // 公众号的唯一标识
        timestamp, // 生成签名的时间戳
        nonceStr, // 生成签名的随机串
        signature, // 签名
        beta: true,
        jsApiList: DEFAULT_API_LIST.concat('hideOptionMenu'), // 需要使用的JS接口列表
        sourceUrl: 'https://res.wx.qq.com/open/js/jweixin-1.4.0.js'
      })

      return true
    }
  } catch (e) {
    console.error(e)
  }

  return false
}

export default wechat
