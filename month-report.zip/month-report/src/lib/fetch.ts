import config from './config'
import { initFetch } from '@kada/library/src/fetch'

console.log(config)
export const { getApi, fetch } = initFetch(config)
