/**
 * 活动音频播放管理
 */
import { Sound } from '@kada/library/src/sound'

// 声道配置项
type SoundChannelOptions = {
  id: string; // 声道ID
  volume?: number; // 音量
  loop?: boolean; // 是否循环
  autoplay?: boolean; // 是否自动播放
  webAudio?: boolean; // 是否使用webAudio
}

// 声道管理器配置项
type SoundManagerOptions = {
  channels: SoundChannelOptions[]; // 声道配置
}

export class SoundManager {
  soundChannels: { [id: string]: Sound }

  constructor (options: SoundManagerOptions) {
    const { channels = [] } = options

    this.soundChannels = channels.reduce((previousValue, item) => {
      let config = item
      if (typeof item === 'string') {
        config = {
          id: item
        }
      }

      previousValue[item.id] = new Sound({
        ...config
      })

      return previousValue
    }, {})
  }

  getSoundChannelById (channelId) {
    const channelSound = this.soundChannels[channelId]

    if (!channelSound) {
      throw new Error(`ChannelSound[${channelId}] 声道不存在`)
    }

    return channelSound
  }

  destroy () {
    Object.keys(this.soundChannels).forEach(id => {
      const channelSound = this.soundChannels[id]

      if (!channelSound) {
        channelSound.destroy()
        this.soundChannels[id] = null
      }
    })
    soundManager = null
  }
}

let soundManager = null
export default function getSoundManager () {
  if (!soundManager) {
    soundManager = new SoundManager({
      channels: [
        // 背景音频
        {
          id: 'bgsound',
          volume: 1, // 音频音量,  默认1
          loop: true, // 音频是否循环,  默认false
          autoplay: true, // 音频是否自动播放,  默认false
          webAudio: false //  是否开启webaudio模式， 默认false
        },
        // 语音音道
        {
          id: 'voice',
          volume: 1,
          loop: false,
          autoplay: false,
          webAudio: false
        },
        // 音效
        {
          id: 'effect',
          volume: 2.5,
          loop: false,
          autoplay: false,
          webAudio: true
        }
      ]
    })
  }

  return soundManager
}
