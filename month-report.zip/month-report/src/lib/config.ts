/* 项目全局基本属性相关 */
const env = process.env.APP_ENV || 'production'
const project = {
  name: __APP_PACKAGE_NAME__,
  version: __APP_VERSION__,
}
const envConfig = __APP_ENV_CONFIG__


console.log('环境', env)

export default {
  env,
  project,
  isDebug: env !== 'staging' && env !== 'production',
  ...envConfig,
}
