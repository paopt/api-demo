<div class="o-app">
  <Router hashchange>
    <div class="o-app__body">
      <Route exact path="/report">
        {#await initPage() then module}
          {#if pageData}  
            <svelte:component this={module} bind:this={homeEl} {pageData} reload={homeReload} pageLoaded={!pageLoading} on:refresh={handleRefresh} />
          {/if}
        {/await}
      </Route>
      <Route exact path="/summary" component={SummaryComponent} />
      <Route exact path="/feedback" component={FeedbackComponent} />
    </div>
    <Route exact redirect="/report" />
    <Route fallback component={NotFound} />
  </Router>
</div>

<script context="module" lang="ts">
  const moduleCache = new Map<string, any>()
</script>

<script lang="ts">
  import type { SvelteComponent } from 'svelte'
  // @ts-ignore
  import { Router, Route } from '@kada/yrv'
  import NotFound from '@/views/NotFound.svelte'
  import { getPageData, PageData } from './app'
  import './styles/global.scss'
  import { deviceInfo } from '@kada/library/src/device'
  import URLParser from '@/lib/urlParser'
  import FeedbackComponent from './views/feedback.svelte';
  import SummaryComponent from './views/summary.svelte';
  
  // @ts-ignore
  Router.hashchange = true

  let homeEl: any

  // 首页是否处于加载状态
  let pageLoading: boolean = true

  let pageData: PageData

  // 首页是否重新加载
  let homeReload = true

  let flag  = 1

  /**
   * 初始化首页
   */
  async function homeLoader () {
    const moduleName = '@/views/report.svelte'
    if (moduleCache.has(moduleName)) {
      homeReload = false
      return moduleCache.get(moduleName)
    }

    const module = await import('@/views/report.svelte')

    moduleCache.set(moduleName, module.default)
    homeReload = true
    return module.default
  }

  /**
   * 初始化页面
   */
  async function initPage (): Promise<{ module: SvelteComponent }> {

    let [data, module] = await Promise.all([getPageData(true), homeLoader()])

    // @ts-ignore
    if (typeof window.kadarem === 'function' && deviceInfo.isPad) {
      // @ts-ignore
      window.kadaRemLayout = window.kadarem({ designWidth: flag ? 2048 : 1024, maxClientWidth: 1536 })
    }

    if (!data) {
      pageData = null
      return module
    }

    if (pageLoading) {
      pageLoading = false
    }
    pageData = data

    return module
  }

  async function handleRefresh () {
    // 刷新数据
    pageData = await getPageData(true)
  }
</script>

<style lang="scss">
  @import './styles/variables';
  $page-name: 'o-app';

  .#{$page-name} {
    height: 100%;

    &__body {
    }

    @media #{$pad_landscape_query} {
      &__body {

      }
    }
  }
</style>
