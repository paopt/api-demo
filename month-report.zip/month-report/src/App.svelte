<div class="o-app l-maxwidth">
  <Router hashchange>
    <Route exact path="/report">
      {#if isValidation}
        <ReportComponent></ReportComponent>
      {/if}
    </Route>
    <Route exact path="/summary">
      {#if isValidation}
        <SummaryComponent></SummaryComponent>
      {/if}
    </Route>
    <Route exact path="/feedback">
      {#if isValidation}
        <FeedbackComponent></FeedbackComponent>
      {/if}
    </Route>
    <Route exact path="/quarter">
      {#if isValidation}
        <QuarterComponent></QuarterComponent>
      {/if}
    </Route>
    <Route exact fallback component={NotFoundComponent} />
  </Router>
</div>

<script lang="ts">
  import { onMount } from 'svelte'
  import { Router, Route } from '@kada/yrv'
  import { deviceInfo } from '@kada/library/src/device'

  import './styles/global.scss'
  import FeedbackComponent from '@/views/feedback.svelte'
  import SummaryComponent from '@/views/summary.svelte'
  import ReportComponent from '@/views/report.svelte'
  import NotFoundComponent from '@/views/NotFound.svelte'
  import QuarterComponent from '@/views/quarter.svelte'
  import { getUser, checkVersion, showSVipDialog, showReportDialog, userInfo } from './app'
  import { sendReportBehavior } from '@/lib/analytics'
  import { channelId } from './app'

  // @ts-ignore
  Router.hashchange = true


  // 路由校验通过
  let isValidation = false

  initPage()

  onMount(() => {
    console.log('app::onMount')
  })

  function initPage (){
    check()
  }

  /**
   * 路由拦截
   */
  function check() {
    const path = location.hash
    if (path.includes('#/report') || path.includes('#/summary') || path.includes('#/feedback')) {
      checkReport().then(res => {
        isValidation = res
      })
    } else if (path.includes('#/quarter')) {
      checkQuarter().then(res => {
        isValidation = res
        console.log('check user', res)
      })
    }
  }

  /**
   * 阅读报告页面，路由拦截
   */
  async function checkReport() {
    if (!checkVersion('8.7.0', '<')) {
      return false
    }

    const res = await getUser()
    if (!res) {
      showSVipDialog()
      return false
    }
    return true
  }

  /**
   * 季度总结页面，路由拦截
   */
  async function checkQuarter() {
    if (!checkVersion('4.7.10', '<')) {
      return false
    }
    const res = await getUser(1)
    if (!res) {
      sendReportBehavior('pgv_100203_1_YY_1', {
        type: 1,
        channelId: channelId,
        type2: 1
      }, null, false)
      showReportDialog()
      return false
    }
    return true
  }
</script>

<style lang="scss">
  @import './styles/variables';
  $page-name: 'o-app';

  .#{$page-name} {
    overflow-x: hidden;
    margin: 0 auto;
    height: 100%;
  }
</style>
