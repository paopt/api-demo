<div class="o-app">
  <Router hashchange>
    <div class="o-app__body">
      <Route path="/report" component={ReportComponent}>
        <!-- {#await initPage() then module}
          {#if pageData}  
            <svelte:component this={module} bind:this={homeEl} {pageData} reload={homeReload} pageLoaded={!pageLoading} on:refresh={handleRefresh} />
          {/if}
        {/await} -->
      </Route>
      <Route path="/summary">
        {#if isLogin}
          <SummaryComponent></SummaryComponent>
        {/if}
      </Route>
      <Route path="/feedback" component={FeedbackComponent} />
    </div>
    <Route fallback component={NotFoundComponent} />
  </Router>
</div>

<script lang="ts">
  import { Router, Route } from '@kada/yrv'
  import { deviceInfo } from '@kada/library/src/device'

  import NotFoundComponent from '@/views/NotFound.svelte'
  import FeedbackComponent from '@/views/feedback.svelte';
  import SummaryComponent from '@/views/summary.svelte';
  import ReportComponent from '@/views/report.svelte';
  import './styles/global.scss'
  import { getUser } from './app'
  
  // @ts-ignore
  Router.hashchange = true

  // 是否支持pad
  let flag = 1

  // 是否获取到用户信息
  let isLogin = false

  initPage()

  function initPage (){
    // @ts-ignore
    if (typeof window.kadarem === 'function' && deviceInfo.isPad) {
          // @ts-ignore
      window.kadaRemLayout = window.kadarem({ designWidth: flag ? 2048 : 1024, maxClientWidth: 1536 })
    }

    // 查询用户信息
    getUser().then(res => {
      isLogin = res
    })
  }
</script>

<style lang="scss">
  @import './styles/variables';
  $page-name: 'o-app';

  .#{$page-name} {
    height: 100%;

    &__body {
    }

    @media #{$pad_landscape_query} {
      &__body {

      }
    }
  }
</style>
