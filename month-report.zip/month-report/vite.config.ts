import { defineConfig } from 'vite'
import * as fs from 'fs'
import * as path from 'path'
import glob from 'fast-glob'
import yaml from 'js-yaml'
import UglifyJS from 'uglify-js'
import sveltePreprocess from 'svelte-preprocess'
import { svelte } from '@sveltejs/vite-plugin-svelte'
import legacy from '@vitejs/plugin-legacy'
import { ViteEjsPlugin as ejs } from 'vite-plugin-ejs'

const cwd = process.cwd()
const root = path.join(cwd, 'src')

const env = process.env.APP_ENV || 'development'
const baseConfig = yaml.load(fs.readFileSync(path.resolve('./config/env.yaml'), 'utf-8'))
const envConfig = yaml.load(fs.readFileSync(path.resolve(`./config/env.${env}.yaml`), 'utf8'))
const config = { ...baseConfig, ...envConfig }
const { devServer, ...restConfig } = config
const pkg = JSON.parse(fs.readFileSync(path.resolve(`./package.json`), 'utf8'))
const deps = Object.keys(pkg.dependencies)
const { npm_package_name: packageName, npm_package_version: packageVersion } = process.env

let remLayoutCode = ''
const remLayoutPathname = path.resolve(cwd, 'node_modules/@kada/kada-rem-layout/lib/index.iife.js')
if (fs.existsSync(remLayoutPathname)) {
  const rawData = fs.readFileSync(remLayoutPathname, 'utf8')
  if (rawData) {
    remLayoutCode = UglifyJS.minify(rawData).code
  }
}

let base = '/'
if (env !== 'development') {
  base = `${restConfig.staticBaseUrl}${/\/$/g.test(restConfig.staticBaseUrl) ? '' : '/'}${packageName}`
}

const htmlEntry = glob.sync(`*.html`, {
  cwd: root
})
const rollupInputOptions = htmlEntry.reduce((acc, entry) => {
  acc[entry.replace(/\.html/i, '')] = path.resolve(root, entry)
  return acc
}, {})

// https://vitejs.dev/config/
export default defineConfig({
  root,
  base,
  mode: env === 'development' ? 'development' : 'production',
  define: {
    'process.env.APP_ENV': JSON.stringify(env),
    __APP_PACKAGE_NAME__: JSON.stringify(packageName),
    __APP_VERSION__: JSON.stringify(packageVersion),
    __APP_ENV_CONFIG__: JSON.stringify(restConfig),
  },
  resolve: {
    alias: {
      '@': root,
    },
  },
  plugins: [
    ejs({
      APP_ENV: env,
      REM_LAYOUT_CODE: remLayoutCode,
    }),
    svelte({
      preprocess: sveltePreprocess()
    }),
    legacy(),
  ],
  publicDir: '../public',
  build: {
    outDir: '../dist',
    // embuilder不支持 <= iOS11, Android <= 5.0.0 需要另外添加core-js@3.22.7; 否则会报错，期待vite解决此类问题
    minify: env === 'development' ? false : 'terser',
    rollupOptions: {
      input: rollupInputOptions,
      output: {
        strict: false,
      }
    }
  },
  optimizeDeps: {
    include: [
      // @kada依赖强制加入编译
      ...deps.filter(dep => dep.startsWith('@kada')).reduce((prev, dep) => {
        // @kada/library 组件库不完善，需要逐一文件加入编译
        if (/@kada\/library/i.test(dep)) {
          const files = glob.sync(`${dep}/**/*.js`, { cwd: path.resolve('node_modules') })
          prev.push(...files)
        }

        return prev
      }, []),
    ],
  },
  server: {
    ...devServer,
  }
})
