const path = require('path')

module.exports = {
  presets: [
    [
      '@babel/preset-env',
      {
        useBuiltIns: 'usage',
        corejs: 3
      }
    ]
  ],
  plugins: [
    'lodash',
    '@babel/plugin-transform-runtime'
    // ['import', {
    //   libraryName: '@kada/svelte-activity-ui',
    //   libraryDirectory: 'components',
    //   camel2DashComponentName: false,
    //   style: false
    // }, '@kada/svelte-activity-ui']
  ]
}
