const fs = require('fs')
const path = require('path')
const glob = require('glob')
const watch = require('glob-watcher')
const yaml = require('js-yaml')

const env = process.env.NODE_ENV || 'development'

/**
 * 编译yaml文件成json
 * @param {String} src yaml源文件地址
 * @param {String} dest 保存json文件地址
 */
function compilerYamlFile (src, dest) {
  try {
    const yamlData = fs.readFileSync(src, { encoding: 'utf8' })
    const jsonData = yaml.safeLoad(yamlData, {
      filename: src,
      json: true
    })

    if (jsonData) {
      fs.writeFileSync(dest, JSON.stringify(jsonData), {
        encoding: 'utf8'
      })
    }
  } catch (error) {
    console.error('compilerYamlFile: ERROR:', error)
  }
}

const yamlDir = path.resolve(__dirname, '../public/data/yaml/')
const configDir = path.resolve(__dirname, '../public/data/config/')

if (!fs.existsSync(configDir)) {
  fs.mkdirSync(configDir, { recursive: true })
}

/**
 * 编译所有 yaml 文件至 config 文件夹
 */
exports.compileFiles = () => {
  const yamlPaths = glob.sync('**/*.yaml', {
    cwd: yamlDir
  })

  const configPaths = yamlPaths.map(filename => {
    const yamlFilename = path.join(yamlDir, filename)
    const relativePath = filename
    const configRelativePath = relativePath.replace(/\.(yaml|yml)$/ig, '.json')
    compilerYamlFile(yamlFilename, path.join(configDir, configRelativePath))

    return `'${relativePath}' --> ${configRelativePath}`
  })

  console.log(`yaml文件夹：${yamlDir}`)
  console.log(configPaths.join('\n'))
}
exports.compileYamlFile = compilerYamlFile

function watchYamlChange () {
  const watcher = watch([`${yamlDir}**/*.yaml`], {
    ignoreInitial: false,
    delay: 400,
    events: ['add', 'change']
  })

  watcher.on('change', (filename) => {
    const relativePath = path.relative(yamlDir, filename)
    const configRelativePath = relativePath.replace(/\.(yaml|yml)$/ig, '.json')
    compilerYamlFile(filename, path.join(configDir, configRelativePath))
    console.log(`[change] ${relativePath} --> ${configRelativePath}`)
  })

  watcher.on('add', (filename) => {
    const relativePath = path.relative(yamlDir, filename)
    const configRelativePath = relativePath.replace(/\.(yaml|yml)$/ig, '.json')
    compilerYamlFile(filename, path.join(configDir, configRelativePath))
    console.log(`[add] ${relativePath} --> ${configRelativePath}`)
  })

  console.log(`正在监听 ${yamlDir} 目录`)
}

// 开发环境监听yaml变化，并编译成 config 文件夹下面的json文件
if (env === 'development' && (require.main || !module.parent)) {
  watchYamlChange()
}
