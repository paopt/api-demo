const kadaDeploy = require('@kada/static-deploy')
const pkg = require('../package.json')
const deployConfig = require('../.kadadeployrc.js')

const entries = deployConfig.entries

entries.forEach(async entry => {
  const target = `wepage/${pkg.name}/v${pkg.version}/${entry}`
  const symlink = `w/${pkg.name}/${entry}`
  const result = await kadaDeploy.symlink({
    env: 'production',
    target,
    symlink,
    serviceName: 'kada-h5'
  })

  console.log(`${symlink} --> ${target}`)
  console.log(result)
})
