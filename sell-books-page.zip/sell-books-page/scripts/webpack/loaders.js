const sveltePreprocess = require('svelte-preprocess')
const path = require('path')
const {
  env,
  dirs: {
    project: projectDir
  }
} = require('../env')

module.exports = [
  {
    test: /\.m?jsx?$/,
    exclude: [/(.*[\\\/])*node_modules[\\\/](?!(svelte|@kada|swiper|dom7|ssr-window)[\\\/]).*/],
    use: [
      {
        loader: 'thread-loader'
      },
      {
        loader: 'babel-loader'
      }
    ]
  },
  {
    test: /\.svelte$/,
    exclude: [/(.*[\\\/])*node_modules[\\\/](?!(svelte|@kada|swiper|dom7|ssr-window)[\\\/]).*/],
    use: [
      {
        loader: 'babel-loader'
      },
      {
        loader: 'svelte-loader',
        options: {
          dev: env === 'development',
          emitCss: true,
          hydratable: true,
          hotReload: false,
          hotOptions: {
            noPreserveState: true
          },
          preprocess: sveltePreprocess()
        }
      }
    ]
  },
  {
    test: /\.(png|jpe?g|gif|webp)(\?.*)?$/,
    use: [
      {
        loader: 'url-loader',
        options: {
          limit: 1024,
          fallback: {
            loader: 'file-loader',
            options: {
              name: 'img/[name].[hash:8].[ext]'
            }
          }
        }
      }
    ]
  },
  {
    test: /\.(svg)(\?.*)?$/,
    use: [
      {
        loader: 'file-loader',
        options: {
          name: 'img/[name].[hash:8].[ext]'
        }
      }
    ]
  },
  {
    test: /\.svga$/i,
    use: 'url-loader'
  },
  {
    test: /\.(mp4|webm|ogg|mp3|wav|flac|aac)(\?.*)?$/,
    use: [
      {
        loader: 'url-loader',
        options: {
          limit: 4096,
          fallback: {
            loader: 'file-loader',
            options: {
              name: 'media/[name].[hash:8].[ext]'
            }
          }
        }
      }
    ]
  },
  {
    test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/i,
    use: [
      {
        loader: 'url-loader',
        options: {
          limit: 4096,
          fallback: {
            loader: 'file-loader',
            options: {
              name: 'fonts/[name].[hash:8].[ext]'
            }
          }
        }
      }
    ]
  },
  {
    enforce: 'pre',
    test: /\.m?jsx?$/,
    exclude: [
      /node_modules/
    ],
    use: [
      {
        loader: 'eslint-loader',
        options: {
          extensions: [
            '.js',
            '.jsx',
            '.mjs'
          ],
          cache: false,
          emitWarning: true,
          emitError: false,
          eslintPath: path.join(projectDir, './node_modules/eslint')
        }
      }
    ]
  }
]
