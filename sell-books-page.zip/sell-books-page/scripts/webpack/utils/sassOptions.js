const sass = require('sass')
const sassUtils = require('node-sass-utils')

const _sassUtils = sassUtils(sass)

module.exports = (targetName = 'browser') => ({
  functions: {
    'target-env()': () => _sassUtils.castToSass(targetName)
  }
})
