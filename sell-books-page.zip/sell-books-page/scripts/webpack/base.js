const path = require('path')
const webpack = require('webpack')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const CopyWebpackPlugin = require('copy-webpack-plugin')
const CaseSensitivePathsPlugin = require('case-sensitive-paths-webpack-plugin')
const ESLintPlugin = require('eslint-webpack-plugin')
const WebpackBar = require('webpackbar')

const {
  env,
  pages,
  packageConfig,
  globalConfig,
  codes: {
    remLayoutCode,
    resetCssCode
  },
  dirs: {
    project: projectDir,
    src: srcDir,
    dist: distDir,
    public: publicDir
  },
  baseUrl,
  project
} = require('../env')
const loaders = require('./loaders')

const {
  assets: staticBaseUrl,
  entry: entryBaseUrl
} = baseUrl
const {
  name: projectName,
  version: projectVersion
} = project
const { DefinePlugin } = webpack

const mode = env === 'development' ? 'development' : 'production'
let devtool = false
const dev = env === 'development'

switch (env) {
  case 'development' :
    devtool = 'eval-nosources-cheap-source-map'
    break
  case 'test' :
    devtool = 'nosources-cheap-module-source-map'
    break
  case 'staging' :
    devtool = 'nosources-cheap-module-source-map'
    break
}

const pageKeys = Object.keys(pages)
const htmlPlugins = []
const entry = {}
pageKeys.forEach(key => {
  const { entry: pageEntry, skeleton = {}, inject = true, title, template, filename = `${key}.html` } = pages[key]

  if (pageEntry) {
    entry[key] = pageEntry
  }

  htmlPlugins.push(
    new HtmlWebpackPlugin(
      {
        chunks: [
          key
        ],
        templateParameters: (compilation, assets, options) => {
          return {
            STATIC_BASE_URL: staticBaseUrl,
            ENTRY_BASE_URL: entryBaseUrl,
            NODE_ENV: env,
            ENTRY_NAME: key,
            PAGE_TITLE: title,
            PROJECT_NAME: projectName,
            PROJECT_VERSION: projectVersion,
            REM_LAYOUT_CODE: remLayoutCode,
            RESET_CSS_CODE: resetCssCode,
            PAGE_ASSETS: {
              files: assets,
              options
            },
            SKELETON: skeleton
          }
        },
        template,
        filename,
        title,
        inject,
        minify: {
          removeComments: true,
          collapseWhitespace: true,
          removeAttributeQuotes: true,
          collapseBooleanAttributes: true,
          removeScriptTypeAttributes: true,
          minifyCSS: !dev,
          minifyJS: !dev
        }
      }
    )
  )
})

module.exports = {
  mode,
  entry,
  output: {
    path: distDir,
    filename: '[name].js'
  },
  // context: projectDir,
  devtool,
  node: {
    global: false,
    __filename: false,
    __dirname: false,
  },
  resolve: {
    alias: {
      '@': srcDir,
      svelte: path.resolve('node_modules', 'svelte')
    },
    extensions: ['.mjs', '.js', '.json', '.svelte', '.html'],
    mainFields: ['svelte', 'browser', 'module', 'main'],
    modules: [
      'node_modules',
      path.join(projectDir, 'node_modules'),
      path.join(projectDir, 'packages')
    ]
  },
  resolveLoader: {
    modules: [
      'node_modules',
      path.join(projectDir, 'node_modules'),
      path.join(projectDir, 'packages')
    ],
  },
  module: {
    rules: loaders
  },
  plugins: [
    new DefinePlugin(
      {
        'process.browser': true,
        'process.env.NODE_ENV': JSON.stringify(env),
        __ENV_CONFIG__: {
          BASE_URL: JSON.stringify(baseUrl),
          GLOBAL_CONFIG: JSON.stringify(globalConfig),
          PROJECT: JSON.stringify({
            ...project,
            appId: packageConfig.appId || '',
            channelId: packageConfig.channelId || ''
          })
        }
      }
    ),

    new CaseSensitivePathsPlugin(),

    ...htmlPlugins,

    new CopyWebpackPlugin(
      [
        {
          from: publicDir,
          to: distDir,
          toType: 'dir',
          ignore: [
            '.DS_Store',
            'template.html'
          ]
        }
      ]
    ),
    new WebpackBar(),
    new ESLintPlugin()
  ].filter(Boolean)
}
