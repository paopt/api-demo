const chalk = require('chalk')
const webpack = require('webpack')
const webpackMerge = require('webpack-merge').default
const FriendlyErrorsPlugin = require('@soda/friendly-errors-webpack-plugin')
const portfinder = require('portfinder')
const address = require('address')
const prepareProxy = require('./utils/prepareProxy')
const sassOptions = require('./utils/sassOptions')
const { transformer, formatter } = require('./utils/resolveLoaderError')
const { devServer, pages, dirs: { public: publicDir } } = require('../env')
const baseConfig = require('./base')


const { proxy, port = 8080, host = address.ip() } = devServer

const proxySettings = proxy && prepareProxy(
  proxy,
  publicDir
)

const devConfig = webpackMerge(baseConfig, {
  mode: 'development',
  // target: [ 'web', 'es5' ],
  optimization: {
    usedExports: false,
  },
  cache: {
    type: 'memory',
  },
  stats: 'errors-only',
  module: {
    rules: [
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader', 'postcss-loader']
      },
      {
        test: /\.p(ost)?css$/,
        use: ['style-loader', 'css-loader', 'postcss-loader']
      },
      {
        test: /\.scss$/,
        use: [
          'style-loader', 'css-loader', 'postcss-loader',
          {
            loader: 'sass-loader',
            options: {
              sassOptions: sassOptions(),
            },
          }
        ]
      }
    ]
  },
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    new webpack.ProgressPlugin()
  ],
  devServer: {
    port,
    host,
    historyApiFallback: true,
    open: false,
    hot: false,
    liveReload: true,
    proxy: proxySettings,
  }
})

module.exports = async () => new Promise((resolve, reject) => {
  portfinder.basePort = process.env.PORT || port
  portfinder.getPort((err, port) => {
    if (err) {
      reject(err)
    } else {
      process.env.PORT = port

      // const pageName = pkg.name
      const protocol = 'http'
      const networkUrl = `${protocol}://${host}:${chalk.bold(port)}`
      const localUrl = `${protocol}://localhost:${chalk.bold(port)}`
      devConfig.devServer.port = port

      devConfig.plugins.push(new FriendlyErrorsPlugin({
        compilationSuccessInfo: {
          messages: [
            chalk.yellow('App running at:') + '\n' +
            '    - Local: ' + chalk.cyan(`${localUrl}`) + '\n' +
            '    - Network: ' + chalk.cyan(`${networkUrl}`) + '\n',
          ]
        },
        clearConsole: true,
        additionalTransformers: [transformer],
        additionalFormatters: [formatter]
      }))

      resolve(devConfig)
    }
  })
})
