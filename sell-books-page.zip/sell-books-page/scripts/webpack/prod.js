const webpackMerge = require('webpack-merge').default
const TerserPlugin = require('terser-webpack-plugin')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
// const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer')
const terserOptions = require('./utils/terserOptions')
const baseConfig = require('./base')
const sassOptions = require('./utils/sassOptions')

const {
  env,
  pages,
  baseUrl: {
    assets: staticBaseUrl
  }
} = require('../env')

const jsFilename = 'js/[name].[contenthash:8].js'
const cssFilename = 'css/[name].[contenthash:8].css'

const pageKeys = Object.keys(pages)

const prodConfig = webpackMerge(baseConfig, {
  mode: 'production',
  target: ['web', 'es5'],
  output: {
    filename: jsFilename,
    chunkFilename: jsFilename,
    publicPath: staticBaseUrl
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'postcss-loader']
      },
      {
        test: /\.p(ost)?css$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'postcss-loader']
      },
      {
        test: /\.scss$/,
        use: [
          MiniCssExtractPlugin.loader, 'css-loader', 'postcss-loader',
          {
            loader: 'sass-loader',
            options: {
              sassOptions: sassOptions(),
            },
          }
        ]
      }
    ]
  },
  performance: {
    hints: 'warning',
    maxAssetSize: 250000,
    maxEntrypointSize: 400000,
    assetFilter(assetFilename) {
      return !/\.map$/.test(assetFilename)
    },
  },
  optimization: {
    usedExports: true,
    minimize: true,
    minimizer: [
      new TerserPlugin(terserOptions({
        parallel: require('os').cpus().length > 1,
        productionSourceMap: env === 'test'
      }))
    ],
    splitChunks: {
      chunks: 'all',
      minSize: 0,
      minChunks: Math.ceil(pageKeys.length / 2),
      maxAsyncRequests: 8,
      maxInitialRequests: 8,
      enforceSizeThreshold: 50000,
      name: false,
      cacheGroups: {
        vue: {
          chunks: 'all',
          name: 'chunk-commons',
          test: /node_modules[\\/](svelte|@kada)[\\/]/i,
          priority: 10,
          reuseExistingChunk: true,
          enforce: true
        }
      }
    },
    runtimeChunk: {
      name: 'runtime',
    }
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: cssFilename,
      chunkFilename: cssFilename
    }),
    // new BundleAnalyzerPlugin({
    //   analyzerMode: 'json'
    // })
  ]
})

module.exports = prodConfig
