const path = require('path')
const glob = require('glob')
const kadaDeploy = require('@kada/static-deploy')
const pkg = require('../package.json')
const yamlConfig = require('./yaml-config')

const env = process.env.NODE_ENV || 'development'

yamlConfig.compileFiles()

// mutle pages
const configDir = path.join(__dirname, '../public/data/config')
const configPaths = glob.sync('**/*', {
  cwd: configDir
})
if (['development'].indexOf(env) < 0) {
  configPaths.forEach(async pathname => {
    const target = path.join(configDir, pathname)
    const destConfigDir = env === 'staging' ? 'staging-config' : 'config'
    const destname = `data/${destConfigDir}/${pkg.name}/${pathname}`
    const result = await kadaDeploy.file({
      env: env === 'test' ? 'test' : 'production',
      pathname: target,
      destname,
      overwritten: true,
      headers: {
        'Cache-Control': 'no-cache'
      }
    })

    console.log(`public/data/${destConfigDir}/${pathname}`)
    console.log(` --> ${destname}`)
    console.log(result)
  })
}
