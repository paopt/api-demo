const rimraf = require('rimraf')
const webpack = require('webpack')
const chalk = require('chalk')
const ora = require('ora')
const prodConfig = require('./webpack/prod')
const { env, dirs: { dist: distDir } } = require('./env')

const spinner = ora(`Building for ${env}`).start()

rimraf(distDir, err => {
  if (err) throw err
  webpack(prodConfig, (err, stats) => {
    spinner.stop()
    if (err) {
      throw err
    }
    if (stats.hasErrors()) {
      spinner.fail(chalk.red('Build failed with errors.'))
    }
    process.stdout.write(stats.toString({
      colors: true,
      modules: false,
      children: false,
      chunks: false,
      chunkModules: false
    }) + '\n\n')

    spinner.succeed(`${chalk.black.bgRgb(13, 188, 121)(' DONE ')} ${chalk.rgb(64, 255, 55)('Build complete.')}`)
  })
})
