/**
 * 活动音频播放管理
 *
 * @summary 活动音频播放管理
 * @author diaoling <jinjian@hhdd.com>
 */
import { Sound } from '@kada/library/src/sound'

export class SoundManager {
  constructor (options = {}) {
    const { channels = [] } = options

    this.soundChannels = channels.reduce((previousValue, item) => {
      let config = item
      if (typeof item === 'string') {
        config = {
          id: item
        }
      }

      previousValue[item.id] = new Sound({
        ...config
      })

      return previousValue
    }, {})
  }

  getSoundChannelById (channelId) {
    const channelSound = this.soundChannels[channelId]

    if (!channelSound) {
      throw new Error(`ChannelSound[${channelId}] 声道不存在`)
    }

    return channelSound
  }

  destroy () {
    Object.keys(this.soundChannels).forEach(id => {
      const channelSound = this.soundChannels[id]

      if (!channelSound) {
        channelSound.destroy()
        this.soundChannels[id] = null
      }
    })
    soundManager = null
  }
}

let soundManager = null
/**
 * 获取音频播放管理器
 * @param {Object} options
 * @property {Object} options.bgsound 背景音频播放配置
 * @property {Object} options.voice 人声音频播放配置
 * @property {Object} options.effect 音效音频播放配置
 *
 * @returns
 */
export default function getSoundManager (options = {}) {
  if (!soundManager) {
    const { bgsound, voice, effect } = options
    soundManager = new SoundManager({
      channels: [
        // 背景音频
        {
          id: 'bgsound',
          volume: 1, // 音频音量,  默认1
          loop: true, // 音频是否循环,  默认false
          autoplay: true, // 音频是否自动播放,  默认false
          webAudio: false, //  是否开启webaudio模式， 默认false
          ...bgsound
        },
        // 语音音道
        {
          id: 'voice',
          volume: 1,
          loop: false,
          autoplay: false,
          webAudio: false,
          ...voice
        },
        // 音效
        {
          id: 'effect',
          volume: 2.5,
          loop: false,
          autoplay: false,
          webAudio: true,
          ...effect
        }
      ]
    })
  }

  return soundManager
}
