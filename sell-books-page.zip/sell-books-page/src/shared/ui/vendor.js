/**
 * 活动公共部分UI封装
 *
 * @summary 活动公共部分UI封装
 * @author diaoling <jinjian@hhdd.com>
 */
export {
  toast,
  showLoading, hideLoading,
  DIALOG_TYPE, showTypedDialog as showDialog, closeTypedDialog as closeDialog
} from '@kada/svelte-activity-ui'
