/**
 * 活动公共部分UI封装
 *
 * @summary 活动公共部分UI封装
 * @author diaoling <jinjian@hhdd.com>
 */
 import {
  toast as _toast,
  showLoading as _showLoading, hideLoading as _hideLoading,
  DIALOG_TYPE as _DIALOG_TYPE, showTypedDialog, closeTypedDialog,
  DIALOG_THEMES as _DIALOG_THEMES
} from '@kada/svelte-activity-ui'

/**
 * 显示Toast弹窗
 * @type {(msg: string|import('@kada/svelte-activity-ui/types/Toast/Toast').ToastProps) => Promise<Object>}
 */
export let toast = _toast

/**
 * 显示loading弹窗
 * @type {(msg: string|import('@kada/svelte-activity-ui/types/Indicator/Indicator').IndicatorProps) => Promise<Object>}
 */
export let showLoading = _showLoading

/**
 * 隐藏loading弹窗
 * @type {() => Promise<Object>}
 */
export let hideLoading = _hideLoading

/**
 * 弹窗类型
 * @type {('message'|'error'|'app-upgrade'|'wechat-open'|'subvip'|'lifevip'|'ended')}
 */
export const DIALOG_TYPE = _DIALOG_TYPE

export const DIALOG_THEMES = _DIALOG_THEMES

/// <reference types="@kada/svelte-activity-ui/TypedDialogProps" />
/**
 * 显示类型弹窗
 * @type {(msg: String|import('@kada/svelte-activity-ui/types/TypedDialog/TypedDialog').TypedDialogProps) => Promise<Object>}
 */
export let showDialog = (options) => {
  return showTypedDialog({
    theme: DIALOG_THEMES.NEW2021,
    ...options,
  })
}

/**
 * 隐藏loading弹窗
 * @type {() => Promise<Object>}
 */
export let closeDialog = closeTypedDialog

/**
 * 购买逻辑UI相关实现
 * @param {{
 *  toast?: (msg: string|import('@kada/svelte-activity-ui/types/Toast/Toast').ToastProps) => Promise<Object>,
 *  showLoading?: (msg: string|import('@kada/svelte-activity-ui/types/Indicator/Indicator').IndicatorProps) => Promise<Object>,
 *  hideLoading?: () => Promise<Object>,
 *  showDialog?: (msg: String|import('@kada/svelte-activity-ui/types/TypedDialog/TypedDialog').TypedDialogProps) => Promise<Object>,
 *  closeDialog?: () => Promise<Object>,
 * }} options 配置项
 *
 * @returns {Object}
 */
export function setImplementor (options = {}) {
  toast = options.toast || _toast

  // 显示和隐藏Loading必须成对出现
  if (options.showLoading && options.hideLoading) {
    showLoading = options.showLoading || _showLoading
    hideLoading = options.hideLoading || _hideLoading
  }

  // 显示和关闭弹窗必须成对出现
  if (options.showDialog && options.showDialog) {
    showDialog = options.showDialog || showTypedDialog
    closeDialog = options.closeDialog || closeTypedDialog
  }
}
