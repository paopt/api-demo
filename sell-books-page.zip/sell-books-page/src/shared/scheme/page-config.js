/**
 * 页面配置信息解析及获取
 *
 * @summary 页面配置信息解析及获取
 * @author diaoling <jinjian@hhdd.com>
 */

import _get from 'lodash/get'
import projectConfig from '@/lib/config'
import { deviceInfo } from '@kada/library/src/device'
import {
  resetPageStatus,
  resetResponseCodeToPageStatus,
  resetResponseStatusToPageStatus,
  resetPageStatusToCanbuy,
  resetBoughtStatus,
  resetOpenedStatus,
  resetComputedStatusToPageStatus
} from '../internal/page-status'

// 页面配置信息缓存
let _pageConfigCache = null

// 页面标题
export let pageTitle = ''
// 活动ID
export let activityKey = ''
// 某个路由地址映射的配置ID
let routesMapConfigId = new Map()
// 页面音频配置信息
let audioConfig = new Map()
// 页面弹窗配置信息
let dialogConfig = new Map()
// 页面状态映射的弹窗信息
let whenStatusDialogConfig = new Map()
// 页面打点相关配置信息
let analyticsConfig = {}
// 页面界面相关配置信息
let viewConfig = {}
// 分享配置信息
let shareConfig = {}

/**
 * 初始化页面配置
 * @param {Object} config 页面配置信息
 * @param {Context} context 页面上下文
 */
export function initPageConfig(config, context) {
  _pageConfigCache = config

  const updateConfig = (isRefresh = true) => {
    const configContext = {
      env: projectConfig.env,
      context: context.getData(),
      deviceInfo
    }

    updatePageConfig(isRefresh, configContext)
  }

  // 页面状态变化时更新配置
  context.subscribe('pageStatus', updateConfig)
  context.subscribe('viewData', updateConfig)

  updateConfig(false)
}

/**
 * 更新页面配置
 *
 * @param {Boolean} isRefresh 是否为刷新配置
 * @param {Context} context 页面请求上下文
 *
 * @return {Boolean} 是否刷新成功
 */
export function updatePageConfig(isRefresh, context) {
  if (!_pageConfigCache) {
    return
  }

  const {
    useMates,
    useStatus,
    useAudio,
    useDialog,
    useShareConfig,
    useAnalytics,
    useBody,
  } = _pageConfigCache

  // 活动Meta配置信息解析
  useMates && parseActivityMeta(useMates(context))

  // 解析业务逻辑配置信息

  // 解析页面音频配置
  useAudio && parseAudioInfo(useAudio(context))
  // 解析页面状态配置
  useStatus && parsePageStatusConfigInfo(useStatus(context))
  // 解析页面弹窗配置
  useDialog && parseDialogConfigInfo(useDialog(context))
  // 解析页面打点配置信息
  useAnalytics && parseAnalyticsConfigInfo(useAnalytics(context))

  // 解析页面可视区域相关配置
  useBody && parseBodyInfo(useBody(context))
  // 解析页面分享配置
  useShareConfig && parseShareConfig(useShareConfig(context))
}

/**
 * 更新页面配置
 *
 * @param {Boolean} isRefresh 是否为刷新配置
 * @param {Context} context 页面请求上下文
 *
 * @return {Boolean} 是否刷新成功
 */
 export function updatePageStatusConfig(isRefresh, context) {
  if (!_pageConfigCache) {
    return
  }

  const configContext = {
    env: projectConfig.env,
    context: context.getData(),
    deviceInfo
  }

  const {
    useMates,
    useAudio,
    useStatus,
  } = _pageConfigCache

  // 活动Meta配置信息解析
  useMates && parseActivityMeta(useMates(context))

  // 解析业务逻辑配置信息

  // 解析页面音频配置
  useAudio && parseAudioInfo(useAudio(context))
  // 解析页面状态配置
  useStatus && parsePageStatusConfigInfo(useStatus(configContext))
}

/**
 * 活动相关Meta信息配置
 * @param {Object} config
 */
function parseActivityMeta(config) {
  if (!config) {
    return
  }
  // 页面标题
  pageTitle = config.title || ''
  // 活动ID
  activityKey = config.activityKey || ''
  // 解析路由配置信息
  routesMapConfigId = new Map(Object.entries(config.routes || {}))
}

/**
 * 解析页面音频配置信息
 * @param {Object} config 配置信息
 */
function parseAudioInfo(config) {
  if (!config || typeof config !== 'object') {
    return
  }

  audioConfig = new Map(Object.entries(config))
}

/**
 * 解析页面状态配置信息
 * @param {Object} config 配置信息
 * @param {Context} context 活动上下文
 */
function parsePageStatusConfigInfo(config) {
  if (!config || typeof config !== 'object') {
    return
  }

  const {
    boughtStatus = null,
    openedStatus = null,
    responseToPageStatus: {
      code = null,
      status = null,
      computedStatus = null
    } = {},
    pageStatus = null,
    canbuy = null
  } = config

  resetPageStatus(pageStatus)
  resetBoughtStatus(boughtStatus)
  resetOpenedStatus(openedStatus)
  resetResponseCodeToPageStatus(code)
  resetResponseStatusToPageStatus(status)
  resetComputedStatusToPageStatus(computedStatus)
  resetPageStatusToCanbuy(canbuy)
}

/**
 * 解析弹窗配置信息
 * @param {Object} config 配置信息
 */
function parseDialogConfigInfo(config) {
  if (!config || typeof config !== 'object') {
    return
  }

  const { whenStatus = {}, ...dialogOpts } = config

  dialogConfig = new Map(Object.entries(dialogOpts))
  whenStatusDialogConfig = new Map(Object.entries(whenStatus))
}

/**
 * 解析弹窗配置信息
 * @param {Object} config 配置信息
 */
function parseAnalyticsConfigInfo(config) {
  if (!config || typeof config !== 'object') {
    return
  }

  analyticsConfig = config
}

/**
 * 解析可视界面配置信息
 *
 * @param {Object} config 配置信息
 */
function parseBodyInfo(config) {
  if (!config) {
    console.info('可视界面配置信息 config.body 不存在')
    return
  }

  viewConfig = config

  console.log('viewConfig', viewConfig)
}

/**
 * 解析分享配置信息
 *
 * @param {Object} config 配置信息
 */
 function parseShareConfig(config) {
  if (!config) {
    console.info('分享配置信息 config.shareConfig 不存在')
    return
  }
  shareConfig = config
}

/**
 * 根据名称获取音频
 * @param {String} name 音频名称
 *
 * @returns {String} 音频地址
 */
export function getVoiceByName(name) {
  return audioConfig.get(name)
}

/**
 * 获取打点信息
 * @param {String} name 打点类型
 *
 * @returns {String} 打点数据
 */
export function getAnalyticsIdByName(name) {
  return _get(analyticsConfig, name, '')
}

/**
 * 根据弹窗名称获取弹窗配置信息
 * @param {String} name 弹窗名称
 *
 * @returns {Object} 弹窗配置
 */
export function getDialogOptionsByName(name) {
  return dialogConfig.get(name) || null
}

/**
 * 根据根据某个页面状态获取弹窗配置信息
 * @param {String} status 页面状态
 *
 * @returns {Object} 弹窗配置
 */
export function getDialogOptionsWhenStatus(status) {
  const dialogOpts = whenStatusDialogConfig.get(status)

  return dialogOpts || null
}

/**
 * 根据路由获取路由对应的配置ID
 * @param {String} name
 *
 * @returns {String} 配置ID
 */
export function getConfigIdByRoute(name) {
  return routesMapConfigId.get(name) || ''
}

/**
 * 根据界面组件名称获取相关配置信息
 * @param {String} name
 *
 * @returns {Object} 配置信息
 */
export function getViewConfigByName(name) {
  return _get(viewConfig, name, null) || null
}


/**
 * 获取分享配置信息
 * @returns {Object} 分享配置信息
 */
 export function getShareConfig() {
  return shareConfig || null
}
