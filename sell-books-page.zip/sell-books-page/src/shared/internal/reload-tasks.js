/**
 * 页面重新加载后，自动执行的任务
 *
 * @summary 页面重新加载后，自动执行的任务
 * @author diaoling <jinjian@hhdd.com>
 */
// 页面重载后，执行任务保存键值
const AFTER_RELOAD_TASKS_STORE_KEY = 'WECHAT_AFTER_RELOAD_TASKS_STORE_KEY'
// 页面重载支持的任务
const RELOAD_TASKS = new Map()
// 页面重载后任务信息
let afterReloadTasks = []

/**
 * 添加支持的任务
 *
 * @param {String} name 任务名称
 * @param {Function} callback 任务执行函数
 */
export function addTask (name, callback) {
  RELOAD_TASKS.set(name, callback)
}

/**
 * 添加登录刷新后任务
 *
 * @param {string} type 任务类型 参见 AFTER_RELOAD_TASKS_TYPES
 * @param {Object} params 调用方法 参数
 */
export function setAfterReloadTask (type, params = []) {
  if (!afterReloadTasks) {
    afterReloadTasks = []
  }
  const tasks = afterReloadTasks

  tasks.push({
    type,
    params
  })

  sessionStorage.setItem(AFTER_RELOAD_TASKS_STORE_KEY, JSON.stringify(tasks))
}

/**
 * 获取所有登录刷新后的任务
 * @returns {Array<{ type:string, params:any }}
 */
export function getAfterReloadTasks () {
  const strTasks = sessionStorage.getItem(AFTER_RELOAD_TASKS_STORE_KEY)
  console.log('get tasks', strTasks)
  sessionStorage.removeItem(AFTER_RELOAD_TASKS_STORE_KEY)
  let afterReloadTasks = strTasks

  if (typeof strTasks === 'string') {
    try {
      afterReloadTasks = JSON.parse(strTasks)
    } catch (error) {
      console.error(error)
    }
  }

  return afterReloadTasks
}

/**
 * 获取所有登录刷新后的任务
 */
export function execAfterReloadTasks () {
  const tasks = getAfterReloadTasks()
  console.log('exec tasks', tasks)
  if (Array.isArray(tasks) && tasks.length > 0) {
    tasks.forEach(({ type, params = [] }) => {
      const func = RELOAD_TASKS.get(type)

      if (typeof func === 'function') {
        func.apply(RELOAD_TASKS, params)
      }
    })
  }

  afterReloadTasks = []
}
