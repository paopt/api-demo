/**
 * 购买礼包业务调用函数封装
 *
 * @summary 购买礼包业务调用函数封装
 * @author diaoling <jinjian@hhdd.com>
 */
import {
  PAGE_STATUS,
  getResponsePageStatus
} from './page-status'
import { toast, hideLoading } from '../ui/index'
import { isClientOpen } from '@kada/jsbridge'
import { deviceInfo } from '@kada/library/src/device'
import { sendBehavior as sendStat } from '@/lib/analytics'
import qs from 'qs'
import {
  checkPageStatus as wxCheckPageStatus,
  buyPackage as wxBuyPackage,
  payment as wxPayment,
  checkLogin as wxCheckLogin,
  openLogin as wxOpenLogin
} from './wechat'
import {
  checkPageStatus as appCheckPageStatus,
  buyPackage as appBuyPackage,
  payment as appPayment,
  checkLogin as appCheckLogin,
  openLogin as appOpenLogin
} from './app'
import {
  checkPageStatus as h5CheckPageStatus,
  buyPackage as h5BuyPackage,
  payment as h5Payment,
  checkLogin as h5CheckLogin,
  openLogin as h5OpenLogin
} from './h5'
import config from '@/lib/config'
import { getConfigIdByRoute, updatePageStatusConfig } from '../scheme/page-config'
import getSoundManager from '../media/sound-manager'

// 音频管理类
const soundManager = getSoundManager()
// 语音声道
export const voiceSoundChannel = soundManager.getSoundChannelById('voice')

// 活动上下文
export let context = null

/**
 * 设置活动上下文实例
 * @param {Context} ctx
 */
export function setContext (ctx) {
  context = ctx
}

/**
 * 发送活动相关打点
 * @param {String} stateId 打点前缀
 */
export function sendBehavior (stateId, data, pageView) {
  let activityKey = ''
  // 添加全局渠道参数
  if (context) {
    if (!data) {
      data = {}
    }
    data.channelId = context.channelId
    activityKey = context.activityKey
  } else if (data && data.activityKey) {
    activityKey = data.activityKey
  }

  delete data.activityKey

  try {
    if (stateId) {
      sendStat(`${stateId}_${activityKey}`, data, pageView)
    }
  } catch (error) {
    console.error(error.message, error)
  }
}

// 各环境下通用Usage地址
const USAGE_PAGE_URL = (config.wechat && config.wechat.usagePage) || '//h5.hhdd.com/n/wechat/usage.html'

/**
 * 跳转至使用说明页面
 */
export function toUsageView (configId) {
  if (!configId) {
    configId = getConfigIdByRoute('/usage')
  }
  const query = {
    cid: configId
  }
  if (context.channelId) {
    query.channelId = context.channelId
  }
  const queryData = qs.stringify(query, { addQueryPrefix: true })
  const usageUrl = USAGE_PAGE_URL

  setTimeout(() => { location.href = `${usageUrl}${queryData}` }, 300)
}


/**
 * 活动数据入口
 *
 * @param {Boolean} isRefresh 是否为刷新接口
 *
 * @returns {Boolean} 是否支持购买礼包
 */
export async function getPageData (isRefresh) {
  const { activityKey } = context
  let checkResult = true
  try {
    context.responseBody = await context.getServiceData(activityKey, isRefresh)
    const [pageStatus, viewData] = await Promise.all([getPageStatus(context, isRefresh), getViewData(context, isRefresh)])
    // console.log('pageStatus: ', pageStatus, 'viewData: ', viewData)
    // 设置页面整体状态
    context.pageStatus = pageStatus

    // 页面渲染所需数据
    context.viewData = viewData

    // 获取礼包信息
    if (viewData) {
      const { packageId = 0, packageType = 5 } = viewData
      context.packageId = packageId
      context.packageType = packageType
    }

    console.log('viewData: ', viewData)

    const canBuy = await checkPageStatus(context, isRefresh)
    console.log('canBuy: ', canBuy)
    // 是否可以购买礼包
    context.canBuy = canBuy

    checkResult = canBuy

    //关闭微信登录loading
    hideLoading()
    if (checkResult && pageStatus === PAGE_STATUS.NETWORK_ERROR) {
      toast('网络错误，请稍后再试')
    }
  } catch (error) {
    console.error(error)
    hideLoading()
  }

  Promise.resolve().then(() => {
    // 页面加载并完成解析
    context.pageLoaded = true
  })

  return checkResult
}

/**
 * 获取页面全局状态
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {Boolean} isRefresh 是否为刷新接口
 *
 * @returns {String} 页面全局状态
 */
async function getPageStatus (ctx, isRefresh = false) {
  if (!ctx) {
    throw new Error('getPageStatus 必须传上下文')
  }

  // 返回数据为空，网络异常
  if (!ctx.responseBody) {
    return PAGE_STATUS.NETWORK_ERROR
  }

  return getResponsePageStatus(ctx.responseBody, isRefresh)
}

/**
 * 获取页面渲染所需数据
 *
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {String} ctx.pageStatus 页面当前状态
 * @param {Boolean} isRefresh 是否为刷新接口
 *
 * @returns {Object}
 */
async function getViewData (ctx, isRefresh = false) {
  return ctx.getViewData(isRefresh)
}

/**
 * 检查接口返回页面数据
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {String} ctx.pageStatus 页面当前状态
 * @param {Boolean} isRefresh 是否为刷新接口
 */
async function checkPageStatus (ctx, isRefresh = false) {
  if (deviceInfo.isKadaClient) {
    return appCheckPageStatus(ctx, isRefresh)
  }

  // HD或手机3.7.5之前判断是否App打开
  try {
    await isClientOpen()

    return appCheckPageStatus(ctx, isRefresh)
  } catch (error) {
    console.log('app外打开活动页面')
  }

  return wxCheckPageStatus(ctx, isRefresh)
}

/**
 * 打开登录弹层
 *
 * @param {Object} options 登录弹层相关配置
 * @param {Number} options.loginType 指定优先某种登录方式 0=??? 1=??? 2=微信(v4.1.20)  仅支持App
 * @param {Number} options.skipUserGuide 跳过新用户注册引导 默认为 0不跳过， 1跳过  仅支持App
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址, 默认为 true  仅支持App
 *
 * @returns {Boolean} 是否登录成功
 */
export async function openLogin (options) {
  if (deviceInfo.isKadaClient) {
    return appOpenLogin(options)
  }

  // HD或手机3.7.5之前判断是否App打开
  try {
    await isClientOpen()

    return appOpenLogin(options)
  } catch (error) {
    console.log('app外打开活动页面')
  }

  return wxOpenLogin()
}

/**
 * 检查页面是否已经登录
 *
 * @param {Object} options
 * @param {Boolean} options.openLogin 如果未登录，尝试打开登录弹层, 默认为 false
 * @param {Number} options.loginType 指定优先某种登录方式 0=??? 1=??? 2=微信(v4.1.20)  仅支持App
 * @param {Number} options.skipUserGuide 跳过新用户注册引导 默认为 0不跳过， 1跳过  仅支持App
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址  仅支持App
 *
 * @returns {Boolean} 是否已经登录成功
 */
export async function checkLogin (options = {}) {
  const { openLogin = false, ...otherOptions } = options
  const appOpts = { openLogin, ...otherOptions }

  if (deviceInfo.isKadaClient) {
    return appCheckLogin(appOpts)
  }

  // HD或手机3.7.5之前判断是否App打开
  try {
    await isClientOpen()

    return appCheckLogin(appOpts)
  } catch (error) {
    console.log('app外打开活动页面')
  }

  return wxCheckLogin({ openLogin })
}

/**
 * 礼包支付流程
 *
 * @param {Number} packageId [必填] 礼包ID
 * @param {Object} options
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址, 仅 App支持
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 *
 * @return {Boolean} 是否购买成功
 * 疑似从未使用
 */
export async function paymentNotUse (packageId = 0, options = {}) {
  const { packageType, packageIdType = 'main', loginHelpVoice } = options
  let result = false
  if (deviceInfo.isKadaClient) {
    result = appPayment(packageId, {
      loginHelpVoice,
      packageType,
      packageIdType,
      refreshPageData: async () => getPageData(true),
      getPackageId: async (type) => {
        if (context.viewData && (typeof context.viewData[type] !== 'undefined')) {
          return context.viewData[type]
        }

        return context.packageId
      }
    })
  } else {
    result = wxPayment(packageId, false, {
      packageType,
      packageIdType
    })
  }

  return result
}

/**
 * 购买礼包
 * @param {Number} packageId [必填] 购买礼包ID
 * @param {Object} options
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 *
 * @return {Boolean} 是否购买成功
 */
export async function buyPackage (packageId = 0, options = {}) {
  const { packageIdType = 'main', refreshMoudles = [], orderTraceInfo = {} } = options
  console.log(orderTraceInfo)
  // 保持当前packageIdType到上下文
  context.packageIdType = packageIdType
  updatePageStatusConfig(false, context)
  let result = false
  if (deviceInfo.isKadaClient) {
    result = await appBuyPackage(packageId, {
      context,
      loginHelpVoice: true,
      packageType: context.packageType,
      packageIdType,
      refreshMoudles,
      refreshPageData: async () => getPageData(true),
      getPackageId: async (type) => {
        if (context.viewData && (typeof context.viewData[type] !== 'undefined')) {
          return context.viewData[type]
        }

        return context.packageId
      }
    })
  } else if (deviceInfo.wechat) {
    result = await wxBuyPackage(packageId, {
      context,
      packageType: context.packageType,
      packageIdType,
      orderTraceInfo
    })
  } else {
    // h5支付
    result = await h5BuyPackage(packageId, {
      context,
      packageType: context.packageType,
      packageIdType,
      orderTraceInfo
    })
  }

  return result
}
