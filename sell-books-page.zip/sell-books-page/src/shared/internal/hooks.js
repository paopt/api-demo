/**
 * 活动内环节各类 Hook
 *
 * @summary 活动内环节各类 Hook
 * @author diaoling <jinjian@hhdd.com>
 */
import { Hook } from 'before-after-hook'

/**
 * response转成pageStatus Hook
 */
 export const responseToStatusHook = Hook.Singular()

 /**
  * 检查页面状态 Hook
  */
export const checkPageStatusHook = Hook.Singular()

/**
 * 检查当前状态是否可以参与购买 Hook
 */
export const canbuyWithPageStatusHook = Hook.Singular()

/**
 * 检查是否已经活动外开通 Hook
 */
export const openedWithPageStatusHook = Hook.Singular()

/**
 * 检查是否已经活动内开通 Hook
 */
 export const boughtWithPageStatusHook = Hook.Singular()

/**
 * 显示状态弹窗 Hook
 */
export const showWhenPageStatusDialogHook = Hook.Singular()

/**
 * 显示购买时已参与活动弹窗 Hook
 */
export const showOpenedDialogHook = Hook.Singular()

/**
 * 显示购买礼包成功弹窗 Hook
 */
export const showSuccessDialogHook = Hook.Singular()

/**
 * 显示挽留弹窗 Hook
 */
export const showRetainDialogHook = Hook.Singular()

/**
 * 登录失败 Hook
 */
export const loginFailHook = Hook.Singular()

/**
 * 不允许购买 Hook
 */
export const notAllowBuyHook = Hook.Singular()

/**
 * 礼包ID错误 Hook
 */
export const packageIdErrorHook = Hook.Singular()

/**
 * 使用Hook
 */
export function useHookWrap (callback, hook) {
  return async (...args) => hook((options) => callback(...options), args)
}
