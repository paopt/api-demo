/**
 * h5购买逻辑
 */
import {
  DIALOG_TYPE,
  toast,
  showLoading,
  hideLoading,
  showDialog
} from '../ui/index'
import {
  RESPONSE_CODE_MESSAGE,
  PAGE_STATUS,
  isBoughtWithPageStatus,
  isCanBuyWithPageStatus,
  isOpenedWithPageStatus
} from './page-status'
import { KADA_APP_DOWNLOAD_URL, WECHAT_PAY_INFO_COVER_URL } from './constants'
import * as userService from '@/services/user'
import { getPreOrder } from '@/services/subscribe'
import {
  setAfterReloadTask,
  execAfterReloadTasks,
  addTask
} from './reload-tasks'
import {
  useHookWrap,
  checkPageStatusHook,
  showWhenPageStatusDialogHook,
  showOpenedDialogHook,
  showSuccessDialogHook,
  notAllowBuyHook,
  packageIdErrorHook
} from './hooks'
import {
  getDialogOptionsByName,
  getAnalyticsIdByName,
  getDialogOptionsWhenStatus
} from '../scheme/page-config'
import { context, getPageData, sendBehavior, toUsageView } from './index'
import { showDialog as showLoginDialog } from '@/page/components/LoginDialog'

/**
 * 不允许购买的处理函数
 * @param {Boolean} isCanbuy
 * @returns {Boolean}
 */
const notAllowBuy = useHookWrap((canBuy) => canBuy, notAllowBuyHook)

/**
 * 礼包ID错误处理
 */
const packageIdError = useHookWrap((packageId) => {
  throw new Error('礼包ID不存在', packageId)
}, packageIdErrorHook)

// 支持的ReloadTasks的方法
export const AFTER_RELOAD_TASKS_TYPES = {
  PAYMENT: 'payment',
  REPAYMENT: 'repayment',
  BUY_SUCCESS: 'buySuccess'
}

// 添加重载后执行任务
addTask(AFTER_RELOAD_TASKS_TYPES.PAYMENT, payment)
addTask(AFTER_RELOAD_TASKS_TYPES.REPAYMENT, repayment)
addTask(AFTER_RELOAD_TASKS_TYPES.BUY_SUCCESS, showSuccessDialog)

/**
 * h5登录
 */
export function openLogin () {
  showLoginDialog({
    onClose: (res) => {
      console.log('弹窗关闭状态', res)
      if (res === true) {
        // 登录成功
        execAfterReloadTasks()
      }
    }
  })
}

/**
 * 检查页面是否已经登录
 *
 * @param {Object} options
 * @param {Boolean} options.openLogin 如果未登录，尝试打开登录弹层, 默认为 true
 *
 * @returns {Boolean}
 */
export async function checkLogin (options = {}) {
  const { openLogin: openLoginPanel = false } = options

  if (!userService.isLogin()) {
    if (openLoginPanel) {
      return openLogin()
    }

    return false
  }
  return true
}

// 支付成功之后刷新接口
let successRefreshTimer = 0
// 最大刷新次数
const MAX_SUCESS_REFRESH_COUNT = 4
/**
 * 显示购买成功弹窗
 *
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
function showSuccessDialog(options) {
  console.log('执行购买成功任务')
  if (successRefreshTimer) {
    clearTimeout(successRefreshTimer)
  }

  // 根据配置是否显示购买成功弹窗
  const successDialogOptions = getDialogOptionsByName('successDialog')
  console.log('successDialogOptions', successDialogOptions)
  if (successDialogOptions) {
    const viewStatId = getAnalyticsIdByName('dialog.successDialog.view')
    const clickStatId = getAnalyticsIdByName('dialog.successDialog.doneClick')
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    showDialog({
      ...successDialogOptions,
      onDone: () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }

        const doneButton = successDialogOptions && successDialogOptions.doneButton
        const doneAction = doneButton.action
        if (doneAction === 'linkTo') {
          const url = doneButton.params
          if (url) {
            location.href = url
          }
        } else if (doneAction === 'toRead' || doneAction === 'toUsageView') {
          toDownload(true)
        } else if (doneAction === 'toDownload') {
          toDownload()
        }
      }
    })
  } else {
    console.log('刷新页面，购买成功逻辑')
    let refreshTimes = MAX_SUCESS_REFRESH_COUNT
    const refreshPageData = async () => {
      try {
        refreshTimes--
        const canbuy = await getPageData(false)
        console.log('showSuccessDialog::refreshPageData', canbuy)

        if (canbuy && refreshTimes > 0) {
          successRefreshTimer = setTimeout(refreshPageData, 2000)
        }
      } catch (err) {
        console.log(err)
      }
    }
    // 购买成功后，每隔0.6s轮询消息同步后刷新接口
    successRefreshTimer = setTimeout(refreshPageData, 1000)
  }
}

/**
 * 购买前刷新接口，获取最新礼包ID
 * @param {Boolean} isRefresh 是否为刷新接口
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
export async function repayment (isRefresh = false, options = {}) {

  const { packageIdType } = options

  if (packageIdType && context.packageIdType !== packageIdType) {
    // 重新加载之后，重置当前packageIdType到上下文
    context.packageIdType = packageIdType
  }

  // 再次检查是否允许参与活动并且支付
  const canBuy = await getPageData(true)
  if (!canBuy) {
    return notAllowBuy(canBuy)
  }

  let { packageId, packageType = options.packageType, viewData } = context

  if (viewData && (typeof viewData[packageIdType] !== 'undefined')) {
    packageId = viewData[packageIdType]
  }

  return payment(packageId, isRefresh, { ...options, packageType })
}

/**
 * 购买活动礼包
 * @param {Number} packageId [必填] 礼包ID
 * @param {Boolean} isRefresh 登录后刷新支付流程
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 *
 * @returns {Boolean}
 */
export async function payment (packageId, isRefresh = false, options = {}) {
  const { packageType = 5, orderTraceInfo = {} } = options
  console.log(orderTraceInfo)
  
  const isLogin = await checkLogin()
  console.log('登录状态', isLogin)
  if (!isLogin) {
    // 重试情况下不注册 repayment 方法
    if (!isRefresh) {
      console.log('after task')
      setAfterReloadTask(AFTER_RELOAD_TASKS_TYPES.REPAYMENT, [true, options])
    }
    return openLogin()
  }

  if (!packageId) {
    return packageIdError(packageId)
  }
  console.log(packageType)
  showLoading('正在创建订单')
  try {
    const data = await getPreOrder({
      sourceId: packageId,
      sourceType: packageType,
      tradeType: 'MWEB',
      orderTraceInfo: JSON.stringify(orderTraceInfo)
    }, {
      partnerId: context.channelId || ''
    })
    hideLoading()

    console.log(data)

    // 跳转微信支付
    setAfterReloadTask(AFTER_RELOAD_TASKS_TYPES.BUY_SUCCESS, [options])
    // location.href = `${data.mweb_url}&redirect_url=${encodeURIComponent('https://h5.hhdd.com/n/month-report/index.html#/report?date=2023-05&channelId=xxxx&u=RJBBTSR')}`
    let url
    if (location.hash.includes('?')) {
      url = location.href + `&ticket=${(new Date).getTime()}`
    } else {
      url = location.href + `?ticket=${(new Date).getTime()}`
    }
    location.href = `${data.mweb_url}&redirect_url=${encodeURIComponent(url)}`
  } catch (error) {
    hideLoading()
    // eslint-disable-next-line
    if (error.code == 410) {
      toast(error.message || '已经订阅')
      throw error
    } else {
      toast(error.message || '订单创建失败')
    }
  }
}

/**
 * 跳转下载页面
 */
export function toDownload (isUsage) {
  const downloadStatId = getAnalyticsIdByName('toDownload')

  if (downloadStatId) {
    sendBehavior(downloadStatId)
  }
  // 延迟100ms跳转，目的是保证打点能正常提交
  setTimeout(() => {
    if (isUsage) {
      toUsageView()
    } else {
      location.href = KADA_APP_DOWNLOAD_URL
    }
  }, 100)
}

/**
 * 检查接口返回页面数据
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {String} ctx.pageStatus 页面当前状态
 * @param {Boolean} isRefresh 是否为刷新接口
 */
 export const checkPageStatus = useHookWrap(_checkPageStatus, checkPageStatusHook)

/**
 * 根据页面状态显示弹窗
 * @param {String} pageStatus
 */
 const showWhenPageStatusDialog = useHookWrap(async (pageStatus) => {
  const canBuy = await isCanBuyWithPageStatus(pageStatus)
  const dialogOpts = getDialogOptionsWhenStatus(pageStatus)

  if (dialogOpts) {
    const viewStatId = getAnalyticsIdByName(`dialog.${pageStatus}.view`)
    const clickStatId = getAnalyticsIdByName(`dialog.${pageStatus}.doneClick`)
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    const { showTimes = canBuy ? 'once' : 'always', ...showDialogOpts } = dialogOpts

    return showDialog({
      ...showDialogOpts,
      doneCloseDialog: showTimes === 'once',
      onDone: () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }

        toDownload()
      }
    })
  }
}, showWhenPageStatusDialogHook)

/**
 * 检查接口返回页面数据
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {String} ctx.pageStatus 页面当前状态
 * @param {Boolean} isRefresh 是否为刷新接口
 */
async function _checkPageStatus (ctx, isRefresh = false) {
  if (!ctx) {
    throw new Error('context 为必传参数')
  }

  const {
    pageStatus,
    responseBody = {}
  } = ctx

  if (!isRefresh) {
    // 页面PV打点
    const statId = getAnalyticsIdByName('pageView')
    const boughtStatId = getAnalyticsIdByName('boughtPageView')
    if (statId) {
      sendBehavior(statId)
    }
    if (boughtStatId) {
      sendBehavior(boughtStatId)
    }
  }

  const canBuy = await isCanBuyWithPageStatus(pageStatus)
  if (pageStatus === PAGE_STATUS.NETWORK_ERROR) {
    const { code, msg } = responseBody || {}
    const errorObj = RESPONSE_CODE_MESSAGE[code] || { title: msg || '网络错误，请稍后再试' }
    const dialogOpts = getDialogOptionsByName('dialog.networkError')
    const viewStatId = getAnalyticsIdByName('dialog.networkError.view')
    const clickStatId = getAnalyticsIdByName('dialog.networkError.doneClick')
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    showDialog({
      type: DIALOG_TYPE.ERROR,
      title: errorObj.title || '网络请求异常',
      message: errorObj.message,
      hideOnMask: false,
      buttonText: '我知道了',
      doneCloseDialog: false,
      ...dialogOpts,
      onDone: () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }

        toDownload()
      }
    })

    return false
  }

  const isBought = await isBoughtWithPageStatus(pageStatus)
  console.log(isBought, '页面刷新任务')
  if (isBought) {
    Promise.resolve().then(() => execAfterReloadTasks())

    return false
  }

  // 根据页面状态显示弹窗
  showWhenPageStatusDialog(pageStatus)

  return canBuy
}

/**
 * 显示已经开通弹窗
 * @param {String} pageStatus
 */
const showOpenedDialog = useHookWrap(async () => {
  const openedDialogOptions = getDialogOptionsByName('opened')
  const viewStatId = getAnalyticsIdByName('dialog.opened.view')
  const clickStatId = getAnalyticsIdByName('dialog.opened.doneClick')
  if (viewStatId) {
    sendBehavior(viewStatId)
  }

  showDialog({
    type: DIALOG_TYPE.MESSAGE,
    title: '你已享有该活动所有权益',
    message: '无需参加本活动哦',
    buttonText: '我知道了',
    doneCloseDialog: false,
    ...openedDialogOptions,
    onDone: () => {
      if (clickStatId) {
        sendBehavior(clickStatId)
      }

      toDownload()
    }
  })
}, showOpenedDialogHook)

/**
 * 购买礼包
 * @param {Number} packageId [必填] 礼包ID
 * @param {Object} options
 * @param {Context} options.context 页面上下文
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
export async function buyPackage (packageId, options = {}) {
  console.log('buyPackage', packageId, options)
  const { context = {}, packageIdType = 'main', packageType = 5, orderTraceInfo = {} } = options
  const { pageStatus } = context
  const canBuy = await isCanBuyWithPageStatus(pageStatus)

  if (canBuy) {
    return payment(packageId, false, {
      packageType,
      packageIdType,
      orderTraceInfo
    })
  }

  const isOpened = await isOpenedWithPageStatus(pageStatus)
  if (isOpened) {
    showOpenedDialog(pageStatus)

    return false
  }

  const isBought = await isBoughtWithPageStatus(pageStatus)
  toDownload(isBought)
  return false
}
