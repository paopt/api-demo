/**
 * 微信内购买礼包逻辑
 *
 * @summary 微信内购买礼包逻辑
 * @author diaoling <jinjian@hhdd.com>
 */
import qs from 'qs'
import { deviceInfo } from '@kada/library/src/device'
import {
  DIALOG_TYPE,
  toast,
  showLoading,
  hideLoading,
  showDialog
} from '../ui/index'
import {
  RESPONSE_CODE_MESSAGE,
  PAGE_STATUS,
  isBoughtWithPageStatus,
  isCanBuyWithPageStatus,
  isOpenedWithPageStatus
} from './page-status'
import { KADA_APP_DOWNLOAD_URL, WECHAT_PAY_INFO_COVER_URL } from './constants'
import * as userService from '@/services/user'
import { getPreOrder } from '@/services/subscribe'
import { getGoodsData } from '@/services/goods'
import config from '@/lib/config'
import {
  setAfterReloadTask,
  execAfterReloadTasks,
  addTask
} from './reload-tasks'
import {
  useHookWrap,
  checkPageStatusHook,
  showWhenPageStatusDialogHook,
  showOpenedDialogHook,
  showSuccessDialogHook,
  notAllowBuyHook,
  packageIdErrorHook
} from './hooks'
import {
  getDialogOptionsByName,
  getAnalyticsIdByName,
  getDialogOptionsWhenStatus
} from '../scheme/page-config'
import { logger } from '@/lib/logger'
import { context, getPageData, sendBehavior, toUsageView } from './index'
import { showDialog as showLoginDialog } from '@/page/components/LoginDialog'
import * as storage from '@/lib/storage'

const { loginType } = config.wechat

/**
 * 不允许购买的处理函数
 * @param {Boolean} isCanbuy
 * @returns {Boolean}
 */
const notAllowBuy = useHookWrap((canBuy) => canBuy, notAllowBuyHook)

/**
 * 礼包ID错误处理
 */
const packageIdError = useHookWrap((packageId) => {
  throw new Error('礼包ID不存在')
}, packageIdErrorHook)

const { wechat: wechatConfig } = config

// 页面请求参数
const pageQuery = qs.parse(location.search, {
  ignoreQueryPrefix: true
})

// 微信授权页面地址
const AUTH_PAGE = wechatConfig.authPage || 'https://h5.hhdd.com/n/wechat/auth.html'
// 页面原始地址（排除微信登录信息之后的地址）
let getOriginUrl = () => location.href.replace(/(\?|&)*(code|state)=([^&=?#]+)/ig, '')
// 设置年龄之后，排除微信登录，年龄字段
let getOriginSetageUrl = () => location.href.replace(/(\?|&)*(code|state|newUser)=([^&=?#]+)/ig, '')

// 支持的ReloadTasks的方法
export const AFTER_RELOAD_TASKS_TYPES = {
  PAYMENT: 'payment',
  REPAYMENT: 'repayment',
  BUY_SUCCESS: 'buySuccess'
}

// 添加重载后执行任务
addTask(AFTER_RELOAD_TASKS_TYPES.PAYMENT, payment)
addTask(AFTER_RELOAD_TASKS_TYPES.REPAYMENT, repayment)
addTask(AFTER_RELOAD_TASKS_TYPES.BUY_SUCCESS, showSuccessDialog)

/**
 * 用户授权登录
 *
 * @param {Object} query url中请求参数
 * @param {Boolean} forceAuth 微信环境下强制授权登陆
 * @return {Object} 用户数据字段：newUser，deviceId
 */
let _wxauthLoadingHideTimer = 0
export async function userWxAuth (query = pageQuery, forceAuth = false) {
  if (!deviceInfo.wechat) {
    return false
  }

  if (_wxauthLoadingHideTimer) {
    clearTimeout(_wxauthLoadingHideTimer)
  }

  if (!query.code) {
    console.log('无code')
    _wxauthLoadingHideTimer = setTimeout(() => {
      hideLoading()
    }, 1600)
    goWxAuth(getOriginUrl())
  } else {
    // 拿到授权
    let res

    console.log('有code')

    try {
      showLoading('努力加载中...')
      res = await userService.login(query.code, loginType)
      hideLoading()
    } catch (error) {
      hideLoading()
      toast('网络错误，请稍后再试')
    }

    const queryCode = query.code
    query.code = ''
    // if (userInfo && !forceAuth) {
    //   execAfterReloadTasks()
    // }

    storage.set('openId', `${res.data.openId}`)
    storage.set('unionId', `${res.data.unionId}`)

    const newUrl = location.href.replace(/(\?|&)*(code|state)=([^&=?#]+)/ig, '')
    if (history.replaceState) {
      history.replaceState(queryCode, document.title, newUrl)
    } else {
      location.replace(newUrl)
    }

    return res
  }
}

/**
 * 跳转微信登录授权
 * @param {string} originalPath
 */
function goWxAuth (originalPath) {
  if (!deviceInfo.wechat) {
    toast('请在微信中打开')
    return
  }

  // 去授权
  const state = 63560
  const time = Date.now()
  const redirectUri = encodeURIComponent(`${AUTH_PAGE}?origin=${encodeURIComponent(originalPath)}&t=${time}`)
  const url = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${wechatConfig.appId}&redirect_uri=${redirectUri}&response_type=code&scope=snsapi_userinfo&state=${state}#wechat_redirect`
  location.replace(url)
}

/***
 * 微信授权登陆
 */
export async function wxAuthLogin(forceAuth) {
  userWxAuth(pageQuery, forceAuth)
}

/**
 * 微信登录
 *
 * @return {Boolean} 是否已经登录
 */
export async function openLogin () {
  if (!deviceInfo.wechat) {
    toast('请在微信中打开此页面')
    return false
  }
  // const useInfo = await userWxAuth(pageQuery)

  // return useInfo || userService.isLogin()

  showLoginDialog({
    onClose: (res) => {
      console.log('弹窗关闭状态', res)
      if (res === true) {
        // 登录成功
        execAfterReloadTasks()
      }
    }
  })
}

/**
 * 检查页面是否已经登录
 *
 * @param {Object} options
 * @param {Boolean} options.openLogin 如果未登录，尝试打开登录弹层, 默认为 true
 *
 * @returns {Boolean}
 */
export async function checkLogin (options = {}) {
  const { openLogin: openLoginPanel = false } = options
  if (!deviceInfo.wechat) {
    return false
  }

  if (!userService.isLogin()) {
    if (openLoginPanel) {
      return openLogin()
    }

    return false
  }
  return true
}

// 礼包信息
let _packageInfo = null

// 支付成功之后刷新接口
let successRefreshTimer = 0
// 最大刷新次数
const MAX_SUCESS_REFRESH_COUNT = 4
/**
 * 显示购买成功弹窗
 *
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
function showSuccessDialog(options) {
  if (successRefreshTimer) {
    clearTimeout(successRefreshTimer)
  }

  // 根据配置是否显示购买成功弹窗
  const successDialogOptions = getDialogOptionsByName('successDialog')
  if (successDialogOptions) {
    const viewStatId = getAnalyticsIdByName('dialog.successDialog.view')
    const clickStatId = getAnalyticsIdByName('dialog.successDialog.doneClick')
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    showDialog({
      ...successDialogOptions,
      onDone: () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }

        const doneButton = successDialogOptions && successDialogOptions.doneButton
        const doneAction = doneButton.action
        if (doneAction === 'linkTo') {
          const url = doneButton.params
          if (url) {
            location.href = url
          }
        } else if (doneAction === 'toRead' || doneAction === 'toUsageView') {
          toDownload(true)
        } else if (doneAction === 'toDownload') {
          toDownload()
        }
      }
    })
  } else {
    let refreshTimes = MAX_SUCESS_REFRESH_COUNT
    const refreshPageData = () => {
      refreshTimes--
      const canbuy = getPageData(false)
      console.log('showSuccessDialog::refreshPageData')

      if (canbuy && refreshTimes > 0) {
        successRefreshTimer = setTimeout(refreshPageData, 1000)
      }
    }
    // 购买成功后，每隔0.6s轮询消息同步后刷新接口
    successRefreshTimer = setTimeout(refreshPageData, 1000)
  }
}

/**
 * 购买前刷新接口，获取最新礼包ID
 * @param {Boolean} isRefresh 是否为刷新接口
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
export async function repayment (isRefresh = false, options = {}) {
  if (!deviceInfo.wechat) {
    toast('请在微信中打开')
    return false
  }

  const { packageIdType } = options

  if (packageIdType && context.packageIdType !== packageIdType) {
    // 重新加载之后，重置当前packageIdType到上下文
    context.packageIdType = packageIdType
  }

  // 再次检查是否允许参与活动并且支付
  const canBuy = await getPageData(true)
  if (!canBuy) {
    return notAllowBuy(canBuy)
  }

  let { packageId, packageType = options.packageType, viewData } = context

  if (viewData && (typeof viewData[packageIdType] !== 'undefined')) {
    packageId = viewData[packageIdType]
  }

  return payment(packageId, isRefresh, { ...options, packageType })
}

/**
 * 购买活动礼包
 * @param {Number} packageId [必填] 礼包ID
 * @param {Boolean} isRefresh 登录后刷新支付流程
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 *
 * @returns {Boolean}
 */
export async function payment (packageId, isRefresh = false, options = {}) {
  const { packageType = 5, orderTraceInfo = {} } = options
  console.log(orderTraceInfo)
  if (!deviceInfo.wechat) {
    toast('请在微信中打开')
    return false
  }
  const isLogin = await checkLogin()

  if (!isLogin) {
    // 重试情况下不注册 repayment 方法
    if (!isRefresh) {
      setAfterReloadTask(AFTER_RELOAD_TASKS_TYPES.REPAYMENT, [true, options])
    }
    return openLogin()
  }

  if (!packageId) {
    return packageIdError(packageId)
  }
  // showLoading('正在获取商品信息')
  console.log(packageType)
  // _packageInfo = await getGoodsInfoById(packageId, packageType)
  // if (!_packageInfo) {
  //   hideLoading()
  //   toast('获取商品信息失败')
  //   return
  // }
  // hideLoading()
  showLoading('正在创建订单')
  try {
    const data = await getPreOrder({
      sourceId: packageId,
      sourceType: packageType,
      tradeType: 'JSAPI',
      orderTraceInfo: JSON.stringify(orderTraceInfo)
    }, {
      partnerId: context.channelId || ''
    })
    hideLoading()
    // return
    setTimeout(() => {
      wxPay(data, options)
    }, 300)
  } catch (error) {
    hideLoading()
    // 微信端终身会员不支持购买礼包
    // eslint-disable-next-line eqeqeq
    if (error.code == 410) {
      toast(error.message || '已经订阅')
      throw error
    } else {
      toast(error.message || '订单创建失败')
    }
  }
}

/**
 * 获取商品信息
 * @param {String} sourceId 资源ID
 * @param {Promise<any>} 商品信息
 */
export async function getGoodsInfoById (sourceId, sourceType = 5) {
  try {
    if (sourceId) {
      const goodsInfo = await getGoodsData(sourceId)

      if (goodsInfo) {
        return {
          sourceId,
          sourceType,
          ...goodsInfo
        }
      }
    }
  } catch (error) {
    logger.error(error)
    toast(error.message || '获取商品信息失败')
  }

  return null
}

/**
 * 跳转微信支付
 * @param {Object} order 订单信息
 *
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
function wxPay (order, options) {
  if (!deviceInfo.wechat) {
    toast('请在微信中打开')
    return
  }

  if (!wechatConfig.payPage) {
    throw new Error('支付页面地址不存在')
  }
  if (!order) {
    toast('订单不存在，支付失败')
    return
  }
  const { appId, timeStamp, nonceStr, package: payPackage, signType, paySign, orderInfo = {} } = order

  // const { coverUrl, name, price } = _packageInfo
  const { orderNo, orderPrice, productName, coverUrl = WECHAT_PAY_INFO_COVER_URL } = orderInfo
  const [originBaseUrl, originHash = ''] = getOriginSetageUrl().split(/#+/)
  const [hashPath = '', hashQuery = ''] = originHash.split(/\?+/)
  const hashQueryObj = qs.parse(hashQuery)

  const successPage = `${originBaseUrl}#${hashPath}${qs.stringify(hashQueryObj, { addQueryPrefix: true })}`
  const query = qs.stringify({
    params: JSON.stringify({
      appId: appId || wechatConfig.appId,
      timeStamp,
      nonceStr,
      package: payPackage,
      signType,
      paySign,
      coverUrl,
      name: productName,
      price: orderPrice <= 900 ? (orderPrice / 100) : Math.floor(orderPrice / 100),
      orderNo,
      // 支付成功后的跳转页
      successDirectUrl: successPage
    })
  }, { addQueryPrefix: true })

  setAfterReloadTask(AFTER_RELOAD_TASKS_TYPES.BUY_SUCCESS, [options])
  location.href = `${wechatConfig.payPage}${query}`
}

/**
 * 跳转下载页面
 */
export function toDownload (isUsage) {
  const downloadStatId = getAnalyticsIdByName('toDownload')

  if (downloadStatId) {
    sendBehavior(downloadStatId)
  }
  // 延迟100ms跳转，目的是保证打点能正常提交
  setTimeout(() => {
    if (isUsage) {
      toUsageView()
    } else {
      location.href = KADA_APP_DOWNLOAD_URL
    }
  }, 100)
}

/**
 * 检查接口返回页面数据
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {String} ctx.pageStatus 页面当前状态
 * @param {Boolean} isRefresh 是否为刷新接口
 */
 export const checkPageStatus = useHookWrap(_checkPageStatus, checkPageStatusHook)

/**
 * 根据页面状态显示弹窗
 * @param {String} pageStatus
 */
 const showWhenPageStatusDialog = useHookWrap(async (pageStatus) => {
  const canBuy = await isCanBuyWithPageStatus(pageStatus)
  const dialogOpts = getDialogOptionsWhenStatus(pageStatus)

  if (dialogOpts) {
    const viewStatId = getAnalyticsIdByName(`dialog.${pageStatus}.view`)
    const clickStatId = getAnalyticsIdByName(`dialog.${pageStatus}.doneClick`)
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    const { showTimes = canBuy ? 'once' : 'always', ...showDialogOpts } = dialogOpts

    return showDialog({
      ...showDialogOpts,
      doneCloseDialog: showTimes === 'once',
      onDone: () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }

        toDownload()
      }
    })
  }
}, showWhenPageStatusDialogHook)

/**
 * 检查接口返回页面数据
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {String} ctx.pageStatus 页面当前状态
 * @param {Boolean} isRefresh 是否为刷新接口
 */
async function _checkPageStatus (ctx, isRefresh = false) {
  if (!ctx) {
    throw new Error('context 为必传参数')
  }

  const {
    pageStatus,
    responseBody = {}
  } = ctx

  if (!isRefresh) {
    // 页面PV打点
    const statId = getAnalyticsIdByName('pageView')
    const boughtStatId = getAnalyticsIdByName('boughtPageView')
    if (statId) {
      sendBehavior(statId)
    }
    if (boughtStatId) {
      sendBehavior(boughtStatId)
    }
  }

  const canBuy = await isCanBuyWithPageStatus(pageStatus)
  if (pageStatus === PAGE_STATUS.NETWORK_ERROR) {
    const { code, msg } = responseBody || {}
    const errorObj = RESPONSE_CODE_MESSAGE[code] || { title: msg || '网络错误，请稍后再试' }
    const dialogOpts = getDialogOptionsByName('dialog.networkError')
    const viewStatId = getAnalyticsIdByName('dialog.networkError.view')
    const clickStatId = getAnalyticsIdByName('dialog.networkError.doneClick')
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    showDialog({
      type: DIALOG_TYPE.ERROR,
      title: errorObj.title || '网络请求异常',
      message: errorObj.message,
      hideOnMask: false,
      buttonText: '我知道了',
      doneCloseDialog: false,
      ...dialogOpts,
      onDone: () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }

        toDownload()
      }
    })

    return false
  }

  const isBought = await isBoughtWithPageStatus(pageStatus)
  if (isBought) {
    Promise.resolve().then(() => execAfterReloadTasks())

    return false
  }

  // 根据页面状态显示弹窗
  showWhenPageStatusDialog(pageStatus)

  return canBuy
}

/**
 * 显示已经开通弹窗
 * @param {String} pageStatus
 */
const showOpenedDialog = useHookWrap(async () => {
  const openedDialogOptions = getDialogOptionsByName('opened')
  const viewStatId = getAnalyticsIdByName('dialog.opened.view')
  const clickStatId = getAnalyticsIdByName('dialog.opened.doneClick')
  if (viewStatId) {
    sendBehavior(viewStatId)
  }

  showDialog({
    type: DIALOG_TYPE.MESSAGE,
    title: '你已享有该活动所有权益',
    message: '无需参加本活动哦',
    buttonText: '我知道了',
    doneCloseDialog: false,
    ...openedDialogOptions,
    onDone: () => {
      if (clickStatId) {
        sendBehavior(clickStatId)
      }

      toDownload()
    }
  })
}, showOpenedDialogHook)

/**
 * 购买礼包
 * @param {Number} packageId [必填] 礼包ID
 * @param {Object} options
 * @param {Context} options.context 页面上下文
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
export async function buyPackage (packageId, options = {}) {
  const { context = {}, packageIdType = 'main', packageType = 5, orderTraceInfo = {} } = options
  const { pageStatus } = context
  const canBuy = await isCanBuyWithPageStatus(pageStatus)

  if (canBuy) {
    return payment(packageId, false, {
      packageType,
      packageIdType,
      orderTraceInfo
    })
  }

  const isOpened = await isOpenedWithPageStatus(pageStatus)
  if (isOpened) {
    showOpenedDialog(pageStatus)

    return false
  }

  const isBought = await isBoughtWithPageStatus(pageStatus)
  toDownload(isBought)
  return false
}
