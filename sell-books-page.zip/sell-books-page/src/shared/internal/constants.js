/**
 * 购买礼包业务配置常量
 *
 * @summary 购买礼包业务配置常量
 * @author diaoling <jinjian@hhdd.com>
 */
import { INNER_APP_NAME_ENUM } from '@kada/lib-ua-parser/src/ua-parser'
// KaDa阅读下载地址
export const KADA_APP_DOWNLOAD_URL = 'https://a.app.qq.com/o/simple.jsp?pkgname=com.hhdd.kada'
export const KADA_APP_OPEN_IN_APPSTORE = 'itms-apps://itunes.apple.com/app/id990142347'
// 页面返回标记
export const STATE_BACK_REFERRER = 'STATE_BACK_REFERRER'
// 用户是否第一进入页面
export const STATE_FIRST_ENTRY = 'STATE_FIRST_ENTRY'

// HD支持在线客服的版本
export const HD_SUPPORT_ONLINE_SERVICE_VERSION = {
  [INNER_APP_NAME_ENUM.KADA]: {
    version: '4.7.21.20',
    operator: '<='
  },
  [INNER_APP_NAME_ENUM.QUXUE]: {
    version: '1.0.0',
    operator: '<'
  }
}
// HD支持礼包购买版本
export const HD_SUPPORT_PACKAGE_PAYMENT = {
  [INNER_APP_NAME_ENUM.KADA]: {
    version: '4.0.20',
    operator: '<'
  },
  [INNER_APP_NAME_ENUM.QUXUE]: {
    version: '1.0.0',
    operator: '<'
  }
}
// App支持礼包购买版本
export const APP_SUPPORT_PACKAGE_PAYMENT = {
  [INNER_APP_NAME_ENUM.KADA]: {
    version: '4.7.10',
    operator: '<'
  }
}
// App新版tab页
export const NEW_TABBAR_APP_VERSION = {
  [INNER_APP_NAME_ENUM.KADA]: {
    version: '5.4.10',
    operator: '>='
  }
}
// HD支持返回推荐页
export const HD_CAN_BACK_RECOMMENT_VERSIONS = {
  [INNER_APP_NAME_ENUM.KADA]: {
    version: '4.9.2.0',
    operator: '>='
  },
  [INNER_APP_NAME_ENUM.QUXUE]: {
    version: '1.0.0',
    operator: '>='
  }
}

export const DEFAULT_REFRESH_MOUDLES = ['course', 'vipinfo']

export const WECHAT_PAY_INFO_COVER_URL = '//cdn.hhdd.com/frontend/as/i/db41f48c-11d5-5991-a2e4-8b3e9df26210.jpg'

//常用正则表达式
export const regExp = {
  zhCn: /^[\u4e00-\u9fa5a-zA-Z]+$/,             //姓名仅支持中文
  zhCnNum: /^[\u4e00-\u9fa5a-zA-Z0-9]+$/,       //地址详情仅支持中英文数字
  phone: /^1[3456789]\d{9}$/,                   //手机号
  svgaSuffix: /^.+(\.svga)$/
}
