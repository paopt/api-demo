/**
 * 页面状态管理
 *
 * @summary 页面状态管理
 * @author diaoling <jinjian@hhdd.com>
 */
import {
  useHookWrap,
  responseToStatusHook,
  canbuyWithPageStatusHook,
  openedWithPageStatusHook,
  boughtWithPageStatusHook
} from './hooks'

// 常见 CODE 错误信息
export const RESPONSE_CODE_MESSAGE = {
  5404: {
    title: '活动不存在'
  },
  5405: {
    title: '活动已结束',
    message: '下次早点来参加哦'
  },
  5406: {
    title: '活动还未开始哦！'
  },
  5401: {
    title: '此用户信息未找到'
  },
  55404: {
    title: '找不到拼团队伍信息！'
  },
  44400: {
    title: '网络请求异常！'
  },
  400: {
    title: 'cookie 不合法'
  },
  403: {
    title: '用户异常'
  }
}

/**
 * 内部预置页面各状态
 */
const INTERNAL_PAGE_STATUS = {
  NETWORK_ERROR: 'networkError', // 网络请求返回数据错误
  ACTIVITY_ENDED: 'activityEnded', // 活动已经结束
  TIME_ENDED: 'timeEnded', // 为注册超过30天的老用户
  NOT_LOGIN: 'notLogin', // 未登录
  UNKNOWN: 'unknown', // 状态未知
  NORMAL: 'normal', // 非终身
  LIFEVIP: 'lifevip', // 活动外：已开通终身会员
  OPENED: 'lifevip', // 活动外，已开通所有权益 此活动中已是终身会员就是享有所有权益
  BOUGHT: 'bought', // 已经参加过
  SUBVIP: 'subvip' // 听书/绘本会员（需要升级）
}

/**
 * 根据返回CODE映射页面状态
 */
export let RESPONSE_CODE_TO_PAGESTATUS = {
  4403: INTERNAL_PAGE_STATUS.NOT_LOGIN, // 未登录
  7003: INTERNAL_PAGE_STATUS.LIFEVIP, // 活动外终身会员
  5405: INTERNAL_PAGE_STATUS.ACTIVITY_ENDED, // 活动已经结束
  8001: INTERNAL_PAGE_STATUS.SUBVIP // 听书/绘本会员
}

/**
 * 重置 RESPONSE_CODE_TO_PAGESTATUS 值
 *
 * @param {Object} statusMap
 */
export function resetResponseCodeToPageStatus (statusMap) {
  RESPONSE_CODE_TO_PAGESTATUS = statusMap || {}
}

/**
 * 根据返回状态status映射页面状态
 */
export let RESPONSE_STATUS_TO_PAGESTAUS = {
  0: INTERNAL_PAGE_STATUS.NORMAL
}

/**
 * 根据DataService计算状态computedStatus映射页面状态
 */
export let COMPUTED_STATUS_TO_PAGESTATUS = {}

/**
 * 重置 RESPONSE_STATUS_TO_PAGESTAUS 值
 *
 * @param {Object} statusMap
 */
export function resetResponseStatusToPageStatus (statusMap) {
  RESPONSE_STATUS_TO_PAGESTAUS = statusMap || {}
}

/**
 * 重置 COMPUTED_STATUS_TO_PAGESTATUS 值
 *
 * @param {Object} statusMap
 */
export function resetComputedStatusToPageStatus (statusMap) {
  COMPUTED_STATUS_TO_PAGESTATUS = statusMap || {}
}

/**
 * 页面某个状态是否可以购买礼包
 */
const INTERNAL_PAGETSTATUS_TO_CANBUY = {
  [INTERNAL_PAGE_STATUS.NETWORK_ERROR]: false,
  [INTERNAL_PAGE_STATUS.ACTIVITY_ENDED]: false,
  [INTERNAL_PAGE_STATUS.TIME_ENDED]: false,
  [INTERNAL_PAGE_STATUS.NOT_LOGIN]: true,
  [INTERNAL_PAGE_STATUS.UNKNOWN]: true,
  [INTERNAL_PAGE_STATUS.NORMAL]: true,
  [INTERNAL_PAGE_STATUS.LIFEVIP]: true,
  [INTERNAL_PAGE_STATUS.OPENED]: false,
  [INTERNAL_PAGE_STATUS.BOUGHT]: false,
  [INTERNAL_PAGE_STATUS.SUBVIP]: false
}
let PAGESTAUS_TO_CANBUY = INTERNAL_PAGETSTATUS_TO_CANBUY

/**
 * 重置 PAGESTAUS_TO_CANBUY 值
 *
 * @param {Object} statusMap
 */
export function resetPageStatusToCanbuy (statusMap) {
  PAGESTAUS_TO_CANBUY = { ...INTERNAL_PAGETSTATUS_TO_CANBUY, ...statusMap }
}

/**
 * 已购买状态集
 */
export let BOUGHT_STATUS = [
  INTERNAL_PAGE_STATUS.BOUGHT
]

/**
 * 重置 BOUGHT_STATUS 值，如：配置文件中定义购买状态集
 *
 * @param {Array<String>} status
 */
export function resetBoughtStatus (status) {
  BOUGHT_STATUS = [
    ...status
  ]
}

/**
 * 活动外开通全部权益的状态集
 */
export let OPENED_STATUS = [
  INTERNAL_PAGE_STATUS.OPENED
]

/**
 * 重置 OPENED_STATUS 值，如：配置文件中定义活动外已开通状态集
 *
 * @param {Array<String>} status
 */
export function resetOpenedStatus (status) {
  OPENED_STATUS = [
    ...status
  ]
}

/**
 * 页面状态枚举
 */
export let PAGE_STATUS = INTERNAL_PAGE_STATUS

/**
 * 重置 PAGE_STATUS 值，如：配置文件中定义的状态
 *
 * @param {Object<String, String>} status
 */
export function resetPageStatus (status) {
  PAGE_STATUS = {
    ...INTERNAL_PAGE_STATUS,
    ...status
  }
}

/**
 * 根据Response返回页面状态
 * @param {{code:Number, data: { userInfo: { status:Number } }}} response 请求返回数据
 * @param {Boolean} isRefresh 是否刷新接口
 *
 * @returns {String} 页面状态
 */
export const getResponsePageStatus = useHookWrap(async (response, isRefresh = false) => {
  if (!response) {
    throw new Error('response 为必传参数')
  }
  const { code, data } = response
  // 根据返回的 Code 返回页面状态
  const codeKey = code

  if (RESPONSE_CODE_TO_PAGESTATUS[codeKey]) {
    return RESPONSE_CODE_TO_PAGESTATUS[codeKey]
  }

  // 请求数据异常
  if (!data) {
    return PAGE_STATUS.NETWORK_ERROR
  }

  const { userInfo } = data

  if (userInfo) {
    const { status, userStatus, computedStatus } = userInfo
    if (COMPUTED_STATUS_TO_PAGESTATUS[computedStatus]) {
      return COMPUTED_STATUS_TO_PAGESTATUS[computedStatus]
    }

    console.log('计算页面状态: ', COMPUTED_STATUS_TO_PAGESTATUS, computedStatus)

    // 兼容服务端两种字段返回，status 汤洪池返回字段， userStatus 陶新返回字段
    const statusKey = status || userStatus
    if (RESPONSE_STATUS_TO_PAGESTAUS[statusKey]) {
      return RESPONSE_STATUS_TO_PAGESTAUS[statusKey]
    }
  }

  if (code !== 200) {
    return PAGE_STATUS.NETWORK_ERROR
  }

  return PAGE_STATUS.NORMAL
}, responseToStatusHook)

/**
 * 根据当前状态检查是否可以购买
 * @param {String} pageStatus 页面状态
 */
export const isCanBuyWithPageStatus = useHookWrap((pageStatus) => {
  return !!PAGESTAUS_TO_CANBUY[pageStatus]
}, canbuyWithPageStatusHook)

/**
 * 根据当前状态检查是否可以购买
 * @param {String} pageStatus 页面状态
 */
export const isOpenedWithPageStatus = useHookWrap((pageStatus) => (Array.isArray(OPENED_STATUS) && OPENED_STATUS.includes(pageStatus)), openedWithPageStatusHook)

/**
 * 是否已经参与并购买
 * @param {String} pageStatus
 */
 export const isBoughtWithPageStatus = useHookWrap((pageStatus) => (Array.isArray(BOUGHT_STATUS) && BOUGHT_STATUS.includes(pageStatus)), boughtWithPageStatusHook)
