/**
 * 活动页面上下文
 *
 * @summary 活动页面上下文
 * @author diaoling <jinjian@hhdd.com>
 */
import { writable, get, derived } from 'svelte/store'
import { PAGE_STATUS } from './page-status'

const noop = () => {}

export default class Context {
  /**
   * 获取上下文实例
   * @param {Object} options 参数
   * @param {Number|String} options.activityKey 活动ID
   * @param {Function} options.dataService 请求活动数据Service
   * @param {Function} options.parseViewData 获取view渲染所需数据
   */
  constructor (options = {}) {
    const { dataService = noop, parseViewData = noop, activityKey, channelId } = options

    this._activityKey = writable(activityKey) // 活动ID
    this._channelId = writable(channelId) // 渠道ID
    this._getServiceData = dataService
    this._getViewData = parseViewData

    this._packageId = writable(0) // 礼包ID
    this._packageType = writable(5) // 礼包类型
    this._packageIdType = writable('') // 礼包ID类型，同一活动内包含多个礼包ID，礼包ID保持在viewData字段
    this._pageLoaded = writable(false) // 页面数据加载和完成解析
    this._responseBody = writable(null) // 主页面请求返回数据
    this._pageStatus = writable(PAGE_STATUS.UNKNOWN) // 页面当前状态
    this._canBuy = writable(false) // 是否可以购买礼包
    this._viewData = writable(null) // 页面渲染所需数据
  }

  // 活动ID相关读写操作
  get activityKey () {
    return get(this._activityKey)
  }

  set activityKey (value) {
    this._activityKey.set(value)
  }

  // 渠道号相关读写操作
  get channelId () {
    return get(this._channelId)
  }

  set channelId (value) {
    this._channelId.set(value)
  }

  // 活动礼包读写操作
  get packageId () {
    return get(this._packageId)
  }

  set packageId (value) {
    this._packageId.set(value)
  }

  // 活动礼包类型读写操作
  get packageType () {
    return get(this._packageType)
  }

  set packageType (value) {
    this._packageType.set(value)
  }

  // 活动礼包ID类型读写操作
  get packageIdType () {
    return get(this._packageIdType)
  }

  set packageIdType (value) {
    this._packageIdType.set(value)
  }

  // 页面数据加载解析完成读写操作
  get pageLoaded () {
    return get(this._pageLoaded)
  }

  set pageLoaded (value) {
    this._pageLoaded.set(value)
  }

  // 页面状态变化读写操作
  get pageStatus () {
    return get(this._pageStatus)
  }

  set pageStatus (value) {
    this._pageStatus.set(value)
  }

  // 是否可以购买礼包相关读写操作
  get canBuy () {
    return get(this._canBuy)
  }

  set canBuy (value) {
    this._canBuy.set(value)
  }

  // 页面渲染所需数据相关读写操作
  get viewData () {
    return get(this._viewData)
  }

  set viewData (value) {
    this._viewData.set(value)
  }

  /**
   * 生成计算属性
   *
   * @param {Array<String>} watchProps 属性名称，一个属性仅传属性名称 viewData, 多个属性使用逗号（半角）隔开，如 viewData,canBuy
   * @param {Function} callback 计算属性内部处理逻辑
   * @param {*} initValue 初始化值
   *
   * @returns {Object} 计算属性变量值
   */
  computed (watchProps, callback, initValue) {
    if (!watchProps) {
      throw new Error('propName 不能为空')
    }

    const names = watchProps.map(item => item.trim()).filter(item => !!item)

    if (names.length) {
      const props = names.map(item => `_${item}`).filter(item => (item in this)).map(item => this[item])
      return derived(props, callback, initValue)
    }

    return null
  }

  /**
   * 订阅属性变化
   * @param {String} propName 监听属性
   * @param {Function} callback 属性变化回调函数
   */
  subscribe (propName, callback) {
    const internalName = `_${propName}`
    if (!(internalName in this)) {
      throw new Error(`${internalName} 不存在`)
    }

    const prop = this[internalName]

    return prop.subscribe(callback)
  }

  /**
   * 获取view渲染所需数据
   */
  getViewData () {
    return this._getViewData(this.pageStatus, this.responseBody)
  }

  /**
   * 请求活动数据Service
   * @param {String|Number} activityKey
   * @param {Boolean} isRefresh 是否刷新接口
   */
  getServiceData (activityKey, isRefresh) {
    if (typeof activityKey === 'undefined') {
      activityKey = this.activityKey
    }

    return this._getServiceData(activityKey, isRefresh)
  }

  /**
   * 获取上下文数据
   * @returns {Object}
   */
  getData () {
    return Object.keys(this).map(key => key && key.replace(/^_/, '')).reduce((previouseValue, key) => {
      if ((key in this) && typeof this[key] !== 'function') {
        previouseValue[key] = this[key]
      }

      return previouseValue
    }, {})
  }
}
