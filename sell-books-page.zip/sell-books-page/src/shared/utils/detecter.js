import { compareVersion, deviceInfo } from '@kada/library/src/device'
import { HD_SUPPORT_ONLINE_SERVICE_VERSION, NEW_TABBAR_APP_VERSION } from '../internal/constants'

export const noop = () => {}

/**
 * 是否支持在线客服
 *
 * @returns {Promise<Boolean>}
 */
export const hasSupportOnlineService = async () => {
  if (!(deviceInfo.isPad && deviceInfo.android) || deviceInfo.isKadaClient || deviceInfo.wechat) return true

  return compareVersion(HD_SUPPORT_ONLINE_SERVICE_VERSION)
}

/**
 * 是否为新版界面(AI课程、书房等)
 */
export const hasNewTabbarApp = async () => {
  if ((deviceInfo.isPad && deviceInfo.android) || !deviceInfo.isKadaClient) return false

  return compareVersion(NEW_TABBAR_APP_VERSION)
}
