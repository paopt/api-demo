/**
 * 数组映射判断
 *
 * @param {Array<[boolean, Object]} cases 判断列表
 * @param {Object} defaultValue 默认值
 *
 * @returns {Object}
 */
 export function mapSwitch (cases, defaultValue) {
  if (!Array.isArray(cases) && !cases.length) {
    return defaultValue
  }

  for (let i = 0, len = cases.length; i < len; i++) {
    const [expression, value] = cases[i] || {}

    if (expression) {
      return value
    }
  }

  return defaultValue
}
