/**
 * 屏蔽用户真实昵称
 * @param {String} name 用户昵称
 * @param {Object} item 用户全部信息
 * @return {String}
*/
export function maskNickName (name, item) {
  name = name || '宝贝' + (item.userId || '')
  const firstWord = name.substr(0, 1)
  const lastWord =
    name.length > 2 ? name.substring(name.length - 1) : ''
  const midWord = '**'

  return `${firstWord + midWord + lastWord}`
}
