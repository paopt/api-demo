<div class="o-page-loading"></div>

<style global>
  .o-page-loading {
    display: flex;
    width: 100%;
    height: 100%;
    align-items: center;
    justify-content: center;
  }
</style>
