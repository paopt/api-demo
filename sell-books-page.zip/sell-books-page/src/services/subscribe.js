import { getApi, fetch } from '@/lib/fetch'
import { getDeviceId } from '@kada/library/src/device'

/* 微信预下单操作 */
/**
 * @public
 * POST params
 * @see https://note.youdao.com/share/?id=a8db729f722c9879a81f5e063d018417&type=note#/
 *
 * @param {Object} params 提交数据
 * @param {Number} params.sourceId 下单礼包ID 打包销售（sourceType=5）是gookskey为sourceId
 * @param {Number} params.sourceType 下单礼包类型 1:绘本合辑，2：听书合辑，4：优才计划 5：促销商品合辑
 * @param {String} params.tradeType 交易类型 JSAPI--公众号支付 MWEB--H5支付 PMMB--妈妈帮支付 PMMN--妈妈帮支付
 * @param {Object} headers Header参数
 * @param {String} headers.partnerId 接入渠道ID
 */
export const getPreOrder = async (params, headers) => {
  const api = getApi('pay', 'order/create.json')
  const deviceId = getDeviceId()
  const data = Object.assign({
    deviceId
  }, params)

  const res = await fetch.post(api, data, { headers })
  if (res.code !== 200) {
    const event = new Error(res.msg || '创建订单失败')
    event.code = res.code
    throw event
  }
  const rawData = res.data || ''
  if (!rawData) {
    throw new Error('创建订单失败')
  }

  let resData = rawData
  if (typeof rawData === 'string') {
    try {
      resData = JSON.parse(rawData)
    } catch (e) {
      resData = null
      console.error(e)
    }
  }

  return resData
}
