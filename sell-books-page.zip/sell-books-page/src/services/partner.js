import { getApi, fetch } from '@/lib/fetch'
import config from '@/lib/config'
import { getCookie } from 'tiny-cookie'
import { getClientDeviceId, setDeviceId, getDeviceId } from '@kada/library/src/device'

const { loginType } = config.wechat

/**
 * 获取签名数据
 * @param {String} url 当前网页的URL，不包含hash部分
 * @see http://note.youdao.com/noteshare?id=a8db729f722c9879a81f5e063d018417&sub=ED166E6A07644FEC8A062F72443940C4
 */
export const getWechatConfig = url => {
  if (!url) {
    throw Error('请求参数[url]不存在！')
  }
  const params = {
    url,
    loginType
  }

  return fetch.post(getApi('partner', 'js/ticket/wechat.json'), params)
}

// 微信中是否登陆
export function isLogin () {
  const hhddCookie = getUserCookie()

  return hhddCookie && hhddCookie.userId && getDeviceId()
}

export function getUserCookie (name) {
  const rawCookie = getCookie('_HHDD_') || ''
  let userCookie = null
  if (rawCookie) {
    try {
      userCookie = JSON.parse(rawCookie)
    } catch (e) {
      console.error('service/user::getUserCookie parseUserCookie Error: ', e, rawCookie)
      userCookie = null
    }
  }

  if (name && userCookie) {
    return userCookie[name]
  }

  return userCookie
}

export async function login (code) {
  const params = {
    code,
    deviceId: getClientDeviceId(),
    loginType: config.wechat.loginType
  }

  // 获取JSSDK需要的签名认证信息
  // await getTicket()
  // 微信登陆
  const res = await wxLogin(params)

  if (res.code === 200 && res.data) {
    setDeviceId(res.data)
    return res
  }

  const error = new Error(res.msg || '登录失败')
  error.code = res.code
  throw error
}

/**
 * @private
 * GET 微信登陆
 */
const wxLogin = params => {
  const api = getApi('weixin', 'login/gzh.json')

  return fetch.get(api, {
    params
  })
}
