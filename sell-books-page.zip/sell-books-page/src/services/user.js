import { getCookie } from 'tiny-cookie'
import { getClientDeviceId, setDeviceId, getDeviceId, RDI as rdi } from '@kada/library/src/device'
import { getApi, fetch } from '@/lib/fetch'
import config from '@/lib/config'
const { loginType } = config.wechat


/**
 * 获取openId
 * @param {*} params 
 * @returns 
 */
const wxLogin = params => {
  const api = getApi('weixin', 'openId/get.json')

  return fetch.get(api, {
    params,
  })
}

export async function login (code, loginType) {
  const params = {
    code,
    deviceId: getClientDeviceId(),
    loginType: loginType
  }

  // 获取JSSDK需要的签名认证信息
  // await getTicket()
  // 微信登陆
  const res = await wxLogin(params)

  if (res.code === 200 && res.data) {
    setDeviceId(res.data)
    setTimeout(() => doLoginTask(), 0)
    return res
  }

  const error = new Error(res.msg || '登录失败')
  error.code = res.code
  throw error
}

const state = {
  userInfo: null
}

export async function getUserInfo () {
  if (state.userInfo && Object.keys(state.userInfo)) {
    return state.userInfo
  }

  const api = getApi('user', 'getUserInfo.json')

  return fetch.get(api, {
    params: {
      url: location.href
    }
  }).then(res => {
    if (res.code === 200) {
      state.userInfo = res.data
    } else {
      state.userInfo = null
    }

    return state.userInfo
  })
}

export function getUserCookie (name) {
  const rawCookie = getCookie('_HHDD_') || ''
  let userCookie = null

  if (rawCookie) {
    try {
      userCookie = JSON.parse(rawCookie)
      // 保证一些特殊情况下，cookie是多层字符串
      if (typeof userCookie === 'string') {
        userCookie = JSON.parse(userCookie)
      }
    } catch (e) {
      console.error('service/user::getUserCookie parseUserCookie Error: ', e, rawCookie)
      userCookie = null
    }
  }

  if (name && userCookie) {
    return userCookie[name]
  }

  return userCookie
}

const pendingTask = []

/**
 * 设置登录成功等待队列
 *
 * @param {Function} task
 */
export function addLoginTask (task) {
  pendingTask.push(task)
}

/**
 * 执行登录任务队列
 * @private
 */
function doLoginTask () {
  while (pendingTask.length) {
    const task = pendingTask.shift()
    if (typeof task === 'function') {
      task()
    }
  }
}

export function isLogin () {
  const hhddCookie = getUserCookie()
  console.log('cookie', hhddCookie)

  return hhddCookie && hhddCookie.userKey && getDeviceId()
}

export function getUserId () {
  const hhddCookie = getUserCookie()

  return hhddCookie && hhddCookie.userId
}

/**
 * 创建或登录
 * @see http://10.0.10.51:3000/project/119/interface/api/7637
 *
 * @param {Number} deviceId 设备id
 * @param {Number} phoneNumber 手机号
 * @param {Number} smsCode 验证码
 * @param {Number} wechatOpenId 微信端授权
 */
export const createUser = (params) => {
  const url = getApi('phone', 'login.json')
  return fetch.post(url, params)
}

/**
 * 用户信息
 * @see http://10.0.10.51:3000/project/119/interface/api/7016
 */
export const fetchUserInfo = () => {
  const url = getApi('user', 'getUserInfo.json')
  return fetch.get(url, {
    params: {
      s: new Date().getTime(),
    }
  })
  return {
    code: 200,
    data: {
      newUser: 0,
      deviceId: 'ksahdfkjhsadfhkasdfkn',
      avatar: '//cdn.hhdd.com/frontend/as/i/0743f092-4590-5288-b579-f14f08100c11.png',
      userNick: '用户昵称',
    },
  }
}

/**
 * 发送验证码
 * @see http://10.0.10.51:3000/project/119/interface/api/7644
 *
 * @param {Number} phoneNumber 手机号
 */
export const sendSmsCode = ({ phoneNumber, sessionId, sig, token }) => {
  const url = getApi('phone', 'sms/send.json')
  return fetch.post(url, {
    phoneNumber,
    sessionId,
    sig,
    token,
    scene: 'nc_message_h5',
  })
  return {
    code: 200,
    message: '发送验证码成功',
  }
}
