import { getCookie } from 'tiny-cookie'
import { getClientDeviceId, setDeviceId, getDeviceId, RDI as rdi } from '@kada/library/src/device'
import { getApi, fetch } from '@/lib/fetch'
import config from '@/lib/config'

/**
 * @private
 * GET 微信登陆
 * @see http://note.youdao.com/noteshare?id=a8db729f722c9879a81f5e063d018417&sub=ED166E6A07644FEC8A062F72443940C4
 */
const wxLogin = params => {
  const api = getApi('weixin', 'login/gzh.json')

  return fetch.get(api, {
    params,
    headers: {
      RDI: rdi
    }
  })
}

export async function login (code) {
  const params = {
    code,
    deviceId: getClientDeviceId(),
    loginType: config.wechat.loginType,
    type: 2                             //type:2，data中返回多个字段
  }

  // 获取JSSDK需要的签名认证信息
  // await getTicket()
  // 微信登陆
  const res = await wxLogin(params)

  if (res.code === 200 && res.data) {
    setDeviceId(res.data.deviceId)
    setTimeout(() => doLoginTask(), 0)
    return res.data
  }

  const error = new Error(res.msg || '登录失败')
  error.code = res.code
  throw error
}

const state = {
  userInfo: null
}

export async function getUserInfo () {
  if (state.userInfo && Object.keys(state.userInfo)) {
    return state.userInfo
  }

  const api = getApi('user', 'getUserInfo.json')

  return fetch.get(api, {
    params: {
      url: location.href
    }
  }).then(res => {
    if (res.code === 200) {
      state.userInfo = res.data
    } else {
      state.userInfo = null
    }

    return state.userInfo
  })
}

export function getUserCookie (name) {
  const rawCookie = getCookie('_HHDD_') || ''
  let userCookie = null

  if (rawCookie) {
    try {
      userCookie = JSON.parse(rawCookie)
      // 保证一些特殊情况下，cookie是多层字符串
      if (typeof userCookie === 'string') {
        userCookie = JSON.parse(userCookie)
      }
    } catch (e) {
      console.error('service/user::getUserCookie parseUserCookie Error: ', e, rawCookie)
      userCookie = null
    }
  }

  if (name && userCookie) {
    return userCookie[name]
  }

  return userCookie
}

const pendingTask = []

/**
 * 设置登录成功等待队列
 *
 * @param {Function} task
 */
export function addLoginTask (task) {
  pendingTask.push(task)
}

/**
 * 执行登录任务队列
 * @private
 */
function doLoginTask () {
  while (pendingTask.length) {
    const task = pendingTask.shift()
    if (typeof task === 'function') {
      task()
    }
  }
}

export function isLogin () {
  const hhddCookie = getUserCookie()

  return hhddCookie && hhddCookie.userKey && getDeviceId()
}

export function getUserId () {
  const hhddCookie = getUserCookie()

  return hhddCookie && hhddCookie.userId
}
