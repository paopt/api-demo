import { getApi, fetch } from '@/lib/fetch'

/**
 * 获取售卖礼包信息
 *
 * @param {string} goodsKey
 */
export function getGoodsData (goodsKey) {
  const api = getApi('promotion', 'goods/info.json')

  return fetch.get(api, {
    params: {
      goodsKey,
      _: Date.now()
    }
  }).then(res => {
    if (res.code === 200) {
      return res.data
    }
    throw new Error('获取商品数据失败')
  })
}
