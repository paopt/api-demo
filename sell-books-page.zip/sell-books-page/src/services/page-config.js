import { getApi, fetch } from '@/lib/fetch'
import { DAY_TIME } from '@kada/library/utils/datetime'
import config from '@/lib/config'
import * as storage from '@/lib/storage'

const { env, project: { name: projectName } } = config
// 页面配置默认版本号
export const PAGE_CONFIG_DEFAULT_VERSION = 'v1_0'
// 页面配置保存KEY
export const PAGE_CONFIG_PREFIX = 'PAGE_CONFIG_LCACHE_'
// 配置内存缓存
const PAGE_CONFIG_MEM_CACHE_DATA = {}

/**
 * 获取页面配置信息，配置获取顺序内存、localStorage、请求接口
 * @param {Number|String} activityKey
 * @param {Object} options
 * @param {Boolean} options.fetchData 是否请求远程JSON配置
 * @param {String} options.jsonVersion JSON配置格式版本，版本如：v1.0.0 --> v1_0_0
 *
 * @returns {Promise<Object>}
 */
export async function getPageConfig (activityKey, options = {}) {
  const { fetchData, jsonVersion = PAGE_CONFIG_DEFAULT_VERSION } = options
  const url = getApi('dataConfig', env === 'development' ? `${activityKey}.json` : `${projectName}/${activityKey}.json`)
  const key = PAGE_CONFIG_PREFIX + activityKey + jsonVersion

  let result = null
  if (fetchData && url) {
    result = fetch.get(url).then(data => {
      PAGE_CONFIG_MEM_CACHE_DATA[key] = data
      storage.set(key, JSON.stringify(data), {
        expire: Date.now() + DAY_TIME * 7
      })

      return data
    }).catch(error => {
      console.error(`getPageConfig activityKey=${activityKey} ERROR: `, error)
      return ''
    })
  }

  // 开发环境直接返回配置信息
  if (env === 'development') {
    return result
  }

  if (PAGE_CONFIG_MEM_CACHE_DATA[key]) {
    return PAGE_CONFIG_MEM_CACHE_DATA[key]
  }

  const data = storage.get(key)
  if (data) {
    PAGE_CONFIG_MEM_CACHE_DATA[key] = data
    if (typeof data === 'string') {
      try {
        PAGE_CONFIG_MEM_CACHE_DATA[key] = JSON.parse(data)
      } catch (error) {
        console.log(`localStorage[${key}] JSON.parse ERROR`, error)
        PAGE_CONFIG_MEM_CACHE_DATA[key] = null
      }
    }

    return data
  }
  return result || ''
}
