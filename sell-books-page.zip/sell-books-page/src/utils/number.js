/**
 * 数字格式化
 *
 * @param {Number}      number
 * @param {Number}      decimals
 * @param {String}      decPoint
 * @param {String}      thousandsSep
 *
 * @return {String}
 */
export function numberFormat (number = 0, decimals = 0, decPoint = '.', thousandsSep = ',') {
  const n = !isFinite(+number) ? 0 : +number
  const prec = !isFinite(+decimals) ? 0 : Math.abs(decimals)
  const sep = thousandsSep
  const dec = decPoint
  let s = ''
  const toFixedFix = (n, prec) => {
    const k = Math.pow(10, prec)

    return '' + Math.round(n * k) / k
  }

  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.')

  if (s[0].length > 3) {
    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep)
  }
  if ((s[1] || '').length < prec) {
    s[1] = s[1] || ''
    s[1] += new Array(prec - s[1].length + 1).join('0')
  }

  return s.join(dec)
}
