/**
 * 延迟执行任务
 * @param {Number} time
 */
export function promiseDelay (time = 0) {
  return new Promise((resolve) => {
    setTimeout(resolve, time)
  })
}

/**
 * 加载图片
 * @param {String} url
 */
export function promiseLoadImage (url) {
  return new Promise((resolve, reject) => {
    let img = new Image()
    img.onload = () => {
      resolve()
      img = null
    }
    img.onerror = reject

    img.src = url
  })
}
