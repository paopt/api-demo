<svelte:window bind:scrollY={windowScrollY} />
<div class="o-home l-maxwidth"
  bind:this={homeEl}
  class:bg-filter={isPopLoadingPage}
  class:is-wechat={deviceInfo.wechat}
  class:is-fill-bottom={footerBarConfig?.config}>

  <!-- 邀请类活动，显示邀请记录 -->
  {#if viewData.identityFlag == 2}
    <div class="btn-invitation" on:click={handleInvitationButtonClick}></div>
  {/if}

  {#if !isEmpty(bannerConfig)}
    <!-- 头部banner -->
    <div id="banner" class="o-home__banner {bannerConfig.className || ''}">
      <img class="c-sliced-bg-item" style={bannerConfig.style || ''} src={bannerConfig.image.url} draggable="false" alt="" />
    </div>
  {/if}

  {#if !isEmpty(memberBannerConfig)}
    <!-- 会员头部banner -->
    <MemberBanner
      bind:this={statePanelEl}
      on:member-click={handleMemberClick}
      config={memberBannerConfig}>
        {#if viewData.timerDeadline > 0 && (viewData.timerDeadline <= SHOW_COUNTDOWN_DAY_TIME || viewData.countdown === 2)}
          <!-- 倒计时 -->
          <Timer
            class="timer-new"
            deadline={viewData.timerDeadline}
            format={viewData.timer.format}
            millisecond>
            <span slot="before" class="before">{viewData.timer.label}</span>
          </Timer>
        {/if}
    </MemberBanner>
  {/if}

 <!-- 续费活动头部banner -->
 {#if !isEmpty(renewBannerConfig)}
 <RenewBanner
   bind:this={statePanelEl}
   renewBannerConfig={renewBannerConfig}
   on:button-click={e => handleRenewButtonClick(e.detail)}
   on:button-load={e => handleRenewButtonLoad(e.detail)}
   on:slide-change={e => handleSlideChange(e.detail)}>
   <div class="overday" slot="timmer">
     {#if viewData.timerDeadline > 0 && viewData.timerDeadline <= SHOW_COUNTDOWN_DAY_TIME}
       <!-- 倒计时 -->
       <Timer
         deadline={viewData.timerDeadline}
         format={'D天HH小时MM分SS秒'}
         class="overday-time"
         millisecond>
         <span class="before" slot="before">离活动结束：</span>
       </Timer>
     {:else}
       <!-- {#if viewData?.userInfo?.isVip || viewData?.userInfo?.isSvip} -->
         {#if renewBannerConfig.days > 0}
           <div>您的会员还有<span class="overday-time">{renewBannerConfig.days}天</span>到期</div>
         {:else}
           <div>您的会员已过期<span class="overday-time">{Math.abs(renewBannerConfig.days)}天</span></div>
         {/if}
       <!-- {/if} -->
     {/if}
   </div>
 </RenewBanner>
{/if}


  <!-- 赠品组件 -->
  {#if !isEmpty(giftPackConfig) && pageStatus === PAGE_STATUS.BOUGHT_PACKAGE}
    <div class="o-home__section c-gift-pack {giftPackConfig.className || ''}" style={giftPackConfig.style || ''}>
      <img class="c-sliced-bg-item c-gift-pack__bg" src={giftPackConfig.image.url} draggable="false" alt="" />
      <div class="c-gift-pack__list">
        <h2 class="c-gift-pack__title">恭喜你获得以下内容</h2>
        {#each giftPackConfig.list as item, index}
          <div class="c-gift-pack__item">
            <div class="info">
              <span class="number">{index + 1}</span>
              {#if [5, 6].includes(item.sourceType)}
                <span class="text">已获得"{item.name}"</span>
              {:else if item.hasMerged && item.count > 1}
                <span class="text">已获得"{item.name}"等{item.count}个{GIFT_TYPE_MAP_NAME[item.sourceType]}</span>
              {:else}
                <span class="text">已获得"{item.name}"{GIFT_TYPE_MAP_NAME[item.sourceType]}</span>
              {/if}
            </div>
            <button class="button" on:click={() => { handleGetGiftClick(item) }}>{item.sourceType == 6 ? '填地址' : '去查看'}</button>
          </div>
        {/each}
      </div>
    </div>
  {/if}

  <!-- 转盘抽奖组件 -->
  {#if !isEmpty(parseLotteryConfig)}
    <Lottery
      lotteryConfig={parseLotteryConfig}
      on:lottery-start={handleLotteryStart}
      on:end-rotate={handleLotteryEnded}
      on:show-list={handleLotteryList}
      bind:this={lotteryEl}
    />
  {/if}

  <!-- 抽奖组件 -->
  {#if !isEmpty(drawPanelConfig)}
    <PrizeDrawPanel
      drawPanelConfig={drawPanelConfig}
      winnerMarqueeConfig={drawPanelConfig?.winPrizeMarquee}
      prizeMarqueeConfig={drawPanelConfig?.prizeMarquee}
      bind:this={drawPanelEl}
      on:drawed-click={e => handleDrawedClick(e)}></PrizeDrawPanel>
  {/if}


  <!-- 图片组件 -->
  {#if !isEmpty(sectionsConfig)}
    {#each sectionsConfig.dataSource as item, index}
      {#if item.type === COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.VIDEO]}
        <div
          class="o-home__section o-home__section-video"
          bind:this={sectionEls[index]}>
          <img class="o-home__video-bg c-sliced-bg-item" src={item.image.url} draggable="false" alt="" />
          <!-- <span style="position: fixed;top: 50px;background: #fff;z-index: 100000;">{~~(windowScrollY + window.innerHeight)}:{~~(sectionElRects[6]?.top)}:{windowScrollY + window.innerHeight >= sectionElRects[6]?.top}</span> -->
          <!-- <span style="position: fixed;top: 100px;background: #fff;z-index: 100000;">底部{+windowScrollY}:{~~(sectionElRects[6]?.top + sectionElRects[6]?.height)}: {windowScrollY <= sectionElRects[6]?.top + sectionElRects[6]?.height}</span> -->
          <VideoPlayer
            class="o-home__video"
            style={item.style || ''}
            showPlayIcon
            autoplay={windowScrollY + window.innerHeight > window.innerHeight && windowScrollY + window.innerHeight >= sectionElRects[index]?.top && windowScrollY <= sectionElRects[index]?.top + sectionElRects[index]?.height}
            videoInfo={item}
            on:video-click={() => { handleVideoClick(item)}}>
          </VideoPlayer>
        </div>
      {:else if item.type === COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.USER_BANNER]}
        <!--用户信息组件  -->
        <UserBanner config={item}></UserBanner>
      {:else if item.type === COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.TEXT_BANNER]}
        <!-- 文案组件 -->
        <TextBanner config={item}></TextBanner>
      {:else}
        <div class="o-home__section {item.className || ''}"
          style={item.style || ''}
          bind:this={sectionEls[index]}
          on:click={() => { handleSectionClick(item) }}>
          <img class="c-sliced-bg-item" src={item.image.url} draggable="false" alt="" />
        </div>
      {/if}
    {/each}
  {/if}
  <div class="o-home__body">
    <!-- 跑马灯 -->
    {#if !isEmpty(marqueeConfig) && isMarqueeShowed}
      <div
        class={['o-home__marquee-wrapper', marqueeConfig.wrapperClassName || ''].join(' ')}
        style={marqueeConfig.wrapperStyle || ''}
        class:is-hide={(!marqueeConfig.dataSource || marqueeConfig.dataSource.length === 0)}
        >
      {#if Array.isArray(marqueeConfig.dataSource)}
        <HMarquee
          class={['o-home__marquee', marqueeConfig.className || ''].join(' ')}
          style={marqueeConfig.style || ''}
          autoplay
          bind:this={marqueeEl}>
          {#each marqueeConfig.dataSource as item, index (index)}
            <HMarqueeItem>
              <div class="o-home__marquee-item" style={marqueeConfig.itemStyle || ''}>
                <span class="avatar lazy" data-background-image={item.avatar ? imageResize({ url: item.avatar, width: 40, height: 40 }) : ''}></span>
                <div class="body">{item.prefix || ''}{maskNickName(item.nickName, item)}{item.packageName || marqueeConfig.packageName || ''}</div>
              </div>
            </HMarqueeItem>
          {/each}
        </HMarquee>
      {/if}
      </div>
    {/if}
  </div>
  
  <!-- 联系客服 -->
  {#if pageLoaded}
    <p class="o-home__rule" class:is-fill-bottom={footerBarConfig?.config}>如有任何疑问，请联系<a href="https://h5.hhdd.com/n/h5-macqueen/service-center.html#/home?openChat=1">在线客服</a>，我们将尽快为您解决.</p>
  {/if}

  {#if !isEmpty(statePanelConfig)}
    <!-- 中间状态 -->
    <StatePanel
      class={['o-home__panel', !pageLayoutResized || !pageLoaded ? 'is-hide' : '', statePanelConfig.className || ''].join(' ')}
      style={statePanelConfig.style || ''}
      theme={statePanelConfig.theme || 'normal'}
      config={statePanelConfig.config}
      bind:this={statePanelEl}
      on:button-click={
        (event) => handlePanelMainButtonClick(event && event.detail && event.detail.action, event.detail.params)
      }>
      <div class="o-home__timer" style={(statePanelTimerConfig && statePanelTimerConfig.wrapperStyle) || ''} slot="footer">
        {#if !isEmpty(statePanelTimerConfig) && (statePanelTimerConfig.title || statePanelTimerConfig.format) && pageLoaded}
          <!-- 倒计时 -->
          {#if viewData.timerDeadline > 0 && (viewData.timerDeadline <= SHOW_COUNTDOWN_DAY_TIME || viewData.countdown === 2)}
            <Timer
              class="timer-new"
              deadline={viewData.timerDeadline}
              format={statePanelTimerConfig.format || 'HH时MM分SS秒m'}
              millisecond
              on:update={handleTimerUpdate}
              on:end={handleTimerEnd}>
              <span class="before" slot="before">{statePanelTimerConfig.title || ''}</span>
            </Timer>
          {/if}
        {/if}
      </div>
    </StatePanel>
  {/if}

  {#if !isEmpty(footerBarConfig) && footerBarConfig?.config}
    <!-- 底部栏 -->
    <FooterBar
      show={pageLayoutResized && footerVisible}
      class={["o-home__footer", footerBarConfig.className || ""].join(" ")}
      style={footerBarConfig.style || ""}
      barClass="l-maxwidth"
      config={footerBarConfig.config}
      memberBannerConfig={memberBannerConfig}
      on:bar-click={
        (event) => handleFooterBarClick(event && event.detail && event.detail.action, 'packageIdLifevip')
      }>
    </FooterBar>
  {/if}

  <!-- 微信分享提示 -->
  {#if deviceInfo.wechat && showShareTip}
    <div class="c-share-tip"
      on:touchmove|stopPropagation|preventDefault
      on:click={() => { showShareTip = false }}></div>
  {/if}
</div>
<script>
  import { onMount, tick, onDestroy } from "svelte"
  import lozad from "lozad"
  import { deviceInfo, compareVersion } from "@kada/library/src/device"
  import _chunk from "lodash/chunk";
  import isEqual from "lodash/isEqual"
  import isEmpty from "lodash/isEmpty"
  import scrollIntoView from 'scroll-into-view'
  import { promiseDelay } from '@/utils/promisify'
  import { maskNickName } from '@/shared/utils/user'
  import { resize as imageResize } from '@kada/library/utils/image'
  import { Timer, HMarquee, HMarqueeItem, showTypedDialog, DIALOG_TYPE, DIALOG_THEMES, toast, showLoading, hideLoading} from "@kada/svelte-activity-ui"
  import { ACTIVITY_COMPONENT_MAP_TYPE, COMPONENT_CONFIG_MAP_TYPE } from '@/page/app'
  import { backToHome, openBook, openVipCenter,openMedallist, openVipCharge, openMiniProgram } from "@kada/kada-schema/lib/index.esm"
  import { refresh, remove as removeWebviewEvent, onShow as onWebviewShow, setTraceData, getUserInfo, exposurePv, clearExposure, onShow } from '@kada/jsbridge'
  import { debounce } from "@/utils/throttle"
  import { clearBodyLocks } from 'tua-body-scroll-lock'
  import { DAY_TIME } from '@kada/library/utils/datetime'
  import { buyPackage, sendBehavior, getPageData, voiceSoundChannel } from "@/shared/internal"
  import { upgradeNotifier } from "@/shared/internal/upgrade-notifier"
  import {getViewConfigByName, getAnalyticsIdByName, getDialogOptionsByName, getShareConfig} from "@/shared/scheme/page-config"
  import { PAGE_STATUS, } from "@/shared/internal/page-status"
  import { leftPaddingZero } from '@/utils/timer'
  import { KADA_APP_DOWNLOAD_URL } from '@/shared/internal/constants'
  import { GIFT_MAP_TYPE, GIFT_TYPE_MAP_NAME, STUDY_TOUR_PAGE_MAP_URL, SUPPORT_READING_PLAN_APP_VERSIONS, SUPPORT_SV_APP_VERSION, KADA_SCHEMA_TYPE, SUPPORT_IOS_870_APP_VERSION } from '../../constants'
  import config from '@/lib/config'
  import wechat from '@/lib/wechat'
  import {checkDrawDetail, goDraw, removeUrlParam} from './home'
  import FooterBar from "@/page/components/FooterBar.svelte"
  import VideoPlayer from "@/page/components/VideoPlayer.svelte"
  import StatePanel from '@/page/components/StatePanel.svelte'
  import PrizeDrawPanel from '@/page/components/PrizeDrawPanel.svelte'
  import RenewBanner from '@/page/components/RenewBanner.svelte'
  import Lottery from "@/page/components/Lottery.svelte"
  import MemberBanner from "@/page/components/MemberBanner.svelte"
  import UserBanner from '@/page/components/UserBanner.svelte'
  import TextBanner from "@/page/components/TextBanner.svelte"
  import { showDialog as showWinThePrizeDialog } from '@/page/components/WinThePrizeDialog'
  import {showDialog as showVisualObjectDialog} from '@/page/components/RulesDialog'
  import {showDialog as showLogisticDialog} from '@/page/components/LogisticDialog'
  import {showDialog as showInvListDialog} from "@/page/components/InvitationListDialog/index"
  import {showDialog as showWithdrawFormDialog} from "@/page/components/WithdrawFormDialog/index"
  import {showDialog as showDrawChanceDialog} from '@/page/components/DrawChanceDialog/index'
  import {showDialog as showSharePosterDialog} from '@/page/components/PosterDialog'
  import {showDialog as showChooseAgeDialog} from '@/page/components/ChooseAgeDialog'
  import {showDialog as showPageLoadDialog} from '@/page/components/EnterPopupDialog'
  import { showDialog as showLotteryListDialog } from "@/page/components/LotteryListDialog"
  import * as service from '@/page/service'
  import {navigateTo, router} from '@kada/yrv'
  import memoize from "lodash/memoize";
  const { env } = config
  const rem2px = window.kadaRemLayout && window.kadaRemLayout.rem2px ? window.kadaRemLayout.rem2px : (rem) => rem * 50

  let homeEl
  let drawPanelEl
  let activityKey = ""

  let sectionEls = []
  let sectionElRects = []

  let webviewShowedId = 0
  /**
   * 活动ID
   * @type {String} configId
   */
  export { activityKey as configId }
  /**
   * 页面上下文信息
   * @type {Object} config
   */
  export let pageContext = null


  // 倒计时显示天数
  const SHOW_COUNTDOWN_DAY_TIME = 3 * DAY_TIME
  let marqueeEl
  // 页面中间部分状态组件DOM
  let statePanelEl = null

  // 页面中间部分状态组件位置信息
  let statePanelRect = null
  /**
   * 跑马灯组件引用
   * @type {SvelteComponent}
   */
  let lazyInstace = null

  // 转盘抽奖
  let lotteryEl = null

  // Y轴方向滚动距离
  let windowScrollY = 0
  // 是否为低版本App或非微信环境等不可用状态
  let isUseable = true

  // 是否显示跑马灯
  let isMarqueeShowed = false

  //显示微信分享蒙层
  let showShareTip = false

  //进入页面弹框时，显示毛玻璃效果
  let isPopLoadingPage = false

  // View渲染相关数据
  let viewData = {
    expireDays: 0, // 活动剩余天数
    timerDeadline: 0, // 倒计时时长
    packageId: 0, // 礼包ID
    identityFlag: 0, // 是否区分用户， 0不分用户，1分用户，2邀请类活动
    jumpType: 0, // 用户跳转类型
    jumpExtraData: '', // 用户跳转额外信息 档位id，kada协议，小程序链接
    footerTimerText: "", // 底部栏倒计时文案
    joinJumpUrl: ''      //已参加活动跳转
  }

  // 页面是否加载完成
  let pageLoaded = false
  // 页面布局是否完成
  let pageLayoutResized = false
  // 页面状态
  let pageStatus = PAGE_STATUS.UNKNOWN
  // 页面请求上下文
  let pageDataContext = null
  // 页面背景配置信息
  let bannerConfig = null
  // 续费活动背景配置信息
  let renewBannerConfig = null
  // 跑马灯配置信息
  let marqueeConfig = null
  // 赠品配置信息
  let giftPackConfig = null
  // 图片区块配置信息
  let sectionsConfig = null
  // 活动倒计时
  let statePanelTimerConfig = null
  // 状态面板配置信息
  let statePanelConfig = null
  // 底部栏配置信息
  let footerBarConfig = null
  // 侧边回到顶部栏
  let sideBarConfig = null
  // 活动规则按钮配置
  let rulesButtonConfig = null
  // 规则弹窗配置
  let rulesDialogConfig = null
  // 抽奖配置
  let drawPanelConfig = null
  //分享配置
  let sharePosterConfig = null
  //进入页面弹框配置
  let enterPopupConfig = null
  //微信分享信息
  let shareConfig = null
  // 转盘组件
  let parseLotteryConfig = null
  // 会员头图组件
  let memberBannerConfig = null

  // 判断底部栏是否显示
  $: footerVisible = (() => {
    if (!pageLoaded) {
      return false
    }
    if (pageLoaded && !statePanelRect) {
      return true
    }
    return windowScrollY >= (statePanelRect?.top + statePanelRect?.height * 0.8)
  })()
  $: if (pageContext && !pageDataContext) {
    initPageView(pageContext)

  }
  /**
   * 检查配置是否相等，如果不等则修改值对象
   * @param {Object} value 原值
   * @param {Object} newValue 新值
   *
   * @returns {Object}
   */
  function checkObjectValue(value, newValue) {
    if (isEqual(value, newValue)) {
      return value
    }

    return newValue
  }

  /**
   * 解析kada协议内的sourceId、sourceType
   * @param {string} uri 
   * @returns {Object}
   */
  const pid = 10000
  const mid = compareVersion(SUPPORT_IOS_870_APP_VERSION) ? +activityKey : `ac_${activityKey}`

  function parseKadaSchemaSource (uri) {
    if (!compareVersion(SUPPORT_SV_APP_VERSION) || !deviceInfo.isKadaClient) {
      return location.href = uri
    }

    const pattern = /kada:\/\/([^?]+)/

    const match = uri.match(pattern)
    
    if (match) {
      const result = match[1]

      if (!KADA_SCHEMA_TYPE[result]) {
        location.href = uri
      }

      const { sourceType, sourceIdName } = KADA_SCHEMA_TYPE[result]

      const sourceIdPatterm = new RegExp(`\\?${sourceIdName}=(\\d+)`)
      const matchSourceId = uri.match(sourceIdPatterm)

      let sourceId
      if (matchSourceId) {
        sourceId = matchSourceId[1]
      }

      if (sourceId && sourceType) {
        setTraceData({
          fromType: 10, // 9: 代表阅读计划 10: 代表活动
          fromId: activityKey,
          extStr: '',
          extStr2: `${pid}_${mid}_${1}_${sourceId}_${sourceType}`
        })
        location.href = uri
      }
      
    } else {
      return location.href = uri
    }
  }
  
  const getParsedExposure = async (activityInfo) => {
    if (!activityInfo) {
      return
    }
    const { joinJumpUrl, jumpData } = activityInfo
    const { dataSource = [] } = sectionsConfig

    const parse = (uri) => {
      const pattern = /kada:\/\/([^?]+)/

      const match = uri.match(pattern)
    
      if (match) {
        const result = match[1]

        if (!KADA_SCHEMA_TYPE[result]) {
          return ''
        }

        const { sourceType, sourceIdName } = KADA_SCHEMA_TYPE[result]

        const sourceIdPatterm = new RegExp(`\\?${sourceIdName}=(\\d+)`)
        const matchSourceId = uri.match(sourceIdPatterm)

        let sourceId
        if (matchSourceId) {
          sourceId = matchSourceId[1]
        } else {
          return ''
        }
      
       if (sourceId && sourceType) {
          return [{
            sourceId,
            sourceType
          }]
        } else {
          return ''
        }
      
      } else {
        return ''
      }
    
    }
    console.log(dataSource)
    const hasLinkArr = dataSource.reduce((accumulator, item) => {
      if (item?.link) {
        accumulator.push(...parse(item?.link))
      }
      return accumulator
    }, [])

    const parseJsonStr = [
      ...parse(joinJumpUrl),
      ...parse(jumpData),
      ...hasLinkArr
    ]

    if (parseJsonStr.length) {
      const exposureJsonStr = parseJsonStr.map((item, index) => {
        return {
          index: index + 1,
          ...item
        }
      })

      exposurePv(pid, mid, exposureJsonStr)
    }

  }

  /**
   * 获取界面所需配置信息
   */
  async function getViewConfig() {
    // 获取背景配置
    bannerConfig = await checkObjectValue(bannerConfig, getViewConfigByName('banner'))
    // 续费活动背景配置
    renewBannerConfig = await checkObjectValue(renewBannerConfig, getViewConfigByName('renewBanner'))
    console.log('renewBannerConfig', renewBannerConfig)
    // 获取跑马灯配置
    marqueeConfig = checkObjectValue(marqueeConfig, getViewConfigByName('marquee'))
    promiseDelay(1000).then(() => {
      isMarqueeShowed = true
      return promiseDelay(500)
    }).then(() => {
      if (lazyInstace && lazyInstace.observer) {
        lazyInstace.observer.disconnect()
      }

      lazyInstace = lozad(document.querySelectorAll('.o-home__marquee .lazy'))
      lazyInstace.observe()
    })
    // 赠品区块列表配置
    giftPackConfig = await checkObjectValue(giftPackConfig, getViewConfigByName('giftPack'))
    // 图片区块列表配置
    sectionsConfig = await checkObjectValue(sectionsConfig, getViewConfigByName('sections'))
    // 规则弹窗配置
    rulesDialogConfig = checkObjectValue(rulesDialogConfig, getDialogOptionsByName('rulesDialog'))

    // 获取中间状态面板倒计时配置
    statePanelTimerConfig = checkObjectValue(statePanelTimerConfig, getViewConfigByName('statePanelTimer'))
console.log('倒计时', statePanelTimerConfig)
    // 获取中间状态面板配置
    statePanelConfig = checkObjectValue(statePanelConfig, getViewConfigByName('statePanel'))

    // 获取底部栏配置
    footerBarConfig = checkObjectValue(footerBarConfig, getViewConfigByName('footerBar'))
    sideBarConfig = checkObjectValue(sideBarConfig, getViewConfigByName('sideBar'))
    // 活动规则按钮配置
    rulesButtonConfig = checkObjectValue(rulesButtonConfig, getViewConfigByName('rulesButton'))

    //抽奖组件配置
    drawPanelConfig = checkObjectValue(drawPanelConfig, getViewConfigByName('drawPannel'))

    //分享海报配置
    sharePosterConfig = checkObjectValue(sharePosterConfig, getViewConfigByName('sharePoster'))

    //进入页面弹框配置
    enterPopupConfig = checkObjectValue(enterPopupConfig, getViewConfigByName('enterPopup'))

    //微信分享信息配置设置
    shareConfig = getShareConfig()
    wechat.share(shareConfig)

    parseLotteryConfig = checkObjectValue(parseLotteryConfig, getViewConfigByName('lottery'))
    console.log(parseLotteryConfig)

    // 会员头图组件配置
    memberBannerConfig = checkObjectValue(memberBannerConfig, getViewConfigByName('memberBanner'))
    // console.log('会员头图组件配置：', memberBannerConfig)

    await tick()

    sectionElRects = generateVideoElRects(sectionEls)
    //头图组件，续费头图组件支持底部按钮默认隐藏，滚动显示
    if (statePanelConfig || renewBannerConfig || memberBannerConfig) {
      setStatePanelRect()
    }
  }

    /**
   * 跳转去阅读计划
   */
   const goToReadingPlan = debounce((planId, open = 1) => {
    if (compareVersion(SUPPORT_READING_PLAN_APP_VERSIONS)) {
      return upgradeNotifier({ activityKey })
    }

    parseKadaSchemaSource(`kada://openreadplan?planId=${planId}`)
  }, 1000)

  function setStatePanelRect() {
    if (statePanelEl) {
      const rect = statePanelEl.getBoundingClientRect()
      statePanelRect = { top: windowScrollY + rect.top, left: rect.left, width: rect.width, height: rect.height, bottom: windowScrollY + rect.bottom, right: rect.right }
    }
  }

  // 刷新页面配置信息
  const refreshViewConfig = debounce(async () => getViewConfig(), 300)

  /**
   * 购买完成礼包之后添加一个加入人数
   * @param {Boolean} isSuccess 是否购买成功
   */
  function afterBuyPackage(isSuccess) {
    if (isSuccess) {
      // 刷新app书单列表
      try {
        refresh(['bookList'])
      } catch (error) {
        console.log('refresh bookList error::', error)
      }
      // 购买后，服务端任务有效期倒计时有2-3秒延迟，在App中前端购买后2-3秒后刷新状态
      promiseDelay(2800).then(() => {
        getPageData(true)
        window.scrollTo(0, 0)
      })
    }
  }
  function goBackToAppHome() {
    refresh(['studyOperate', 'vipinfo'])
    setTimeout(() => { backToHome({ site: 'book' }) }, 100)
  }
  /**
   * 返回顶部点击
   */
  // const handleSideBarClick = () => {
  //   const staId = getAnalyticsIdByName('sideBarClick')
  //   if (staId) {
  //     sendBehavior(staId)
  //   }
  //   scrollTo(0)
  // }

  const handleSectionClick = debounce((item) => {
    const { id = 0, link } = item
    const sectionClickStatId  = getAnalyticsIdByName('pictureSectionClick')
    const { userInfo: {  isJoin = 0 } } = pageDataContext.responseBody?.data

    sendBehavior(`${sectionClickStatId}_${isJoin}_${id}`)
    if (link !== '') {
      setTimeout(() => { parseKadaSchemaSource(link) }, 100)
    }
  }, 1000)


  // 礼品按钮点击跳转, 类别：1书单，2课程，3阅读计划，4游学计划
  function handleGetGiftClick (item) {
    const { sourceId = 0, sourceType = 0 } = item
    // 统计打点：赠品按钮点击
    sendGiftsStatId('giftClick', item)
    if (item.sourceType == GIFT_MAP_TYPE.REAL_THING) {
      //实物直接显示地址
      checkLogistickInfo(1)
    } else if (deviceInfo.isKadaClient) {
      switch (sourceType) {
        case GIFT_MAP_TYPE.BOOKLIST:
          location.href = 'kada://openmybooklist'
          break;
        case GIFT_MAP_TYPE.COURSE:
          location.href = 'kada://openmycourse'
          break;
        case GIFT_MAP_TYPE.READING_PLAN:
          goToReadingPlan(sourceId)
          break;
        case GIFT_MAP_TYPE.STUDYTOUR_PLAN:
          location.href = `kada://openurl?orientation=1&cocos=2&url=${STUDY_TOUR_PAGE_MAP_URL[env]}?planId=${sourceId}`
          break;
        case GIFT_MAP_TYPE.SVIP_DAYS:
          openVipCenter()
          break
      }
    } else {
      showUnSupportDialog()
    }
  }

  //点击抽奖
  async function handleDrawedClick(e) {
    //造数据测试弹框样式
    // let data = {
    //   "id": 2,
    //   "userId": 60058041,
    //   "crc32name": "19680924",
    //   "awardUrl": "https://image.hhdd.com/activity/offline/cover/4d550a517bc24eb8bdda2b673091a5a1.png",
    //   "awardType": 6,
    //   "config": "http://www.baidu.com",
    //   "awardName": "免单卡12Ac！",
    //   "cardUrl": "https://image.hhdd.com/activity/offline/cover/53b9e6a010694789aface7f26e363126.svga"
    // }
    // return showWinThePrizeDialog({ prize: data, onDone() { if (data.awardType == 6) { window.location.href = data.config } } })
    // let {awardType, cardUrl, content: config, title: awardName} = data
    // return showVisualObjectDialog({ awardType, cardUrl, content: config, title: awardName, onDone() { if (data.awardType == 6 && data?.cardUrl) { window.location.href = data?.cardUrl } } })
    let {action, orderAudioUrl} = e.detail
    // 抽奖组件点击，打点
    const clickId = getAnalyticsIdByName('drawPanelButtonClick')
    sendDrawPanelViewStateId(clickId)
    if (action === 'toGuide') {
      //播放引导语音
      if (orderAudioUrl) {
        voiceSoundChannel.play(orderAudioUrl)
      }
      toast('需先下单才可以抽奖哦')
    } else if (action === 'toDraw') {
      //去抽奖
      showLoading()
      try {
        let {msg, data, code} = await goDraw(activityKey)
        hideLoading()
        if (code == 200) {
          drawPanelEl.start(data, () => {
            showWinThePrizeDialog({
              prize: data,
              onDone() {
                if (data?.awardType == 6 && data?.config) {
                  location.href = data?.config
                }
              }
            })
            getPageData(true)
          })
        } else {
          toast(msg)
        }
      } catch (e) {
        hideLoading()
        console.log(e)
      }
    } else if (action == 'toPrize') {
      //去查看
      showLoading()
      try {
        let {msg, data, code} = await checkDrawDetail(activityKey)
        // let {msg, data, code} = {"msg":"成功","data":{"id":26,"crc32name":"19680924","userId":60058041,"awardType":2,"config":"","awardName":"儿童读物","awardUrl":"https://image.hhdd.com/activity/offline/cover/5150ed8863284e9b80f05d42f6b82507.png","status":1,"modifyTime":1671075686000,"createTime":1671075686000},"code":200}
        if (code == 200) {
          data && showPrize(data)
        } else {
          toast(msg)
        }
      } catch (e) {
        hideLoading()
        console.log(e)
      }
    }
  }

  function showPrize(data) {
    let {awardType, config, awardName, cardUrl} = data
    //实物要查询邮寄地址
    awardType !== 2 && hideLoading()
    if (awardType === 1) {
      //会员时长
      deviceInfo.isKadaClient ? openVipCenter() : showUnSupportDialog()
    } else if (awardType == 2) {
      //实物
      checkLogistickInfo(2)
    } else if ([3, 6].includes(awardType)) {
      //虚拟物，免单卡显示弹框
      showVisualObjectDialog({
        awardType,
        cardUrl,
        content: config,
        title: awardName,
        onClose() {
          if (awardType == 6 && config) {
            location.href = config
          }
        }
      })
    } else if (awardType === 4) {
      //勋章殿堂
      deviceInfo.isKadaClient ? openMedallist() : showUnSupportDialog()
    } else if (awardType === 5) {
      //第三方链接，微信显示跳转app弹框
      deviceInfo.isKadaClient ? window.location.href = config : showUnSupportDialog()
    }
  }
  //显示物流信息
  function checkLogistickInfo(type) {
    // let res = {"msg":"成功","data":{"id":3,"activityKey":"19680924","userId":60058041,"type":2,"realName":"儿童读物","logisticsNo":"","logisticsCompany":"","recipient":"宁冬","region":"北京市 北京市 东城区","address":"人民路23号","phone":"15381105360","logisticsNo":"123", "logisticsCompany":"张三的公司", "operator":"","createTime":1671075686000,"modifyTime":1671083184000,"status":1},"code":200}
    service.exchangeAddressDetail({activityKey, type}).then(res => {
      hideLoading()
      let {code, data} = res
      if (code == 200) {
        if (data?.phone) {
          showLogisticDialog({dialogInfo: data})
        } else {
          navigateTo('/address/', {queryParams: {activityKey, type}})
        }
      }
    }).catch(e => {
      hideLoading()
      console.log(e)
    })
  }
  //邀请记录
  function handleInvitationButtonClick() {
    service.listAward({activityKey}).then(res => {
      let {code, data} = res
      if (code == 200) {
        showInvListDialog({
          dataSource: data || [],
          onWithDraw() {
            openWithDrawPanel()
          },
          onGotoInvite() {
            gotoShare()
          },
          onClose() {}
        })
      }
    })
  }

  //打开返现登记
  const openWithDrawPanel = async () => {
    let account = '', accountName = ''
    let res = await service.getAccount({activityKey})
    let {code, data} = res
    if (code == 200 && data) {
      account = data.account
      accountName = data.accountName
    }
    showWithdrawFormDialog({
      account,
      accountName,
      onDone({ inputAccount, inputAccountName }) {
        // 无输入信息则不执行提交
        if (!inputAccount || !inputAccountName) {
          return
        }
        //提交信息
        submitWithDrawAccountInfo({account: inputAccount, accountName: inputAccountName})
      },
      onClose() {}
    })
  }
  // 提交提现帐户信息
  async function submitWithDrawAccountInfo ({ account, accountName }) {
    showLoading({delay: 0, text: '正在提交提现信息...'})
    let params = {activityKey, account, accountName}
    service.saveAccount(params).then(res => {
      if (res.code == 200) {
        toast('提交成功!')
      } else {
        toast(res.msg)
      }
    }).catch(error => {
      toast('提交失败请重试~')
    }).finally(() => {
      hideLoading()
    })
  }

  function handleLotteryEnded (e) {
    const { awardName, awardType } = e.detail
    console.log(awardName)
    console.log(awardType)
    showWinThePrizeDialog({
      headerTit: awardType ? '恭喜你抽中了' : '好可惜，没抽中',
      contentImage: !awardType ? '//cdn.hhdd.com/frontend/as/i/162ec24e-3175-5cc8-ab98-86213b7f4c88.png' : '//cdn.hhdd.com/frontend/as/i/f93308fd-b622-5ac2-9524-1a96d1c26a8a.png',
      btnImage: awardType ? '//cdn.hhdd.com/frontend/as/i/b6635d2b-a740-52c9-9e84-ef8dc6b16aad.png' : '//cdn.hhdd.com/frontend/as/i/9a4f2519-5de3-538b-a543-772ba4139358.png',
      prize: {
        awardName: awardType ? awardName : '', // 根据awardType判断是否中奖，不要根据awardName
        text: '下次加油'
      },
      onDone() {
        lotteryFlag = true
        // if (data?.awardType == 6 && data?.config) {
        //   location.href = data?.config
        // }
      }
    })
  }

  const handleLotteryList = debounce(async () => {
    const { data: lotteryList } = await service.turntableDetail(activityKey)

    showLotteryListDialog({
      lotteryList
    })
  }, 300)

  let lotteryFlag = true
  const handleLotteryStart = debounce(async (e) => {
    if (!lotteryEl || !lotteryFlag) return

    const { action, orderAudioUrl } = e.detail
    
    if (action === 'toGuide') {
      if (orderAudioUrl) {
        voiceSoundChannel.play(orderAudioUrl)
      }
      toast('需先下单才可以抽奖哦')
    } else if (action === 'toLottery') {
      lotteryFlag = false
      showLoading()
      const { data, code, msg } = await service.turntableDraw(activityKey)

      if (parseLotteryConfig.turntableNumber) {
        parseLotteryConfig.turntableNumber--
      }

      if (data && code === 200) {
        const rotateIndex = parseLotteryConfig.prizeData.findIndex(({ sort }) => sort === data.sort)

        if (rotateIndex !== null || rotateIndex !== undefined) {
          lotteryEl.rotate(rotateIndex, data)
        } else {
          toast('系统异常')
        }
        
      } else if (code === 5505) {
        showWinThePrizeDialog({
          headerTit: '没有库存了',
          contentImage: '//cdn.hhdd.com/frontend/as/i/162ec24e-3175-5cc8-ab98-86213b7f4c88.png',
          btnImage: '//cdn.hhdd.com/frontend/as/i/b6635d2b-a740-52c9-9e84-ef8dc6b16aad.png',
          prize: {
            awardName: '',
            text: '奖品已派完，下次请早哦'
          },
          onDone() {
            lotteryFlag = true
            // if (data?.awardType == 6 && data?.config) {
            //   location.href = data?.config
            // }
          }
        })
      } else {
        toast(msg)
      }
      hideLoading()
    } else if (action === 'noChance') {
      toast('抽奖次数已用完')
    }
    
  }, 300)

  //分享
  const gotoShare = async () => {
    if (deviceInfo.wechat) {
      showShareTip = true
    } else {
      showLoading({ delay: 0, text: '正在生成分享海报...' })
      const { data: appUserInfo } = await getUserInfo()
      showSharePosterDialog({
        nickName: appUserInfo?.nickName,
        avatarUrl: appUserInfo?.avatarUrl,
        qrcodeUrl: sharePosterConfig?.shareJumpUrl,
        sharePosterImg: sharePosterConfig.sharePosterImg,
        shareTitle: sharePosterConfig.shareTitle,
        maskClickHide: true,
        onRendered() {
          hideLoading()
        },
        onClose() {
          console.log('关闭了分享')
        }
      })
    }
  }
  /**
   * 视频点击
   */
  const handleVideoClick = (video) => {
    const { id = 0 } = video
    const videoClickStatId  = getAnalyticsIdByName('videoSectionClick')
    const { userInfo: {  isJoin = 0 } } = pageDataContext.responseBody?.data

    sendBehavior(`${videoClickStatId}_${isJoin}_${id}`)
  }
  /**
   * 滚动置页面某处
   */
  const scrollToView = async (elClass) => {
    const el = document.querySelector(`${elClass}`)
    if (el) {
      scrollIntoView(el)
    }
  }
  /**
   * 生成视频元素矩形数据
   */
  const generateVideoElRects = (els) => {
    return els.map(el => el.getBoundingClientRect())
  }
  /**
   * 错误弹窗处理
   */
  const onErrorDialogDoneClick = (staId) => {
    sendBehavior(staId)
    if (deviceInfo.isKadaClient) {
      backToHome({site: 'mom'})
    } else {
      location.href = KADA_APP_DOWNLOAD_URL
    }
  }
  /**
   * 显示下载弹窗
   */
  const showDownloadDialog = () => {
    clearBodyLocks()
    const staIdView = getAnalyticsIdByName('dialog.downloadDialog.view')
    const staIdClick = getAnalyticsIdByName('dialog.downloadDialog.click')
    if (staIdView) sendBehavior(staIdView)
    showTypedDialog({
      type: DIALOG_TYPE.SUCCESS,
      theme: DIALOG_THEMES.NEW2021,
      title: '当前环境不支持',
      message: '请在KaDa阅读APP内打开哦～',
      buttonText: '去阅读',
      doneCloseDialog: false,
      maskClickHide: true,
      onDone() {
        onErrorDialogDoneClick(staIdClick)
      },
      onMaskClick: () => {
        clearBodyLocks()
      },
    })
  }
  /**
   * 显示当前环境不支持，app内打开
  */
  const showUnSupportDialog = () => {
    clearBodyLocks()
    const staIdView = getAnalyticsIdByName('dialog.downloadDialog.view')
    const staIdClick = getAnalyticsIdByName('dialog.downloadDialog.click')
    if (staIdView) sendBehavior(staIdView)
    showTypedDialog({
      type: DIALOG_TYPE.APP_ONLY,
      theme: DIALOG_THEMES.NEW2021,
      title: '当前环境不支持',
      message: '请在KaDa阅读APP内打开哦～',
      showCloseButton: true,
      onDone: () => {
        location.href = KADA_APP_DOWNLOAD_URL
      }
    })
  }
  /**
   * 点击主按钮事件
   */
  const handlePanelMainButtonClick = debounce((action) => {
    // showLoginDialog({
    //   onClose: () => {
    //     getPageData(true)
    //   }
    // })
    let packageId = pageDataContext.packageId
    doPackageClickAction(action, packageId)

    const statId = getAnalyticsIdByName('statusMainPanelButtonClick')
    if (statId) {
      sendBehavior(`${statId}_${getUserPageTracks()}`)
    }
  }, 1000, true)

  /**
   * 会员头图按钮点击事件
  */
  const handleMemberClick = debounce(() => {
    // 打点
    const statId = getAnalyticsIdByName('statusMainPanelButtonClick')
    if (statId) {
      sendBehavior(`${statId}_${getUserPageTracks()}`)
    }

    let action = memberBannerConfig.button.action
    let packageId = memberBannerConfig.payInfoId
    
    // 更新全局的packageId，防止使用错误的packageId
    pageDataContext.packageId = packageId
    viewData.packageId = packageId

    // 这里只处理：不区分用户，唤起档位支付的逻辑分支。其他的待定
    console.log('会员头图按钮点击: ', packageId, action)
    // TODO 处理浏览器情况
    // if ([deviceInfo.isKadaClient, deviceInfo.wechat].some(d => !!d)) {
      //已参加活动根据配置跳转，非邀请类活动
      if (action == 'bought') {
        if (viewData?.joinJumpUrl) {
          if (deviceInfo.isKadaClient || deviceInfo.wechat) {
            parseKadaSchemaSource(viewData.joinJumpUrl)
          } else {
            showDownloadDialog()
          }
        } else {
          console.log('跳转到书房')
          deviceInfo.isKadaClient ? goBackToAppHome() : showUnSupportDialog()
        }
        return
      }
      if (action === 'buyPackage') {
        openPayPanel(packageId)
      } 
    // } else {
    //   showDownloadDialog()
    // }
  }, 1000, true)
  /**
   * 点击底部栏处理事件
   */
  const handleFooterBarClick = debounce((action) => {
    const statId = getAnalyticsIdByName('footerBarButtonClick')
    if (statId) {
      sendBehavior(`${statId}_${getUserPageTracks()}`)
    }
    // 配置了会员头图，处理逻辑不一样。不区分用户
    if (memberBannerConfig) {
      handleMemberClick();
      return
    }
    let packageId = pageDataContext.packageId
    doPackageClickAction(action, packageId)
  }, 1000, true)

  /**
   * 点击续费活动按钮事件
   * @param tracks
   */
  const handleRenewButtonClick = debounce(action => {
    const tracks = getUserPageTracks()
    const strId = `top_button_click_${tracks}_${activityKey}`
    sendBehavior(strId)
    let packageId = pageDataContext.packageId
    doPackageClickAction(action, packageId)
  }, 1000, true)

  /**
   * 续费按钮加载打点
   */
  const handleRenewButtonLoad = debounce(action => {
    const tracks = getUserPageTracks()
    const strId = `top_button_view_${tracks}_${activityKey}`
    sendBehavior(strId)
  }, 1000, true)

  /**
   * 轮播切换打点
   */
  const handleSlideChange = debounce(detail => {
    const {index, id} = detail
    const tracks = getUserPageTracks()
    const strId = `top_tab${index}_view_${tracks}_${id}_${activityKey}`
    sendBehavior(strId)
  }, 1000, true)


  function sendPageViewStatId(tracks) {
    const pageViewId = getAnalyticsIdByName('pageView')
    const stateMainPanelButtonViewId = getAnalyticsIdByName('statusMainPanelButtonView')
    const footerBarButtonViewId = getAnalyticsIdByName('footerBarButtonView')

    if (tracks) {
      sendBehavior(`${pageViewId}_${tracks}`)
      sendBehavior(`${stateMainPanelButtonViewId}_${tracks}`)
      sendBehavior(`${footerBarButtonViewId}_${tracks}`)
    } else {
      sendBehavior(pageViewId)
      sendBehavior(stateMainPanelButtonViewId)
      sendBehavior(footerBarButtonViewId)
    }
  }
  function sendSectionViewStatId() {
    if (!sectionsConfig) {
      return null
    }
    const { dataSource = [] } = sectionsConfig
    const pictureStatId = getAnalyticsIdByName('pictureSectionView')
    const videoStatId  = getAnalyticsIdByName('videoSectionView')
    const { userInfo: {  isJoin = 0 } } = pageDataContext.responseBody?.data
    dataSource.forEach(section => {
      const { id = 0, type = 0 } = section
      switch (type) {
        case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.SECTIONS]:
          sendBehavior(`${pictureStatId}_${isJoin}_${id}`)
          break;
        case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.VIDEO]:
          sendBehavior(`${videoStatId}_${isJoin}_${id}`)
          break;
      }
    })
  }

  //抽奖组件打点
  function sendDrawPanelViewStateId(drawPanelStatId) {
    if (!drawPanelConfig) {
      return
    }
    const {id} = drawPanelConfig
    const { userInfo: {  isJoin = 0, drawFlag = 0 } } = pageDataContext.responseBody?.data
    let drawStatus = (!!isJoin && !!drawFlag) ? 2 : (!!isJoin ? 1 : 0)
    sendBehavior(`${drawPanelStatId}_${isJoin}_${id}_${drawStatus}`)
  }

  function sendGiftViewStatId() {
    const { dataSource = [] } = giftPackConfig || {}
    if (Array.isArray(dataSource) && dataSource.length > 0) {
      // 统计打点: 礼品按钮展示
      dataSource.forEach(gift => {
        sendGiftsStatId('giftView', gift)
      })
    }
  }

  function sendGiftsStatId (name, gift) {
    const { dataSource = [] } = giftPackConfig
    const { sourceId = 0, sourceType = 0 } = gift
    const statId  = getAnalyticsIdByName(name)
    let matchedIds = []
    // 如果是书单和课程，则选择所有同类项
    // 否则就只选择出当前项即可
    dataSource.forEach(item => {
      if (item.sourceType === sourceType && (item.sourceType === GIFT_MAP_TYPE.BOOKLIST || item.sourceType === GIFT_MAP_TYPE.COURSE)) {
        matchedIds.push(item.sourceId)
      } else if (item.sourceId === sourceId) {
        matchedIds.push(item.sourceId)
      }
    })
    if (matchedIds.length === 0) {
      sendBehavior(`${statId}_${sourceType}_${sourceId}`)
    } else {
      sendBehavior(`${statId}_${sourceType}_${matchedIds.join('_')}`)
    }
  }

  const doPackageClickAction = (action, packageId = 0) => {
    // TODO 处理浏览器情况
    // if ([deviceInfo.isKadaClient, deviceInfo.wechat].some(d => !!d)) {
      //已参加活动根据配置跳转，非邀请类活动
      if (action == 'bought') {
        if (viewData?.joinJumpUrl) {
          // TODO 浏览器怎样处理
          if (deviceInfo.isKadaClient || deviceInfo.wechat) {
            parseKadaSchemaSource(viewData.joinJumpUrl)
          } else {
            showDownloadDialog()
          }
        } else {
          deviceInfo.isKadaClient ? goBackToAppHome() : showUnSupportDialog()
        }
        return
      }
      // 如果不区分身份 则未购买状态下全部执行 唤起支付面板逻辑
      if (viewData.identityFlag == 0 && pageStatus !== PAGE_STATUS.BOUGHT_PACKAGE) {
        openCustomizeAction()
        return
      }
      //区分用户
      if (viewData.identityFlag == 1) {
        if (action === 'buyPackage') {
          openPayPanel(packageId)
        } else if (action === 'toVipCharge') {
          deviceInfo.isKadaClient ? gotoUpgradeVip() : showUnSupportDialog()
        } else {
          deviceInfo.isKadaClient ? goBackToAppHome() : showUnSupportDialog()
        }
      }
      //邀请类活动
      else if (viewData.identityFlag == 2) {
        if (deviceInfo.isKadaClient || deviceInfo.wechat) {
          gotoShare()
        } else {
          showDownloadDialog()
        }
      }
    // } else {
    //   showDownloadDialog()
    // }
  }

  async function gotoUpgradeVip (type = 'panel') {
    // 监听返回刷新数据
    webviewShowedId = await onWebviewShow(() => {
      getPageData(true)
      removeWebviewEvent('onShow', webviewShowedId)
      webviewShowedId = 0
    })
    openVipCharge({sourceId: activityKey, sourceType: 10})
  }
  
  // 自定义按钮行为
  async function openCustomizeAction () {
    const { jumpType = 0, jumpExtraData = '' } = viewData
    // （当identityFlag=0不分用户时有效）跳转类型，1唤起档位支付，2跳转至档位页，3小程序，4kada协议
    const CUSTOM_ACTION_MAP_TYPE = { NORMAL: 0, PANEL: 1, VIPUPGRADE: 2, WECHATAPP: 3, PROTOCOL: 4 }
    switch (jumpType) {
      case CUSTOM_ACTION_MAP_TYPE.PANEL:
        openPayPanel(jumpExtraData)
        break;
      case CUSTOM_ACTION_MAP_TYPE.VIPUPGRADE:
        deviceInfo.isKadaClient ? gotoUpgradeVip() : showUnSupportDialog()
        break;
      case CUSTOM_ACTION_MAP_TYPE.WECHATAPP:
        // 跳转小程序
        deviceInfo.isKadaClient ? gotoWechatMiniApp({fromLocation: jumpExtraData}) : showUnSupportDialog()
        break;
      case CUSTOM_ACTION_MAP_TYPE.PROTOCOL:
        // 跳转协议
        deviceInfo.isKadaClient ? parseKadaSchemaSource(jumpExtraData) : showUnSupportDialog()
        break;
      default:
        // 其它  
        goBackToAppHome()
        break;
    }
  }

  const openPayPanel = (packageId = 0) => {
    // 档位支付必须执行传type和id过去 否则服务端无法正常变更已购买状态
    setTraceData({
      fromType: 10, // 9: 代表阅读计划 10: 代表活动
      fromId: activityKey,
      extStr: ''
    })
    //微信端传递订单来源，orderTraceInfo
    let orderTraceInfo = {fromSourceId: parseInt(activityKey), fromSourceType: 10, trace: activityKey}
    buyPackage(packageId, {packageType: 6, orderTraceInfo}).then(afterBuyPackage)
  }

  async function initPageView (context) {
    pageDataContext = context
    isUseable = await upgradeNotifier({ activityKey })
    if (!isUseable) {
      pageLoaded = true
      refreshViewConfig()
      return
    }

    context.subscribe('pageLoaded', async (value) => {
      await refreshViewConfig()
      pageLoaded = value
      if (pageLoaded) {
        // 进入页面统计打点
        sendPageViewStatId(getUserPageTracks())
        await promiseDelay(500).then(() => {
          refreshViewConfig()
          // 组件模块统计打点
          sendSectionViewStatId()
          if (pageStatus === PAGE_STATUS.BOUGHT_PACKAGE) {
            sendGiftViewStatId()
          }
          // 页面加载完成后的相关DOM操作
          settingLayoutDom()
          // 抽奖组件加载打点
          const viewId = getAnalyticsIdByName('drawPanelButtonView')
          sendDrawPanelViewStateId(viewId)
          //显示进入页面弹框
          showPageLoadPopup()
        })

        getParsedExposure(pageDataContext.responseBody.data?.activityInfo)
      }
    })

    context.subscribe('pageStatus', async (value) => {
      if (pageStatus !== value) {
        if (pageStatus === PAGE_STATUS.BOUGHT_PACKAGE) {
          promiseDelay(500).then(() => sendGiftViewStatId())
        }
        pageStatus = value
        refreshViewConfig()
      }
    })

    context.subscribe('viewData', (value) => {
      if (!isEqual(viewData, value)) {
        viewData = {...viewData, ...value}
        refreshViewConfig()
      }
    })
  }

  // 跳转小程序
  function gotoWechatMiniApp ({ fromLocation = '' }) {
    // 1: 开发版  2：体验版  0： 正式版
    const WECHAT_MINI_APP_ENV_MAP_TYPE = {
      // development: 1,
      development: 0,
      // test: 2,
      test: 0,
      // staging: 2,
      staging: 0,
      production: 0
    }
    const params = {
      // userId,
      fromLocation
    }
    const appId = 'gh_d851f6e29013'
    const path =  `independent/webviewTransfer/webviewTransfer?params=${JSON.stringify(params)}`
    const envType = WECHAT_MINI_APP_ENV_MAP_TYPE[config.env]

    openMiniProgram({userName: appId, pagePath: path, miniProgramType: envType})
    console.log('wechat miniapp path is:', path)
  }

  async function settingLayoutDom () {
    await tick()
    await promiseDelay(250)
    resetStatePanelLayout()
  }

  function resetStatePanelLayout () {
    // 中间面板
    const statePanelEl = document.querySelector('.o-home__panel')
    const bannerEl = document.getElementById('banner')

    if (bannerEl) {
      const { height: bannerHeight } = bannerEl.getBoundingClientRect()
      const statePanelButtonEl = statePanelEl.querySelector('.btn')
      // const { height: statePanelButtonHeight } = statePanelButtonEl?.getBoundingClientRect() || {}
      const statePanelButtonHeight = rem2px(1.6)
      const offsetBottom = rem2px(0.8)
      const defaultBottom = rem2px(7.2)
      console.log(bannerHeight, statePanelButtonHeight)
      const statePanelTop = bannerHeight && bannerHeight > statePanelButtonHeight ?  bannerHeight - statePanelButtonHeight - offsetBottom : defaultBottom
      statePanelEl.style.cssText = `top: ${statePanelTop}px`
    }
    pageLayoutResized = true

    // 进入页面滚动，显示主按钮
    const mainBtnEle = document.querySelector('#mainBtn')
    if (mainBtnEle) {
      const animate = () => {
        const rect = mainBtnEle.getBoundingClientRect()
        if (rect.bottom > window.innerHeight) {
          window.scrollBy(0, 2);
          requestAnimationFrame(animate)
        }
      }
      animate();
    }
  }

  function getUserPageTracks () {
    if (pageDataContext?.responseBody?.data?.userInfo) {
      const { userInfo: {
        isVip = 0,
        isSvip = 0,
        isVisitor = 0,
        isJoin = 0,
        vipDays = 0,
        svipDays = 0,
        isLifeVip = 0,
        isLifeSvip = 0,
        isGiveVip = 0,
      } } = pageDataContext.responseBody?.data

      let userVipDays = vipDays || svipDays

      let vipType = 0
      let vipDay = 0

      if (isSvip) {
        vipType = 5
      } else if (isVip) {
        vipType = 1
      } else {
        vipType = 0
      }

      if (isLifeVip || isLifeSvip) {
        vipDay = 36500
      } else if (userVipDays <= 30) {
        vipDay = 0
      } else if (userVipDays >= 30) {
        vipDay = 30
      } else {
        vipDay = 0
      }

      const tracks = {
        login: isVisitor ? 0 : 1,
        join: isJoin,
        vipType,
        vipDay,
        isGiveVip
      }
      return Object.values(tracks).join('_')
    } else {
      return ''
    }
  }
  /**
   * 倒计时更新状态
   */
  const handleTimerUpdate = (event) => {
    const { timestamp, day, hour, minute, second, millisecond = '' } = event.detail
    if (timestamp >= 0) {
      viewData.timerDeadline = timestamp
    }

    viewData.footerTimerText = (timestamp < 0) ? '' : statePanelTimerConfig.format.replace(/(D+|H+|M+|S+|m+)/g, (_, key) => {
      let value = null
      if (key.charAt(0) === 'D') {
        value = day
      } else if (key.charAt(0) === 'H') {
        value = hour
      } else if (key.charAt(0) === 'M') {
        value = minute
      } else if (key.charAt(0) === 'S') {
        value = second
      } else if (key.charAt(0) === 'm') {
        value = millisecond
        return value
      }
      return value !== null ? leftPaddingZero(value, key.length) : ''
    })
  }
  /**
   * 倒计时结束
   */
  const handleTimerEnd = () => {
    pageDataContext.pageStatus = PAGE_STATUS.TIME_ENDED
    viewData.timerDeadline = 0

    // 刷新页面状态
    getPageData(true)
  }

  //进入页面弹框
  const pageLoadPopup = () => {
    //造数据测试弹框动画样式
    // let config = {"enterButtonUrl":"https://image.hhdd.com/activity/offline/cover/c8c6642674ba439ebe3fc6f7a727d3e9.png","enterPopUrl":"https://image.hhdd.com/activity/offline/cover/d840dd4cff5f4693aa74942da46d8bc2.svga","id":492,"secondPopButtonUrl":"https://image.hhdd.com/activity/offline/cover/17eed3e402374c2b9dee0bb1b846a7b7.png","secondPopUrl":"https://image.hhdd.com/activity/offline/cover/3f0b4183257d4de482ccce0949d78dc8.svga"}
    // let {enterPopUrl, enterButtonUrl, secondPopUrl, secondPopButtonUrl} = config
    // return showPageLoadDialog({
    //   popUpImg: enterPopUrl,
    //   btnImg: enterButtonUrl,
    //   showCloseBtn: true,
    //   autoClose: false,
    //   onClose() {
    //     if (secondPopUrl && secondPopButtonUrl) {
    //       showPageLoadDialog({
    //         popUpImg: secondPopUrl,
    //         btnImg: secondPopButtonUrl,
    //         showCloseBtn: false,
    //         autoClose: true,
    //         onClose() {
    //           service.setLoadPopuped(activityKey, userId)
    //         }
    //       })
    //     }
    //   }
    // })
    const {isJoin = 0, drawFlag = 0, userId = 0} = pageDataContext?.responseBody?.data?.userInfo || {}
    const loadPagePoped = service.isLoadPopupPoped(activityKey, userId)
    //已购买
    if (isJoin) {
      //有抽奖组件，未抽奖，提示抽奖并跳转到抽奖楼层
      !!drawPanelConfig && !drawFlag && showDrawChanceDialog({ onClose() { scrollToView('.c-prize-draw-panel') } })
    }
    //未购买，如果有配置弹框，今天未弹出则弹出
    else if (enterPopupConfig && !loadPagePoped) {
      let {enterPopUrl, enterButtonUrl, secondPopUrl, secondPopButtonUrl} = enterPopupConfig
      if (enterPopUrl && enterButtonUrl) {
        isPopLoadingPage = true
        showPageLoadDialog({
          popUpImg: enterPopUrl,
          btnImg: enterButtonUrl,
          showCloseBtn: true,
          autoClose: true,
          onClose() {
            isPopLoadingPage = false
            // 未配置二次弹窗按钮，也显示弹窗图片
            if (secondPopUrl || secondPopButtonUrl) {
              isPopLoadingPage = true
              showPageLoadDialog({
                popUpImg: secondPopUrl,
                btnImg: secondPopButtonUrl,
                showCloseBtn: false,
                autoClose: true,
                memberBannerConfig,
                onClose() {
                  isPopLoadingPage = false
                  service.setLoadPopuped(activityKey, userId)
                }
              })
            }
          }
        })
      }
    }
  }

  const showPageLoadPopup = () => {
    let {query: {newUser = 0}} = $router
    //微信端
    if (deviceInfo.wechat) {
      //新用户设置年龄
      if (newUser && parseInt(newUser) == 1) {
        showChooseAgeDialog({
          onDone(data) {
            showLoading()
            //去掉url中的newUser参数
            removeUrlParam(newUser)
            service.setAge({readingStage: data.value}).then(res => {
              hideLoading()
              let {code} = res
              if (code == 200) {
                getPageData(true)
              } else {
                toast(res.msg)
              }
            })
            //显示页面弹框
            pageLoadPopup()
          }
        })
      } else {
        //老用户，显示页面弹框
        pageLoadPopup()
      }
    } else {
      //app，显示页面弹框
      pageLoadPopup()
    }
  }

  onMount(async () => {
    promiseDelay(200).then(() => window.scrollTo(0, 0))
    console.log(pageDataContext)
  })

  onDestroy(() => {
    if (lazyInstace && lazyInstace.observer) {
      lazyInstace.observer.disconnect()
    }

    if (deviceInfo.isKadaClient && compareVersion(SUPPORT_SV_APP_VERSION)) {
      clearExposure()
    }
    
  })
</script>
<style lang="scss" global>
  @import '../../../styles/variables';
  @import '../../../styles/mixins';
  $page-name: "o-home";
  // .l-maxwidth {
  //   max-width: 7.5rem;
  // }

  @mixin posBlockCenter {
    width: 7.5rem;
    position: absolute;
    left: 0;
    right: 0;
    margin: auto;
  }

  @mixin sliced-bg-image-style () {
    img {
      display: block;
      padding: 0;
      border: 0;
      -webkit-user-drag: none;
      pointer-events: none;
    }

    margin-top: var(--item-margin-top, -1px);
    transition: opacity var(--item-fade-duration, 0.15s) ease-in;

    &::first-child {
      margin: 0;
    }

    &.lazy {
      opacity: 0;
    }

    &[data-loaded] {
      opacity: 1;
    }
  }

  .bg-filter {
    filter: blur(5px);
    -webkit-filter: blur(5px);
  }

  .#{$page-name} {
    position: relative;
    overflow-x: hidden;
    margin: 0 auto;
    &.is-fill-bottom {
      padding-bottom: 1.7rem;
      // @media #{$pad_landscape_query} {
      //   padding-bottom: 2rem;
      // }
    }
    // 邀请记录按钮
    .btn-invitation {
      position: absolute;
      z-index: 3;
      top: 11.98rem;
      left: -1.3rem;
      width: 2rem;
      height: 0.88rem;
      background-image: url('//cdn.hhdd.com/frontend/as/i/3c89a0c5-6fd4-5dd7-8693-66377b766874.png');
      background-repeat: no-repeat;
      background-size: 100% 100%;
      // @media #{$pad_landscape_query} {
      //   top: 9.56rem;
      //   right: auto;
      //   left: -2.32rem;
      //   width: 3.6rem;
      //   height: 1.58rem;
      //   background-image: url('//cdn.hhdd.com/frontend/as/i/3c89a0c5-6fd4-5dd7-8693-66377b766874.png');
      // }
    }
    // 微信分享蒙层
    .c-share-tip {
      background: rgba(0, 0, 0, 0.7);
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 10000;
      &::after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 3.18rem;
        height: 2.64rem;
        background-image: url('//cdn.hhdd.com/frontend/as/i/e8b28d6c-297b-5210-ac39-c1762db8735d.png');
        z-index: 9999;
        background-size: cover;
      }
    }
    &__banner {
      width: 100%;
    }
    &__section {
      width: 100%;
    }
    &__section-video {
      width: 100%;
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      position: relative;
    }
    &__video {
      width: 6.42rem;
      height: 3.6rem;
      position: absolute;
      left: 0;
      top: 0;
      right: 0;
      bottom: 0;
      margin: auto;
      :global(.video-content) {
        border: none;
        width: 6.42rem;
        height: 3.6rem;
        border-radius: 0.4rem;
        transform: translateZ(0);
      }
      :global(.c-video-player__icon--play) {
        width: 1.2rem;
        height: 1.2rem;
      }
      // @media #{$pad_landscape_query} {
      //   left: 2.79rem;
      //   width: 7.88rem;
      //   height: 4.42rem;
      //   right: auto;
      //   :global(.video-content) {
      //     border-radius: 0.4rem;
      //     width: 7.88rem;
      //     height: 4.42rem;
      //   }
      //   :global(.c-video-player__icon--play) {
      //     width: 1.44rem !important;
      //     height: 1.44rem !important;
      //   }
      // }
    }
    &__video-bg {
      width: 100%;
    }
    &__body {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
    }

    &__marquee {
      height:0.54rem;
      line-height: 1;
      font-size: 0.24rem;
      font-weight: 400;

      &-item {
        display: flex;
        align-items: center;
        // min-width: 2.57rem;
        height: 0.50rem;
        background: rgba(66, 27, 198, 0.75) ;
        border-radius: 0.26rem;
        padding: 0.03rem 0.22rem 0.04rem 0.08rem;
        font-size: 0.24rem;
        font-weight: 400;
        line-height: 1;
        opacity: 0.8;
        color: #fff;

        .body {
          display: inline-block;
          line-height: 1;
          padding-top: 0.04rem;
        }

        .avatar {
          display: inline-block;
          width: 0.4rem;
          height: 0.4rem;
          border-radius: 50%;
          overflow: hidden;
          margin: 0 0.09rem 0 0;
          padding: 0;
          background: url(//cdn.hhdd.com/frontend/as/i/dfdfa1df-fa50-5e3d-ba2d-7ba2a90ce400.png?x-oss-process=image/format,jpg/quality,q_65/interlace,1/resize,m_pad,w_40,h_40) no-repeat 50% 50% / 100% 100%;
        }
      }

      &-wrapper {
        position: absolute;
        overflow: hidden;
        left: 0;
        top: 0.5rem;
        top: calc(constant(safe-area-inset-top) + 0.05rem);
        top: calc(env(safe-area-inset-top) + 0.05rem);
        right: 0;
        z-index: 3;
        &.is-hd {
          top: 0.4rem;
        }
      }

      :global(.c-marquee) {
        display: block;
        background: none;
        pointer-events: none;
      }

      :global(.c-marquee__list) {
        min-width: max-content;
      }

      :global(.c-marquee__item) {
        padding-right: 0.78rem;
        padding-left: 0.78rem;
      }
    }

    &__panel {
      position: absolute;
      left: 0;
      right: 0;
      width: 7.5rem;
      margin: auto;
      :global(.c-statpanel__footer) {
        top: 1.6rem;
      }
      // @media #{$pad_landscape_query} {
      //   width: 10.24rem !important;
      //   height: 3rem;
      //   :global(.c-statpanel__footer) {
      //     bottom: 0.06rem;
      //   }
      // }
    }

    &__timer {
      margin-top: 0.07rem;
      // .sui-timer {
      //   // background: rgba(0, 0, 0, 0.4);
      //   // padding: 0.1rem 0.2rem;
      //   // border-radius: 0.4rem;
      //   // font-size: 0.24rem;
      //   // font-family: 'FZLANTY_JW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
      //   // font-weight: normal;
      //   // color: #FFFFFF;
      //   display: flex;
      //   align-items: center;
      //   justify-content: center;
      //   width: 4.44rem;
      //   height: 0.48rem;
      //   background: rgba(0, 0, 0, 0.5);
      //   border-radius: 0.32rem;
      //   font-size: 0.24rem;
      //   font-weight: normal;
      //   color: #FFFFFF;
      // }

      // @media #{$pad_landscape_query} {
      //   .sui-timer {
      //     padding: 0.12rem 0.2rem;
      //     font-size: 0.28rem;
      //     font-family: 'FZLANTY_JW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
      //     font-weight: normal;
      //     color: #FFFFFF;
      //   }
      // }
    }

    &__sticky {
      position: absolute;
    }
    &__sidebar {
      width: 0.94rem;
      height: 0.94rem;
      position: fixed;
      top: 60%;
      bottom: 0;
      margin: auto;
      right: 0.1rem;
      opacity: 0;
      z-index: 99;
      &.is-show {
        opacity: 1;
      }
      // @media #{$pad_landscape_query} {
      //   top: 50%;
      // }
    }

    &__panel {
      @include posBlockCenter;
      top: 0;
      transition: opacity 0.4s;
      opacity: 1;
      &.is-hide {
        opacity: 0;
      }
    }

    &__rule {
      position: absolute;
      bottom: 0.3rem;
      width: 100%;
      font-size: 0.22rem;
      font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
      font-weight: normal;
      color: #5b5b5b;
      background-color: rgba(0, 0, 0, 0.5);
      color: #fff;
      padding: 0.05rem 0 0.05rem 0;
      text-align: center;
      a {
        color: #ffff00;
        text-decoration: underline;
      }
      &.is-fill-bottom {
        bottom: 2rem;
      }
      // @media #{$pad_landscape_query} {
      //   bottom: 0.3rem;
      //   padding-left: 1.7rem;
      //   &.is-fill-bottom {
      //     bottom: 2.2rem;
      //   }
      // }
    }
    .overday {
      padding-bottom: 0.2rem;
      text-align: center;
      @include flex(row, center, center, center, nowrap);
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      line-height: 0.4rem;
      .before {
        color: #814616;
      }
      .overday-time {
        color: #FC4F03;
      }
      // @media #{$pad_landscape_query} {
      //   padding-bottom: 0.8rem;
      //   font-size: 0.26rem;
      // }
    }
  }


  .c-sliced-bg-item {
    @include sliced-bg-image-style();
  }

  .c-gift-pack {
    display: flex;
    justify-content: center;
    align-content: center;
    align-items: center;
    position: relative;
    &__list {
      position: absolute;
      width: 6.94rem;
      min-height: 3.5rem;
      background: #FFFFFF;
      border-radius: 0.4rem;
      padding: 0.4rem 0 0.48rem;
      text-align: center;
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      flex-direction: column;
    }
    &__title {
      font-size: 0.4rem;
      font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
      font-weight: normal;
      color: #FF8217;
      line-height: 0.56rem;
    }
    &__item {
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      width: 6.46rem;
      height: 0.72rem;
      background: rgba(255, 207, 12, 0.2);
      border-radius: 0.36rem;
      display: flex;
      justify-content: space-between;
      align-content: center;
      align-items: center;
      margin-top: 0.32rem;
      padding-left: 0.12rem;

      .info {
        display: flex;
        justify-content: center;
        align-content: center;
        align-items: center;
      }
      .number {
        width: 0.48rem;
        height: 0.48rem;
        line-height: 0.5rem;
        border-radius: 50%;
        background: rgba(255, 130, 23, 0.2);
        font-size: 0.28rem;
        font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
        font-weight: normal;
        color: #FF8217;
      }
      .text {
        font-size: 0.24rem;
        font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
        font-weight: normal;
        color: #3F3F3F;
        line-height: 0.32rem;
        margin-left: 0.08rem;
      }
      .button {
        width: 1.2rem;
        height: 0.72rem;
        background: #FF8217;
        border-radius: 0.36rem;
        font-size: 0.24rem;
        font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
        font-weight: normal;
        color: #FFFFFF;
        line-height: 0.32rem;
        &:active {
          background: #c36515;
        }
      }
    }

    // @media #{$pad_landscape_query} {
    //   &__list {
    //     width: 18rem;
    //     min-height: 3.5rem;
    //     border-radius: 0.72rem;
    //     padding: 0.4rem 0 0.48rem;
    //   }
    //   &__title {
    //     font-size: 0.48rem;
    //     line-height: 0.66rem;
    //   }
    //   &__item {
    //     width: 12rem;
    //     height: 0.8rem;
    //     border-radius: 0.4rem;
    //     margin-top: 0.32rem;
    //     .number {
    //       width: 0.56rem;
    //       height: 0.56rem;
    //       line-height: 0.58rem;
    //       border-radius: 50%;
    //       font-size: 0.33rem;
    //     }
    //     .text {
    //       font-size: 0.32rem;
    //       line-height: 0.32rem;
    //       margin-left: 0.16rem;
    //     }
    //     .button {
    //       width: 2rem;
    //       height: 0.8rem;
    //       border-radius: 0.4rem;
    //       font-size: 0.32rem;
    //       color: #FFFFFF;
    //       line-height: 0.32rem;
    //     }
    //   }
    // }
  }
  .timer-new {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 0.44rem 0 0.58rem;
    height: 0.66rem;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 0.33rem;
    font-size: 0.32rem;
    font-weight: normal;
    color: #FFFFFF;
    font-family: FZLANTY_ZHONGCUJW--GB1;

    .before {
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-size: 0.32rem;
    }
    .sui-timer__zone {
      margin-left: 0.06rem;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      font-size: 0.32rem;
    }
  }
</style>
