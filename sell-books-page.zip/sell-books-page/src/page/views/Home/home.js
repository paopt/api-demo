import Context from '@/shared/internal/context'
import { DAY_TIME } from '@kada/library/utils/datetime'
import { getActivityInfo, receiveGift, draw, drawDetail} from '../../service'
import { parsedActivityRawConfig } from '../../app'
import { setContext, getPageData } from '@/shared/internal'
import * as pageConfig from '../../config'
import{ initPageConfig, updatePageConfig } from '@/shared/scheme/page-config'
import { hasSupportOnlineService, hasNewTabbarApp } from '@/shared/utils/detecter'
import {wxAuthLogin} from '@/shared/internal/wechat'
import {deviceInfo} from '@kada/library/src/device'
import URLParser from "@/lib/urlParser"

const parsed = new URLParser(location.href)
export let userIdStr = parsed.query.u || parsed.query.userIdStr
console.log("页面参数：", userIdStr)


// 活动页面上下文
let context = null

/**
 * 将接口 getActvityInfo 和 getPackageInfo 接口数据合并
 *
 * @param {Number} activityKey 活动ID
 * @return {Promise<Object>}
 */
const getDataService = async (activityKey, isRefresh) => {
  try {
    // 测试数据 活动数据
    const responseInfo = await getActivityInfo(activityKey, userIdStr).then((res) => (res || {}))
    // const responseInfo = {"msg":"成功","data":{"activityInfo":{"id":60,"activityName":"3.6续费","crc32Name":24206527,"payInfoId":0,"packageType":6,"startTime":1678118400000,"endTime":1678982399000,"operator":"anxiangtian","status":1,"modifyTime":1678848797000,"createTime":1678677694000,"buyAudioUrl":"https://image.hhdd.com/activity/offline/cover/1c44ab693c1a4b17bccb328802a2ad68.mp3","upGradeAudioUrl":"https://image.hhdd.com/activity/offline/cover/144ed6ccd419465d95620a0e57ad4394.mp3","svipAudioUrl":"https://image.hhdd.com/activity/offline/cover/7bcd752cac324314a3718b194f5a077a.mp3","orderAudioUrl":"https://image.hhdd.com/activity/offline/cover/52a0db7178f54ed984b289c4e2e838c8.mp3","identityFlag":0,"activityPart":[{"id":1744,"crc32Name":24206527,"type":3,"sort":4,"typeSort":304,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678848796000,"content":"{\"imagUrl\":\"https://image.hhdd.com/activity/offline/cover/a934d816825d4043b6782d00b17efd9f.png\",\"ipadImagUrl\":\"https://image.hhdd.com/activity/offline/cover/79aaac9386b54655bc8ca7b68fc8f59a.png\",\"protocol\":\"\"}"},{"id":1693,"crc32Name":24206527,"type":7,"sort":4,"typeSort":704,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678775846000,"content":"{\"blindBoxButton\":\"https://image.hhdd.com/activity/offline/cover/0039158b60a94bdb9fbb971a5dcce393.png\",\"blindCapButton\":\"https://image.hhdd.com/activity/offline/cover/70367ae375e344fe81b4ac3c628f5a3d.png\",\"blindOpenButton\":\"https://image.hhdd.com/activity/offline/cover/66c1e0ae5463477dbc422c5bdd141c90.png\",\"content\":[{\"awardName\":\"7天\",\"awardType\":1,\"awardUrl\":\"https://image.hhdd.com/activity/offline/cover/7290ad0e8eb24877b83dd14540100b5d.png\",\"cardUrl\":\"\",\"config\":\"7\",\"rate\":1},{\"awardName\":\"dudu\",\"awardType\":5,\"awardUrl\":\"https://image.hhdd.com/activity/offline/cover/d08fa74e9949409fa660dd2626b1e243.png\",\"cardUrl\":\"\",\"config\":\"kada://openurl?url=www.baidu.com\",\"rate\":99}],\"drawBaseMapUrl\":\"https://image.hhdd.com/activity/offline/cover/82127c195e9840cb8ac757e23c5e3e64.png\",\"drawButton\":\"https://image.hhdd.com/activity/offline/cover/a71c897489684567937066f700b84e6a.png\",\"drawOverButton\":\"https://image.hhdd.com/activity/offline/cover/afed80a83ddd44e3b787e8990305220c.png\",\"guideOrderButton\":\"https://image.hhdd.com/activity/offline/cover/2077655f1aba4b508c8a3e54ab46201b.png\",\"id\":1693,\"ipadBlindBoxButton\":\"https://image.hhdd.com/activity/offline/cover/2500e80a3f424a11999a1f65f55cffc5.png\",\"ipadBlindCapButton\":\"https://image.hhdd.com/activity/offline/cover/73275a582d844daf8c99f0e1fb5ff9f6.png\",\"ipadBlindOpenButton\":\"https://image.hhdd.com/activity/offline/cover/a37684a2589041ea827d843fbca3f06a.png\",\"ipadDrawBaseMapUrl\":\"https://image.hhdd.com/activity/offline/cover/e02f1bce296149d2910ae2b5cbfbe544.png\",\"ipadDrawButton\":\"https://image.hhdd.com/activity/offline/cover/cdfff9a890354af2b0ceb26e06a624a7.png\",\"ipadDrawOverButton\":\"https://image.hhdd.com/activity/offline/cover/7b2c53b33e7b4b9dabce689f07852ff3.png\",\"ipadGuideOrderButton\":\"https://image.hhdd.com/activity/offline/cover/ddee29898de34923a8d6ea359fcd5bcf.png\"}"},{"id":1745,"crc32Name":24206527,"type":3,"sort":5,"typeSort":305,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678848796000,"content":"{\"imagUrl\":\"https://image.hhdd.com/activity/offline/cover/75021f0fe13844dd8d691ed0c145d5d0.png\",\"ipadImagUrl\":\"https://image.hhdd.com/activity/offline/cover/3af1e5d22c304c4195ac0402f3072e79.png\",\"protocol\":\"\"}"},{"id":1746,"crc32Name":24206527,"type":3,"sort":6,"typeSort":306,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678848796000,"content":"{\"imagUrl\":\"https://image.hhdd.com/activity/offline/cover/e795ea1979514542bf46b6fac2e48a07.png\",\"ipadImagUrl\":\"https://image.hhdd.com/activity/offline/cover/cf26170e5acd4d5bb67d819ea671d8f1.png\",\"protocol\":\"\"}"},{"id":1630,"crc32Name":24206527,"type":4,"sort":2,"typeSort":402,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678692102000,"content":"{\"backGroundUrl\":\"https://image.hhdd.com/activity/offline/cover/2434b433b29a49e5855aeef3dd40626f.png\",\"id\":1630,\"ipadBackGroundUrl\":\"https://image.hhdd.com/activity/offline/cover/4009b0c820a548d7a477a6da11e3a985.png\",\"previewUrl\":\"https://image.hhdd.com/activity/offline/cover/8056650837414980bfefe323a147c82b.jpg\",\"videoUrl\":\"https://image.hhdd.com/activity/offline/cover/0944acee2ca245dcaa0af2a5deb8269f.mp4\"}"},{"id":1617,"crc32Name":24206527,"type":1,"sort":1,"typeSort":101,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678677694000,"content":"{\"id\":1617,\"text\":\"已参加\"}"},{"id":1739,"crc32Name":24206527,"type":8,"sort":8,"typeSort":808,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678845585000,"content":"{\"enterButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/eda469e2c0f241be8fe8a63ed341cd65.png\",\"enterPopUrl\":\"https://image.hhdd.com/activity/offline/cover/6ec0d1c039cd4667a032f3f44c2435d5.svga\",\"id\":1739,\"secondPopButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/eb459e7110924ed3b2fbc95070cc4512.png\",\"secondPopUrl\":\"https://image.hhdd.com/activity/offline/cover/c83acb9574a4449a9aa242a9294e6494.svga\"}"},{"id":1623,"crc32Name":24206527,"type":6,"sort":99,"typeSort":699,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678677694000,"content":"{\"buyButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/73a763d26ff54fd2966e47948923f4ab.png\",\"id\":1623,\"ipadBuyButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/499cdb90b5534f72a2f3e7871e2b8c5c.png\",\"ipadSvipButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/499cdb90b5534f72a2f3e7871e2b8c5c.png\",\"ipadUpGradeButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/499cdb90b5534f72a2f3e7871e2b8c5c.png\",\"svipButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/73a763d26ff54fd2966e47948923f4ab.png\",\"upGradeButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/73a763d26ff54fd2966e47948923f4ab.png\"}"},{"id":1624,"crc32Name":24206527,"type":9,"sort":9,"typeSort":909,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678677694000,"content":"{\"buyAfterButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/cf61dd2dde6d44f194ec0709e6b60bf8.png\",\"buyButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/3dba28f12e8d4e4da380eb1f9eeee843.png\",\"id\":1624,\"imageUrl\":\"https://image.hhdd.com/activity/offline/cover/981b2c53680143359f85af45e4e0fc99.png\",\"ipadBuyAfterButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/483be78670a648c7920da3eb1ab125f5.png\",\"ipadBuyButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/35c6661579d44150bfae3828a3ae7034.png\",\"ipadImageUrl\":\"https://image.hhdd.com/activity/offline/cover/8418a0efe79e4b22996485ecb3b7f5d0.png\"}"},{"id":1742,"crc32Name":24206527,"type":3,"sort":1,"typeSort":301,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678848796000,"content":"{\"imagUrl\":\"https://image.hhdd.com/activity/offline/cover/e181a271e86b42f5bae9b9a3980dc11a.png\",\"ipadImagUrl\":\"https://image.hhdd.com/activity/offline/cover/e919a2bb8da04d379202efb0ca3909bb.png\",\"protocol\":\"\"}"},{"id":1743,"crc32Name":24206527,"type":3,"sort":3,"typeSort":303,"status":1,"classificationId":1,"subSort":1,"modifyTime":1678848796000,"createTime":1678848796000,"content":"{\"imagUrl\":\"https://image.hhdd.com/activity/offline/cover/ecb39d1bd3cc4a338fb762a1a82cf418.png\",\"ipadImagUrl\":\"https://image.hhdd.com/activity/offline/cover/d57f49a252414c5794a9ba008b7974f0.png\",\"protocol\":\"\"}"}],"currentTime":1678849744864,"jumpType":1,"jumpData":"456","shareJumpUrl":"","shareImgUrl":"https://image.hhdd.com/activity/offline/cover/d04aeb737661473c8ad73950e1771eaa.png","shareTitle":"777","shareSubTitle":"8285","joinJumpUrl":"https://www.baidu.com","phoneShareImg":"","hdShareImg":"","awardType":1,"award":"","classificationFlag":0},"userInfo":{"isVip":1,"isSvip":1,"vipDays":1539,"svipDays":826,"isVisitor":0,"isJoin":0,"drawFlag":0,"awardType":0,"awardUrl":"","awardName":"","userId":60048070,"isLifeVip":0,"isLifeSvip":0,"isReceived":0,"isGiveVip":0,"isOverUser":1,"overUserInfo":{"id":36,"userId":60048070,"startTime":1669879244000,"status":1,"modifyTime":1678679770000,"createTime":1678679770000,"headImg":"","nickName":"一二三四五六七八九十","totalReadDays":199,"totalReadBooks":99,"recentOpenApp":50,"recentMonthReadTime":360,"recentMonthReadBooks":6,"joinReadPlans":0,"readSubjectOne":"世界充满爱","readSubjectTwo":"","readPlanLink":10,"mostLikeCollectId":77005,"mostLikeCollectRecommend":"不忘历史 感恩先烈","mostLikeCollectName":"战斗英雄 爱国故事","mostLikeCollectImgUrl":"https://image.hhdd.com/books/cover/7ce3ed1c-06fd-4a8a-8aad-76e58d606169.jpg","days":20,"fonts":198000}}},"code":200}

    // 异常情况，默认都显示未参数错误 44400
    let { code = 44400, msg = '', data } = responseInfo

    if (data) {
      let { userInfo, activityInfo } = data

      // mock
      // activityInfo.countdown = 2
      if (!userInfo) {
        data.userInfo = userInfo = {}
      }

      if (!activityInfo) {
        data.activityInfo = activityInfo = {}
      }

      const { endTime, startTime, currentTime } = activityInfo

      // 根据服务端返回数据生成计算状态
      if (currentTime < startTime) { // 活动未开始
        code = 5406
      } else if (currentTime >= endTime) { // 活动已经结束
        code = 5405
      }
      // 自然日24小时倒计时剩余时间计算
      // const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
      // const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
      let timerDeadline = endTime - currentTime
      if (isNaN(timerDeadline)) {
        timerDeadline = 0
      }

      // 计算活动结束时间，单位天
      const endRemainTime = Math.floor((endTime - currentTime) / 1000) * 1000
      const expireDays = isNaN(endRemainTime) ? 0 : Math.max(0, Math.ceil(endRemainTime / DAY_TIME))

      let computedStatus = 5

      const {
        isLifeSvip,
        isLifeVip,
        vipDays,
        isVip,
        isSvip,
        isVisitor,
        isJoin,
        drawFlag,
        isOverUser
      } = userInfo

      if (isVisitor) {
        computedStatus = 0
      }
      if ((isVip && vipDays >= 30)) {
        computedStatus = 1
      }
      if (isLifeVip) {
        computedStatus = 2
      }
      if (isSvip || isLifeSvip) {
        computedStatus = 3
      }

      if (isJoin) {
        computedStatus = 4
      }

      if (isOverUser === 0
        && Array.isArray(activityInfo.activityPart)
        && activityInfo.activityPart.some(p => p.type == 9)) {
        computedStatus = 7             //未参加续费活动，不是过期30天以内用户，且不是临期30天以内用户
      }

      activityInfo.expireDays = expireDays // 活动剩余天数
      activityInfo.expire = endRemainTime // 活动剩余毫秒数
      userInfo.computedStatus = computedStatus // 计算状态
      userInfo.timerDeadline = timerDeadline // 自然日剩余时长
      activityInfo.timer = {
        label: '活动仅剩',
        format: 'D天HH小时MM分SS秒'
      }
      // 每天倒计时
      if (activityInfo.countdown === 2) {
        // let now = new Date(currentTime)
        // let nextDay = new Date(`${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate() + 1}`)
        // userInfo.timerDeadline = nextDay.getTime() - currentTime

        const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
        const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
        const timerDeadline = todayLastTime - nowDate.getTime()
        userInfo.timerDeadline = timerDeadline

        activityInfo.timer = {
          label: '仅剩',
          format: 'HH小时MM分SS秒'
        }
      }
      activityInfo.isSvip = isSvip
      console.log('home执行：', activityInfo.countdown)
    }


    return {
      code,
      msg,
      data
    }
  } catch (error) {
    console.error('dataService Error: ', error)
  }

  return null
}



/**
 * 获取初始活动相关数据
 * @param {Object} options 相关配置
 * @param {String} options.activityKey 活动ID
 * @param {String} options.channelId 渠道ID
 *
 * @returns {{pageData:Boolean, historyData:Array<{name:string}>}}
 */
export async function onInitPageData ({ activityKey, channelId } = {}) {
  const [isSupportOnlineService, isNewTabbarApp] = await Promise.all([hasSupportOnlineService(), hasNewTabbarApp()])

  // 测试数据 微信授权登陆
  if (deviceInfo.wechat && !location.href.includes('newUser=')) {
    try {
      await wxAuthLogin()
    } catch (e) {
      console.log('wechat login fail' + e.message)
    }
  }
  context = new Context({
    activityKey,
    channelId,
    dataService: getDataService,
    parseViewData: (pageStatus, reponseBody) => {
      if (!reponseBody || reponseBody.code !== 200 || !reponseBody.data) {
        return null
      }

      const { activityInfo, userInfo } = reponseBody.data
      if (!activityInfo) {
        return null
      }

      if (!userInfo) {
        return null
      }
      // 解析活动原始配置
      parsedActivityRawConfig(activityInfo)
      // 更新页面配置
      updatePageConfig(pageConfig, context)
      let {shareTitle, shareSubTitle, shareImgUrl, shareJumpUrl, crc32Name, identityFlag} = activityInfo
      console.log('timerDeadline', userInfo.timerDeadline)
      return {
        activityKey, //活动编号
        expireDays: activityInfo.expireDays, // 距活动结束还有几天
        timerDeadline: userInfo.timerDeadline, // 自然日倒计时剩余时长
        packageId: activityInfo.payInfoId || 0, // 默认购买礼包
        packageType: activityInfo.packageType || 6, // 支付类型
        identityFlag: activityInfo.identityFlag || 0, // 是否区分用户（用于用户跳转逻辑）
        jumpType: activityInfo.jumpType || 0, // 用户跳转类型
        jumpExtraData: activityInfo.jumpData || '', // 用户跳转额外信息 档位id，kada协议，小程序链接
        isSupportOnlineService, // 是否支持在线客服
        isNewTabbarApp, // 是否为新版界面App
        joinJumpUrl: activityInfo.joinJumpUrl, //已参加活动跳转
        shareData: {
          shareTitle,
          shareSubTitle,
          shareImgUrl,
          shareJumpUrl,
          crc32Name,
          identityFlag,
          canUseShare:  activityInfo.shareFlag === 1 // shareFlag: 1 可以分享，0不可以。
        },
        userInfo: userInfo,
        countdown: activityInfo.countdown, // 倒计时：1、最后三天倒计时；2、每天倒计时
        timer: activityInfo.timer,
        isSvip: activityInfo.isSvip
      }
    }
  })

  // 初始化页面配置
  initPageConfig(pageConfig, context)
  // 设置礼包购买逻辑上下文
  setContext(context)
  //调用ajax获取页面配置信息
  getPageData(false)

  return {
    context,
    pageConfig
  }
}


// 去领取书单
export async function gotoReceiveGift() {
  try {
    const responseInfo = await receiveGift()
    const { code } = responseInfo
    if (code !== 200) {
      throw new Error(responseInfo)
    }
    return true
  } catch (error) {
    console.error('receiveGift Error: ', error)
    return false
  }
}

/**
 * 去抽哦讲
 * @param {*} activityKey 活动编号
 */
export async function goDraw(activityKey) {
  return await draw(activityKey)
}

/**
 * 查看抽中奖品
 * @param {*} activityKey 活动编号
 * @returns
 */
export async function checkDrawDetail(activityKey) {
  return await drawDetail(activityKey)
}

/**
 * 去掉url中的newUser
 */
export function removeUrlParam(param) {
  const newUrl = location.href.replace(/(\?|&)*(newUser)=([^&=?#]+)/ig, '')
  if (history.replaceState) {
    history.replaceState(param, document.title, newUrl)
  } else {
    location.replace(newUrl)
  }
}
