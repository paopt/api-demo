import Context from '@/shared/internal/context'
import { DAY_TIME } from '@kada/library/utils/datetime'
import { getActivityInfo, receiveGift, draw, drawDetail} from '../../service'
import { parsedActivityRawConfig } from '../../app'
import { setContext, getPageData } from '@/shared/internal'
import * as pageConfig from '../../config'
import{ initPageConfig, updatePageConfig } from '@/shared/scheme/page-config'
import { hasSupportOnlineService, hasNewTabbarApp } from '@/shared/utils/detecter'
import {deviceInfo} from '@kada/library/src/device'
import URLParser from "@/lib/urlParser"
import * as storage from '@/lib/storage'
import { wxAuthLogin } from '@/shared/internal/wechat'

const parsed = new URLParser(location.href)
export let userIdStr = parsed.query.u || parsed.query.userIdStr
console.log("页面参数：", userIdStr)


// 活动页面上下文
let context = null

/**
 * 将接口 getActvityInfo 和 getPackageInfo 接口数据合并
 *
 * @param {Number} activityKey 活动ID
 * @return {Promise<Object>}
 */
const getDataService = async (activityKey, isRefresh) => {
  try {
    // const res = await fetchUserInfo()
    // console.log('活动 fetchUserInfo', res)
    // 测试数据 活动数据
    const responseInfo = await getActivityInfo(activityKey, userIdStr).then((res) => (res || {}))
    // 这里可以mock数据
    // const responseInfo = {
    //   "msg": "成功",
    //   "data": {
    //       "activityInfo": {
    //           "id": 71,
    //           "activityName": "倒计时",
    //           "crc32Name": 34308307,
    //           "payInfoId": 0,
    //           "packageType": 6,
    //           "startTime": 1692806400000,
    //           "endTime": 1693497599000,
    //           "operator": "yjf",
    //           "status": 1,
    //           "modifyTime": 1693274239000,
    //           "createTime": 1692861976000,
    //           "buyAudioUrl": "",
    //           "upGradeAudioUrl": "",
    //           "svipAudioUrl": "",
    //           "orderAudioUrl": "",
    //           "identityFlag": 0,
    //           "activityPart": [
    //               {
    //                   "id": 3152,
    //                   "crc32Name": 34308307,
    //                   "type": 13,
    //                   "sort": 1,
    //                   "typeSort": 1303,
    //                   "status": 1,
    //                   "classificationId": 1,
    //                   "subSort": 1,
    //                   "modifyTime": 1693362948000,
    //                   "createTime": 1693274238000,
    //                   "content": "{\"text\":\"这是个文案组件\",\"color\":\"#000000\"}"
    //               },
    //               {
    //                   "id": 3126,
    //                   "crc32Name": 34308307,
    //                   "type": 2,
    //                   "sort": 2,
    //                   "typeSort": 202,
    //                   "status": 1,
    //                   "classificationId": 1,
    //                   "subSort": 1,
    //                   "modifyTime": 1693274238000,
    //                   "createTime": 1692861976000,
    //                   "content": "{\"buyAfterButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/7ce92d48db3f4595baecc8966fa511ef.png\",\"buyButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/3830135c828642d99ce30a2e13d9dd9b.png\",\"headImagUrl\":\"https://image.hhdd.com/activity/offline/cover/b524b1d62b0d4368b57c220f5a7ce3ef.png\",\"id\":3126,\"ipadBuyAfterButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/58b9a1135a0548a7ab4926f7503797dd.png\",\"ipadBuyButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/09e2e25fa4144947b35345ed556a68c7.png\",\"ipadHeadImagUrl\":\"https://image.hhdd.com/activity/offline/cover/c922584611c2403391cbe3c82fa66d18.png\",\"ipadSvipButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/51efcd0bc93744279a27a6bee3080c6b.png\",\"ipadUpGradeButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/84c43e5aedd3453c82d2bb643b0dfdc2.png\",\"svipButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/a3b7a1b16a16490a8396788bfc594953.png\",\"upGradeButtonUrl\":\"https://image.hhdd.com/activity/offline/cover/60645754b8ef47378b0d0e2c5cf06f84.png\"}"
    //               },
    //               {
    //                   "id": 3151,
    //                   "crc32Name": 34308307,
    //                   "type": 3,
    //                   "sort": 2,
    //                   "typeSort": 301,
    //                   "status": 1,
    //                   "classificationId": 1,
    //                   "subSort": 1,
    //                   "modifyTime": 1693274238000,
    //                   "createTime": 1693274238000,
    //                   "content": "{\"imagUrl\":\"https://image.hhdd.com/activity/offline/cover/f3800f3e520c4c7989f719f01f3e5174.png\",\"ipadImagUrl\":\"https://image.hhdd.com/activity/offline/cover/7ca05c49dfb94f64b53fce6f66a09036.png\",\"protocol\":\"\"}"
    //               }
    //           ],
    //           "currentTime": 1693365515123,
    //           "jumpType": 1,
    //           "jumpData": "456",
    //           "shareJumpUrl": "",
    //           "shareImgUrl": "https://image.hhdd.com/activity/offline/cover/d04aeb737661473c8ad73950e1771eaa.png",
    //           "shareTitle": "",
    //           "shareSubTitle": "",
    //           "joinJumpUrl": "",
    //           "phoneShareImg": "",
    //           "hdShareImg": "",
    //           "awardType": 1,
    //           "award": "",
    //           "shareFlag": 0,
    //           "countdown": 2,
    //           "classificationFlag": 0
    //       },
    //       "userInfo": {
    //           "headUrl": null,
    //           "nick": null,
    //           "ageType": 0,
    //           "isVip": 0,
    //           "isSvip": 0,
    //           "vipDays": 0,
    //           "svipDays": 0,
    //           "isVisitor": 1,
    //           "isJoin": 0,
    //           "turntableNumber": 1,
    //           "drawFlag": 0,
    //           "awardType": 0,
    //           "awardUrl": "",
    //           "awardName": "",
    //           "userId": 0,
    //           "isLifeVip": 0,
    //           "isLifeSvip": 0,
    //           "isReceived": 0,
    //           "isGiveVip": 1,
    //           "isOverUser": 0,
    //           "overUserInfo": null
    //       }
    //   },
    //   "code": 200
    // }
    // 异常情况，默认都显示未参数错误 44400
    let { code = 44400, msg = '', data } = responseInfo

    if (data) {
      let { userInfo, activityInfo } = data

      // mock
      // activityInfo.countdown = 2
      if (!userInfo) {
        data.userInfo = userInfo = {}
      }

      if (!activityInfo) {
        data.activityInfo = activityInfo = {}
      }

      const { endTime, startTime, currentTime } = activityInfo

      // 根据服务端返回数据生成计算状态
      if (currentTime < startTime) { // 活动未开始
        code = 5406
      } else if (currentTime >= endTime) { // 活动已经结束
        code = 5405
      }
      // 自然日24小时倒计时剩余时间计算
      // const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
      // const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
      let timerDeadline = endTime - currentTime
      if (isNaN(timerDeadline)) {
        timerDeadline = 0
      }

      // 计算活动结束时间，单位天
      const endRemainTime = Math.floor((endTime - currentTime) / 1000) * 1000
      const expireDays = isNaN(endRemainTime) ? 0 : Math.max(0, Math.ceil(endRemainTime / DAY_TIME))

      let computedStatus = 5

      const {
        isLifeSvip,
        isLifeVip,
        vipDays,
        isVip,
        isSvip,
        isVisitor,
        isJoin,
        drawFlag,
        isOverUser
      } = userInfo

      if (isVisitor) {
        computedStatus = 0
      }
      if ((isVip && vipDays >= 30)) {
        computedStatus = 1
      }
      if (isLifeVip) {
        computedStatus = 2
      }
      if (isSvip || isLifeSvip) {
        computedStatus = 3
      }

      if (isJoin) {
        computedStatus = 4
      }

      if (isOverUser === 0
        && Array.isArray(activityInfo.activityPart)
        && activityInfo.activityPart.some(p => p.type == 9)) {
        computedStatus = 7             //未参加续费活动，不是过期30天以内用户，且不是临期30天以内用户
      }

      activityInfo.expireDays = expireDays // 活动剩余天数
      activityInfo.expire = endRemainTime // 活动剩余毫秒数
      userInfo.computedStatus = computedStatus // 计算状态
      userInfo.timerDeadline = timerDeadline // 自然日剩余时长
      activityInfo.timer = {
        label: '活动仅剩',
        format: 'D天HH小时MM分SS秒'
      }
      // 每天倒计时
      if (activityInfo.countdown === 2) {
        // let now = new Date(currentTime)
        // let nextDay = new Date(`${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate() + 1}`)
        // userInfo.timerDeadline = nextDay.getTime() - currentTime

        const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
        const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
        const timerDeadline = todayLastTime - nowDate.getTime()
        userInfo.timerDeadline = timerDeadline

        activityInfo.timer = {
          label: '仅剩',
          format: 'HH小时MM分SS秒'
        }
      }
      activityInfo.isSvip = isSvip
      console.log('home执行：', activityInfo.countdown)
    }


    return {
      code,
      msg,
      data
    }
  } catch (error) {
    console.error('dataService Error: ', error)
  }

  return null
}



/**
 * 获取初始活动相关数据
 * @param {Object} options 相关配置
 * @param {String} options.activityKey 活动ID
 * @param {String} options.channelId 渠道ID
 */
export async function onInitPageData ({ activityKey, channelId } = {}) {
  const [isSupportOnlineService, isNewTabbarApp] = await Promise.all([hasSupportOnlineService(), hasNewTabbarApp()])

  context = new Context({
    activityKey,
    channelId,
    dataService: getDataService,
    parseViewData: (pageStatus, reponseBody) => {
      if (!reponseBody || reponseBody.code !== 200 || !reponseBody.data) {
        return null
      }

      const { activityInfo, userInfo } = reponseBody.data
      if (!activityInfo) {
        return null
      }

      if (!userInfo) {
        return null
      }
      // 解析活动原始配置
      parsedActivityRawConfig(activityInfo)
      // 更新页面配置
      updatePageConfig(pageConfig, context)
      let {shareTitle, shareSubTitle, shareImgUrl, shareJumpUrl, crc32Name, identityFlag} = activityInfo
      console.log('timerDeadline', userInfo.timerDeadline)
      return {
        activityKey, //活动编号
        expireDays: activityInfo.expireDays, // 距活动结束还有几天
        timerDeadline: userInfo.timerDeadline, // 自然日倒计时剩余时长
        // packageId: activityInfo.payInfoId || 0, // 默认购买礼包
        packageId: activityInfo.identityFlag === 0 ? activityInfo.jumpData : activityInfo.payInfoId,
        packageType: activityInfo.packageType || 6, // 支付类型
        identityFlag: activityInfo.identityFlag || 0, // 是否区分用户（用于用户跳转逻辑）
        jumpType: activityInfo.jumpType || 0, // 用户跳转类型
        jumpExtraData: activityInfo.jumpData || '', // 用户跳转额外信息 档位id，kada协议，小程序链接
        isSupportOnlineService, // 是否支持在线客服
        isNewTabbarApp, // 是否为新版界面App
        joinJumpUrl: activityInfo.joinJumpUrl, //已参加活动跳转
        shareData: {
          shareTitle,
          shareSubTitle,
          shareImgUrl,
          shareJumpUrl,
          crc32Name,
          identityFlag,
          canUseShare:  activityInfo.shareFlag === 1 // shareFlag: 1 可以分享，0不可以。
        },
        userInfo: userInfo,
        countdown: activityInfo.countdown, // 倒计时：1、最后三天倒计时；2、每天倒计时
        timer: activityInfo.timer,
        isSvip: activityInfo.isSvip
      }
    }
  })

  // 初始化页面配置
  initPageConfig(pageConfig, context)
  // 设置礼包购买逻辑上下文
  setContext(context)

  if (deviceInfo.wechat) {
    const openId = storage.get('openId')
    if (!openId) {
      await wxAuthLogin()
      return
    }
  }
  //调用ajax获取页面配置信息
  getPageData(false)

  return {
    context,
    pageConfig
  }
}


// 去领取书单
export async function gotoReceiveGift() {
  try {
    const responseInfo = await receiveGift()
    const { code } = responseInfo
    if (code !== 200) {
      throw new Error(responseInfo)
    }
    return true
  } catch (error) {
    console.error('receiveGift Error: ', error)
    return false
  }
}

/**
 * 去抽哦讲
 * @param {*} activityKey 活动编号
 */
export async function goDraw(activityKey) {
  return await draw(activityKey)
}

/**
 * 查看抽中奖品
 * @param {*} activityKey 活动编号
 * @returns
 */
export async function checkDrawDetail(activityKey) {
  return await drawDetail(activityKey)
}

/**
 * 去掉url中的newUser
 */
export function removeUrlParam(param) {
  const newUrl = location.href.replace(/(\?|&)*(newUser)=([^&=?#]+)/ig, '')
  if (history.replaceState) {
    history.replaceState(param, document.title, newUrl)
  } else {
    location.replace(newUrl)
  }
}
