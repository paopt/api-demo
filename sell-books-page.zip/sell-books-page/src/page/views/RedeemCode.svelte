<div class="redeemCode l-maxwidth">
  <img class="bg" src={wyExchangeImage} alt="">
  <div class="content">
    <div class="value">{redeemCode}</div>
    <div class="btn" on:click={copy}>
      <div class="bg3"></div>
      <div class="bg2"></div>
      <div class="bg1"></div>
      <div class="label">复制兑换码</div>
    </div>
  </div>
</div>

<script>
  import { showTypedDialog, DIALOG_TYPE, DIALOG_THEMES, toast, closeTypedDialog } from "@kada/svelte-activity-ui"
  import {router, navigateTo} from '@kada/yrv'
  import { onMount, onDestroy } from "svelte";
  import * as storage from '@/lib/storage'
  import { sendBehavior } from "@/shared/internal"

  // 兑换码
  let redeemCode
  // 底图
  let wyExchangeImage

  init()

  onDestroy(() => {
    closeTypedDialog()
  })

  function init() {
    // 从url获取兑换码
    redeemCode = $router.query.redeemCode
    if (!redeemCode) {
      showNoModal()
    }

    wyExchangeImage = storage.get('wyExchangeImage')

    console.log(wyExchangeImage)

    // sendBehavior(`ac_phone_log_view_${$router.query.activityKey}`)
  }

  /**
   * 兑换码已领完弹窗
   */
  function showNoModal() {
    showTypedDialog({
      type: DIALOG_TYPE.ENDED,
      theme: DIALOG_THEMES.NEW2021,
      title: '',
      message: '对应福利已领完，如有疑问请联系客服',
      buttonText: '我知道了',
      doneCloseDialog: true,
      maskClickHide: false,
      showCloseButton: false,
      onDone: () => {
        const params = {...$router.query}
        const activityKey = params.activityKey
        // 去掉多余的参数
        closeTypedDialog()
        Reflect.deleteProperty(params, 'redeemCode')
        Reflect.deleteProperty(params, 'activityKey')
        navigateTo(`/home/${activityKey}`, {queryParams: params})
      }
    })
  }

  /**
   * 复制兑换码
   */
   function copy() {
    const inputNode = document.createElement('input')
    inputNode.value = redeemCode
    document.body.appendChild(inputNode)
    inputNode.select()
    document.execCommand('copy')
    document.body.removeChild(inputNode)
    toast({
      text: '复制成功',
    })
  }

</script>

<style lang="scss" scoped>
  @import '../../styles/variables';
  @import '../../styles/mixins';
  //cdn.hhdd.com/frontend/as/f/4fb67841-e21d-5e8c-9df2-6a2054768718.ttf

  .redeemCode {
    position: relative;
    margin: 0 auto;

    .bg {
      width: 100%;
    }

    .content {
      position: absolute;
      top: 6.62rem;
      width: 100%;
    }

    .value {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 5.19rem;
      height: 1.02rem;
      margin: 0 auto;
      background: #FFF191;
      border-radius: 0.51rem;
      font-size: 34px;
      font-family: Alibaba PuHuiTi, FZLANTY_ZHONGCUJW--GB1;
      font-weight: 500;
      color: #6723C9;
    }

    .btn {
      position: relative;
      width: 5.16rem;
      height: 0.9rem;

      margin: 0.48rem auto 0 auto;
    }

    .bg1 {
      position: absolute;
      top: 0;
      width: 5.16rem;
      height: 0.45rem;
      background: #FFF2A6;
      opacity: 0.14;
      border-radius: 0.4rem;
    }
    .bg2 {
      position: absolute;
      top: 0;
      width: 5.16rem;
      height: 0.8rem;
      background: #FF5226;
      border-radius: 0.4rem;
    }

    .bg3 {
      position: absolute;
      top: 0.1rem;
      width: 5.16rem;
      height: 0.8rem;
      background: #DD1417;
      border-radius: 0.4rem;
    }

    .label {
      position: absolute;;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.32rem;
      font-family: Alibaba PuHuiTi, FZLANTY_ZHONGCUJW--GB1;
      font-weight: 500;
      color: #FFFFB0;
      text-shadow: 0 0.04rem 0.1rem rgba(221,20,23,0.8);
    }
  }
</style>
