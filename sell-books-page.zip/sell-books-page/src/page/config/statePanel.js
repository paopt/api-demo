import { deviceInfo } from '@kada/library/src/device'
import { mapSwitch } from '@/shared/utils/config-helper'
import { PAGE_STATUS } from './status'

export function getStatePanelCountdownConfig (config, options) {
  if (!config) {
    return
  }
  const { text } = config
  const context = options.context || {}
  const viewData = context?.viewData || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN
  const identityFlag = viewData?.identityFlag
  const isSvip = viewData?.isSvip
  
  const timerDeadline = +text
  // 默认最后三天倒计时
  let countdownConfig = {
    title: '活动仅剩',
    format: 'D天HH时MM分SS秒',
  }
  // 每天倒计时
  if (viewData?.countdown === 2) {
    countdownConfig = {
      title: '仅剩',
      format: 'HH时MM分SS秒',
    }
  }
  const showTimer = ([PAGE_STATUS.NORMAL, PAGE_STATUS.NOT_LOGIN, PAGE_STATUS.YEARVIP, PAGE_STATUS.OPENED_LIFEVIP].includes(pageStatus) || (isSvip === 1 && !identityFlag)) && timerDeadline >= 0
  console.log('showTimer', showTimer)
  return showTimer
    ? countdownConfig
    : {
      text: ''
    }
}

export function getStatePanelConfig (config, options) {
  if (!config) {
    return
  }
  const context = options.context || {}
  const viewData = context?.viewData || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN

  return {
    // 状态配置
    config: mapSwitch([
      [
        [PAGE_STATUS.NORMAL, PAGE_STATUS.NOT_LOGIN].includes(pageStatus),
        {
          button: {
            action: 'buyPackage',
            params: {
              packageIdType: 'packageIdLifevip',
            },
            style: `background: url(${config['canbuy']?.image.url}) no-repeat 50% 50% / 100% auto;`,
            className: 'ani-breath'
          }
        },
      ],
      [
        [PAGE_STATUS.BOUGHT_PACKAGE].includes(pageStatus),
        {
          button: {
            action: 'bought',
            style:  `background: url(${config['bought']?.image.url}) no-repeat 50% 50% / 100% auto`,
          },
        },
      ],
      [
        [PAGE_STATUS.YEARVIP, PAGE_STATUS.OPENED_LIFEVIP].includes(pageStatus),
        {
          button: {
            action: 'toVipCharge',
            style: `background: url(${config['upgrade']?.image.url}) no-repeat 50% 50% / 100% auto`,
            className: 'ani-breath',
          },
        },
      ],
      [
        [PAGE_STATUS.SUBVIP].includes(pageStatus),
        {
          button: {
            action: 'toRead',
            style: `background: url(${config['svip']?.image.url}) no-repeat 50% 50% / 100% auto`,
            className: 'ani-breath'  //SVIP状态支持呼吸效果
          },
        },
      ]
    ])
  }
}
