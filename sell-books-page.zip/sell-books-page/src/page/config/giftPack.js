export function getGiftPackConfig (configs) {
  if (!configs) {
    return
  }
  const { image, list, dataSource, wyExchangeImage } = configs
  return {
    image,
    list,
    dataSource,
    wyExchangeImage
  }
}
