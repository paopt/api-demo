export function getMarqueeConfig (config) {
  if (!config) {
    return
  }
  const { text = '已购买' } = config
  return {
    itemStyle: `
      border: 0.01rem solid #000;
      background: rgba(0, 0, 0, 0.7);
    `,
    packageName: text,
    dataSource: [
      {
        nickName: '轩**',
        avatar: '//image.hhdd.com/user/photo/cf7d11d8-ecf3-4581-b311-48e72f75f8fb.jpg',
        packageName: text
      },
      {
        nickName: '请**贝',
        avatar: '//image.hhdd.com/user/photo/0c7b46c6-0080-424c-a79c-6e4ba107b172.jpg',
        packageName: text
      },
      {
        nickName: '刀**神',
        avatar: '//image.hhdd.com/user/photo/ebd6baa4-961b-4652-ad7e-29f8883f8bca.jpg',

        packageName: text
      },
      {
        nickName: '美**渲',
        avatar: '//image.hhdd.com/user/photo/2f93ff4d-1a71-4471-a56f-39d813db6c6e.jpg',
        packageName: text
      },
      {
        nickName: '桐**',
        avatar: '//image.hhdd.com/user/photo/48f30d46-5528-43e1-ad93-95c9ac97e9ad.jpg',
        packageName: text
      },
      {
        nickName: '小**主',
        avatar: '//image.hhdd.com/user/photo/62748fc7-f69e-4139-98af-99fb0dedd801.jpg',
        packageName: text
      },
      {
        nickName: '李**岑',
        avatar: '//image.hhdd.com/user/photo/364eb7f1-af6a-44a8-afd0-dfb7e09bec85.jpg',
        packageName: text
      },
      {
        nickName: '王**皓',
        avatar: '//image.hhdd.com/user/photo/c0f94669-2211-47dd-8a8e-4274b3a26f40.jpg',
        packageName: text
      },
      {
        nickName: '姗姗5',
        avatar: '//image.hhdd.com/user/photo/3db3c3fa-b8b8-478d-a772-14954e3dc851.jpg',
        packageName: text
      },
      {
        nickName: '春*风',
        avatar: '//image.hhdd.com/user/photo/a85e3f29-9363-40ed-8d6e-f9a3368c7f6e.jpg',
        packageName: text
      },
      {
        nickName: '小*条',
        avatar: '//image.hhdd.com/user/photo/a59739b6-1d1c-4d78-9f09-0bffc5bb7820.jpg',
        packageName: text
      },
      {
        nickName: '爱**睿',
        avatar: '//image.hhdd.com/user/photo/6697a8e9-184c-479d-9593-6edbae9374ef.jpg',
        packageName: text
      },
      {
        nickName: '焖**瓶',
        avatar: '//image.hhdd.com/user/photo/504beaba-9347-4b95-95a1-a2c74ddf7343.jpg',
        packageName: text
      },
      {
        nickName: '大**家',
        avatar: '//image.hhdd.com/user/photo/e22563d1-4c94-4657-9236-2b3ddd815aa4.jpg',
        packageName: text
      },
      {
        nickName: '宝**',
        avatar: '//image.hhdd.com/user/photo/8b598cf8-a613-4324-a4fd-e1faaa4cec3c.jpg',
        packageName: text
      },
      {
        nickName: '依**',
        avatar: '//image.hhdd.com/user/photo/ab87ce48-0961-415a-9a6d-f4d60bd33a2e.jpg',
        packageName: text
      },
      {
        nickName: '嘉**',
        avatar: '//image.hhdd.com/user/photo/87246d9f-ca83-4afd-a12e-d0513950eaa6.jpg',
        packageName: text
      },
      {
        nickName: '颜**蕊',
        avatar: '//image.hhdd.com/user/photo/4d7140ef-9241-46cf-b19e-48d7a994cc4d.jpg',
        packageName: text
      },
      {
        nickName: '郭**源',
        avatar: '//image.hhdd.com/user/photo/8b249c26-bac0-4fbb-8160-8ae719b25442.jpg',
        packageName: text
      },
      {
        nickName: '土**',
        avatar: '//image.hhdd.com/user/photo/bb63f298-2f53-422e-b254-4086171fc99f.jpg',
        packageName: text
      },
      {
        nickName: '峻**',
        avatar: '//image.hhdd.com/user/photo/0babf935-9884-4a0b-af17-15796c6c75ca.jpg',
        packageName: text
      },
      {
        nickName: '哒**',
        avatar: '//image.hhdd.com/user/photo/ff054089-d4f7-46b4-9a1d-17ecaf4c2b13.jpg',
        packageName: text
      },
      {
        nickName: '雪**',
        avatar: '//image.hhdd.com/user/photo/1990f7ff-f126-4389-b298-941e87f53521.jpg',
        packageName: text
      },
      {
        nickName: '柠**',
        avatar: '//image.hhdd.com/user/photo/9e58e0d7-460f-4206-8f3b-41469d1dea0f.jpg',
        packageName: text
      },
      {
        nickName: '嘟**妈',
        avatar: '//image.hhdd.com/user/photo/3b0614f7-3149-4911-a46f-a3e6a09d6807.jpg',
        packageName: text
      },
      {
        nickName: '何**',
        avatar: '//image.hhdd.com/user/photo/9be9ea82-08d3-496b-b6ce-57d2637089b6.jpg',

        packageName: text
      },
      {
        nickName: '郭**',
        avatar: '//image.hhdd.com/user/photo/815c3113-e201-4256-92c1-e2e33e0571b5.jpg',

        packageName: text
      },
      {
        nickName: '可爱**',
        avatar: '//image.hhdd.com/user/photo/64df6d6a-a808-4b45-9eb7-d7f3b836a526.jpg',

        packageName: text
      },
      {
        nickName: '笑口**',
        avatar: '//image.hhdd.com/user/photo/6697a8e9-184c-479d-9593-6edbae9374ef.jpg',

        packageName: text
      },
      {
        nickName: '程**',
        avatar: '//image.hhdd.com/user/photo/504beaba-9347-4b95-95a1-a2c74ddf7343.jpg',

        packageName: text
      },
      {
        nickName: '胡*',
        avatar: '//image.hhdd.com/user/photo/e22563d1-4c94-4657-9236-2b3ddd815aa4.jpg',

        packageName: text
      },
      {
        nickName: '壮*',
        avatar: '//image.hhdd.com/user/photo/8b598cf8-a613-4324-a4fd-e1faaa4cec3c.jpg',

        packageName: text
      },
      {
        nickName: '孙慧*',
        avatar: '//image.hhdd.com/user/photo/ab87ce48-0961-415a-9a6d-f4d60bd33a2e.jpg',

        packageName: text
      },
      {
        nickName: '霖*',
        avatar: '//image.hhdd.com/user/photo/87246d9f-ca83-4afd-a12e-d0513950eaa6.jpg',

        packageName: text
      },
      {
        nickName: '李俐*',
        avatar: '//image.hhdd.com/user/photo/4d7140ef-9241-46cf-b19e-48d7a994cc4d.jpg',

        packageName: text
      },
      {
        nickName: '星*',
        avatar: '//image.hhdd.com/user/photo/8b249c26-bac0-4fbb-8160-8ae719b25442.jpg',

        packageName: text
      },
      {
        nickName: '收*',
        avatar: '//image.hhdd.com/user/photo/bb63f298-2f53-422e-b254-4086171fc99f.jpg',

        packageName: text
      },
      {
        nickName: '朱**',
        avatar: '//image.hhdd.com/user/photo/0babf935-9884-4a0b-af17-15796c6c75ca.jpg',

        packageName: text
      },
      {
        nickName: '皮*',
        avatar: '//image.hhdd.com/user/photo/ff054089-d4f7-46b4-9a1d-17ecaf4c2b13.jpg',

        packageName: text
      },
      {
        nickName: '爸爸*',
        avatar: '//image.hhdd.com/user/photo/1990f7ff-f126-4389-b298-941e87f53521.jpg',

        packageName: text
      },
      {
        nickName: 'Mich**',
        avatar: '//image.hhdd.com/user/photo/9e58e0d7-460f-4206-8f3b-41469d1dea0f.jpg',

        packageName: text
      },
      {
        nickName: '杨**言',
        avatar: '//image.hhdd.com/user/photo/3db3c3fa-b8b8-478d-a772-14954e3dc851.jpg',

        packageName: text
      },
      {
        nickName: '李**轩',
        avatar: '//image.hhdd.com/user/photo/a85e3f29-9363-40ed-8d6e-f9a3368c7f6e.jpg',

        packageName: text
      },
      {
        nickName: '贝**',
        avatar: '//image.hhdd.com/user/photo/a59739b6-1d1c-4d78-9f09-0bffc5bb7820.jpg',

        packageName: text
      },
      {
        nickName: 'l**g',
        avatar: '//image.hhdd.com/user/photo/3b0614f7-3149-4911-a46f-a3e6a09d6807.jpg',

        packageName: text
      },
      {
        nickName: '李**岭',
        avatar: '//image.hhdd.com/user/photo/5eafb59a-8a95-444f-84c8-51ba2eca3cd0.jpg',

        packageName: text
      },
      {
        nickName: '杨**童',
        avatar: '//image.hhdd.com/user/photo/9be9ea82-08d3-496b-b6ce-57d2637089b6.jpg',

        packageName: text
      },
      {
        nickName: '金**',
        avatar: '//image.hhdd.com/user/photo/815c3113-e201-4256-92c1-e2e33e0571b5.jpg',

        packageName: text
      },
      {
        nickName: '琪**',
        avatar: '//image.hhdd.com/user/photo/64df6d6a-a808-4b45-9eb7-d7f3b836a526.jpg',

        packageName: text
      },
      {
        nickName: '施**欣',
        avatar: '//image.hhdd.com/user/photo/fa102ee0-5728-4466-8560-8debc1e73cd2.jpg',

        packageName: text
      },
      {
        nickName: '天**网',
        avatar: '//image.hhdd.com/user/photo/8e731ac6-ea33-4258-aafe-b0478a7dc4db.jpg',

        packageName: text
      },
      {
        nickName: '静**',
        avatar: '//image.hhdd.com/user/photo/1a54c5d7-4f16-4251-ba9b-ce52dc0e5564.jpg',

        packageName: text
      },
      {
        nickName: '百**',
        avatar: '//image.hhdd.com/user/photo/af6bb7cd-dc8f-4892-b29b-b507def03833.jpg',

        packageName: text
      },
      {
        nickName: '玉**',
        avatar: '//image.hhdd.com/user/photo/cdf8cd78-80a5-4d9c-9096-8a9590969dfc.jpg',

        packageName: text
      }
    ]
  }
}
