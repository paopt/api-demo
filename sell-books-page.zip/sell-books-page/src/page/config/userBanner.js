export function getUserBannerConfig (config, options) {
  if (!config) return
  const userInfo = options?.context?.viewData?.userInfo
  config.userInfo = userInfo
  return config
}