import { formatDate } from '@kada/library/utils/datetime'
import { mapSwitch } from '@/shared/utils/config-helper'
import { PAGE_STATUS } from './status'
import { deviceInfo } from '@kada/library/src/device'
import {splitString} from '@/utils/math'
import {compressImage} from '@/utils/image'
import appConfig from '@/lib/config'

// const isHd = deviceInfo.ipad || deviceInfo.isPad || deviceInfo.isAndroidHD
const isHd = appConfig.isPad
const adaption = (n, rate = 1.33) => isHd ? (n * rate).toFixed(2) : n
const fontFamily = 'font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;' //字体样式
const subFontFamily = 'font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;'
const fontColorFC4F00 = 'color: #FC4F00;'   //字体颜色
const fontSize27 = `font-size: ${isHd ? 0.32 : 0.27}rem;`
const fontSize24 = `font-size: ${adaption(0.24)}rem;`
const fontSize32 = `font-size: ${adaption(0.32)}rem;`
const fontSize36 = `font-size: ${adaption(0.36)}rem;`
const fontSize20 = `font-size: ${adaption(0.2)}rem;`
const fontSize40 = `font-size: ${adaption(0.4)}rem;`
const lineHeight40 = `line-height: ${adaption(0.4, 1.1)}rem;`
const lineHeight30 = `line-height: ${adaption(0.3)}rem;`
const titlePaddingLeft = `padding-left: ${adaption(0.68)}rem;`
const fontSizeTitle = isHd ? 'font-size:0.3rem;' : 'font-size:0.23rem;'
const marginTop12 = `margin-top: ${adaption(0.12)}rem;`

const firstStatisticBg = [
  `padding-left:${adaption(0.6)}rem;height:${adaption(0.59)}rem;display: flex;align-items: center;background: left center/${adaption(0.4, 1.2)}rem ${adaption(0.42, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/86481f3c-c382-5cba-ac08-a55abb1d59a4.png);`,
  `padding-left:${adaption(0.64)}rem;height:${adaption(0.59)}rem;display: flex;align-items: center;background: left center/${adaption(0.44, 1.2)}rem ${adaption(0.4, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/88a1d2d6-9196-52f4-a8d6-1d9139ad2ac7.png);`,
  `padding-left:${adaption(0.62)}rem;height:${adaption(0.59)}rem;display: flex;align-items: center;background: left center/${adaption(0.42, 1.2)}rem ${adaption(0.42, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/99cda85c-9f6f-5a08-ad39-4189d6356416.png);`
]
const firstStatisticNm = `${fontSize40}${fontFamily}${fontColorFC4F00}`
const firstStatisticSuffix = `${fontSizeTitle}${subFontFamily}${fontColorFC4F00}`


const fontColor814616 = 'color: #814616;'
const secondStasticBg = [
  `padding-left:${adaption(0.68)}rem;background: left center/${adaption(0.48, 1.2)}rem ${adaption(0.36, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/48301a47-e04a-5c47-b667-009a6ce90d62.png);`,
  `padding-left:${adaption(0.64)}rem;background: left center/${adaption(0.42, 1.2)}rem ${adaption(0.42, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/ef0ca9a8-83c8-5a6e-a62b-dd80f1482f59.png);`,
  `padding-left:${adaption(0.62)}rem;background: left center/${adaption(0.42, 1.2)}rem ${adaption(0.42, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/684b2278-d444-5f50-891c-e0ca589e6655.png);`
]

const thirdStaticBg = [
  `padding-left:${adaption(0.66)}rem;background: left center/${adaption(0.46, 1.2)}rem ${adaption(0.46, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/c61657b3-fe8c-5a89-b139-d0e1d11878d5.png);`,
  `padding-left:${adaption(0.64)}rem;background: left center/${adaption(0.44, 1.2)}rem ${adaption(0.44, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/ae701c86-4a1e-5cd3-9e83-270a98125616.png);`,
  `padding-left:${adaption(0.64)}rem;background: left center/${adaption(0.44, 1.2)}rem ${adaption(0.4, 1.2)}rem no-repeat url(//cdn.hhdd.com/frontend/as/i/88a1d2d6-9196-52f4-a8d6-1d9139ad2ac7.png);`
]

const titleStyle = fontSizeTitle + fontColor814616 + subFontFamily
const subTitleStyle = fontSizeTitle + lineHeight40 + fontColorFC4F00 + subFontFamily
const valueStyle = fontSize40 + fontFamily

const barXaxis = [{ type: 'category', splitLine:{show: false}, data: ['阅读天数', '阅读数量', '识字量/万'], axisLabel: {fontSize: '8'}, axisLine: {show: false}, axisTick: {show: false}}]
const barYaxis = [{ splitLine:{show: false}, type: 'value', show: false }]
const barGrid = { left: '0', right: '0', top: '30%'}
/**
 * 续费活动头图
 * @param {*} config
 */
export function getRenewBannerConfig(config, options) {
  if (!config) {
    return
  }
  const context = options.context || {}
  const viewData = context?.viewData || {}
  const userInfo = viewData?.userInfo || {}
  const overUserInfo = userInfo?.overUserInfo || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN
  const {isJoin} = userInfo
  const {imageUrl, buyButtonUrl, buyAfterButtonUrl, id} = config
  const {
    headImg,
    nickName,
    totalReadDays = 0,
    totalReadBooks = 0,
    startTime,
    joinReadPlans = 0,
    readPlanLink = 0,
    readSubjectOne,
    readSubjectTwo,
    mostLikeCollectId,
    recentOpenApp,
    recentMonthReadTime,
    recentMonthReadBooks,
    mostLikeCollectName,
    mostLikeCollectRecommend,
    mostLikeCollectImgUrl,
    days = 0 } = overUserInfo


  // 根据配置获取组件信息
  const info = getReadInfo(overUserInfo)
  let bannerConfig = {
    id,
    backgroundImg: compressImage(imageUrl) || '//cdn.hhdd.com/frontend/as/i/da8ab39c-f2c1-52db-8efe-3fcbc0fb6b77.png?x-oss-process=image/quality,q_80/format,png',
    awardUrl: headImg || 'https://image.hhdd.com/activity/offline/cover/d04aeb737661473c8ad73950e1771eaa.png',
    scholarship: 30,
    userName: splitString(nickName, 10) || 'KaDa小读者',
    title: info.title,
    titleIcon: info.titleIcon,
    days,
    startTime,
    //购买按钮
    button: mapSwitch([
      //引导下单
      [
        [PAGE_STATUS.NORMAL, PAGE_STATUS.NOT_LOGIN].includes(pageStatus) || isJoin == 0,
        {action: 'buyPackage', imgUrl: compressImage(buyButtonUrl), className: 'ani-breath'}
      ],
      [
        [PAGE_STATUS.BOUGHT_PACKAGE].includes(pageStatus),
        {action: 'bought', imgUrl: compressImage(buyAfterButtonUrl)}
      ],
      [
        [PAGE_STATUS.SUBVIP, PAGE_STATUS.ISOVER_USER].includes(pageStatus),
        {action: 'toRead', imgUrl: compressImage(buyAfterButtonUrl)}
      ]
    ]),
    //swipler-slide-1
    content: [
      {
        name: 'slide-first',
        title: `<span style="${fontFamily} ${fontColorFC4F00}">${getStartDate(startTime)}</span>成为会员,你已累计阅读`,
        statistic: [
          `<div style="${firstStatisticBg[0]}">
            <span style="${firstStatisticNm}">${totalReadDays}<span style="${firstStatisticSuffix}">天</span>
            </span>
          </div>`,
          `<div style="${firstStatisticBg[1]}"">
            <span style="${firstStatisticNm}">${totalReadBooks}<span style="${firstStatisticSuffix}">本书</span>
            </span>
          </div>`,
          `<div style="${firstStatisticBg[2]}">
            <span style="${firstStatisticNm}">${info.totalFonts}<span style="${firstStatisticSuffix}">万字</span>
            </span>
          </div>`
        ],
        desc: info.desc,
        echartOption: info.echartOption,
      }
    ]
  }
  //swiper-slider-2
  if (joinReadPlans > 0) {
    bannerConfig.content.push(
      {
        name: 'slide-second',
        title: `365天阅读训练营,你已累计学习`,
        statistic: [
          `<div style="${secondStasticBg[0]}">
            <div style="${titleStyle}">阅读训练</div>
            <div style="${subTitleStyle}">
              <span style="${valueStyle}">${joinReadPlans}</span>周
            </div>
          </div>`,
          `<div style="${secondStasticBg[1]}">
            <div style="${titleStyle}">主题学习</div>
            <div style="${subTitleStyle}">
              <span style="${valueStyle}">${joinReadPlans}</span>个
            </div>
          </div>`,
          `<div style="${secondStasticBg[2]}">
            <div style="${titleStyle}">互动学习</div>
            <div style="${subTitleStyle}">
              <span style="${valueStyle}">${readPlanLink}</span>次
            </div>
          </div>`
        ],
        desc: [
          `<div style="${fontFamily} ${lineHeight40}">已经学习</div>`,
          readSubjectOne ? `<div style="${fontColorFC4F00}${fontFamily} ${lineHeight40}">${readSubjectOne}</div>` : '',
          readSubjectTwo ? `<div style="${fontColorFC4F00}${fontFamily} ${lineHeight40}">${readSubjectTwo}</div>` : '',
          `<div style="${fontFamily} ${lineHeight40}">等${joinReadPlans}个主题</div>`,
          `<div style="${fontFamily}${lineHeight40}${marginTop12}">${joinReadPlans >= 4 ? '以读促写，你的阅读能力、表达能力已远超同龄人' : '继续学习，你的阅读能力、表达能力一定会远超同龄人'}!</div>`
        ],
        //雷达图
        echartOption: {
          radar: {
            indicator: [{ name: '阅读力', max: 550 }, { name: '理解力', max: 1600 }, { name: '表达力', max: 3000 }, { name: '思维力', max: 3800 }, { name: '认知力', max: 5200 }],
            nameGap : 2,
            center:['50%','35%'],
            radius: '55%',
          },
          series: [{type: 'radar', data: [{value: [420, 1280, 2000, 3500, 5000]}]}]
        }
      }
    )
  }
  //swiper-slider-3
  if (recentMonthReadBooks >= 6 && mostLikeCollectId > 0) {
    bannerConfig.content.push(
      {
        name: 'slide-third',
        title: `最近<span style="${fontColorFC4F00} ${fontFamily}">一个月</span>,你依然常用KaDa`,
        statistic: [
          `<div style="${thirdStaticBg[0]}">
            <div style="${titleStyle}">累计使用</div>
            <div style="${subTitleStyle}">
              <span style="${valueStyle}">${recentOpenApp}</span>次
            </div>
          </div>`,
          `<div style="${thirdStaticBg[1]}">
            <div style="${titleStyle}">阅读时长</div>
            <div style="${subTitleStyle}">
              <span style="${valueStyle}">${recentMonthReadTime}</span>分钟
            </div>
          </div>`,
          `<div style="${thirdStaticBg[2]}">
            <div style="${titleStyle}">新读书籍</div>
            <div style="${subTitleStyle}">
              <span style="${valueStyle}">${recentMonthReadBooks}</span>本书
            </div>
          </div>`
        ],
        desc: [
          `<div style="${fontSize27}${fontFamily}${lineHeight40}">最近，你<span style="${fontColorFC4F00}${fontFamily}">最爱读的书</span>是：</div>`,
          `<div style="${fontSize27}${fontColorFC4F00}${fontFamily}${lineHeight40}">《${splitString(mostLikeCollectName, 16)}》</div>`,
          `<div style="${fontSize20}${fontColor814616}${lineHeight40}">“${splitString(mostLikeCollectRecommend, 25)}”</div>`,
          `<div style="${fontSize27}${fontFamily}${lineHeight40}${marginTop12}">这本书一定让你受益颇多, </div>`,
          `<div style="${fontSize27}${fontFamily}${lineHeight40}">和爸爸妈妈分享一下吧!</div>`
        ],
        bookImg: compressImage(mostLikeCollectImgUrl)
      }
    )
  }

  return bannerConfig
}

//swipler-slide-1
const getReadInfo = data => {
  let info = {}
  const {totalReadBooks = 0, totalReadDays = 0, fonts = 0} = data
  // 阅读字数
  info.totalFonts = Math.trunc(fonts / 10000)

  if (totalReadBooks >= 100) {
    info.title = '小博士'
    info.titleIcon = '//cdn.hhdd.com/frontend/as/i/a4f43ce8-ba92-5b10-b119-5cb37931d9ce.png'
    info.desc = [
      `你的阅读量`,
      `超越了<span style="${fontColorFC4F00}${fontSize36}${fontFamily}">95%</span>的同龄人!`,
      `累计阅读${info.totalFonts}万字`,
      `<span style="${fontSize20}${lineHeight40}">已达新课标<span style="${fontColorFC4F00}">3-4</span>年级阅读量标准(40万字)</span>`,
      `<div style="${fontFamily}">获得<span style="${fontFamily}">"阅读小博士"</span>称号</div>`
    ]
    info.echartOption = {
      grid: barGrid,
      color: ['#BEBEBE', '#FFBD2B'],
      legend: {orient: 'horizontal', x: 'right', textStyle: {color: '#BEBEBE', fontSize: 10}, itemWidth: 8, itemHeight: 8, data: ['普通用户', '当前用户']},
      xAxis: barXaxis,
      yAxis: barYaxis,
      series: [
        {
          name: '普通用户',
          type: 'bar',
          data: [
            {value: 60, itemStyle: { color: '#BEBEBE' }},
            {value: 80, itemStyle: { color: '#BEBEBE' }},
            {value: 12, itemStyle: { color: '#BEBEBE' }}
          ]
        },
        {
          name: '当前用户',
          type: 'bar',
          data: [
            {value: totalReadDays, itemStyle: { color: '#FFBD2B' }},
            {value: totalReadBooks, itemStyle: { color: '#FFBD2B' }},
            {value: info.totalFonts, itemStyle: { color: '#FFBD2B' }}
          ],
          markPoint: {
            data: [
              {coord: [0, totalReadDays], value: totalReadDays, itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}},
              {coord: [1, totalReadBooks], value: totalReadBooks, itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}},
              {coord: [2, info.totalFonts], value: info.totalFonts, itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}}
            ]
          }
        }
      ]
    }
  } else if (totalReadBooks >= 26 && totalReadBooks < 100) {
    info.title = '小学士'
    info.titleIcon = '//cdn.hhdd.com/frontend/as/i/a4f43ce8-ba92-5b10-b119-5cb37931d9ce.png'
    info.desc = [
      `你的阅读量`,
      `超越了<span style="${fontColorFC4F00} ${fontSize36}">83%</span>的同龄人!`,
      `累计阅读${info.totalFonts}万字`,
      `<span style="${fontSize20}">已达新课标<span style="${fontColorFC4F00}">1-2</span>年级阅读量标准</span>`,
      `<span style="${fontSize20} ${fontColorFC4F00}">(5万字)</span>`,
      `获得<span style="${fontFamily}">"阅读小学士"</span>称号`
    ]
    info.echartOption = {
      grid: barGrid,
      color: ['#FFBD2B'],
      legend: {orient: 'horizontal', x: 'right', textStyle: {color: '#BEBEBE', fontSize: 10}, itemWidth: 8, itemHeight: 8, data: ['当前用户']},
      xAxis: barXaxis,
      yAxis: barYaxis,
      series: [
        {
          name: '当前用户',
          type: 'bar',
          data: [
            {value: totalReadDays, itemStyle: { color: '#FFBD2B' }},
            {value: totalReadBooks, itemStyle: { color: '#FFBD2B' }},
            {value: info.totalFonts, itemStyle: { color: '#FFBD2B' }}
          ],
          markPoint: {
            data: [
              {coord: [0, totalReadDays], value: totalReadDays, itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}},
              {coord: [1, totalReadBooks], value: totalReadBooks, itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}},
              {coord: [2, info.totalFonts], value: info.totalFonts, itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}}
            ]
          }
        }
      ]
    }
  } else {
    info.title = '新芽'
    info.titleIcon = '//cdn.hhdd.com/frontend/as/i/84786146-a957-506b-a69b-0f3cd6809564.png'
    info.desc = [
      `KaDa会员年均阅读<span style="${fontSize36} ${fontColorFC4F00}">300</span>本`,
      `<span style="${fontSize20}">累计阅读<span style="${fontColorFC4F00}">45</span>万字</span>`,
      `“书山有路勤为径”`,
      `冲击年读300本,继续加油吧!`
    ]
    info.echartOption = {
      grid: barGrid,
      color: ['#FFBD2B'],
      legend: {orient: 'horizontal', x: 'right', textStyle: {color: '#BEBEBE', fontSize: 10}, itemWidth: 8, itemHeight: 8, data: ['目标阅读量']},
      xAxis: barXaxis,
      yAxis: barYaxis,
      series: [
        {
          type: 'bar',
          name: '目标阅读量',
          data: [
            {value: 200, itemStyle: { color: '#FFBD2B' }},
            {value: 300, itemStyle: { color: '#FFBD2B' }},
            {value: 45, itemStyle: { color: '#FFBD2B' }}
          ],
          markPoint: {
            data: [
              {coord: [0, 200], value: 200, itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}},
              {coord: [1, 300], value: 300, itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}},
              {coord: [2, 45], value: '45', itemStyle: {color: '#FFBD2B'}, label: {color: '#FFFFFF', fontSize: 10}}
            ]
          }
        }
      ]
    }
  }

  return info
}

//转化时间
const getStartDate = time => {
  let date = formatDate(time, 'YYYY-MM-DD').split('-')
  return `${date[0]}年${date[1]}月${date[2]}日`
}
