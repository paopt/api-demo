import { formatDate } from '@kada/library/utils/datetime'
import { mapSwitch } from '@/shared/utils/config-helper'
import { PAGE_STATUS } from './status'
import { deviceInfo } from '@kada/library/src/device'
import {compressImage} from '@/utils/image'

export function getMemberBannerConfig (config, options) {
  if (!config) return
  
  const {
    buyHeadUrl,
    buyButtonUrl,
    buyAfterButtonUrl,
    bubbleButtonUrl,
    priceFontsColor,
    payInfoId,
    originPrice,
    realPrice
  } = config

  const context = options.context || {}
  const viewData = context?.viewData || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN

  const userInfo = viewData?.userInfo || {}
  const overUserInfo = userInfo?.overUserInfo || {}
  const {isJoin} = userInfo

  // 更新全局packageId
  context.packageId = payInfoId
  viewData.packageId = payInfoId

  const button = mapSwitch([
    [
      [PAGE_STATUS.NORMAL, PAGE_STATUS.NOT_LOGIN].includes(pageStatus) || isJoin == 0,
      {
        action: 'buyPackage',
        imgUrl: compressImage(buyButtonUrl),
        className: 'ani-breath',
      }
    ],
    [
      [PAGE_STATUS.BOUGHT_PACKAGE].includes(pageStatus),
      {
        action: 'bought',
        imgUrl: compressImage(buyAfterButtonUrl),
        className: '',
      }
    ]
  ])

  console.log('当前页面状态：', pageStatus)

  return {
    buyHeadUrl: buyHeadUrl,
    bubbleButtonUrl: bubbleButtonUrl,
    showBubble: button?.action === 'buyPackage' && bubbleButtonUrl, // 未购买用户且配置了气泡，才显示气泡
    showPrice: button?.action === 'buyPackage',
    button,
    style: `color: ${priceFontsColor}`,
    payInfoId,
    originPrice: originPrice / 100,
    realPrice: realPrice / 100,
    discount: (originPrice - realPrice) / 100
  }
}