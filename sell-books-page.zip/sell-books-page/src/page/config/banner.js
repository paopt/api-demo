export function getBannerConfig (config) {
  if (!config) {
    return
  }
  const { image } = config
  return {
    image: image
  }
}
