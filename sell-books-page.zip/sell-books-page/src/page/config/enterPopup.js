
//进入页面弹框
export function getEnterPopupConfig(config, options) {
  if (!config) {
    return
  }
  return config
}
