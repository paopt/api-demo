// 页面状态枚举
export const PAGE_STATUS = {
  UNKNOWN: 'unknown', // 未知状态
  NETWORK_ERROR: 'networkError', // 网络错误
  ACTIVITY_NOT_START: 'activityUnstart', // 活动未开始
  ACTIVITY_ENDED: 'activityEnded', // 活动已过期
  ACTIVITY_NOT_FOUND: 'activityNotFound', // 活动未找到
  USER_NOT_FOUND: 'userNotFound', // 用户未找到
  NOT_LOGIN: 'notLogin', // 用户未登录
  TIME_ENDED: 'timeEnded', // 当日倒计时已结束
  NORMAL: 'normal', // 可以正常购买的状态
  OPENED: 'openedYearvip', // 档位页已经开通年卡会员30天内
  YEARVIP: 'yearvip', // 年卡vip
  OPENED_LIFEVIP: 'openedLifevip', // 已经开通终身会员
  LIFEVIP: 'openedLifevip', // 是终身会员
  BOUGHT_PACKAGE: 'boughtPackage', // 已参加活动
  RECEIVED: 'received', // 已领取
  SUBVIP: 'subvip', // 听书或绘本子会员
  DRAWED: 'drawed', // 已抽奖
  ISOVER_USER: 'isOverUser',  //未参加续费活动不是过期30天以内用户，且不是临期30天以内用户进入活动
}
