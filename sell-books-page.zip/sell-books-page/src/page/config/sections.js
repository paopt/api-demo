import { ACTIVITY_COMPONENT_MAP_TYPE, COMPONENT_CONFIG_MAP_TYPE } from '../app'
export function getSectionsConfig (configs, options) {
  if (!configs) {
    return
  }
  const sections = configs

  sections.forEach(item => {
    // 用户信息组件，需要用户信息
    if (item.type === COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.USER_BANNER]) {
      item.userInfo = options?.context?.viewData?.userInfo
    }
  })
  return {
    dataSource: sections.sort((a, b) => a.sort - b.sort)
  }
}
