import { deviceInfo } from '@kada/library/src/device'
import { mapSwitch } from '@/shared/utils/config-helper'
import { PAGE_STATUS } from './status'
import appConfig from '@/lib/config'

export function getFooterBarConfig (config, options) {
  if (!config) {
    return
  }
  const context = options.context || {}
  const viewData = context?.viewData || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN
  return {
    // footerBar内部配置
    config: mapSwitch([
      [
        [PAGE_STATUS.NORMAL, PAGE_STATUS.NOT_LOGIN].includes(pageStatus),
        {
          button: {
            action: 'buyPackage',
            className: appConfig.isPad ? '' : 'ani-breath2',
            type: 'html',
            content: `<img src="${config['canbuy']?.image.url}" />`
          }
        },
      ],
      [
        [PAGE_STATUS.YEARVIP, PAGE_STATUS.OPENED_LIFEVIP].includes(pageStatus),
        {
          button: {
            action: 'toVipCharge',
            className: appConfig.isPad ? '' : 'ani-breath2',
            type: 'html',
            content: `<img src="${config['upgrade']?.image.url}" />`
          },
        },
      ],
      [
        [PAGE_STATUS.SUBVIP].includes(pageStatus),    //底部SVIP用户按钮展示，和中间按钮样式，功能相同
        {
          button: {
            action: 'toRead',                     //和中间按钮保持一致
            className: 'ani-breath2',
            type: 'html',
            content: `<img src="${config['svip']?.image.url}" />`
          }
        }
      ]
    ], null)
  }
}
