<!-- 获得抽奖机会弹框 -->
<Popup class="c-drawchancedlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-drawchancedlg__body" on:touchmove|stopPropagation|preventDefault>
    <div class="btn-go-draw" on:click={close}></div>
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  import { getAnalyticsIdByName } from '@/shared/scheme/page-config'
  import { sendBehavior } from "@/shared/internal"
  const dispatch = createEventDispatcher()
  //组件样式
  let className = ''
  export { className as class }

  //是否支持点击mask关闭弹窗
  export let maskClickHide = false

  //点击关闭按钮回调
  export let onClose = null

  let popupEl

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  let guideDrawDialog = getAnalyticsIdByName('dialog.guideDrawDialog')

  function close() {
    sendBehavior(guideDrawDialog.click)
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  onMount(() => {
    popupEl && popupEl.show()
    sendBehavior(guideDrawDialog.view)
  })

  onDestroy(() => {

  })
</script>

<style lang="scss" scoped>
  $component-name: 'c-drawchancedlg';

  :global {
    .#{$component-name} {
      z-index: 999;
      &__body {
        position: relative;
        width: 5.89rem;
        height: 8.28rem;
        top: -0.4rem;
        background: url('//cdn.hhdd.com/frontend/as/i/3cf30fed-57ca-515d-9db1-576f39e28ba8.png') no-repeat 50% 0 / 100% 100%;
        z-index: 999;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        align-items: center;
        .btn-go-draw {
          width: 4.11rem;
          height: 1.41rem;
          background: url('//cdn.hhdd.com/frontend/as/i/53d9bc73-15d7-552c-a451-e861b6caf0f8.png');
          background-size: 100%;
          background-position: center;
          background-repeat: no-repeat;
          margin-bottom: 0.12rem;
        }
      }
    }
  }
</style>
