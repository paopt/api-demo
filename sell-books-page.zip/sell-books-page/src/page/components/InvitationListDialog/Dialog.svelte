<Popup class="c-invitationdlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-invitationdlg__body" on:touchmove|stopPropagation|preventDefault bind:this={bodyEl}>

    <div class="c-invitationdlg__content" bind:this={contentEl}>
       {#if dataSource.length === 0}
         <p class="c-invitationdlg__empty fzlty">亲亲，您当前还没有成功邀<br>请的用户哦，快去邀请吧~</p>
       {:else}
        <table class="c-invitationdlg__table">
          <tr class="header" >
            <th>被邀请人ID</th>
            <th>奖励</th>
          </tr>
          {#each dataSource as item}
            <tr class="content">
              <td>{item.inviteeUserId}</td>
              <td>+{item.award}元</td>
            </tr>
          {/each}

        </table>
       {/if}
    </div>

    <div class="c-invitationdlg__footer">
      <button class="c-invitationdlg__btn c-invitationdlg__btn-withdraw" on:click={handleWithDrawClick}></button>
      <button class="c-invitationdlg__btn c-invitationdlg__btn-invite" on:click={handleGotoInviteClick}></button>
    </div>
    <div class="close" on:click={close}></div>
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import IScroll from 'iscroll/build/iscroll-lite'
  import { Popup } from '@kada/svelte-activity-ui'
  import { promiseDelay } from '@/utils/promisify'
  import { getAnalyticsIdByName } from '@/shared/scheme/page-config'
  import { sendBehavior } from "@/shared/internal"

  const dispatch = createEventDispatcher()
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }


  export let dataSource = []


  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = false

  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  export let onWithDraw = null
  export let onGotoInvite = null


  let popupEl
  // 活动规则弹窗滚动内容
  let bodyEl
  // 内容模块
  let contentEl
  // 内容区域滚动示例
  let contentScroll

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  //打点信息
  let inviteListDialog = getAnalyticsIdByName('dialog.inviteListDialog')

  function close() {
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  function handleWithDrawClick () {
    if (typeof onWithDraw === 'function') {
      onWithDraw()
    }
  }

  function handleGotoInviteClick () {
    sendBehavior(inviteListDialog.click)
    if (typeof onGotoInvite === 'function') {
      onGotoInvite()
    }
  }

  onMount(() => {
    sendBehavior(inviteListDialog.view)
    popupEl && popupEl.show()
    promiseDelay(600).then(() => {
      if (!contentScroll && contentEl) {
        contentScroll = new IScroll(contentEl, {
          disablePointer: false,
          click: true,
          scrollY: true,
          scrollX: false,
          disableMouse: true,
          bindToWrapper: true
        })
      }

      if (contentScroll) {
        contentScroll.refresh()
      }
    })
  })

  onDestroy(() => {
    if (contentScroll) {
      contentScroll.destroy()
      contentScroll = null
    }
  })
</script>

<style lang="scss">
  @import "../../../styles/variables";
  $component-name: 'c-invitationdlg';

  :global {
    .#{$component-name} {
      z-index: 999;
      &__body {
        position: absolute;
        width: 6.46rem;
        height: 9.18rem;
        top: 1rem;
        background: url('//cdn.hhdd.com/frontend/as/i/3938ed2c-863e-5f6e-9020-82a265f3dab8.png') no-repeat 50% 0 / 100% 100%;
        font-family: PingFangSC-Medium,PingFang SC;
        z-index: 999;
        // @media #{$pad_landscape_query} {
        //   top: 1.8rem;
        // }
        .close {
          position: absolute;
          width: 0.9rem;
          height: 0.9rem;
          left: 50%;
          bottom: -1.2rem;
          margin-left: -0.45rem;
          background: {
            repeat: no-repeat;
            position: 50% 50%;
            size: 100% 100%;
            image: url('//cdn.hhdd.com/frontend/as/i/ce360163-bc41-5954-9b20-732b2503e620.png');
          }
          z-index: 99;
        }
      }

      &__content {
        position: absolute;
        top: 3.42rem;
        left: 0.35rem;
        right: 0.35rem;
        bottom: 0;
        font-size: 0.3rem;
        font-weight: 400;
        color: #7F584C;
        line-height: 0.46rem;
        overflow: hidden;
        padding: 0.05rem 0.5rem 0.05rem;
        max-height: 4.25rem;

        > div {
          height: max-content;
          background: rgba(0, 0, 0, 0);
        }
      }
      &__empty {
        width: 4.08rem;
        margin: auto;
        text-indent: 0.32rem;
        color: #f86838;
        font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
      }

      &__table {
        width: 100%;
        margin: 0 auto;
        text-align: center;
        &, th, td {
          border: 0.02rem #f6e7bb solid;
          border-collapse: collapse;
          font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
        }

        th, td {
          padding: 0.2rem;
        }
        .header {
          th {
            background-color: #ff8526;
            color: white;
            padding-top: 0.25rem;
            border: none;
          }
          th:first-child {
            border-top-left-radius: 0.2rem;
          }
          th:last-child {
            border-top-right-radius: 0.2rem;
          }
        }
        .content {
          background-color: #fff;
          color: #f86838;

        }
      }

      &__footer {
        position: absolute;
        bottom: 0.38rem;
        left: 0;
        width: 6.46rem;
        right: 0;
        margin: auto;
        display: flex;
        justify-content: center;
        align-content: center;
        align-items: center;
      }
      &__btn {
        width: 2.88rem;
        height: 0.95rem;
        background: transparent;
        &:active {
          background-color: rgba(255, 255, 255, 0.1);
          border-radius: 0.7rem;
        }
      }
    }
  }
</style>
