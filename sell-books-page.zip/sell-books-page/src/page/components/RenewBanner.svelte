<div
  class="c-renewbanner"
  style={`background-image:url(${renewBannerConfig?.backgroundImg})`}
  bind:this={panelEl}>
  <div class="content">
    <div class="header">
      <!-- <div class="scholarship">
        续费最高可抵<span>{renewBannerConfig?.scholarship}元</span>
      </div> -->
      <img src="{renewBannerConfig.awardUrl}" class="award" alt="">
      <div class="header-tip">恭喜 <span>{renewBannerConfig.userName}</span> 荣获</div>
      <img class="header-title" alt="titilIcon" src={renewBannerConfig.titleIcon}/>
    </div>
    <div class="swiper-div">
      <!-- autoplay={{ delay: 2000, disableOnInteraction: false }}
      on:slideChange={e => handleSlideChange(e)} -->
      <Swiper
        modules={[ Pagination, Zoom, Autoplay]}
        loop={true}
        spaceBetween={0}
        slidesPerView={"auto"}
        zoom={true}
        autoplay={{ delay: 2000, disableOnInteraction: false }}
        pagination={{ clickable: true, bulletClass: 'swiper-pagination-bullet'}}
        on:swiper={setSwiperRef}
        bind:this={swiperEl}>
        {#each renewBannerConfig.content as content, i}
          <SwiperSlide class="swipers-slides">
            <!-- 标题 -->
            <div class="title">{@html content.title}</div>
            <!-- 统计信息 -->
            <div class="statistic">
              {#each content.statistic as s}
                {@html s}
              {/each}
            </div>
            <div class="hr"></div>
            <!-- 描述 -->
            <div class="desc">
              <!-- 描述 -->
              <div class="desc-text">
                {#each content.desc as d}
                  <div class="text">{@html d}</div>
                {/each}
              </div>
              {#if content.name == 'slide-first'}
                <!-- 图表 -->
                <div class="desc-chart-first"></div>
              {/if}
              {#if content.name == 'slide-second'}
                <!-- 图表 -->
                <div class="desc-chart-second"></div>
              {/if}
              {#if content.name == 'slide-third'}
                <!-- 图表 -->
                <div class="desc-chart-third">
                  <img src="{content.bookImg}" alt="">
                </div>
              {/if}
            </div>
          </SwiperSlide>
        {/each}
      </Swiper>
    </div>
  </div>
  <div class="o-home__panel swiper-bottom" id="mainBtn">
    <img
      alt=""
      class={["btn-buy", renewBannerConfig?.button?.className || ''].join(" ")}
      src="{renewBannerConfig?.button?.imgUrl}"
      on:click={handleButtonClick(renewBannerConfig?.button?.action)}
      on:load={handleButtonLoad(renewBannerConfig?.button?.action)}/>
      <!-- 倒计时 -->
      <slot name="timmer"></slot>
  </div>
</div>

<script>
  import { onMount, tick, onDestroy, createEventDispatcher } from "svelte"
  import {Pagination, Scrollbar, Zoom, Autoplay} from 'swiper'
  import {Swiper, SwiperSlide} from 'swiper/svelte'
  import 'swiper/css'
  import 'swiper/css/navigation'
  import 'swiper/css/pagination'
  import 'swiper/css/scrollbar'
  import "swiper/css/zoom"
  import Timer from '@/components/Timer.svelte';

  //按需引入echart
  // import * as echarts from 'echarts/core'
  // import {BarChart} from 'echarts/charts'
  // import {TitleComponent, LegendComponent, GridComponent, DatasetComponent, TransformComponent} from 'echarts/components'
  // import {LabelLayout, UniversalTransition} from 'echarts/features'
  // import {CanvasRenderer} from 'echarts/renderers'
  // echarts.use([ TitleComponent, LegendComponent, GridComponent, DatasetComponent, TransformComponent, BarChart, LabelLayout, UniversalTransition, CanvasRenderer ])
  import * as echarts from 'echarts'

  const dispatch = createEventDispatcher()

  let panelEl
  let swiperEl

  export let renewBannerConfig = null
  export let index = 0

  /**
   * 获取组件位置信息
   *
   * @returns {Rectangle}
   */
   export function getBoundingClientRect () {
    return panelEl ? panelEl.getBoundingClientRect() : null
  }

  const setSwiperRef = ({ detail }) => {
    const [swiper] = detail
    setTimeout(() => {
      swiperEl = swiper
      swiperEl.slideTo(index)
    })
  }

  onMount(() => {
    tick().then(() => {
      const firstEchart = document.getElementsByClassName('desc-chart-first')
      let chart = null
      for (const item of firstEchart) {
        chart = echarts.init(item)
        chart.setOption(renewBannerConfig.content[0].echartOption)
      }

      const secondEchart = document.getElementsByClassName('desc-chart-second')
      let radar = null
      for (const item of secondEchart) {
        radar = echarts.init(item)
        radar.setOption(renewBannerConfig.content[1].echartOption)
      }
    })
  })

  //事件处理方法
  const handleButtonClick = (action = 'toRead') => {
    dispatch('button-click', action)
  }

  const handleButtonLoad = (action = 'toRead') => {
    dispatch('button-load', action)
  }

  const handleSlideChange = e => {
    let {detail} = e,
      {realIndex} = detail[0][0]
    dispatch('slide-change', {index: realIndex + 1, id: renewBannerConfig?.id})
  }
</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import '../../styles/mixins';

  $component-name: 'c-renewbanner';
  $award-width: 1rem;                   //用户头像大小
  $swiper-width: 6.52rem;               //swiper宽度
  $swiper-height: 6rem;                 //swiper高度

  $hd-swiper-width: 8.25rem;               //swiper宽度
  $hd-swiper-height: 5.62rem;                 //swiper高度

  .#{$component-name} {
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    position: relative;
    width: 100%;
    min-height: 14.96rem;
    background-position: center top;
    background-size: 100% auto;
    background-repeat: no-repeat;
    background-color: #FFFAE8;
    padding-top: 3.78rem;
    // @media #{$pad_landscape_query} {
    //   min-height: 12.96rem;
    // }
    .header {
      width: 5.79rem;
      height: 3.19rem;
      margin: 0 auto;
      .award {
        margin: 0 2.42rem;
        transform: translateY(-0.325rem);
        width: $award-width;
        height: $award-width;
        border-radius: 50%;
      }
      .header-tip {
        text-align: center;
        font-size: 0.3rem;
        color: #814516;
        transform: translateY(-0.2rem);
        span {
          color: #824515;
          font-size: 0.34rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        }
      }
      .header-title {
        margin-left: 0.98rem;
        width: 1.24rem;
      }
    }
    .swiper-div {
      margin: 0.7rem auto auto auto;
      width: $swiper-width;
      height: $swiper-height;
    }

    .swiper-bottom {
      position: absolute;
      top: 12.7rem;
      z-index: 3;
    }

    .btn-buy {
      width: 7.2rem;
      height: 1.6rem;
      margin: 0 0.16rem 0.14rem 0.16rem;
    }

    // @media #{$pad_landscape_query} {
    //   .header, .swiper-div {
    //     position: absolute;
    //   }
    //   .header {
    //     top: 5rem;
    //     left: 1.66rem;
    //     width: 8.06rem;
    //     height: 4.06rem;
    //     @include flex(column, center, flex-start, flex-start, nowrap);
    //     .award {
    //       width: 1.5rem;
    //       height: 1.5rem;
    //       margin: 0 3.27rem;
    //       transform: translateY(-1.26rem);
    //     }
    //     .header-tip {
    //       width: 100%;
    //       text-align: center;
    //       transform: translateY(-1.2rem);
    //       font-size: 0.4rem;
    //       span {
    //         font-size: 0.49rem;
    //       }
    //     }
    //     .header-title {
    //       width: 1.6492rem;
    //       margin-left: 1.3rem;
    //       transform: translateY(-0.8rem);
    //     }
    //   }
    //   .swiper-div {
    //     right: 1.66rem;
    //     width: $hd-swiper-width;
    //     height: $hd-swiper-height;
    //   }
    //   .swiper-bottom {
    //     @include flex(column, center, center, center, nowrap);
    //     position: absolute;
    //     top: 10.28rem;
    //     left: 5.3rem;
    //     right: 5.3rem;
    //     width: 9.9rem;
    //   }
    //   .btn-buy {
    //     width: 7.92rem;
    //     height: 1.76rem;
    //     margin: 0 5.3rem 0.14rem 5.3rem;
    //   }
    // }
  }

  :global(.swipers-slides) {
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    width: $swiper-width !important;
    height: $swiper-height !important;
    padding: 0 0.02rem;
    .title {
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-size: 0.28rem;
      font-weight: normal;
      color: #814616;
      @include flex(row, flex-start, center, flex-start, nowrap);
    }
    .title::before {
      content: '';
      display: inline-block;
      width: 0.106rem;
      height: 0.3rem;
      background: #FFBD2B;
      border-radius: 0.05rem;
      margin-right: 0.16rem;
    }
    .hr {
      width: 100%;
      border-bottom: 0.005rem solid #F9D346;
    }
    .statistic {
      width: 100%;
      color: #FC4F00;
      font-size: 0.13rem;
      margin: 0.1rem auto 0.2rem auto;
      @include flex(row, space-between, center, center, nowrap);
    }
    .desc {
      width: 100%;
      height: 4rem;
      margin-top: 0.3rem;
      @include flex(row, space-between, flex-start, center, nowrap);
      .desc-text {
        width: $swiper-width / 2;
        line-height: 0.4rem;
        font-size: 0.27rem;
        .text {
          color: #814616;
          font-size: 0.27rem;
          line-height: 0.4rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        }
      }
      .desc-chart-first, .desc-chart-second, .desc-chart-third {
        width: $swiper-width / 2;
        height: 4rem;
        // margin-top: 10%;
      }
      .desc-chart-third {
        @include flex(row, center, flex-start, center, nowrap);
        img {
          width: 2rem;
          height: auto;
          border-radius: 0.16rem;
        }
      }
    }
    // @media #{$pad_landscape_query} {
    //   width: $hd-swiper-width !important;
    //   height: $hd-swiper-height !important;
    //   .title {
    //     font-size: 0.399rem;
    //   }
    //   .title::before {
    //     width: 0.14rem;
    //     height: 0.399rem;
    //     border-radius: 0.066rem;
    //   }
    //   .statistic {
    //     font-size: 0.1729rem;
    //   }
    //   .desc {
    //     .desc-text {
    //       line-height: 0.53rem;
    //       width: $hd-swiper-width / 2;
    //       line-height: 0.53rem;
    //       .text {
    //         font-size: 0.32rem;
    //         line-height: 0.53rem;
    //       }
    //     }
    //     .desc-chart-first, .desc-chart-second, .desc-chart-third {
    //       width: $hd-swiper-width / 2;
    //     }
    //     .desc-chart-third {
    //       @include flex(row, center, flex-start, center, nowrap);
    //       img {
    //         border-radius: 0.2rem;
    //       }
    //     }
    //   }
    // }
  }
  :global(.swiper-pagination) {
    bottom: 1rem !important;
    // @media #{$pad_landscape_query} {
    //   bottom: 0.2rem !important;
    // }
  }
  :global(.swiper-pagination-bullet) {
    background-color: #38B8FF;
    width: 0.12rem;
    height: 0.12rem;
  }
</style>
