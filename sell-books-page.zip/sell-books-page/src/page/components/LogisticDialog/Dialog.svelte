<Popup class="logistic-dlg" bind:this={popupEl}>
  <div class="content" on:touchmove|stopPropagation|preventDefault>
    <div class="address">
      您的邮寄地址：{dialogInfo.recipient}, {dialogInfo.phone}, { dialogInfo.region } { dialogInfo.address }
    </div>
    <div class="remark">
      如需修改地址，请<a href="https://h5.hhdd.com/n/h5-macqueen/service-center.html#/home?openChat=1">联系客服</a>。
    </div>
    <!-- 展示物流单号 -->
    <div class="logistics">
      {#if dialogInfo.logisticsNo}
        <div class="logistics-com">
          物流公司：{ dialogInfo.logisticsCompany}
        </div>
        <div class="logistics-no">
          <span> 物流单号：{ dialogInfo.logisticsNo} </span>
          <span
            class="copy"
            data-clipboard-text={dialogInfo.logisticsNo}
            on:click={() => copyLogisticsNo(dialogInfo.logisticsNo)}>
            复制
          </span>
        </div>
      {:else}
        <div class="tip">
          <div>实物赠品自填写地址后15个工作日内发出</div>
          <div>注:部分地区因为疫情会延迟发货，请耐心等待</div>
        </div>
      {/if}
    </div>
    <div class="btn-ok" on:click={close}>好的</div>
  </div>
</Popup>
<script>
  import { onDestroy, onMount } from 'svelte'
  import {setClipBoard} from '@kada/jsbridge'
  import { deviceInfo } from '@kada/library/src/device';
  import {Popup, toast} from '@kada/svelte-activity-ui'
  import ClipboardJS from 'clipboard'

  export let dialogInfo = {}

  let popupEl
  let clipObj

  onMount(() => {
    popupEl && popupEl.show()
  })

  onDestroy(() => {
    clipObj && clipObj.destroy()
  })

  //复制单号
  function copyLogisticsNo (msg) {
    if (deviceInfo.isKadaClient) {
      setClipBoard(msg)
      toast('复制成功')
    } else {
      clipObj = new ClipboardJS('.copy')
      clipObj.on('success', e => toast('复制成功'))
    }
  }
  function close() {
    popupEl && popupEl.close()
  }
</script>

<style lang="scss">
  @import "../../../styles/_variables.scss";
  @import "../../../styles/mixins";
  $component-name: 'logistic-dlg';
  :global {
    .#{$component-name} {
      z-index: 999;
      .content {
        padding: 0.32rem 0.3rem;
        display: flex;
        flex-direction: column;
        width: 6.2rem;
        height: auto;
        background: #fff;
        border-radius: 0.3rem;
        color: #3F3F3F;
        line-height: 0.56rem;
        font-size: 0.32rem;
        .remark {
          a {
            color: #FD3A94;
          }
        }
        .logistics {
          .copy {
            color: #FD3A94;
            text-decoration: underline;
          }
        }
        .tip {
          font-size: 0.3rem;
        }
        .btn-ok {
          width: 2.48rem;
          height: 0.8rem;
          line-height: 0.8rem;
          margin: 0.27rem auto 0;
          font-size: 0.32rem;
          color: #fff;
          text-align: center;
          background: linear-gradient(to bottom, #F94368, #FF35A8);
          border-radius: 0.4rem;
        }
      }
    }
  }

</style>
