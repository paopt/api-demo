<div class="turntable"
  style={`background-image: url(${lotteryConfig.drawBaseMapUrl});`}
  bind:this="{turntable}">
  <div class="lottery-title fzlty-zc">
    <p class="title">{title}</p>
    <p class="subtit">{subtit}</p>
  </div>
  <div class="lottery-turntable">
    <div class="myTurntable" style="transform: {rotateAngle}; background-image: url({lotteryConfig.turntableUrl}); transition: transform {duringTime}s cubic-bezier(0.250, 0.460, 0.455, 0.995), -webkit-transform {duringTime}s cubic-bezier(0.250, 0.460, 0.455, 0.995);">
    </div>
    <p class="lottery-pointer"></p>
  </div>

  <div class="lottery-btn"
    on:click={handleLotteryStart(lotteryConfig.button)}
    style={`background-image: url(${lotteryConfig.drawButton});`}
  >
    {#if lotteryConfig.isJoin && lotteryConfig.turntableNumber}
      <div class="lottery-tips fzlty-zc">x{lotteryConfig.turntableNumber}</div>
    {/if}
    
  </div>

  <!-- 中奖名单 -->
  <div class="lottery__winner-marquee">
    {#if Array.isArray(lotteryConfig?.winPrizeMarquee?.dataSource) && lotteryConfig?.winPrizeMarquee?.dataSource.length > 0}
      <HMarquee
        autoplay
        bind:this={winnerMarqueeEl}
        style={lotteryConfig?.winPrizeMarquee.style || ''}
        class={['c-winner-marquee', lotteryConfig?.winPrizeMarquee.className || ''].join(' ')}>
        {#each lotteryConfig?.winPrizeMarquee.dataSource as item, index (index)}
          <HMarqueeItem>
            <div class="c-winner-marquee__item" style={lotteryConfig?.winPrizeMarquee.itemStyle || ''}>
              <div class="body">{item.prefix || '恭喜'}{item.nickName}抽中{item.packageName || '中奖'}</div>
            </div>
          </HMarqueeItem>
        {/each}
      </HMarquee>
    {/if}
  </div>

  <div class="lottery-show__draw fzlty" on:click={showLotteryList}>中奖记录</div>
</div>
<script>
  import { createEventDispatcher } from 'svelte'
  import { HMarquee, HMarqueeItem } from "@kada/svelte-activity-ui"
  const dispatch = createEventDispatcher()

  export let lotteryConfig = {}
  export let rotateCircle = 6
  export let duringTime = 5

  export let title = ''
  export let subtit = ''

  let turntable = null
  let startRotateDegree = 0
  let rotateAngle = 0
  let rotateTransition = ''
  let winnerMarqueeEl = null

  export function rotate(index, data) {
    // const currentDuringTime = duringTime
    const currentRotateAngle = startRotateDegree + rotateCircle * 360 + 360 - (180 / lotteryConfig.prizeData.length + 360 / lotteryConfig.prizeData.length * index) - startRotateDegree % 360
    startRotateDegree = currentRotateAngle
    rotateAngle = `rotate(${currentRotateAngle}deg)`

    setTimeout(() => {
      dispatch('end-rotate', data)
    }, duringTime * 1000 + 1000)
  }

  function showLotteryList() {
    dispatch('show-list')
  }

  function handleLotteryStart (button) {
    dispatch('lottery-start', button)
  }

</script>

<style lang="scss">
  @import "../../styles/mixins";
  @import '../../styles/variables';
  .turntable {
    position: relative;
    width: 100%;
    height: 12.2rem;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    overflow: hidden;

    .lottery-title {
      margin-top: .66rem;
      
      width: 100%;
      text-align: center;
      color: white;
      .title {
        height: .52rem;
        font-size: .48rem;
        line-height: .52rem;
      }
      .subtit {
        height: .4rem;
        font-size: .26rem;
        line-height: .4rem;
        margin-top: .48rem;
      }
    }

    .lottery-turntable {
      position: relative;
      width: 7rem;
      height: 7rem;
      margin: auto;
    }

    .myTurntable {
      width: 100%;
      height: 100%;
      background-size: 100% 100%;
    }

    .lottery-pointer {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      @include size(1.92rem, 2.32rem);
      @include bg-image;
      background-image: url("//cdn.hhdd.com/frontend/as/i/81a3be4e-5c8f-5e5f-87c6-14ab7c99fa73.png");
    }

    .lottery-btn {
      position: relative;
      width: 5.2rem;
      height: 1.24rem;
      @include bg-image;
      background-image: url("//cdn.hhdd.com/frontend/as/i/a859aa73-a9aa-531f-958f-1feffba7de12.png");
      margin: .1rem auto 0;

      .lottery-tips {
        position: absolute;
        right: .4rem;
        top: -.2rem;
        width: .66rem;
        height: .66rem;
        border-radius: 50%;
        background: #FF5858;
        color: white;
        line-height: .66rem;
        text-align: center;
      }
    }
    
    .lottery-show__draw {
      position: absolute;
      right: 0;
      top: .9rem;
      width: .6rem;
      display: flex;
      flex-wrap: wrap;
      color: white;
      padding: 0.1rem 0.2rem 0.1rem 0.1rem;
      border-radius: 0.2rem 0 0 0.2rem;
      background: rgba(109, 109, 109, .6);
    }

    .lottery__winner-marquee {
      width: 5.5rem;
      height: .4rem;
      display: flex;
      align-items: center;
      overflow: hidden;
      border-radius: .32rem;
      // background: rgba(83, 83, 83, .2);
      margin: .48rem auto 0;
      color: #FFFFFF;
    }

    // @media #{$pad_landscape_query} {
    //   width: 100%;
    //   height: 16.6rem;
    //   .lottery-turntable {
    //     width: 10.6rem;
    //     height: 10.6rem;
    //   }
      
    //   .lottery__winner-marquee {
    //     width: 9.6rem;
    //     height: .6rem;
    //     margin-top: .18rem;
    //   }
    //   .lottery-title {
    //     .title {
    //       height: .72rem;
    //       font-size: .68rem;
    //       line-height: .72rem;
    //     }
    //     .subtit {
    //       height: .56rem;
    //       font-size: .4rem;
    //       line-height: .56rem;
    //       margin-top: .24rem;
    //     }
    //   }

    //   .lottery-pointer {
    //     @include size(3.34rem, 3.88rem);
    //     background-image: url("//cdn.hhdd.com/frontend/as/i/0faf3a93-0e21-5864-a1b5-1663f969b67e.png");
    //   }

    //   .lottery-btn {
    //     width: 7.28rem;
    //     height: 1.74rem;

    //     .lottery-tips {
    //       right: .6rem;
    //     //   width: .92rem;
    //     //   height: .92rem;
    //     //   line-height: .92rem;
    //       font-size: .34rem;
    //     }
    //   }
      
    //   .lottery-show__draw {
    //     top: 3rem;
    //     right: 3.4rem;
    //     width: 1.8rem;
    //     height: .68rem;
    //     justify-content: center;
    //     align-items: center;
    //     border-radius: .16rem;
    //     border: .02rem solid #979797;
    //     font-size: .32rem;
    //     padding: .1rem;
    //   }
    // }
  }
  
</style>