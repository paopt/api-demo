<!-- svga播放器 -->
<canvas class="{['play-canvas', className].join(' ')}" on:click={onClick} bind:this={svgaCanvasEl}></canvas>

<script>
  import { onMount, onDestroy, createEventDispatcher } from 'svelte'
  import { Parser, Player } from 'svga'
  import {regExp} from '@/shared/internal/constants'
  const rem2px = window.kadaRemLayout && window.kadaRemLayout.rem2px ? window.kadaRemLayout.rem2px : (rem) => rem * 50

  //事件转发
  const dispatch = createEventDispatcher()
  //svg容器
  let svgaCanvasEl = null
  //svg播放器
  let player = null
  //解析
  let parser = null
  //组件样式
  export let className = ''
  //svga图片地址
  export let svgaUrl = ''
  //svga动画配置
  export let playerConfig = {
    loop: 0,                //循环次数，默认值 0（无限循环）
  }
  //样式
  export { className as class }

  // 会员头图组件配置
  export let memberBannerConfig = null;

  const initSvgAnimation = async () => {
    if (svgaUrl) {
      try {
        if (!regExp.svgaSuffix.test(svgaUrl)) {
          throw 'inaccurate file format'
        }
        parser = new Parser()
        const svga = await parser.load(svgaUrl)
        player = new Player({
          container: svgaCanvasEl,
          fillMode: 'backwards',    // 最后停留的目标模式，默认值 forwards
          playMode: 'forwards',     //播放顺序顺序播放
          loop: 1,
          startFrame: 0,
          endFrame: svga.frames,
          isUseIntersectionObserver: false,
          isCacheFrames: false,
          ...playerConfig
        })

        // 配置了会员头图，插入动态价格
        if (memberBannerConfig) {
          const {discount} = memberBannerConfig
          const img  = createText(discount)
          svga.replaceElements.money = img
        }
        await player.mount(svga)
        player.onStart = () => console.log('svg play onStart')
        player.onResume = () => console.log('svg play onResume')
        player.onPause = () => console.log('svg play onPause')
        player.onStop = () => console.log('svg play onStop')
        player.onProcess = () => {}
        player.onEnd = () => console.log('onEnd')
        await player.start()
      } catch (e) {
        console.error('svg play error:', e)
      }
    }
  }

  function createText(text) {
    const w = rem2px(1.79)
    const h = rem2px(1.27)
    // 默认绘制两倍图
    const dpr = 2
    const canvas = document.createElement('canvas')
    const context = canvas.getContext('2d')
    canvas.width = dpr * w
    canvas.height = dpr * h
    canvas.style.width = w + 'px'
    canvas.style.height = h + 'px'
    context.scale(dpr, dpr)
    context.font = `${rem2px(1.4)}px FZLANTY_ZHONGCUJW--GB1`
    context.textAlign = 'center'
    context.textBaseline = 'baseline'
    context.fillStyle = '#FFFEF1'
    const obj = context.measureText(text)
    const fix = obj.actualBoundingBoxAscent + obj.actualBoundingBoxDescent;
    console.log('字体高度:', fix)
    console.log('字体宽度:', obj.width)
    context.fillText(text, w / 2, h / 2 + fix / 2)
    return canvas
  }

  function onClick() {
    dispatch('click')
  }

  onMount(() => {
    initSvgAnimation()
  })

  onDestroy(() => {
    // 清空动画
    player && player.clear() && player.destroy()
    // 销毁
    parser && parser.destroy()
  })
</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  //进入页面弹框
  .pageload-pop-svg {
    width: 5.89rem;
    height: auto;
    // @media #{$pad_landscape_query} {
    //   width: 8.39rem;
    //   height: 9.56rem;
    // }
  }
  //免单卡弹框
  .win-invite_card {
    width: 5.89rem;
    height: auto;
  }
</style>
