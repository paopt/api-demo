{#if drawPanelConfig}


  <div class="c-prize-draw-panel"
    style={`background-image:url(${drawPanelConfig?.backgroundImg})`}
    bind:this={panelEl}>

    <!-- 盲盒 -->
    {#if drawPanelConfig?.button?.drawFlag == 1}
      <div class="c-prize-draw-panel__gift-group">
        {#each drawData.gifts as item, index}
          <div class="c-prize-draw-panel__gift-box">
            {#if index != 1}
              <div class="cap" style={`background-image:url(${drawPanelConfig?.blindBoxCapImg})`}></div>
            {/if}
              <div class="body">
                {#if index == 1}
                  <div class="back" style={`background-image:url(${drawPanelConfig?.blindBoxBackImg})`}></div>
                  <div class="prize">
                      <img src={drawPanelConfig?.button?.awardUrl} alt="">
                  </div>
                {/if}
                <div class="front" style={`background-image:url(${drawPanelConfig?.blindBoxImg})`}></div>
              </div>
          </div>
        {/each}
      </div>
    {:else}
      <div class="c-prize-draw-panel__gift-group">
        {#each drawData.gifts as item, index}
          <div class="c-prize-draw-panel__gift-box"
          class:is-tick={!drawData.isDrawing && !drawData.hasDrawed}
          class:is-opening={drawData.activatedIndex === index && drawData.isDrawing}
          class:is-opened={drawData.activatedIndex === index && drawData.hasDrawed}
          style={`animation-delay: ${drawData.isDrawing ? 0 : Math.random() * 5500 + 500}ms`}
          on:click={handleBoxClick}>
              <div class="cap" style={`background-image:url(${drawPanelConfig?.blindBoxCapImg})`}></div>
              <div class="body">
                <div class="back" style={`background-image:url(${drawPanelConfig?.blindBoxBackImg})`}></div>
                <div class="prize">
                  {#if drawResult && drawData.activatedIndex == index}
                  <img src={drawResult.awardUrl} alt="">
                  {/if}
                </div>
                <div class="front" style={`background-image:url(${drawPanelConfig?.blindBoxImg})`}></div>
              </div>
          </div>
        {/each}
      </div>
    {/if}

    <!-- 按钮 -->
    <div class="c-prize-draw-panel__btn-group">
      <button
        class="c-prize-draw-panel__btn c-prize-draw-panel__btn-drawed"
        style={`background-image:url(${drawPanelConfig?.button?.imgUrl})`}
        on:click={handleDrawedClick(drawPanelConfig?.button)}></button>
    </div>

    <!-- 奖品 -->
    <div class="c-prize-draw-panel__prizes-marquee">
      {#if Array.isArray(prizeMarqueeConfig?.dataSource) && prizeMarqueeConfig?.dataSource.length > 0}
        <HMarquee
          autoplay
          speed={50}
          style={prizeMarqueeConfig.style || ''}
          class={['c-prizes-marquee', prizeMarqueeConfig.className || ''].join(' ')}
          cloneItemCount={prizeMarqueeConfig?.dataSource.length}>
          {#each prizeMarqueeConfig.dataSource as item, index (index)}
            <HMarqueeItem>
              <div class="c-prizes-marquee__item" style={prizeMarqueeConfig.itemStyle || ''}>
                <div class="body">
                  <img class="picture" src={item.imageUrl} alt={item.name}>
                  <div class="prize-name">{item.name}</div>
                </div>
              </div>
            </HMarqueeItem>
          {/each}
        </HMarquee>
      {/if}
    </div>

    <!-- 中奖名单 -->
    <div class="c-prize-draw-panel__winner-marquee">
      {#if Array.isArray(winnerMarqueeConfig?.dataSource) && winnerMarqueeConfig?.dataSource.length > 0}
        <HMarquee
          autoplay
          bind:this={winnerMarqueeEl}
          style={winnerMarqueeConfig.style || ''}
          class={['c-winner-marquee', winnerMarqueeConfig.className || ''].join(' ')}>
          {#each winnerMarqueeConfig.dataSource as item, index (index)}
            <HMarqueeItem>
              <div class="c-winner-marquee__item" style={winnerMarqueeConfig.itemStyle || ''}>
                <div class="body">{item.prefix || '恭喜'}{item.nickName}抽中{item.packageName || '中奖'}</div>
              </div>
            </HMarqueeItem>
          {/each}
        </HMarquee>
      {/if}
    </div>

  </div>
{/if}
<script>
  import { HMarquee, HMarqueeItem, toast } from "@kada/svelte-activity-ui"
  import { createEventDispatcher } from "svelte"
  import { promiseDelay } from '@/utils/promisify'

  let panelEl
  let winnerMarqueeEl
  let dispatch = createEventDispatcher()
  let drawData = { isDrawing: false, hasDrawed: false, activatedIndex: -1, gifts: [1, 2, 3] }
  let drawResult = null

  export let drawPanelConfig = null
  export let winnerMarqueeConfig = null
  export let prizeMarqueeConfig = null

  // 点击按钮
  function handleDrawedClick(button) {
    // console.log(`handleDrawedClick-action:${action}`)
    dispatch('drawed-click', button)
  }

  //未抽奖，点击盲盒
  function handleBoxClick () {
    toast('需先下单才可以抽奖哦')
  }

  //已抽奖，显示抽奖结果
  export function showResult(prize = {}) {
    drawData.hasDrawed = true
    drawData.activatedIndex = 1
    drawResult = prize
  }

  //打开盲盒显示奖品
  export async function start (prize = {}, callback) {
    drawData.isDrawing = true
    drawData.activatedIndex = 1
    drawResult = prize
    await promiseDelay(800)
    drawData.hasDrawed = true
    if (typeof callback === 'function') {
      callback()
    }
  }
</script>

<style lang='scss' global>
  @import "../../styles/variables";
  @import '../../styles/mixins';

  $component-name: 'c-prize-draw-panel';
  .#{$component-name} {
    position: relative;
    margin: auto;
    width: 100%;
    height: 10.36rem;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    z-index: 0;
    // @media #{$pad_landscape_query} {
    //   width: 20.48rem;
    //   height: 13.18rem;
    // }

    &__wrapper {
      position: relative;
    }

    &__prizes-marquee {
      position: absolute;
      width: 6.33rem;
      // height: 2rem;
      left: -0.02rem;
      right: 0;
      top: 7.34rem;
      margin: auto;
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      transform: translateZ(0);
      overflow: hidden;
      // @media #{$pad_landscape_query} {
      //   top: 8.88rem;
      //   width: 13.8rem;
      //   // height: 2.09rem;
      //   left: 0;
      //   right: 0;
      // }
    }

    &__winner-marquee {
      position: absolute;
      width: 6.33rem;
      height: 0.4rem;
      left: 0;
      right: 0;
      top: 9.4565rem;
      overflow: hidden;
      margin: auto;
      // background: rgba(172, 0, 0, 0.3);
      border-radius: 0.2rem;
      // @media #{$pad_landscape_query} {
      //   width: 13.1rem;
      //   height: 0.58rem;
      //   top: 11.9rem;
      //   border-radius: 0.26rem;
      //   background: rgba(172, 0, 0, 0);
      // }
    }

    &__gift-group {
      position: absolute;
      top: 2.9rem;
      width: 100%;
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      // @media #{$pad_landscape_query} {
      //   top: 3.8rem;
      // }
    }
    &__gift-box {
      position: relative;
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      width: 1.84rem;
      margin: 0 0.08rem;
      // @media #{$pad_landscape_query} {
      //   width: 3.4rem;
      //   margin: 0 0.5rem;
      // }

      .cap, .front, .back, .prize  {
        position: absolute;
        left: 0;
        right: 0;
        margin: auto;
        background-repeat: no-repeat;
        background-size: 100% 100%;
        transform: scale(1, 1);
        // @media #{$pad_landscape_query} {
        //   transform: scale(1.1, 0.9);
        // }
      }
      .cap {
        width: 1.7rem;
        height: 0.92rem;
        top: -0.71rem;
        z-index: 3;
      //   @media #{$pad_landscape_query} {
      //     width: 3.4rem;
      //     height: 1.18rem;
      //     top: -1.008rem;
      //   }
      }
      .front {
        width: 1.6rem;
        height: 1.32rem;
        z-index: 2;
        // @media #{$pad_landscape_query} {
        //   width: 3.2rem;
        //   height: 1.9rem;
        // }
      }
      .back {
        width: 1.6rem;
        height: 1.06rem;
        z-index: 1;
        top: -0.34rem;
        // @media #{$pad_landscape_query} {
        //   width: 3.2rem;
        //   height: 1.32rem;
        //   top: -0.45rem;
        // }
      }
      .prize {
        width: 1.487rem;
        z-index: 2;
        top: -1.1rem;
        transition: transform 0.4s 0.25s;
        // @media #{$pad_landscape_query} {
        //   width: 2.444rem;
        //   top: -1.433rem;
        // }
        img {
          width: 100%;
        }
        &.is-popup-prize {
          transform: translateY(-0.2rem);
          // @media #{$pad_landscape_query} {
          //   transform: translateY(-0.8rem);
          // }
        }
      }



      &.is-tick {
        transform-origin: center 1rem;
        animation: shakeBubble 3000ms ease-out infinite;
      }
      &.is-opening {
        transform-origin: center 1rem;
        animation: boomToBottom 0.25s 0s ease-in-out both;
        animation-delay: 0;
        .cap {
          animation: boomToUp 0.3s 0.24s cubic-bezier(.03,.76,.87,1.01) both;
        }
        .prize {
          @extend .is-popup-prize;
        }
      }
      &.is-opened {
        .cap {
          opacity: 0;
        }
        .prize {
          @extend .is-popup-prize;
        }
      }
    }

    &__btn-group{
      position: absolute;
      top: 4.8rem;
      width: 100%;
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      // @media #{$pad_landscape_query} {
      //   top: 6.1rem;
      // }
    }
    &__btn {
      width: 5.58rem;
      height: 1.5rem;
      background-repeat: no-repeat;
      background-size: 100% 100%;
      margin: auto;
      background-color: transparent;
      // @media #{$pad_landscape_query} {
      //   width: 7.9rem;
      //   height: 1.7rem;
      // }
      &:active {
        transform: translateY(0.05rem) scale(0.95);
      }
    }
  };

  .c-prizes-marquee {
    width: 100%;
    backface-visibility: hidden;
    &__item {
      display: flex;
      align-items: center;
      width: 1.34rem;
      height: 100%;
      // @media #{$pad_landscape_query} {
      //   width: 1.81rem;
      // }
      .picture {
        width: 100%;
      }
      .prize-name {
        width: 100%;
        font-size: 0.2rem;
        font-family: FZLanTingYuanS-DB-GB;
        font-weight: 400;
        color: #FFFFFF;
        line-height: 0.24rem;
        margin-top: 0.12rem;
        text-align: center;
        // @media #{$pad_landscape_query} {
        //   font-size: 0.25rem;
        //   line-height: 0.32rem;
        //   margin-top: 0.2rem;
        // }
      }
    }
    :global(.sui-hmarquee__list) {
      backface-visibility: hidden;
    }
    :global(.sui-hmarquee__item) {
      margin-left: 0.2rem;
    }
    // @media #{$pad_landscape_query} {
    //   :global(.sui-hmarquee__item) {
    //     margin-left: 0.22rem;
    //   }
    // }
  }

  .c-winner-marquee {
      height: 0.4rem;
      &__item {
        display: flex;
        align-items: center;
        min-width: 2.57rem;
        height: 0.4rem;
        border-radius: 0.26rem;
        padding: 0.03rem 0.22rem 0.04rem 0.08rem;
        opacity: 1;
        line-height: 0.4rem;
        color: #FFFFFF;
        font-size: 0.2rem;
        font-family: 'FZLANTY_JW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
        font-weight: normal;
        .body {
          display: inline-block;
          line-height: 1;
          padding-top: 0.04rem;
          position: relative;
        }
      }
      :global(.sui-hmarquee__item) {
        margin-left: 0.3rem;
      }
      // @media #{$pad_landscape_query} {
      //   height: 100%;
      //   &__item {
      //     height: 0.58rem;
      //     font-size: 0.28rem;
      //     line-height: 0.58rem;
      //   }
      // }
  }

  @keyframes shakeBubble {
    0% {
      transform: scale(1, 1);
    }
    5% {
      transform: scale(1.06, 0.92);
    }
    10% {
      transform: scale(0.9, 1);
    }
    15% {
      transform: scale(1.06, 0.92);
    }
    20% {
      transform: scale(1, 1);
    }
  }
  @keyframes boomToUp {
    0% {
      transform: translateY(0) rotate(0);
      opacity: 1;
    }
    70% {
      opacity: 1;
    }
    100% {
      transform: translateY(-2.5rem) rotate(-15deg);
      opacity: 0;
    }
  }
  @keyframes boomToBottom {
    0% {
      transform: scale(1, 1);
    }
    50% {
      transform: scale(1.1, 0.82);
    }
    100% {
      transform: scale(1, 1);
    }
  }
</style>
