<!-- 进入页面弹框 -->
<Popup class="c-enterpopup {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-enterpopup__body" on:touchmove|stopPropagation|preventDefault>
    <SvgaPlayer svgaUrl={popUpImg} playerConfig={playerConfig} memberBannerConfig={memberBannerConfig} class={"pageload-pop-svg"}></SvgaPlayer>
    {#if showCloseBtn}
      <div style={`background-image:url(${btnImg})`} class="btn-go-draw" on:click={close}></div>
    {/if}
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  import SvgaPlayer from '@/page/components/SvgaPlayer.svelte'
  import Timer from '@/components/Timer.svelte';
  const dispatch = createEventDispatcher()
  //组件样式
  let className = ''

  //计时器
  let timerId = null

  //组件
  let popupEl

  //svg播放器配置
  let playerConfig = { loop: 0 }

  export { className as class }

  export let popUpImg = ''

  export let btnImg = ''

  //是否支持点击mask关闭弹窗
  export let maskClickHide = false

  //点击关闭按钮回调
  export let onClose = null

  //是否显示关闭按钮，默认true
  export let showCloseBtn = true

  //是否自动关闭弹框
  export let autoClose = true

  // 会员头图组件配置，配置了会员头图，会插入动态价格
  export let memberBannerConfig = null;

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  function close() {
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
    clearTimeout(timerId)
  }

  onMount(() => {
    popupEl && popupEl.show()
    if (autoClose) {
      timerId = setTimeout(() => { close() }, 4000)
    }
  })

  onDestroy(() => {
    clearTimeout(timerId)
    timerId = null
  })
</script>

<style lang="scss" scoped>
  @import "../../../styles/variables";
  $component-name: 'c-enterpopup';

  :global {
    .#{$component-name} {
      z-index: 999;
      &__body {
        position: absolute;
        width: 5.89rem;
        height: auto;
        background-position: 50% 0;
        background-size: 100%;
        background-repeat: no-repeat;
        z-index: 999;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        align-items: center;
        // @media #{$pad_landscape_query} {
        //   top: 1.53rem;
        // }
        .canvas {
          width: 5.89rem;
          height: 8.28rem;
        }
        .btn-go-draw {
          width: 5.6rem;
          height: 1.6rem;
          background-size: 100%;
          background-position: center;
          background-repeat: no-repeat;
          // @media #{$pad_landscape_query} {
          //   width: 6.72rem;
          //   height: 1.92rem;
          // }
        }
      }
    }
  }
</style>
