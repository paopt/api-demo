<div class="c-text" style={`background-color:${config.color}`}>
  {config.text}
</div>

<script>
  import appConfig from '@/lib/config'

  
  export let config = null


  $: if (config) {
    console.log('文案组件配置', config)
  }

</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-text {
    position: relative;
  }
</style>
