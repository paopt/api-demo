<div class="c-text" style={`background-color:${config.imageColor}`}>
  <div class="c-text__title" style={`color:${config.textColor}`}>{config.title}</div>
  <div class="c-text__content" style={`color:${config.textColor}`}>{config.text}</div>
</div>

<script>
  export let config = null

  $: if (config) {
    console.log('文案组件配置', config)
  }

</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-text {
    position: relative;
    padding: 0.88rem 0.78rem 1.52rem 0.8rem;

    &__title {
      font-size: 0.36rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      line-height: 0.44rem;
      text-align: center;
    }

    &__content {
      margin-top: 0.32rem;
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      line-height: 0.4rem;
      text-align: left;
    }
  }
</style>
