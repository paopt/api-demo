<div class="c-video-player {className}">
  <div on:click|preventDefault|stopPropagation={onVideoClick} bind:this={videoWrapEl}  class='video-content'>
    <video
      on:play={handleVideoPlayed}
      bind:this={videoEl} preload="none" playsinline class="video-item"  webkit-playsinline x5-video-player-fullscreen x5-video-player-type="h5-page" poster={videoInfo.poster}>
      <source src={videoInfo.source}  type="video/mp4">
      <track kind="captions" />
    </video>
    {#if showPlayerIcon}
      <div class="video-img"  style={`background-image:url(${videoInfo.poster})`}>
        <img class="c-video-player__icon c-video-player__icon--play" src={videoInfo.icon || DEFAULT_VIDEO_PLAY_ICON} alt="">
      </div>
    {/if}
  </div>
</div>
<script>
import { onMount, onDestroy, createEventDispatcher} from 'svelte'
import getSoundManager from '@/shared/media/sound-manager'

const soundManager = getSoundManager()
const voiceSound = soundManager.getSoundChannelById('voice')

const dispatch = createEventDispatcher()

let videoEl = null
let videoWrapEl = null

let showPlayerIcon = false
let isPlaying = false

let className = ''
export { className as class }

export let showPlayIcon = false

const DEFAULT_VIDEO_PLAY_ICON = '//cdn.hhdd.com/frontend/as/i/78df8646-f6a5-5021-b446-99b80ca7cfac.png'
/**
* video资源列表
* @type {Array} videoInfo
*/
export let videoInfo = {
  source: '//cdn.hhdd.com/frontend/as/e/72f21f55-8dc4-5244-a5a6-72a6ddec3075.mp4',
  poster: '//cdn.hhdd.com/frontend/as/i/4eff3efc-b967-5fbd-ac21-3f66c0ebd43b.png',
  icon: DEFAULT_VIDEO_PLAY_ICON
}


$: if (showPlayIcon) {
  showPlayerIcon = showPlayIcon
}
export let autoplay = false

$: if (autoplay) {
  playVideo()
} else {
  pauseVideo()
}

/**
* 获取组件位置信息
*
* @returns {Rectangle}
*/
export function getBoundingClientRect() {
  return videoEl?.getBoundingClientRect()
}
/**
* 事件处理方法
*/
const onVideoClick = () => {
  if (showPlayerIcon) {
    playVideo()
  } else {
    pauseVideo()
  }
  dispatch('video-click', showPlayerIcon)
}
export const playVideo = () => {
  if (isPlaying) {
    return
  }
  isPlaying = true
  // 隐藏播放图标
  showPlayerIcon = false
  videoEl.pause()
  setTimeout(() => {
    videoEl.play()
  }, 100)
}
export const pauseVideo = () => {
  if (!isPlaying) {
    return
  }
  isPlaying = false
  // 显示暂停的图标
  showPlayerIcon = true
  setTimeout(() => {
    videoEl.pause()
  }, 0)
}


const handleVideoPlayed = () => {
  if (voiceSound.audioState === 'PLAYING') {
    voiceSound.stop()
  }
  dispatch('video-played')
}

// 添加监听视频播放结束事件
const addAllListener = () => {
  videoEl.addEventListener('ended', _onVideoPlay)
}
// 移除监听视频播放结束事件
const removeAllListener = () => {
  videoEl.removeEventListener('ended', _onVideoPlay)
}
// 视频播放结束后调用暂停方法， 打点
const _onVideoPlay = () => {
  pauseVideo()
}

onMount(() => {
  if (videoEl) {
    addAllListener()
  }

})
onDestroy(() => {
  removeAllListener()
})
</script>
<style lang="scss" global>
.c-video-player {
// height: 6rem;
width: 100%;
.video-content {
  position: absolute;
  width: 6.53rem;
  height: 3.67rem;
  border: 0.02rem solid #2A9BFD;
  overflow: hidden;
  border-radius: 0.4rem;
  .video-item {
    width: 100%;
    height: 100%;
    object-fit: fill;
  }
  .video-img {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 100%;
    height: 100%;
    transform: translate(-50%, -50%);
    background-repeat: no-repeat;
    background-position: 50% 0;
    background-size: 100% 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 3;
    img {
      width: 1.05rem;
      height: 1.05rem;
    }
  }
}

}
</style>
