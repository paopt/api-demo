<div class={['c-ftbar', (className || ''), theme ? `theme-${theme}` : ''].join(' ')} class:is-show={show} style={style || ''}>
  <div class="c-ftbar__bar {barClass}">
    {#if $$slots.default}
      <div class="c-ftbar__tip"><slot></slot></div>
    {/if}
    {#if statusConfig}
      {#if statusConfig.info}
        <div class="c-ftbar__info {(statusConfig.info && statusConfig.info.className) || ''}">
        {#if statusConfig.info}
          {#if statusConfig.info.type === 'html'}
            {@html statusConfig.info.content || ''}
          {:else}
            {statusConfig.info.content || ''}
          {/if}
        {/if}
        </div>
      {/if}
      {#if Array.isArray(buttonOptions)}
        {#each buttonOptions as item, index}
          <div class="c-ftbar__btn {item.className || ''}" on:click={handleBarClick(item.action, item.params)}>
            {#if item.type === 'html'}
              {@html item.content || ''}
            {:else}
              {item.content || ''}
            {/if}
          </div>
        {/each}
      {:else if buttonOptions}
        <div class="c-ftbar__btn {buttonOptions.className || ''}" on:click={handleBarClick(buttonOptions.action, buttonOptions.params)}>
          {#if buttonOptions.type === 'html'}
            {@html buttonOptions.content || ''}
          {:else}
            {buttonOptions.content || ''}
          {/if}
          {#if memberBannerConfig}
            <span class="price__symbol">¥</span>
            <span class="price__value">{memberBannerConfig.realPrice}</span>
            {#if memberBannerConfig.showBubble}
              <img class="bubble__img" src="//cdn.hhdd.com/frontend/as/i/2760534c-6549-51d2-9727-7404dfdc7f6b.png" alt="">
            {/if}
            <span class="bubble__price">{memberBannerConfig.discount}</span>
          {/if}
        </div>
      {/if}
    {/if}
  </div>
</div>

<script>
  import { deviceInfo } from '@kada/library/src/device'
  import { createEventDispatcher } from 'svelte'

  const dispatch = createEventDispatcher()

  /**
   * 是否显示FooterBar
   * @type {Boolean} show
   */
  export let show = false

  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 自定义内联样式
   * @type {String} style
   */
  export let style = ''

  /**
   * 停靠栏大小
   * @type {String} barClass
   */
  export let barClass = ''

  /**
   * 组件样式主题
   * @type {String} theme
   */
  export let theme = ''

  /**
   * FootBar配置信息
   * @type {Object} config
   */
  export let config = null

  // 会员头图配置
  export let memberBannerConfig = null

  $: statusConfig = config || {}

  $: buttonOptions = statusConfig && statusConfig.button

  /**
   * 事件处理方法
   */
  const handleBarClick = (action = 'buyPackage', params) => {
    dispatch('bar-click', { action, params })
  }

</script>

<style lang="scss">
  @import "../../styles/mixins";
  @import "../../styles/animation.scss";
  @import '../../styles/variables';
  $component-name: 'c-ftbar';

  .#{$component-name} {
    position: fixed;
    margin: 0 auto;
    left: 0;
    right: 0;
    bottom: 0;
    text-align: center;
    transition: transform 0.25s ease;
    transform: translateY(200%);
    background: #fff;
    padding-bottom: calc(constant(safe-area-inset-bottom) - 10px);
    padding-bottom: calc(env(safe-area-inset-bottom) - 10px);
    z-index: 99;

    width: 7.5rem;
    height: 1.8rem;
    // border-radius: 0.4rem 0.4rem 0rem 0rem;
    display: flex;
    justify-content: center;
    align-content: center;
    align-items: center;


    &__bar {
      display: flex;
      width: 100%;
      margin: 0 auto;
      align-items: center;
      justify-content: center;
    }

    &__tip {
      position: absolute;
      left: 0;
      right: 0;
      top: -0.44rem;
      height: 0.46rem;
      line-height: 1;
      font-weight: 400;
      color: #fff;
      text-align: center;
      // background: linear-gradient(-90deg, #FF452A, #FF8A37);
      vertical-align: middle;

      &:empty {
        display: none;
        background: none;
      }
    }

    &__info {
      display: block;
      flex: 1;
      line-height: 1;
      font-size: 0.28rem;
      font-weight: 400;
      color: #535353;
    }

    :global(dt),
    :global(dd) {
      display: block;
      margin: 0;
      padding: 0;
      line-height: 1;
    }

    :global(.fz-53) {
      font-size: 0.53rem;
    }

    :global(.fz-40) {
      font-size: 0.40rem;
    }

    :global(.fz-32) {
      font-size: 0.32rem;
    }

    :global(.fz-30) {
      font-size: 0.30rem;
    }

    :global(.fz-28) {
      font-size: 0.28rem;
    }

    :global(.fz-24) {
      font-size: 0.24rem;
    }

    :global(.fw-bold) {
      font-weight: bold;
    }

    :global(.clr-black) {
      color: #535353;
    }

    :global(.del) {
      text-decoration: line-through;
    }

    &__btn {
      position: relative;
      text-align: center;
      width: 7.2rem;
      :global(img) {
        width: 7.2rem;
      }
    }
    .price__symbol {
      position: absolute;
      left: 1.94rem;
      top: 0.48rem;
      font-size: 0.46rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #F7223A;
      line-height: 0.54rem;
      letter-spacing: 0.01rem;
    }
    .price__value {
      position: absolute;
      left: 2.42rem;
      top: 0.26rem;
      font-size: 0.72rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #F7223A;
      line-height: 0.84rem;
      letter-spacing: 0.01rem;
    }

    .bubble__img {
      position: absolute;
      left: 4rem;
      top: -0.3rem;
      width: 3.12rem;
      height: 0.5rem;
    }
    .bubble__price {
      position: absolute;
      left: 5.66rem;
      top: -0.26rem;
      font-size: 0.24rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FC1400;
      line-height: 0.4rem;
      text-align: center;
    }

    &.is-none {
      display: none;
    }

    &.is-show {
      transform: translateY(0);
    }
    // pad适配
    // @media #{$pad_landscape_query} {
    //   width: 100%;
    //   height: 1.8rem;
    //   border-radius: 0;
    //   &__bar {
    //     width: 100%;
    //   }
    //   &__btn {
    //     width: 18rem;
    //     :global(img) {
    //       width: 18rem;
    //     }
    //   }
    //   .bubble__img {
    //     display: none;
    //   }
    //   .bubble__price {
    //     left: 5.04rem;
    //     top: 0.4rem;
    //     font-size: 0.6rem;
    //     font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    //     font-weight: normal;
    //     color: #FF3200;
    //     line-height: 0.68rem;
    //     letter-spacing: 0.02rem;
    //   }
    //   .price__symbol {
    //     left: 11.76rem;
    //     top: 0.58rem;
    //     font-size: 0.51rem;
    //     line-height: 0.6rem;
    //   }
    //   .price__value {
    //     width: 2.13rem;
    //     left: 12rem;
    //     top: 0.32rem;
    //     font-size: 0.8rem;
    //     line-height: 0.94rem;
    //     text-align: center;
    //   }
    // }
  }
</style>
