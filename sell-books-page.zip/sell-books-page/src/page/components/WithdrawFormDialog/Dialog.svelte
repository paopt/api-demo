<!-- 填写支付宝账号信息 -->
<Popup class={['c-withdrawformdlg', className, theme ? `theme-${theme}` : ''].join(' ')} {maskClickHide} {outPosition} bind:this={popupEl}>
  <div class="c-withdrawformdlg__body">
    <div class="c-withdrawformdlg__forms">
      <div class="c-withdrawformdlg__form-item">
        <label for="account">支付宝账号</label>
        {#if !account}
          <input bind:value={inputAccount} data-name='account' placeholder="请输入支付宝账号" />
        {:else}
          <p class="content">{account}</p>
        {/if}
      </div>
      <div class="c-withdrawformdlg__form-item">
        <label for="name">真实姓名</label>
        {#if !accountName}
          <input bind:value={inputAccountName} data-name='name' placeholder="请输入真实姓名" />
        {:else}
          <p class="content">{accountName}</p>
        {/if}
      </div>
    </div>
    <div class="c-withdrawformdlg__notice">
      <p>1、确认后不可修改，请仔细检查，如需修改，请<a href="https://h5.hhdd.com/n/h5-macqueen/service-center.html#/home?openChat=1">联系客服</a></p>
      <p>2、现金奖励优先通过原支付路径返回，如无法原路退回会通过支付宝转账到您的填写账户中</p>
      <p>3、活动结束后7个工作日内完成返现奖励</p>
    </div>
    <div class="c-withdrawformdlg__buttons">
      <button class="button is-confirm" on:click={handleConfirmClick}>确认</button>
      {#if !accountName || !account}
         <button class="button is-cancel" on:click={handleCancelClick}>取消</button>
      {/if}
    </div>
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount } from 'svelte'
  import { Popup, toast } from '@kada/svelte-activity-ui'
  import { promiseDelay } from '@/utils/promisify'
  import { getAnalyticsIdByName } from '@/shared/scheme/page-config'
  import { sendBehavior } from "@/shared/internal"

  const dispatch = createEventDispatcher()

  //组件样式
  let className = ''
  export { className as class }

  //是否支持点击mask关闭弹窗
  export let maskClickHide = false

  //点击关闭按钮回调
  export let onClose = null

  //点击按钮是否关闭弹窗
  export let doneCloseDialog = true

  //点击按钮回调
  export let onDone = null

  //动画退出位置
  export let outPosition = [0, 0]

  //组件样式主题
  export let theme = ''

  //帐户号
  export let account = ''

  //帐户名
  export let accountName = ''


  let inputAccount = ''
  let inputAccountName = ''

  let countDownEl = null
  let popupEl = null
  let visible = false

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  let aliPayAccountDialog = getAnalyticsIdByName('dialog.aliPayAccountDialog')

  function close() {
    dispatch('close')
    visible = false
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }
  function done() {
    if (countDownEl) {
      countDownEl.pause()
    }
    if (doneCloseDialog) {
      popupEl && popupEl.close()
    }
    resolve(true)
    if (typeof onDone === 'function') {
      onDone({
        inputAccount: trimWhiteSpace(inputAccount),
        inputAccountName: trimWhiteSpace(inputAccountName)
      })
    }
  }

  // 移除指定字符空格
  function trimWhiteSpace (str) {
    if (!str) {
      return str
    }
    return str.replace(/\s+/g, '')
  }

  async function handleConfirmClick () {
    sendBehavior(aliPayAccountDialog.doneClick)
    if (account === '' && inputAccount === '') {
      toast('请填写支付宝账号')
      return
    }
    if (accountName === '' && inputAccountName === '') {
      toast('请填写真实姓名')
      return
    }
    done()
  }
  function handleCancelClick () {
    inputAccount = ''
    inputAccountName = ''
    close()
  }

  onMount(() => {
    sendBehavior(aliPayAccountDialog.view)
    promiseDelay(500).then(() => {
      if (countDownEl) {
        countDownEl.start()
      }
    })
    popupEl && popupEl.show()
    visible = true
  })
</script>

<style lang="scss" global>
  @import "../../../styles/_variables.scss";
  @import "../../../styles/mixins";

  $component-name: 'c-withdrawformdlg';

  .#{$component-name} {
    z-index: 999;

    &__body {
      position: relative;
      top: -1rem;
      width: 5.6rem;
      background: #fff;
      border-radius: 0.4rem;
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      flex-direction: column;
      padding: 0.5rem 0.55rem 0.4rem;
    }

    :global(.sui-popup__mask) {
      background-color: rgba(0, 0, 0, 0.7);
    }

    &__form-item {
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: flex-start;
      flex-direction: column;
      margin-bottom: 0.4rem;
      width: 4.36rem;

      label {
        font-size: 0.32rem;
        color: #393939;
        line-height: 0.44rem;
        margin-bottom: 0.2rem;
        font-weight: bold;
        font-family: 'FZLANTY_JW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
      }
      input {
        width: 100%;
        height: 0.8rem;
        border-radius: 0.08rem;
        border: 0.02rem solid #BABABA;
        text-align: center;
        padding: 0.2rem 0.3rem;
        font-size: 0.28rem;
        font-weight: 500;
        color: #393939;
        line-height: 0.4rem;
        -webkit-appearance: none;
        &::-webkit-input-placeholder {
          color: #C1C1C1;
        }
      }
      .content {
        font-size: 0.32rem;
        font-weight: bold;
        font-family: 'FZLANTY_JW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
        color: #3277EE;
        line-height: 0.44rem;
        letter-spacing: 0.03rem;
        margin: 0.3rem 0 0.18rem;
      }
    }
    &__notice {
      font-size: 0.24rem;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #7E7E7E;
      line-height: 0.34rem;
      p {

      }
      a {
        color: #3277EE;
      }
    }

    &__buttons {
      margin-top: 0.46rem;
      display: flex;
      justify-content: space-between;
      align-content: center;
      align-items: center;
      width: 100%;
      .button {
        width: 2.09rem;
        height: 0.66rem;
        border-radius: 0.08rem;
        font-size: 0.34rem;
        font-weight: 500;
        color: #FFFFFF;
        line-height: 0.46rem;
        // flex: 1 1 auto; = flex-grow + flex-shrink + flex-basic
        flex: 1 1 auto;
        &.is-confirm {
          background: #3277EE;
        }
        &.is-cancel {
          background: #B2B2B2;
          margin-left: 0.24rem;
        }
        &:active {
          transform: scale(0.98);
        }
      }
    }
  }

</style>
