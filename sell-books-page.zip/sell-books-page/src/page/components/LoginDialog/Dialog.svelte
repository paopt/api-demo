<script>
  import { createEventDispatcher, onMount, onDestroy } from "svelte";
  import { Popup, toast, showLoading, hideLoading } from "@kada/svelte-activity-ui";
  import { getClientDeviceId } from '@kada/library/src/device'
  import { sendBehavior } from '@/lib/analytics'
  import { createUser, sendSmsCode } from '@/services/user'

  const dispatch = createEventDispatcher();
  /**
   * 组件样式
   * @type {String} class
   */
  let className = "";
  export { className as class };

  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = false;

  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null;

  let popupEl
  let ncData = null // 滑动验证返回值
  let phoneNumber = '' // 手机号
  let smsCode = '' // 验证码
  let selected = false
  let codeStatus = 'NO_SEND'
  let countDown = 60
  
  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  onMount(() => {
    popupEl && popupEl.show();

    initAwsc()
  });

  function close(status) {
    dispatch("close");
    popupEl && popupEl.close();

    resolve(false);
    if (typeof onClose === "function") {
      onClose(status);
    }
  }

  /**
   * 初始化滑块验证
   */
  function initAwsc() {
    AWSC.use('nc', function (state, module) {
      // 初始化
      window.nc = module.init({
        // 应用类型标识。它和使用场景标识（scene字段）一起决定了滑动验证的业务场景与后端对应使用的策略模型。您可以在阿里云验证码控制台的配置管理页签找到对应的appkey字段值，请务必正确填写。
        appkey: 'FFFF0N0N000000006D3A',
        //使用场景标识。它和应用类型标识（appkey字段）一起决定了滑动验证的业务场景与后端对应使用的策略模型。您可以在阿里云验证码控制台的配置管理页签找到对应的scene值，请务必正确填写。
        scene: 'nc_message_h5',
        // 声明滑动验证需要渲染的目标ID。
        renderTo: 'nc',
        fontSize: '16',
        upLang: {
          'cn': {
            'SLIDE': '按住滑块，拖动至最右'
          }
        },
        //前端滑动验证通过时会触发该回调参数。您可以在该回调参数中将会话ID（sessionId）、签名串（sig）、请求唯一标识（token）字段记录下来，随业务请求一同发送至您的服务端调用验签。
        success: function (data) {
          ncData = { ...data }
          // 滑动验证完成自动发送验证码
          if (validatePhone(phoneNumber)) {
            getSmsCode()
          } else {
            toast('请输入正确的手机号')
          }
        },
        // 滑动验证失败时触发该回调参数。
        fail: function (failCode) {
          console.log('滑动验证失败时', failCode)
        },
        // 验证码加载出现异常时触发该回调参数。
        error: function (errorCode) {
          console.log('验证码加载出现异常时', errorCode)
        },
      })
    })
  }

  /**
   * 登录
   */
  async function login() {
    if (!validatePhone(phoneNumber)) {
      toast('请输入正确的手机号码')
      return
    }

    if (!smsCode) {
      toast('请输入验证码')
      return
    }

    if (smsCode.length === 6) {
      showLoading('正在验证中，请稍后')
      try {
        const res = await createUser({
          deviceId: getClientDeviceId(),
          ...ncData,
          phoneNumber,
          smsCode,
          // wechatOpenId: openId,
        })
        if (res.code === 200) {
          toast('验证成功')
          smsCodeBlur()
          close(true)
        } else {
          toast('验证码输入错误，请重新输入')
        }
        hideLoading()
      } catch (error) {
        toast(error.message)
        hideLoading()
      }
    }
  }

  /**
   * 输入手机号
   * 手机号改变，重置滑块
   */
  function inputPhoneNumber() {
    window.nc.reset()
    ncData = null
  }

  /**
   * 输入手机号touchend
   */
  function smsCodeBlur() {
    const _input = document.getElementById('_inputValidate')
    _input.style.display = 'block'
    setTimeout(() => {
      _input.blur()
    }, 150)
  }

  /**
   * 发送验证码
   */
  async function getSmsCode() {
    if (!validatePhone(phoneNumber)) {
      toast('请输入正确的手机号码')
      return
    }

    // 已发送
    if (codeStatus === 'SEND') {
      return
    }

    if (!ncData) {
      return toast('请先拖动验证滑块')
    }

    showLoading()
    const res = await sendSmsCode({
      phoneNumber,
      ...ncData,
    })
    if (res.code === 200) {
      toast('验证码发送成功')
      codeStatus = 'SEND'
      // 倒计时
      countDown = 60;
      const timer = setInterval(() => {
        countDown--;
        if (countDown == 0) {
          window.nc.reset()
          ncData = null
          codeStatus = 'SEND_OVER';
          clearInterval(timer);
        }
      }, 1000);
    } else {
      toast(res.msg)
    }
    hideLoading()
  }

  function toggleOption () {
    selected = !selected
  }

  /**
   * 验证手机号码
   * @param phoneNumber
   */
  function validatePhone(phoneNumber) {
    const reg = new RegExp(
      /^1(3[0-9]|4[01456879]|5[0-35-9]|6[2567]|7[0-8]|8[0-9]|9[0-35-9])\d{8}$/,
    )
    const valiPhoneNumRes = reg.test(phoneNumber)
    return phoneNumber.length === 11 && valiPhoneNumRes
  }
</script>

<Popup class="c-logindlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-login">
    <img class="c-login__close" on:click={close} src="//cdn.hhdd.com/frontend/as/i/9e874488-034b-5246-b31f-ce9e5ab81b38.png" alt="">
    <div class="c-login__title">登录体验更多精彩</div>
    <div class="c-login__content">
      <input
        id="_input"
        class="inputPhone"
        maxlength="11"
        type="text"
        bind:value={phoneNumber}
        on:input={inputPhoneNumber}
        placeholder="请输入手机号" />
        <div class="validate">
          <input
            id="_inputValidate"
            class="inputValidate"
            maxlength="6"
            bind:value={smsCode}
            type="text"
            placeholder="请输入验证码" />
          <div class="line"></div>
          {#if codeStatus === 'SEND'}
            <span class="code-send">已发送（{countDown}）</span>
          {:else}
            <span class="code-label" on:click={getSmsCode}>{codeStatus == 'NO_SEND' ? '获取验证码' : '再次发送'}</span>
          {/if}
        </div>
      <div class="slide-wrap">
        <div id="nc"></div>
      </div>
    </div>
    <div class="c-login__footer">
      <div class="c-login__button {!selected ? 'disabled-btn' : ''}" on:click={login}>登录</div>
      <div class="checkbox" on:click={toggleOption}>
        {#if selected}
          <img class="icon" src="//cdn.hhdd.com/frontend/as/i/08b8a17f-73a0-502b-a839-f5031a67fe18.png" alt="">
        {:else}
          <img class="icon" src="//cdn.hhdd.com/frontend/as/i/1b9051e8-9e67-556b-ba7b-777a33413242.png" alt="">
        {/if}
        <span class="label">登录代表您已同意<a class="link" href="https://h5.hhdd.com/pages/kada-papers/userprotocol/normal.html">《用户协议》</a>和<a class="link" href="https://h5.hhdd.com/pages/kada-papers/privacypolicy/normal.html">《隐私政策》</a></span>
      </div>
    </div>
  </div>
</Popup>

<style lang="scss">
  $component: 'c-login';
  @import "../../../styles/variables";
  @import "../../../styles/mixins";
  :global {

    .sui-indicator {
      position: fixed;
      z-index: 9999;
    }
    .c-logindlg {
      z-index: 999;
    }
    .#{$component} {
      position: relative;
      width: 6.04rem;
      padding: 0.56rem 0.28rem 0.54rem 0.28rem;
      border-radius: 0.3rem;
      background-color: #fff;

      &__close {
        position: absolute;
        width: 0.72rem;
        height: 0.72rem;
        bottom: -1.2rem;
        left: 2.66rem;
      }

      &__title {
        font-size: 0.36rem;
        font-family: PingFangSC-Semibold, PingFang SC;
        font-weight: 600;
        color: #333333;
        text-align: center;
      }

      &__content {
        margin-top: 0.56rem;
        .inputPhone {
          width: 100%;
          height: .88rem;
          padding-left: 0.4rem;
          background: #F6F8FB;
          border-radius: 0.44rem;
          outline: none;
          font-size: 0.28rem;
          font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
          font-weight: normal;
          // color: #D7D7D7;
        }

        .slide-wrap {
          margin-top: .24rem;
          .slide-text {
            // width: .64rem;
            // display: flex;
            // flex-wrap: wrap;
            padding-left: .04rem;
            font-size: .28rem;
            // margin-right: .4rem;
          }
          align-items: center;
          display: flex;
        }
        #nc {
          flex : 1;
          position: relative;
          // margin-top: 0.3rem;
          height: 0.88rem;
          .nc_wrapper {
            width: 100%;
          }
          #nc_6_wrapper {
            height: .88rem;
            line-height: .88rem;
          }
          .nc_scale {
            height: .88rem;
          }
          #nc_6_n1z {
            height: .88rem;
          }
          .btn_slide, .btn_ok {
            width: .88rem;
            height: .88rem;
            line-height: .88rem;
          }

          .nc-lang-cnt {
            height: .88rem;
            line-height: .88rem;
            b {
              color: white;
            }
          }
          .nc_scale .nc-align-center.scale_text2 {
            text-indent: -20px;
          }
        }

        .validate {
          margin-top: 0.24rem;
          width: 100%;
          height: .88rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: #F6F8FB;
          border-radius: .44rem;

          .inputValidate {
            width: 3.54rem;
            height: 100%;
            padding-left: 0.4rem;
            background: none;
            // line-height: 0.34rem;
            font-size: 0.28rem;
            font-weight: normal;
            font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
            outline: none;
          }

          .line {
            width: .02rem;
            height: .3rem;
            background: #D7D7D7;
          }

          .code-label {
            flex: 1;
            font-size: 0.28rem;
            font-family: PingFangSC-Semibold, PingFang SC;
            font-weight: 600;
            color: #3398FF;
            text-align: center;
          }

          .code-send {
            flex: 1;
            font-size: 0.28rem;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #999999;
            text-align: center;
          }
        }
      }

      &__footer {
        margin-top: 0.82rem;
        text-align: center;

        .checkbox {
          display: flex;
          align-items: center;
          margin-top: 0.32rem;

          .icon {
            width: 0.28rem;
            height: 0.28rem;
            margin-right: 0.08rem;
          }

          .label {
            font-size: 0.24rem;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            line-height: 1;
            color: #999999;
          }

          .link {
            font-size: 0.24rem;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            line-height: 1;
            color: #3398FF;
            line-height: 1;
          }
        }
      }

      &__button {
        margin: 0 auto px2rem(8) auto;
        width: px2rem(550);
        height: px2rem(100);
        background: #3eabff;
        border-radius: px2rem(50);
        font-size: px2rem(34);
        font-family: PingFangSC-Medium;
        font-weight: 500;
        color: #fff;
        line-height: 1;
        padding: px2rem(33) px2rem(60);
        text-align: center;

        &.disabled-btn {
          opacity: 0.6;
          pointer-events: none;
        }

        &:active {
          background-color: #5db9ff;
          transition-duration: 0.15s;
          transition-property: transform backgrond-color;
          transform: scale(0.98);
        }
      }
    }
  }
</style>
