import { deviceInfo } from '@kada/library/src/device'
import { GIFT_MAP_TYPE } from './constants'
import URLParser from '@/lib/urlParser'
import appConfig from '@/lib/config'

// const url = location.href
// const parsed = new URLParser(url)
// const { flag = 0 } = parsed.query
// const orientFlag = +flag

const OSS_PROCESS_EXTRA = '?x-oss-process=image/quality,q_80/format,jpeg'
// parse config
export const ACTIVITY_COMPONENT_MAP_TYPE = {
  BANNER: 'banner',
  RENEW_BANNER: 'renewBanner',                //续费活动头图
  VIDEO: 'video',
  AUDIO: 'audio',
  MARQUEE: 'marquee',
  FOOTER_BUTTON: 'footerButton',
  STATE_PANEL_BUTTON: 'statePanelButton',
  STATE_PANEL_COUNTDOWN: 'statePanelCountdown',
  SECTIONS: 'sections',
  GIFT_PACK: 'giftPack',
  DRAW_PANEL: 'drawPanel',
  DRAW_PANEL_BUTTON: 'drawPanlButton',
  DRAW_PANEL_BG: 'drawPanelBg',
  DRAW_PANEL_BOX: 'drawPanelBox',   //盒子前景
  DRAW_PANEL_CAP: 'drawPanelCap',   //盖子
  DRAW_PANEL_BACK: 'drawPannelBack', //盒子后景
  DRAW_PRIZES: 'prizes',          //奖品
  SHARE_POSTER: 'sharePoster',        //分享海报
  ENTER_POPUP: 'enterPopup',          //进入弹框
  LOTTERY: 'lottery',   //转盘抽奖,
  MRMBER_BANNER: 'memberBanner', // 会员头图
  USER_BANNER: 'userBanner', // 用户信息组件
  TEXT_BANNER: 'textBanner', // 文案组件
}
export const COMPONENT_CONFIG_MAP_TYPE = {
  [ACTIVITY_COMPONENT_MAP_TYPE.MARQUEE]: 1,
  [ACTIVITY_COMPONENT_MAP_TYPE.BANNER]: 2,
  [ACTIVITY_COMPONENT_MAP_TYPE.SECTIONS]: 3,
  [ACTIVITY_COMPONENT_MAP_TYPE.VIDEO]: 4,
  [ACTIVITY_COMPONENT_MAP_TYPE.GIFT_PACK]: 5,
  [ACTIVITY_COMPONENT_MAP_TYPE.FOOTER_BUTTON]: 6,
  [ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PANEL]: 7,
  [ACTIVITY_COMPONENT_MAP_TYPE.ENTER_POPUP]: 8,
  [ACTIVITY_COMPONENT_MAP_TYPE.RENEW_BANNER]: 9,
  [ACTIVITY_COMPONENT_MAP_TYPE.LOTTERY]: 10,
  [ACTIVITY_COMPONENT_MAP_TYPE.MRMBER_BANNER]: 11,
  [ACTIVITY_COMPONENT_MAP_TYPE.USER_BANNER]: 12,
  [ACTIVITY_COMPONENT_MAP_TYPE.TEXT_BANNER]: 13,
}
const COMPONENT_CONFIG_MAP_STATE = {
  CANBUY: 'canbuy',
  BOUGHT: 'bought',
  UPGRADE: 'upgrade',
  SVIP: 'svip'
}

//抽奖状态
const DRAW_PANEL_STATE = { GUIDE: 'guide', CANDRAW: 'candraw', DRAWED: 'drawed' }

export let parsedActivityConfig = {}

export function parsedActivityRawConfig (activityInfo) {
  if (!activityInfo) {
    throw new Error('activityInfo is undefined!')
  }
  //加载前清空当前页面组件内容
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.SECTIONS] = []
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.ENTER_POPUP] = {}
  parsedActivityConfig = {}
  const {
    currentTime,
    endTime,
    buyAudioUrl = '',
    upGradeAudioUrl = '',
    svipAudioUrl = '',
    activityPart: configComponents = [],
    identityFlag
  } = activityInfo

  if (buyAudioUrl !== '') {
    parsedRawAudioConfig({
      [COMPONENT_CONFIG_MAP_STATE.CANBUY]: buyAudioUrl,
      [COMPONENT_CONFIG_MAP_STATE.UPGRADE]: upGradeAudioUrl,
      [COMPONENT_CONFIG_MAP_STATE.SVIP]: svipAudioUrl
    })
  }
  if (currentTime > 0 && endTime > 0) {
    parsedRawStatePanelCountDownConfig({
      currentTime,
      endTime
    })
  }
  //邀请类活动，分享海报
  if (identityFlag == 2) {
    parsedSharePosterConfig(activityInfo)
  }

  configComponents.forEach(componentConfig => {
    const { id, type, content, sort } = componentConfig
    let config = null
    try {
      config = JSON.parse(content)
    } catch (error) {
      config = { content }
    }
    config = {
      id,
      type,
      sort,
      ...config
    }

    switch (type) {
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.MARQUEE]:
        parsedRawMarqueeConfig(config)
        break;
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.BANNER]:
        parsedRawStatePanelButtonConfig(config)
        parsedRawBannerConfig(config)
        break;
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.SECTIONS]:
        parsedRawSectionsConfig(config)
        break;
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.VIDEO]:
        parsedRawSectionsConfig(config)
        break;
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.FOOTER_BUTTON]:
        parsedRawFooterButtonConfig(config)
        break;
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.GIFT_PACK]:
        parsedRawGiftPackConfig(config)
        break;
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PANEL]:
        parsedDrawConfig(config)
        break
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.ENTER_POPUP]:
        parsedEnterPopupConfig(config)
        break
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.RENEW_BANNER]:
        parseRawRenewBanner(config)
        break
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.LOTTERY]:
        parseLotteryConfig(config)
        break
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.MRMBER_BANNER]:
        parseMemberBannerConfig(config)
        break
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.USER_BANNER]:
        parsedRawSectionsConfig(config)
        break
      case COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.TEXT_BANNER]:
        parsedRawSectionsConfig(config)
        break
      default:
        break;
    }
  })
}

function parsedRawAudioConfig (config) {
  let audioConfig = {}
  Object.keys(config).forEach(state => {
    if (config[state]) {
      audioConfig[state] = {
        audio: {
          url: config[state]
        }
      }
    }
  })
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.AUDIO] = audioConfig
}

function parsedRawMarqueeConfig (config) {
  const { text = '' } = config
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.MARQUEE] = {
    text
  }
}

function parsedRawBannerConfig (config) {
  const {
    headImagUrl = '',
    ipadHeadImagUrl = ''
  } = config
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.BANNER] = {
    image: {
      url: appConfig.isPad ? ipadHeadImagUrl : headImagUrl + OSS_PROCESS_EXTRA
    }
  }
}


function parsedRawStatePanelButtonConfig (config) {
  const {
    buyButtonUrl = '' ,
    buyAfterButtonUrl = '',
    upGradeButtonUrl = '',
    svipButtonUrl = '',
    ipadBuyButtonUrl = '',
    ipadBuyAfterButtonUrl = '',
    ipadSvipButtonUrl = '',
    ipadUpGradeButtonUrl = ''
  } = config
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.STATE_PANEL_BUTTON] = {
    [COMPONENT_CONFIG_MAP_STATE.CANBUY]: {
      image: {
        url: appConfig.isPad ? ipadBuyButtonUrl : buyButtonUrl
      }
    },
    [COMPONENT_CONFIG_MAP_STATE.BOUGHT]: {
      image: {
        url: appConfig.isPad ? ipadBuyAfterButtonUrl : buyAfterButtonUrl
      }
    },
    [COMPONENT_CONFIG_MAP_STATE.UPGRADE]: {
      image: {
        url: appConfig.isPad ? ipadUpGradeButtonUrl : upGradeButtonUrl
      }
    },
    [COMPONENT_CONFIG_MAP_STATE.SVIP]: {
      image: {
        url: appConfig.isPad ? ipadSvipButtonUrl : svipButtonUrl
      }
    }
  }
}

function parsedRawSectionsConfig (config) {
  const {
    id,
    type,
    imagUrl = '',
    ipadImagUrl= '',
    protocol = '',
    videoUrl = '',
    previewUrl = '',
    backGroundUrl = '',
    ipadBackGroundUrl = '',
    sort = 0,
    buttomUrl,
    HDButtomUrl,
    showContent,
    text,
    title,
    textColor,
    imageColor
  } = config

  const sections = parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.SECTIONS] || []
  let section = {}
  if (type === COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.VIDEO]) {
    section = {
      id,
      type,
      image: {
        url: appConfig.isPad ? ipadBackGroundUrl : backGroundUrl + OSS_PROCESS_EXTRA
      },
      poster: previewUrl,
      source: videoUrl,
      sort
    }
  } else if(type === COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.USER_BANNER]) {
    section = {
      id,
      type,
      buttonUrl: appConfig.isPad ? HDButtomUrl: buttomUrl,
      showContent,
      sort
    }
  } else if (type === COMPONENT_CONFIG_MAP_TYPE[ACTIVITY_COMPONENT_MAP_TYPE.TEXT_BANNER]) {
    section = {
      id,
      type,
      sort,
      text,
      title,
      textColor,
      imageColor
    }
  } else {
    section = {
      id,
      type,
      image: {
        url: appConfig.isPad ? ipadImagUrl : imagUrl + OSS_PROCESS_EXTRA
      },
      link: protocol,
      sort
    }
  }
  // 如果已存在 则更新
  const pos = sections.findIndex(item => item.id === section.id)
  if (pos > -1) {
    sections[pos] = section
  } else {
    parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.SECTIONS] = [
      ...sections,
      section
    ]
  }
}

function parsedRawFooterButtonConfig (config) {
  const {
    buyButtonUrl = '' ,
    buyAfterButtonUrl = '',
    upGradeButtonUrl = '',
    svipButtonUrl = '',
    ipadSvipButtonUrl = '',
    ipadBuyButtonUrl = '',
    ipadUpGradeButtonUrl = ''
  } = config
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.FOOTER_BUTTON] = {
    [COMPONENT_CONFIG_MAP_STATE.CANBUY]: {
      image: {
        url: appConfig.isPad ? ipadBuyButtonUrl : buyButtonUrl
      }
    },
    [COMPONENT_CONFIG_MAP_STATE.BOUGHT]: {
      image: {
        url: buyAfterButtonUrl
      }
    },
    [COMPONENT_CONFIG_MAP_STATE.UPGRADE]: {
      image: {
        url: appConfig.isPad ? ipadUpGradeButtonUrl : upGradeButtonUrl
      }
    },
    [COMPONENT_CONFIG_MAP_STATE.SVIP]: {
      image: {
        url: appConfig.isPad ? ipadSvipButtonUrl : svipButtonUrl       //图片区分手机屏和pad屏
      }
    }
  }
}

function parsedRawStatePanelCountDownConfig (config) {
  const { currentTime = 0, endTime = 0 } = config
  const timerDeadline = endTime - currentTime
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.STATE_PANEL_COUNTDOWN] = {
    text: timerDeadline
  }
}


function parsedRawGiftPackConfig (config) {
  const {
    baseMapUrl = '',
    ipadBaseMapUrl = '',
    content,
    svipDays = '',
    realName = ''
  } = config
  // 会员时长,实物单独处理
  svipDays && content.push({name: `${svipDays}天会员时长`, sourceType: 5})
  realName && content.push({name: `《${realName}》`, sourceType: 6})

  let dataSource = content
  let giftList = dataSource
  // transform primitive data
  // { sourceType: 1, name: '课程' } to { sourceType: 1, name: '课程', count: 1 }
  const counter = giftList.reduce((prev, item) => {
    if (prev[item?.sourceType]) {
      prev[item?.sourceType].count = ++prev[item?.sourceType].count
    } else {
      prev[item?.sourceType] = {
        sourceId: item.sourceId,
        count: 1
      }
    }
    return prev
  }, {})
  // 1、特定类型 且 (count > 1) 合并  2、新增count属性
  giftList = giftList.filter(gift => {
    const isMergeType = gift.sourceType === GIFT_MAP_TYPE.BOOKLIST || gift.sourceType === GIFT_MAP_TYPE.COURSE
    let isReturnGift = true
    if (isMergeType && gift.sourceId !== counter[gift.sourceType].sourceId && counter[gift.sourceType].count > 1) {
      isReturnGift = false
    }
    gift.hasMerged = isMergeType
    gift.count = counter[gift.sourceType].count
    return isReturnGift
  })
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.GIFT_PACK] = {
    image: {
      url: appConfig.isPad ? ipadBaseMapUrl : baseMapUrl + OSS_PROCESS_EXTRA
    },
    list: giftList,
    dataSource
  }
}

//抽奖面板
function parsedDrawConfig(config) {
  //接口数据
  let { drawBaseMapUrl,
    ipadDrawBaseMapUrl,
    guideOrderButton,
    ipadGuideOrderButton,
    drawButton,
    ipadDrawButton,
    drawOverButton,
    ipadDrawOverButton,
    blindBoxButton,
    ipadBlindBoxButton,
    blindCapButton,
    ipadBlindCapButton,
    blindOpenButton,
    ipadBlindOpenButton,
    content,
    id } = config
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PANEL] = {
    //组件ID
    id,
    //抽奖按钮
    [`${ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PANEL_BUTTON}`]: {
      [DRAW_PANEL_STATE.GUIDE]: {image: {url: appConfig.isPad ? ipadGuideOrderButton : guideOrderButton}},
      [DRAW_PANEL_STATE.CANDRAW]: {image: {url: appConfig.isPad ? ipadDrawButton : drawButton}},
      [DRAW_PANEL_STATE.DRAWED]: {image: {url: appConfig.isPad ? ipadDrawOverButton : drawOverButton}}
    },
    //抽奖背景
    [`${ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PANEL_BG}`]: {image: {url: appConfig.isPad ? ipadDrawBaseMapUrl + OSS_PROCESS_EXTRA : drawBaseMapUrl + OSS_PROCESS_EXTRA}},
    //盒子
    [`${ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PANEL_BOX}`]: {image: {url: appConfig.isPad ? ipadBlindBoxButton : blindBoxButton}},
    //盖子前景
    [`${ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PANEL_CAP}`]: {image: {url: appConfig.isPad ? ipadBlindCapButton : blindCapButton}},
    //盒子后景
    [`${ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PANEL_BACK}`]: {image: {url: appConfig.isPad ? ipadBlindOpenButton : blindOpenButton}},
    //奖品
    [`${ACTIVITY_COMPONENT_MAP_TYPE.DRAW_PRIZES}`]: content
  }
}

//分享海报内容
function parsedSharePosterConfig(activityInfo) {
  let {identityFlag, shareJumpUrl, shareImgUrl, shareTitle, shareSubTitle, phoneShareImg, hdShareImg, awardType, award} = activityInfo
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.SHARE_POSTER] = {
    identityFlag,
    shareJumpUrl,
    shareImgUrl,
    shareTitle,
    shareSubTitle,
    sharePosterImg: appConfig.isPad ? hdShareImg : phoneShareImg,
    awardType,
    award
  }
}

//进入弹框
function parsedEnterPopupConfig(config) {
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.ENTER_POPUP] = {
    ...config
  }
}

//续费活动头图
function parseRawRenewBanner(config) {
  let {id, imageUrl, ipadImageUrl, buyButtonUrl, ipadBuyButtonUrl, buyAfterButtonUrl, ipadBuyAfterButtonUrl} = config
  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.RENEW_BANNER] = {
    id,
    imageUrl: appConfig.isPad ? ipadImageUrl : imageUrl,
    buyButtonUrl: appConfig.isPad ? ipadBuyButtonUrl : buyButtonUrl,
    buyAfterButtonUrl: appConfig.isPad ? ipadBuyAfterButtonUrl : buyAfterButtonUrl
  }
}

// 转盘抽奖组件
function parseLotteryConfig(config) {
  const { id, content, drawBaseMapUrl, drawButton, ipadDrawButton, ipadDrawBaseMapUrl, turntableUrl, ipadTurntableUrl } = config

  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.LOTTERY] = {
    id,
    prizeData: content,
    drawButton: drawButton,
    turntableUrl: turntableUrl,
    drawBaseMapUrl: appConfig.isPad ? ipadDrawBaseMapUrl : drawBaseMapUrl
  }
}

// 会员头图
function parseMemberBannerConfig(config) {
  const {
    id,
    buyHeadUrl,
    ipadBuyHeadUrl,
    buyButtonUrl,
    ipadBuyButtonUrl,
    bubbleButtonUrl,
    ipadBubbleButtonUrl,
    buyAfterButtonUrl,
    ipadBuyAfterButtonUrl,
    priceFontsColor,
    payInfoId,
    originPrice,
    realPrice
  } = config

  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.MRMBER_BANNER] = {
    id,
    buyHeadUrl: appConfig.isPad ? ipadBuyHeadUrl : buyHeadUrl,
    buyButtonUrl: appConfig.isPad ? ipadBuyButtonUrl : buyButtonUrl,
    buyAfterButtonUrl: appConfig.isPad ? ipadBuyAfterButtonUrl : buyAfterButtonUrl,
    bubbleButtonUrl: appConfig.isPad ? ipadBubbleButtonUrl : bubbleButtonUrl,
    priceFontsColor,
    payInfoId,
    originPrice,
    realPrice
  }
}

// 用户信息组件
function parseUserBannerConfig(config) {
  const {
    buttomUrl,
    HDButtomUrl,
    showContent
  } = config

  parsedActivityConfig[ACTIVITY_COMPONENT_MAP_TYPE.USER_BANNER] = {
    buttonUrl: appConfig.isPad ? HDButtomUrl: buttomUrl,
    showContent
  }
}
