export default [
  {
    /**
     * 活动主页
     * @param {number} [configId] 配置ID，也是活动ID
     * 787631814
     *
     * @query {any} [channelId] 渠道ID
     */
    path: '/home/:configId',
    loadConfig: 'configId',
    component: () => import('./views/Home/Home.svelte')
  },
  {
    /**
     * 地址列表
    */
    path: '/address/',
    component: () => import('./views/Address/list.svelte')
  },
  {
    /**
     * 编辑地址
    */
    path: '/address/edit/',
    component: () => import('./views/Address/edit.svelte')
  }
]
