import { kdCookieShim } from '@kada/cookie-shim/src/cookie-shim'
import { deviceInfo } from '@kada/library/src/device'
import { initWechatConfig } from '@/lib/wechat'
import config from '@/lib/config'
import App from './App.svelte'
import { wxAuthLogin } from '@/shared/internal/wechat'

console.log('刷新页面了')

if (process.env.NODE_ENV !== 'production') {
  const VConsole = require('vconsole')
  // eslint-disable-next-line
  new VConsole()
}

kdCookieShim({ env: config.env })
if (deviceInfo.wechat) {
  initWechatConfig()
  wxAuthLogin()
}

const app = new App({
  target: document.body
})

export default app
