
import { INNER_APP_NAME_ENUM } from '@kada/lib-ua-parser/src/ua-parser'

// 游学计划页面
export const STUDY_TOUR_PAGE_MAP_URL = {
  development: 'http://10.1.30.67:3001/#/home',
  test: 'http://10.0.10.61:38890/kada-monthly-study-tour/index.html#/home',
  staging: 'http://h5.hhdd.com/staging/kada-monthly-study-tour/index.html#/home',
  production: 'https://h5.hhdd.com/n/kada-monthly-study-tour/index.html#/home'
}
// 最小支持阅读计划的App版本
export const SUPPORT_READING_PLAN_APP_VERSIONS = {
  [INNER_APP_NAME_ENUM.KADA]: {
    version: '6.8.0',
    operator: '<'
  }
}
export const GIFT_MAP_TYPE = {
  BOOKLIST: 1,
  COURSE: 2,
  READING_PLAN: 3,
  STUDYTOUR_PLAN: 4,
  SVIP_DAYS: 5,
  REAL_THING: 6
}
export const GIFT_TYPE_MAP_NAME = {
  [GIFT_MAP_TYPE.BOOKLIST]: '书单',
  [GIFT_MAP_TYPE.COURSE]: '课程',
  [GIFT_MAP_TYPE.READING_PLAN]: '权益',
  [GIFT_MAP_TYPE.STUDYTOUR_PLAN]: '权益',
  [GIFT_MAP_TYPE.SVIP_DAYS]: '会员时长',
  [GIFT_MAP_TYPE.REAL_THING]: '实物'
}
// 当前展示页面的内容类型，
//1绘本单本，2故事单本，3课程单个，4听书合辑，5绘本合辑，8课程合辑，11通用资源id，
//12IP，13ICON，14漫画，15电子书，16阅读计划合辑，17书单合辑，18阅读计划单个任务；
export const KADA_SCHEMA_TYPE = {
  'openbook': {
    sourceType: 1,
    sourceIdName: 'bookId'
  },
  'openstory2': {
    sourceType: 2,
    sourceIdName: 'storyId'
  },
  'opencoursedetail': {
    sourceType: 8,
    sourceIdName: 'courseId'
  },
  'openmixcoursedetail': {
    sourceType: 8,
    sourceIdName: 'courseId'
  },
  'opennewcoursedetail': {
    sourceType: 8,
    sourceIdName: 'courseId'
  },
  'openstorycollection2': {
    sourceType: 4,
    sourceIdName: 'collectionId',
  },
  'openbookcollection2': {
    sourceType: 5,
    sourceIdName: 'collectionId'
  },
  'opencartoon': {
    sourceType: 14,
    sourceIdName: 'comicId'
  },
  'opencartooncollection': {
    sourceType: 14,
    sourceIdName: 'comicId'
  },
  'openebook': {
    sourceType: 15,
    sourceIdName: 'ebookId'
  },
  'openreadplan': {
    sourceType: 16,
    sourceIdName: 'planId',
  },
  'openbooklist': {
    sourceType: 17,
    sourceIdName: 'bookListId'
  }
}
export const SUPPORT_SV_APP_VERSION = {
  [INNER_APP_NAME_ENUM.KADA]: {
    version: '7.5.0',
    operator: '>='
  }
}

export const SUPPORT_IOS_870_APP_VERSION = {
  [INNER_APP_NAME_ENUM.KADA]: {
    version: '8.7.0',
    operator: '<'
  }
}