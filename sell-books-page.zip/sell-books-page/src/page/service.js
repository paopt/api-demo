/**
 * @see http://10.0.10.52:8090/pages/viewpage.action?pageId=34635846
 */
import { getApi, fetch } from '@/lib/fetch'
import * as storage from '@/lib/storage'
import { deviceInfo } from "@kada/library/src/device"
import { isLogin } from '@/services/user'

export const RESPONSE_CODE_MESSAGE = {
  5404: {
    title: '活动不存在'
  },
  5405: {
    title: '活动已结束',
    message: '下次早点来参加哦'
  },
  5406: {
    title: '活动还未开始哦！'
  },
  5401: {
    title: '此用户信息未找到'
  },
  44400: {
    title: '网络请求异常！'
  },
  5410: {
    title: '你已经购买年卡，暂时无法参与活动'
  }
}

// 活动关键字
export const DEFAULT_ACTIVITYKEY = 14745082

/**
 * 活动与用户状态查询接口
 *
 * @param {Number} activityKey 活动关键字
 * @see http://10.0.10.52:8090/pages/viewpage.action?pageId=41058484
 */
export function getActivityInfo (activityKey = DEFAULT_ACTIVITYKEY, userIdStr) {
  let path = 'configureActivity/getActivityInfo.json'
  if (!deviceInfo.isKadaClient && userIdStr && !isLogin()) {
    path += `?userIdStr=${userIdStr}`
  }
  const url = getApi('income', path)

  return fetch.get(url, {
    params: {
      activityKey
    },
    headers: {
      // RDI: 'actEnWeb'
    }
  })
}

/**
 * 抽奖
 * @param {*} activityKey 活动关键字
 * @returns
 */
export function draw(activityKey = DEFAULT_ACTIVITYKEY) {
  const url = getApi('income', 'configureActivity/draw.json')
  return fetch.get(url, { params: { activityKey } })
}

/**
 * 抽中奖品详情
 * @param {*} activityKey 活动关键字
 * @returns
 */
export function drawDetail(activityKey = DEFAULT_ACTIVITYKEY) {
  const url = getApi('income', 'configureActivity/drawDetail.json')
  return fetch.get(url, { params: { activityKey } })
}

/**
 * 转盘抽奖
 * @param {*} activityKey 活动关键字
 * @returns
 */
export function turntableDraw(activityKey = DEFAULT_ACTIVITYKEY) {
  const url = getApi('income', 'configureActivity/turntableDraw.json')
  return fetch.get(url, { params: { activityKey } })
}

/**
 * 抽奖
 * @param {*} activityKey 活动关键字
 * @returns
 */
export function turntableDetail(activityKey = DEFAULT_ACTIVITYKEY) {
  const url = getApi('income', 'configureActivity/turntableDetail.json')
  return fetch.get(url, { params: { activityKey } })
}


export function receiveGift (activityKey = DEFAULT_ACTIVITYKEY) {
  const url = getApi('income', 'commonActivity/receiveGift.json')

  return fetch.get(url, {
    params: {
      activityKey
    }
  })
}

/**
 * 用户地址列表
*/
export function userAddressList() {
  const url = getApi('activityApi', 'general/userAddressList.json')
  return fetch.get(url)
}
/**
 * 保存用户地址详情
 * @param {*} params
 * params.id: 用户地址id
 * params.recipient: 收件人
 * params.region: 地区
 * params.address: 地址详情
 * params.phone: 手机号
 * @returns
 */
 export function saveUserAddress(params) {
  const url = getApi('activityApi', 'general/saveUserAddress.json')
  return fetch.get(url, {params})
}

/**
 * 删除保存用户地址
 * @param {*} params
 * params.id: 用户地址id
 * @returns
 */
 export function delUserAddress(params) {
  const url = getApi('activityApi', 'general/delUserAddress.json')
  return fetch.get(url, {params})
}

/**
 * 用户地址详情
 * @param {*} params
 * params.id: 用户地址id
 * @returns
 */
export function userAddressDetail(params) {
  const url = getApi('activityApi', 'general/userAddressDetail.json')
  return fetch.get(url, {params})
}

/**
 * 新增邮寄地址
 * @param {*} params
 * params.activityKey: 活动id
 * params.recipient: 收件人
 * params.region: 地区
 * params.address: 地址详情
 * params.phone: 手机号
 * params.type: 1赠品所得，2抽奖所得
 * @returns
 */
export function saveExchangeAddress(params) {
  const url = getApi('income', 'configureActivity/saveExchangeAddress.json')
  return fetch.get(url, {params})
}

/**
 * 查看邮寄地址或者物流信息
 * @param {*} params
 * params.activityKey: 活动id
 * params.type: 1赠品所得，2抽奖所得
 * @returns
 */
 export function exchangeAddressDetail(params) {
  const url = getApi('income', 'configureActivity/exchangeAddressDetail.json')
  return fetch.get(url, {params})
}

/**
 * 获取地址数据
 * @returns
 */
export function getAreaData() {
  const url = 'http://cdn.hhdd.com/frontend/as/w/782b11f4-470c-54a2-a463-c00e054e6444.json'
  return fetch.get(url)
}

/**
 * 保存支付宝账号
 * @param {*} params
 * params.activityKey: 活动ID
 * params.account: 账号
 * params.accountName: 账号名称
 * @returns
 */
export function saveAccount(params) {
  const url = getApi('income', 'configureActivity/saveAccount.json')
  return fetch.get(url, {params})
}

/**
 * 查看支付宝账号
 * @param {*} params
 * params.activityKey: 活动ID
 * @returns
 */
export function getAccount(params) {
  const url = getApi('income', 'configureActivity/getAccount.json')
  return fetch.get(url, {params})
}

/**
 * 奖励列表
 * @param {*} params
 * params.activityKey: 活动ID
 * @returns
 */
 export function listAward(params) {
  const url = getApi('income', 'configureActivity/listAward.json')
  return fetch.get(url, {params})
}

/**
 * 设置用户年龄
 * @param {*} params
 * params.readingStage: 年龄标识
 * @returns
 */
 export function setAge(params) {
  const url = getApi('income', 'configureActivity/setAge.json')
  return fetch.get(url, {params})
}

const createLoadPopupKey = (key, id) => `${key}_${id}`
/**
 * 进入页面弹框已弹出，写入storage
 * @param {*} activityKey
 * @param {*} userId
 */
export function setLoadPopuped(activityKey, userId) {
  const key = createLoadPopupKey(activityKey, userId)
  const nowDate = new Date()
  storage.set(key, 1, {
    // 存储过期时间为，第二天凌晨之后
    expire: (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
  })
}

/**
 * 进入页面弹框弹出之前判断是否已经弹出
 * @param {*} activityKey
 * @param {*} userId
 * @returns
 */
export function isLoadPopupPoped(activityKey, userId) {
  const key = createLoadPopupKey(activityKey, userId)
  return !!storage.get(key)
}
