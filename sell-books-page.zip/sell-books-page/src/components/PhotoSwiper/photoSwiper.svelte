<Popup class="c-rulesdlg {className}" {maskClickHide} bind:this={popupEl}>
  <Swiper
    modules={[ Pagination, Scrollbar, Zoom]}
    spaceBetween={0}
    slidesPerView={1}
    zoom={true}
    pagination={{ clickable: true, bulletClass: 'swiper-pagination-bullet'}}
    scrollbar={{ draggable: true }}
    on:slideChange={() => console.log('slide change')}
    on:swiper={setSwiperRef}
    bind:this={swiperEl}
  >
    {#each galleryList as item }
      <SwiperSlide 
        class="swipers-slides">
        <div class="swiper-zoom-container">
          <img src={item.content} alt="" srcset="">
        </div>
        
      </SwiperSlide>
    {/each}
  </Swiper>
  <div class="close" on:click={close}></div>
</Popup>
<script>
  import { Popup } from '@kada/svelte-activity-ui'
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Pagination, Scrollbar, Zoom } from 'swiper'
  import { Swiper, SwiperSlide } from 'swiper/svelte'
  import 'swiper/css'
  import 'swiper/css/navigation'
  import 'swiper/css/pagination'
  import 'swiper/css/scrollbar'
  import "swiper/css/zoom"
  const dispatch = createEventDispatcher()


  export let galleryList = []
  export let index = 0
  let swiperEl = null
  /**
   * 组件样式
   * @type {String} class
   */
   let className = ''
  export { className as class }
  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = false

   /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  let popupEl
  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  function close() {
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  const setSwiperRef = ({ detail }) => {
    const [swiper] = detail
    setTimeout(() => {
      swiperEl = swiper
      swiperEl.slideTo(index)
    })
  }

  onMount(() => {
    popupEl && popupEl.show()
  })

  onDestroy(() => {

  })
</script>
<style lang="scss">
  :global(.swipers-slides) {
    width: 100%;
    img {
      width: 7.5rem;
    }
  }
  .close {
    position: absolute;
    width: 0.9rem;
    height: 0.9rem;
    left: 50%;
    bottom: .6rem;
    margin-left: -0.45rem;
    background: {
      repeat: no-repeat;
      position: 50% 50%;
      size: 100% 100%;
      image: url('//cdn.hhdd.com/frontend/as/i/ce360163-bc41-5954-9b20-732b2503e620.png');
    }
    z-index: 99;
  }
  :global(.swiper-pagination) {
    bottom: 1.6rem!important;
  }
  :global(.swiper-pagination-bullet) {
    background: white;
  }
</style>