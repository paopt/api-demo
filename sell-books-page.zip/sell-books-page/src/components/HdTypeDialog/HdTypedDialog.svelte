<Popup
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['sui-typed-dlg', $$restProps.class || ''].join(' ')}
  {active}
  {rootElement}
  {maskClickHide}
  on:maskClick={handlePopupMaskClick}
  on:hide={handlePopupHide}
  on:destroy={handlePopupDestroy}
  bind:this={popupEl}
>
  <div class="sui-typed-dlg__body {type ? `is-${type}` : ''}" out:scale={{ start: 0.8 }}>
    {#if showCloseButton}<div class="close" on:click={close}></div>{/if}
    <div class="tips">提示</div>
    {#if title}<div class="title">{@html title}</div>{/if}
    {#if message}<div class="msg">{@html message}</div>{/if}
    {#if buttonText}<div class="btn {buttonClassName}" on:click={done}>{buttonText}</div>{/if}
  </div>
</Popup>

<script>
  /**
   * 预定义样式的弹窗
   * @extends {'@kada/svelte-ui-popup'} PopupProps
   * @component TypedDialog
   */
  import { createEventDispatcher, onDestroy } from 'svelte'
  import { object_without_properties } from 'svelte/internal'
  import { scale } from 'svelte/transition'
  import { Popup } from '@kada/svelte-activity-ui'

  /**
   * 滚动锁定对象
   * @type {HTMLElement} rootElement
   */
  export let rootElement

  /**
   * 显示类型
   * @enum {(-1|0|1)} 显示类型
   */
  export const POPUP_ACTIVE_TYPES = {
    NONE: -1, // 不显示
    HIDE: 0, // 隐藏弹层
    SHOW: 1 // 显示弹层
  }
  const dispatch = createEventDispatcher()

  /**
   * 弹窗是否显示
   * @type {Boolean} active
   */
  export let active = POPUP_ACTIVE_TYPES.NONE
  /**
   * 点击确认按钮是否关闭弹窗
   * @type {Boolean} doneCloseDialog
   */
  export let doneCloseDialog = true
  /**
   * 弹窗类型
   * @type {String} type
   */
  export let type = 'message'
  /**
   * 通用弹窗标题
   * @type {String} title
   */
  export let title = ''
  /**
   * 通用弹窗信息
   * @type {String} message
   */
  export let message = ''
  /**
   * 通用弹窗按钮文案
   * @type {String} buttonText
   */
  export let buttonText = '我知道了'
  /**
   * 弹窗按钮样式
   * @type {String} buttonClassName
   */
  export let buttonClassName = ''
  /**
   * 是否显示关闭按钮
   * @type {Boolean} showCloseButton
   */
  export let showCloseButton = false
  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = false
  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null
  /**
   * 点击确认按钮回调
   * @type {Function} onDone
   */
  export let onDone = null

  let resolve
  /**
   * 弹窗完成后处理结果
   * @type {Promise<Boolean>}
   */
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  // Popup对象
  let popupEl

  /**
   * 关闭弹窗
   * @event {Object} close 关闭事件
   */
  export function close () {
    dispatch('close')
    popupEl.close()

    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  /**
   * 点击确认按钮
   * @event {Object} done 完成事件
   */
  function done () {
    dispatch('done')
    resolve(true)
    if (typeof onDone === 'function') {
      onDone()
    }
    if (doneCloseDialog) {
      popupEl.close()
    }
  }

  /**
   * 处理点击遮罩事件
   */
  function handlePopupMaskClick () {
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  /**
   * 响应销毁
   */
  function handlePopupDestroy () {
    dispatch('destroy')
  }

  /**
   * 处理隐藏弹窗
   */
  function handlePopupHide () {
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  onDestroy(() => {
    onClose = null
    onDone = null
  })
</script>

<style lang="scss">
  @import './variables';

  $component-name: '#{$ui-prefix-name}typed-dlg';

  @mixin component-style () {
    min-height: 100%;
    z-index: 199;
    &__body {
      position: relative;
      width: 8.98rem;
      height: 8.93rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      background: {
        repeat: no-repeat;
        position: 0 0;
        size: 100% 100%;
        image: url('//cdn.hhdd.com/frontend/as/i/98666ded-ee61-5d7e-a99a-616580b4c05c.png');
      }
      padding: 3.2rem 0.2rem 2.8rem 0.2rem;
      font-family: PingFangSC-Medium,PingFang SC;
      text-align: center;

      &.is-message {
        background-image: url('//cdn.hhdd.com/frontend/as/i/4e52c6b6-10b3-5f49-a16f-e53dd8a3f938.png');
      }

      &.is-error {
        background-image: url('//cdn.hhdd.com/frontend/as/i/4e52c6b6-10b3-5f49-a16f-e53dd8a3f938.png');
      }

      &.is-ended {
        background-image: url('//cdn.hhdd.com/frontend/as/i/9108e9dc-b3a6-597d-8c12-4a7f01067a70.png');
      }

      &.is-wechat-open {
        background-image: url('//cdn.hhdd.com/frontend/as/i/4e52c6b6-10b3-5f49-a16f-e53dd8a3f938.png');
      }

      &.is-lifevip {
        padding-top: 3.94rem;
        height: 8.93rem;
        background-image: url('//cdn.hhdd.com/frontend/as/i/4e52c6b6-10b3-5f49-a16f-e53dd8a3f938.png');
      }

      &.is-app-upgrade {
        background-image: url('//cdn.hhdd.com/frontend/as/i/9108e9dc-b3a6-597d-8c12-4a7f01067a70.png');
      }

      &.is-subvip {
        background-image: url('///cdn.hhdd.com/frontend/as/i/9108e9dc-b3a6-597d-8c12-4a7f01067a70.png');
      }
      .tips {
        font-size: 0.51rem;
        font-weight: 600;
        color: #FC6620;
        position: absolute;
        top: 2.1rem;
        left: 50%;
        margin-left: -0.5rem;
      }
      .title {
        font-size: 0.51rem;
        font-weight: 600;
        color: #39364d;
        margin-bottom: 0.07rem;
        line-height: 1;
      }

      .msg {
        font-size: 0.51rem;
        font-weight: 600;
        color: #39364d;
        line-height: 1.5;
      }

      .close {
        position: absolute;
        width: 0.9rem;
        height: 0.9rem;
        bottom: -1.2rem;
        left: 50%;
        margin-left: -0.45rem;
        background: {
          repeat: no-repeat;
          position: 50% 50%;
          size: 100% 100%;
          image: url('//cdn.hhdd.com/frontend/as/i/ce360163-bc41-5954-9b20-732b2503e620.png');
        }
        z-index: 99;
      }

      .btn {
        position: absolute;
        width: 6.56rem;
        height: 1.52rem;
        bottom: 1.2rem;
        left: 50%;
        margin-left: -3.3rem;
        background: url('//cdn.hhdd.com/frontend/as/i/bb553dac-413f-5c69-acf5-a9e1a655103f.png') no-repeat 0 0 / 100% 100%;
        font-size: 0.51rem;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #FC6620;
        line-height: 1.52rem;
        padding: 0rem 0rem;
        text-align: center;
        z-index: 1;
        transition: transform 0.25s ease;

        &:active {
          transform: scale(0.98);
        }
      }
    }
  }

  @if $target-env == 'webcomponent' {
    .#{$component-name} {
      @include component-style();
    }
  } @else {
    :global {
      .#{$component-name} {
        @include component-style();
      }
    }
  }
</style>
