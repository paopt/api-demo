/**
 * @example
 * showDialog({
 *  type: DIALOG_TYPE.ERROR,
 *  title: '错误'
 *  message: '这是错误内容'
 * })
 */
 import TypedDialog from './HdTypedDialog.svelte'
/**
   * 显示类型
   * @enum {(-1|0|1)} 显示类型
   */
 export const POPUP_ACTIVE_TYPES = {
  NONE: -1, // 不显示
  HIDE: 0, // 隐藏弹层
  SHOW: 1 // 显示弹层
}
 
 // 是否为Android版App
 const isAndroid = process.browser ? /android|adr/i.test(window.navigator.userAgent) : false
 // 是否为平板设备
 const isPad = process.browser ? (/androidPad/i.test(window.navigator.userAgent) || Math.min(window.screen.height, window.screen.width) >= 600) : false
 
 let dialog = null
 /**
  * 创建弹窗实例
  * @private
  * @param {Object} props
  * @property {Boolean} doneCloseDialog 点击确认按钮是否关闭弹窗
  * @property {String} type 弹窗类型 @see DIALOG_TYPE
  * @property {String} title 弹窗标题
  * @property {String} message 弹窗消息
  * @property {String} buttonText 按钮文案
  * @property {String} buttonClassName 按钮样式ClassName
  * @property {Boolean} showCloseButton 是否显示关闭弹窗
  * @property {Boolean} maskClickHide 点击遮罩关闭弹窗
  * @property {Function} onClose 关闭弹窗回调
  * @property {Function} onDone 点确认按钮回调
  *
  * @returns {Promise<Boolean>}
  */
 function createDialog (props) {
   if (typeof props === 'string') props = DIALOG_DEFINED_STYLES[props] || { type: props }
   if (dialog) {
     dialog.$destroy()
   }
 
   dialog = new TypedDialog({
     target: document.body,
     props: {
       ...props,
       active: POPUP_ACTIVE_TYPES.SHOW
     }
   })
 
   dialog.$on('destroy', () => {
     dialog.$destroy()
   })
 
   return new Promise((resolve) => {
     dialog.$on('close', () => resolve(false))
     dialog.$on('done', () => resolve(true))
   })
 }
 
 /**
  * 弹窗枚举类型
  * @readonly
  * @enum {String}
  */
 export const DIALOG_TYPE = {
   LIFEVIP: 'lifevip', // 终身会员
   SUBVIP: 'subvip', // 绘本、听书会员
   ENDED: 'ended', // 活动结束
   APP_UPGRAGE: 'app-upgrade', // App升级提示
   WECHAT_OPEN: 'wechat-open', // 在微信中打开提示
   MESSAGE: 'message', // 通用提示弹窗
   ERROR: 'error' // 坏消息提示弹窗
 }
 
 /**
  * 预定义弹窗样式
  * @private
  * @enum
  */
 const DIALOG_DEFINED_STYLES = {
   [DIALOG_TYPE.LIFEVIP]: {
     type: 'lifevip',
     title: '你已经是终身会员啦！',
     message: '无需参加本活动哦~',
     buttonText: '立即阅读',
     doneCloseDialog: false
   },
   [DIALOG_TYPE.ENDED]: {
     type: 'ended',
     title: '活动已结束',
     message: '快去APP首页参加其他精彩活动吧~',
     buttonText: '立即查看',
     doneCloseDialog: false
   },
   [DIALOG_TYPE.APP_UPGRAGE]: {
     type: 'app-upgrade',
     title: '版本过低',
     message: '请到应用市场更新您的应用',
     buttonText: '立即更新',
     doneCloseDialog: false
   },
   [DIALOG_TYPE.SUBVIP]: isAndroid && isPad ? {
     type: 'subvip',
     title: '暂不支持绘本/听书会员参与',
     message: '请至手机App端升级',
     buttonText: '我知道了',
     doneCloseDialog: false
   } : {
     type: 'subvip',
     title: '无法参加本次活动哦',
     message: ' 绘本/听书会员请升级VIP',
     buttonText: '立即升级',
     doneCloseDialog: false
   },
   [DIALOG_TYPE.WECHAT_OPEN]: {
     type: 'wechat-open',
     message: '当前环境不支持<br>请在微信内打开哦',
     doneCloseDialog: false,
     buttonText: '我知道了'
   }
 }
 
 /**
  * 显示弹窗
  * @param {Object|String} props 弹窗属性或弹窗类型
  * @property {Boolean} doneCloseDialog 点击确认按钮是否关闭弹窗
  * @property {String} type 弹窗类型 @see DIALOG_TYPE
  * @property {String} title 弹窗标题
  * @property {String} message 弹窗消息
  * @property {String} buttonText 按钮文案
  * @property {String} buttonClassName 按钮样式ClassName
  * @property {Boolean} showCloseButton 是否显示关闭弹窗
  * @property {Boolean} maskClickHide 点击遮罩关闭弹窗
  * @property {Function} onClose 关闭弹窗回调
  * @property {Function} onDone 点确认按钮回调
  *
  * @returns {Promise<Boolean>}
  */
  export function showTypedDialog (props) {
   return createDialog(props)
 }
 
 /**
  * 关闭当前弹窗
  */
 export function closeTypedDialog () {
   if (dialog) {
     dialog.close()
   }
 }
 
 TypedDialog.showTypedDialog = showTypedDialog
 TypedDialog.closeTypedDialog = closeTypedDialog
 TypedDialog.DIALOG_TYPE = DIALOG_TYPE
 
 export {
   TypedDialog
 }
 