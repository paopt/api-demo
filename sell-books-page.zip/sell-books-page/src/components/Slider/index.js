export { default as Slider } from './Slider.svelte'
export { default as SliderItem } from './SliderItem.svelte'
