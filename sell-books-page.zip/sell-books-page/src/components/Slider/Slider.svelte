<script>
  import { lory } from 'lory.js'
  import { onMount, onDestroy, createEventDispatcher } from 'svelte'

  const webviewInfo = /chrome\/([\d.]+)/i.exec(navigator.userAgent)
  const webviewVersion = (webviewInfo && webviewInfo[1]) ? webviewInfo[1] : '0.0.0'
  const webviewMajor = parseInt(webviewVersion)
  /**
   * 容器宽度
   * @svelte-prop {String} width
   */
  export let width = ''
  /**
   * 容器高度
   * @svelte-prop {String} height
   */
  export let height = ''
  export let slidesToScroll = 1
  export let infinite = 1
  export let enableMouseEvents = false
  export let rewind = false
  export let rewindPrev = false
  export let slideSpeed = 300
  export let rewindSpeed = 600
  export let snapBackSpeed = 200
  export let ease = 'ease'
  export let initialIndex = 0
  export let dots = false
  export let autoplay = false
  export let autoplayDelay = 3000

  // slider DOM实例
  let sliderEl
  // lory实例
  let slidesEl
  // slider 控制器
  let controller
  const dispatch = createEventDispatcher()

  export let selectedIndex = 0
  let pips = []
  $: if (sliderEl) {
    sliderEl.addEventListener('before.lory.init', handleSliderEvent)
    sliderEl.addEventListener('after.lory.init', handleSliderEvent)
    sliderEl.addEventListener('before.lory.slide', handleSliderEvent)
    sliderEl.addEventListener('after.lory.slide', handleSliderEvent)
    sliderEl.addEventListener('on.lory.resize', handleSliderEvent)
    sliderEl.addEventListener('before.lory.destroy', handleSliderEvent)
    sliderEl.addEventListener('after.lory.destroy', handleSliderEvent)
  }

  /**
   * 跳转到末子项目
   * @param {Number} index
   */
  export function go (index) {
    if (controller) {
      controller.slideTo(index)
    }
  }

  let autoplayTimer = 0

  function handleSliderEvent (event) {
    if (event.type === 'after.lory.init') {
      selectedIndex = 0
      const image = slidesEl.querySelector('img.lazy')

      if (image && image.src === ''){
        image.src = image.dataset.src
      }
    }
    if (event.type === 'before.lory.slide') {
      const nextElement = slidesEl.querySelectorAll('.js_slide')[event.detail.nextSlide]
      const image = nextElement && nextElement.querySelector('img.lazy')
      if (image && image.src === ''){
        image.src = image.dataset.src
      }
    }
    if (event.type === 'after.lory.slide') {
      selectedIndex = event.detail.currentSlide - 1

      if (autoplayTimer) {
        clearTimeout(autoplayTimer)
      }
      if (autoplay) {
        autoplayTimer = setTimeout(() => {
          controller.next()
        }, autoplayDelay)
      }
    }
    if (event.type === 'on.lory.resize') {
      selectedIndex = 0
      if (autoplayTimer) {
        clearTimeout(autoplayTimer)
      }
    }

    dispatch(event.type, event.detail)
  }

  let fixTouchStartX = 0
  let fixTouchStartY = 0
  function fixTouchMove (event) {
    const x = event.touches ? event.touches[0].clientX : event.clientX
    const y = event.touches ? event.touches[0].clientY : event.clientY

    if ((Math.abs(y - fixTouchStartY) - Math.abs(x - fixTouchStartX)) <= 0) {
      event.preventDefault()
      return
    }
  }

  function fixTouchStart (event) {
    fixTouchStartX = event.touches ? event.touches[0].clientX : event.clientX
    fixTouchStartY = event.touches ? event.touches[0].clientY : event.clientY
    return
  }

  onMount(() => {
    if (!width || !height) {
      const parentRect = sliderEl.parentElement.getBoundingClientRect()
      const styleSheet = window.getComputedStyle(sliderEl)
      const scaleRatio = parseFloat(styleSheet.width) / parentRect.width

      if (!width) {
        width = parentRect.width * scaleRatio + 'px'
      }
      if (!height) {
        height = parentRect.height * scaleRatio + 'px'
      }
    }
    pips = new Array(slidesEl.children.length).fill(0)

    controller = lory(sliderEl, {
      slidesToScroll,
      infinite,
      enableMouseEvents,
      rewind,
      rewindPrev,
      slideSpeed,
      rewindSpeed,
      snapBackSpeed,
      ease,
      initialIndex
    })

    if (autoplay) {
      autoplayTimer = setTimeout(() => {
        controller.next()
      }, autoplayDelay)
    }

    if (webviewInfo && webviewMajor <= 33) {
      sliderEl.addEventListener('touchmove', fixTouchMove)
      sliderEl.addEventListener('touchstart', fixTouchStart)
    }
  })

  onDestroy(() => {
    sliderEl.removeEventListener('before.lory.init', handleSliderEvent)
    sliderEl.removeEventListener('after.lory.init', handleSliderEvent)
    sliderEl.removeEventListener('before.lory.slide', handleSliderEvent)
    sliderEl.removeEventListener('after.lory.slide', handleSliderEvent)
    sliderEl.removeEventListener('on.lory.resize', handleSliderEvent)
    sliderEl.removeEventListener('before.lory.destroy', handleSliderEvent)
    sliderEl.removeEventListener('after.lory.destroy', handleSliderEvent)
    sliderEl.removeEventListener('touchmove', fixTouchMove)
    sliderEl.removeEventListener('touchstart', fixTouchStart)
    if (autoplayTimer) {
      clearTimeout(autoplayTimer)
    }
    controller.destroy()
  })
</script>

<div class="c-slider" style="width: {width};height: {height};" bind:this={sliderEl}>
  <div class="c-slider__frame js_frame">
    <ul class="c-slider__slides js_slides" bind:this={slidesEl}>
      <slot></slot>
    </ul>
  </div>
  {#if dots}
    <ul class="c-slider__dots">
      {#each pips as pip, index}
      <li on:click={() => go(index)} class="dot-item" class:is-active={selectedIndex === index}></li>
      {/each}
    </ul>
  {/if}
</div>

<style lang="scss" global>
  $component-name: 'c-slider';

  .#{$component-name} {
    &__frame {
      position: relative;
      width: 100%;
      overflow: hidden;
    }

    &__slides {
      display: flex;
      flex-wrap: nowrap;

      > * {
        min-width: 100%;
        flex-shrink: 0;
        flex-grow: 1;
        flex-basis: 100%;
      }
    }

    &__dots {
      position: absolute;
      bottom: 0.14rem;
      display: flex;
      left: 0;
      right: 0;
      justify-content: center;
      align-items: center;

      .dot-item {
        margin: 0 4px;
        width: 6px;
        height: 6px;
        background-color: #f1cebc;
        border-radius: 50%;

        &.is-active {
          background-color: #9b462e;
        }
      }
    }
  }
</style>
