<li class="c-slider-item js_slide"><slot></slot></li>

<style lang="scss" global>
  .c-slider-item {
    min-width: 100%;
    flex-shrink: 0;
    flex-grow: 1;
    flex-basis: 100%;
  }
</style>
