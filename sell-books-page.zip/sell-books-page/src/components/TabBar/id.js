let id = 1;

export default function getId() {
  return `svelte-tabs-${id++}`;
}