<script>
  import { getContext, onMount, tick, createEventDispatcher } from "svelte"
  import getId from "./id"
  import { TABS } from "./Tabs.svelte"

  const dispatch = createEventDispatcher()

  let tabEl;
  const tab = {
    id: getId(),
  };
  const { registerTab, registerTabElement, selectTab, selectedTab, controls } =
    getContext(TABS)
  let isSelected
  $: isSelected = $selectedTab === tab
  registerTab(tab)

  const handleClick = (tab) => {
    selectTab(tab)
    dispatch('tab-bar-click', tab)
  }

  onMount(async () => {
    await tick()
    registerTabElement(tabEl)
  });
</script>
{#if isSelected}
  <div class="svelte-tab-bg {$selectedTab.id}-bg"></div>
{/if}
<li
  bind:this={tabEl}
  role="tab"
  id={tab.id}
  aria-controls={$controls[tab.id]}
  aria-selected={isSelected}
  tabindex={isSelected ? 0 : -1}
  class:svelte-tabs__selected={isSelected}
  class="svelte-tabs__tab {isSelected ? $selectedTab.id : ''}-selected"
  on:click={() => handleClick(tab)}
>
  <slot />
</li>

<style lang="scss">
  .svelte-tab-bg {
    width: 100%;
    height: 1.45rem;
    position: absolute;
    background-repeat: no-repeat;
    background-size: cover;
  }
  .svelte-tabs-1-bg {
    background-image: url(//cdn.hhdd.com/frontend/as/i/084b24c3-f7cf-5707-9534-965a40bf9d84.png);
  }
  .svelte-tabs-2-bg {
    background-image: url(//cdn.hhdd.com/frontend/as/i/d5092dfd-a8c0-5930-970a-05a3f01cdf3f.png);
  }
  .svelte-tabs__tab {
    color: white;
    position: relative;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1;
    transition: 0.3s all;
    margin-bottom: 0.2rem;
  }
  .svelte-tabs__tab:focus {
    outline: none;
  }
</style>
