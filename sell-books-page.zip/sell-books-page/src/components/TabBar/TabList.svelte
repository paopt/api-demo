<script>
  let panelEl = null;
  export let sticky = false
  /**
   * 获取组件位置信息
   *
   * @returns {Rectangle}
   */
  export function getBoundingClientRect() {
    return panelEl ? panelEl.getBoundingClientRect() : null;
  }
</script>

<ul role="tablist" class="svelte-tabs__tab-list is-{sticky ? 'sticky' : ''}" bind:this={panelEl}>
  <slot />
</ul>

<style lang="scss">
  @import '../../../styles/variables';
  .svelte-tabs__tab-list {
    margin: 0;
    padding: 0;
    background: #50C6FF;
    height: 1.45rem;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    overflow: hidden;
    position: relative;
    &.is-sticky {
      position: fixed;
      top: 0;
      width: 7.5rem;
      z-index: 5;
      transition: all 0.8s;

      @media #{$media_query-notch} {
        overflow: visible;
        background-color: #1E8FFD;
        padding-top: calc(0.3rem + constant(safe-area-inset-top));
        padding-top: calc(0.3rem + env(safe-area-inset-top));
      }
    }
  }
</style>
