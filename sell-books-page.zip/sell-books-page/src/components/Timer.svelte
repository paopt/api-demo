<script>
  import { onMount, onDestroy, createEventDispatcher } from 'svelte'

  const requestAnimationFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame
  const cancelAnimationFrame = window.cancelAnimationFrame || window.webkitCancelAnimationFrame

  const dispatch = createEventDispatcher()
  /**
   * 组件样式
   * @svelte-prop {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 倒计时剩余时间, 单位 ms
   * @svelte-prop {Number} deadline
   */
  export let deadline = 0
  /**
   * 是否显示全部信息
   * @svelte-prop {Boolean} fullInfo
   */
  export let fullInfo = false
  /**
   * 自定义格式显示内容, 默认为空时，使用固定格式显示
   * @svelte-prop {String} format
   */
  export let format = ''
  /**
   * 是否显示毫秒数据
   * @svelte-prop {Boolean} milesecond
   */
  export let millisecond = false

  $: if (deadline > 0 && deadline !== viewData.timestamp && !handleTimer) {
    start()
  }

  /**
   * 显示信息
   */
  let viewData = {
    timestamp: millisecond ? (Math.floor(deadline / 100) * 100) : (Math.floor(deadline / 1000) * 1000),
    day: 0,
    hour: 0,
    minute: 0,
    second: 0,
    millisecond: 0
  }

  $: formatHtml = format ? format.replace(/(D+|H+|M+|S+|m+)/g, (_, key) => {
      let value = null
      if (key.charAt(0) === 'D') {
        value = viewData.day
      } else if (key.charAt(0) === 'H') {
        value = viewData.hour
      } else if (key.charAt(0) === 'M') {
        value = viewData.minute
      } else if (key.charAt(0) === 'S') {
        value = viewData.second
      } else if (key.charAt(0) === 'm') {
        value = viewData.millisecond
      }
      return value !== null ? `<span class="c-timer__zone">${leftPaddingZero(value, key.length)}</span>` : ''
    }) : ''

  /**
   * 倒计时时钟
   */
  let handleTimer = 0
  let rAFHandler = 0

  /**
   * 设置倒计时
   */
  function setCountdown () {
    if (handleTimer) {
      clearTimeout(handleTimer)
      handleTimer = 0
    }

    const interval = millisecond ? 100 : 1000
    handleTimer = setTimeout(() => {
      if (viewData.timestamp <= 0) {
        if (handleTimer) {
          clearTimeout(handleTimer)
          handleTimer = 0
        }
        dispatch('end')
        return
      }

      viewData.timestamp -= interval

      if (viewData.timestamp < 0) {
        viewData.timestamp = 0
      }

      rAFHandler = requestAnimationFrame(() => {
        calcTimesRemain()
        setCountdown()
      })
    }, interval)
  }

  /**
   * 计算格式化时间数据
   */
  function calcTimesRemain () {
    let _timestamp = viewData.timestamp / 1000
    let day = Math.floor(_timestamp / 3600 / 24)
    viewData.day = day > 0 ? day : 0
    let hour = Math.floor(_timestamp / 3600 % 24)
    viewData.hour = hour > 0 ? hour : 0
    let minute = Math.floor(_timestamp / 60 % 60)
    viewData.minute = minute > 0 ? minute : 0
    let second = Math.floor(_timestamp % 60)
    viewData.second = second > 0 ? second : 0
    let millis = 0
    if (millisecond) {
      millis = Math.floor(viewData.timestamp % (24 * 3600) / 100)
      viewData.millisecond = Math.round((millis > 0 ? millis : 0) % 10)
    }

    dispatch('update', {
      timestamp: viewData.timestamp,
      day: leftPaddingZero(day, 2),
      hour: leftPaddingZero(hour, 2),
      minute: leftPaddingZero(minute, 2),
      second: leftPaddingZero(second, 2),
      millisecond: leftPaddingZero(millis, 2)
    })
  }

  function leftPaddingZero (num, length) {
    return (Array(length).join(0) + num).slice(-length)
  }

  /**
   * 开始倒计时
   */
  export function start () {
    dispatch('start')
    viewData.timestamp = millisecond ? (Math.floor(deadline / 100) * 100) : (Math.floor(deadline / 1000) * 1000)
    calcTimesRemain()
    setCountdown()
  }

  /**
   * 停止倒计时
   */
  export function stop () {
    if (handleTimer) {
      clearTimeout(handleTimer)
      handleTimer = 0
    }
    cancelAnimationFrame(rAFHandler)
  }

  onMount(() => {
    start()
  })

  onDestroy(() => {
    stop()
  })
</script>

<div class="c-timer {className}">
  <slot name="before"></slot>
  {#if format}
    {@html formatHtml}
  {:else if fullInfo}
    <span class="c-timer__zone">{leftPaddingZero(viewData.day, 2)}</span
    >天<span class="c-timer__zone">{leftPaddingZero(viewData.hour, 2)}</span
    >时<span class="c-timer__zone">{leftPaddingZero(viewData.minute, 2)}</span
    >分<span class="c-timer__zone">{leftPaddingZero(viewData.second, 2)}</span
    >秒
  {:else if viewData.day <= 0}
    <span class="c-timer__zone">{leftPaddingZero(viewData.hour, 2)}</span
    >时<span class="c-timer__zone">{leftPaddingZero(viewData.minute, 2)}</span
    >分<span class="c-timer__zone">{leftPaddingZero(viewData.second, 2)}</span
    >秒
  {:else}
    <span class="c-timer__zone">{leftPaddingZero(viewData.day, 2)}</span
    >天<span class="c-timer__zone">{leftPaddingZero(viewData.hour, 2)}</span
    >时<span class="c-timer__zone">{leftPaddingZero(viewData.minute, 2)}</span
    >分
  {/if}
</div>

<style lang="scss" global>
  $component-name: 'c-timer';

  .#{$component-name} {
    &__zone {
      word-spacing: 0.04em;
    }
  }
  /* .#{$component-name} {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #262727;
    font-size: 0.26rem;
    line-height: 0.40rem;
    height: 0.4rem;
    text-align: center;
    font-weight: 400;
    vertical-align: middle;

    &__zone {
      background-color: #FF2C36;
      color: #fff;
      border-radius: 0.12rem;
      display: inline-block;
      width: 0.4rem;
      height: 0.4rem;
      line-height: 0.42rem;
      vertical-align: middle;
      text-align: center;
      margin: 0 0.04rem;
    }
  } */
</style>
