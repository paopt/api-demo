<Popup class="c-rulesdlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-rulesdlg__body" on:touchmove|stopPropagation|preventDefault bind:this={rulesBodyEl}>
    <div class="close" on:click={close}></div>
    {#if title}<div class="title">{title}</div>{/if}
    <div class="c-rulesdlg__content" bind:this={contentEl}><div>{@html content}</div></div>
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import IScroll from 'iscroll/build/iscroll-lite'
  import { Popup } from '@kada/svelte-activity-ui'
  import { promiseDelay } from '@/utils/promisify'

  const dispatch = createEventDispatcher()
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 通用弹窗标题
   * @type {String} title
   */
  export let title = '活动规则'
  /**
   * 通用弹窗信息
   * @type {String} message
   */
  export let content = `
    <ul>
      <li>1. 活动时间：2021年6月7日-2021年6月20日；</li>
      <li>2. 活动期间，现金券仅支持在活动页购买使用，当日有效；</li>
      <li>3. 订单支付成功后，VIP会员权益自动生效，全平台带“VIP”标识内容在会员有效期内免费使用；</li>
      <li>4. VIP会员属于虚拟产品，不支持退换，敬请理解；</li>
      <li>5. 本活动每位用户仅可参与一次，同一微信号、手机号视为同一账号；</li>
      <li>6. 如有疑问请联系<a href="https://h5.hhdd.com/n/h5-macqueen/service-center.html#/home?openChat=1">在线客服</a>，我们将尽快为您解决；</li>
      <li>7. 活动最终解释权归KaDa阅读所有。</li>
    </ul>
    <p>*本活动与苹果公司无关</p>
  `

  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = false

  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  let _content = ''

  $: if (content !== _content) {
    promiseDelay(600).then(() => {
      if (!contentScroll && contentEl) {
        contentScroll = new IScroll(contentEl, {
          disablePointer: false,
          click: true,
          scrollY: true,
          scrollX: false,
          disableMouse: true,
          bindToWrapper: true
        })
      }

      if (contentScroll) {
        contentScroll.refresh()
      }
    })
  }

  let popupEl
  // 活动规则弹窗滚动内容
  let rulesBodyEl
  // 内容模块
  let contentEl
  // 内容区域滚动示例
  let contentScroll

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  function close() {
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  onMount(() => {
    popupEl && popupEl.show()
  })

  onDestroy(() => {
    if (contentScroll) {
      contentScroll.destroy()
      contentScroll = null
    }
  })
</script>

<style lang="scss">
  $component-name: 'c-rulesdlg';

  :global {
    .#{$component-name} {
      z-index: 999;
      &__body {
        position: relative;
        width: 7rem;
        height: 9rem;
        top: -0.4rem;
        background: url('//cdn.hhdd.com/frontend/as/i/db14cb5a-5ce1-51e6-a8ee-8a0b3ba5c230.png') no-repeat 50% 0 / 100% 100%;
        font-family: PingFangSC-Medium,PingFang SC;
        z-index: 999;

        .title {
          position: absolute;
          top: 0.66rem;
          left: 1rem;
          right: 1rem;
          text-align: center;
          font-size: 0.34rem;
          font-family: PingFangSC-Medium,PingFang SC;
          font-weight: 500;
          color: #fff;
          line-height: 1;
        }

        .close {
          position: absolute;
          width: 0.9rem;
          height: 0.9rem;
          left: 50%;
          bottom: -.2rem;
          margin-left: -0.45rem;
          background: {
            repeat: no-repeat;
            position: 50% 50%;
            size: 100% 100%;
            image: url('//cdn.hhdd.com/frontend/as/i/ce360163-bc41-5954-9b20-732b2503e620.png');
          }
          z-index: 99;
        }
      }

      &__content {
        position: absolute;
        top: 1.52rem;
        left: 0.35rem;
        right: 0.35rem;
        bottom: 0.35rem;
        // font-size: 0.22rem;
        font-size: 0.26rem;
        font-weight: 400;
        color: #7F584C;
        // line-height: 0.3rem;
        line-height: 0.4rem;
        overflow: hidden;
        // padding: 0 .6rem;
        // padding: 0.1rem .8rem;
        padding: 0.05rem .8rem 0.1rem;
        max-height: 5.8rem;


        > div {
          height: max-content;
          background: rgba(0, 0, 0, 0);
        }

        :global(li) {
          margin-bottom: 0.1rem;
        }

        :global(p) {
          margin: 0.1rem 0;
        }
      }
    }
  }
</style>
