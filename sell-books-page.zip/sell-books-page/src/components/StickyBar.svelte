<script>
  import { createEventDispatcher } from 'svelte'
  import { deviceInfo } from '@kada/library/src/device'

  const dispatch = createEventDispatcher()

  /**
   * 组件样式
   * @svelte-prop {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 自定义内联样式
   * @svelte-prop {String} style
   */
  export let style = ''

  /**
   * 组件样式主题
   * @svelte-prop {String} theme
   */
  export let theme = ''

  /**
   * 停靠栏大小
   * @svelte-prop {String} barClass
   */
  export let barClass = ''

  /**
   * 是否显示StickyBar
   * @svelte-prop {Boolean} show
   */
  export let show = false

  /**
   * 选中的tab序号
   * @svelte-prop {Number} selected
   */
  export let selected = 0

  let stickyBarEl = null
  const tabItemEls = []

  /**
   * 课程列表数据
   * @svelte-prop {Array} dataSource
   */
  export let dataSource = [
    {
      link: '#one',
      title: '终身<br>会员'
    },
    {
      link: '#two',
      title: '神奇<br>的人体'
    },
    {
      link: '#three',
      title: '这是<br>什么'
    },
    {
      link: '#four',
      title: '恐龙<br>大冒险'
    },
    {
      link: '#five',
      title: '地球<br>环游记'
    },
    {
      link: '#six',
      title: '地球<br>环游记'
    }
  ]
  /**
   * 获取组件位置信息
   *
   * @returns {Rectangle}
   */
  export function getBoundingClientRect() {
    return stickyBarEl ? stickyBarEl.getBoundingClientRect() : null
  }
  /**
   * TabItem点击事件处理
   */
  const handleTabItemClick = (event) => {
    const target = event.currentTarget
    const { index, link } = target.dataset
    selected = parseInt(index, 10)

    dispatch('tab-click', { index: selected, link })
  }
</script>

<div class={[
    'c-stickybar',
    (className || ''),
    theme ? `theme-${theme}` : ''
  ].join(' ')}
  style={style || ''}
  class:is-show={show}
  class:is-ipad={deviceInfo.ipad}
>
  <div class="c-stickybar__bar {barClass}" bind:this={stickyBarEl}>
  {#each dataSource as item, index}
    <div class="c-stickybar__tab" data-link={item.link || ''} class:is-active={index === selected} bind:this={tabItemEls[index]} data-index={index} on:click={handleTabItemClick}>
      <div style={`background-image:url(${index === selected ? item.active : item.normal})`}>

      </div>
    </div>
  {/each}
  </div>
</div>

<style lang="scss">
  @import '../../../styles/variables';
  $component-name: 'c-stickybar';

  $transition-duration: 0.25s;

  .#{$component-name} {
    position: absolute;
    left: 0;
    right: 0;
    top: 10rem;
    padding: 0.3rem 0;
    align-items: center;
    transition: opacity 0.25s ease;
    opacity: 1;
    z-index: 5;
    &.is-ipad {
      padding: 0.48rem 0 0.2rem 0;
    }
    &.wechat-bar {
      top: 10.5rem;
    }
    &__bar {
      position: relative;
      display: flex;
      flex-wrap: nowrap;
      width: 7.50rem;
      height: 1.25rem;
      margin: 0 auto;
      padding: 0 0.15rem;
      justify-content: space-between;
      align-items: center;
      background: url(//cdn.hhdd.com/frontend/as/i/16c54747-5024-5820-a07e-84420112b81b.png) no-repeat;
      background-size: cover;
    }

    &__tab {
      position: relative;
      z-index: 3;

      &:last-child {
        margin-right: 0;
      }
      div {
        width: 1.16rem;
        height: 0.84rem;
        background-repeat: no-repeat;
        background-size: cover;
      }

      &.is-active {
        div {
          width: 1.2rem;
          height: 1.34rem;
        }
      }
    }

    &.is-show {
      position: fixed;
      top: 1.12rem;
      @media #{$media_query-notch} {
        top: calc(.72rem + constant(safe-area-inset-top));
        top: calc(.72rem + env(safe-area-inset-top));
      }
      
    }
  }
</style>
