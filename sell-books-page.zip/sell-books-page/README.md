# sell-books-page

书单营销配置售卖活动

## 页面地址

 - 测试环境 `http://10.0.10.61:38890/wepage/sell-books-page/index.html#/home/787631814`
 - 预发环境 `http://h5.hhdd.com/wepage-staging/sell-books-page/index.html#/home/787631814`
 - 生产环境 `https://h5.hhdd.com/w/sell-books-page/index.html#/home/787631814`

建议运营配置地址：

 - 测试环境：kada://openurl?url=http://10.0.10.61:38890/wepage/sell-books-page/index.html#/home/787631814
 - 预发环境：kada://openurl?url=http://h5.hhdd.com/wepage-staging/sell-books-page/index.html#/home/787631814
 - 生产环境：kada://openurl?url=https://h5.hhdd.com/w/sell-books-page/index.html#/home/787631814


## 项目相关文档

- [TAPD需求文档](https://www.tapd.cn/20723331/prong/stories/view/1120723331001019630)
- [蓝湖设计稿](https://lanhuapp.com/web/#/item/project/stage?pid=d87e4afc-f0bc-474c-af5a-668770c7fc81&image_id=cf39e978-0aaa-4a21-914e-8721a6bf0096&tid=d5158442-7870-479c-8b14-41f86d5f899b)
- [服务端接口文档](http://10.0.10.52:8090/pages/viewpage.action?pageId=41058484)
