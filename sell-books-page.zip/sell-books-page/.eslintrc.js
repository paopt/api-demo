module.exports = {
  parser: '@babel/eslint-parser',
  parserOptions: {
    ecmaVersion: 2019,
    sourceType: 'module'
  },
  env: {
    es6: true,
    node: true,
    browser: true
  },
  plugins: [
    'svelte3',
    'standard'
  ],
  overrides: [
    {
      files: ['*.svelte'],
      processor: 'svelte3/svelte3'
    }
  ],
  rules: {
    'no-console': 'off',
    'no-debugger': 'error'
  },
  settings: {
    'import/extensions': ['.js', '.jsx'],
    "svelte3/ignore-styles": () => true
  },
  globals: {
    __ENV_CONFIG__: true
  }
}
