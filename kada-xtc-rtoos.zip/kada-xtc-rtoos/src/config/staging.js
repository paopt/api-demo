// 主服务接口BaseUrl
export const apiBaseUrl = 'http://pre-mini.hhdd.com'

// 服务器接口版本号
export const apiVersion = '7.1.0'

// SecretDevice环境配置 1 正式，2 预发， 0 测试
export const secretDeviceEnv = 1

export const loginUrl = 'http://h5.hhdd.com/staging/h5-xtc-rtos/index.html#/login?t='  //登录地址

export const vipcenterUrl = 'http://h5.hhdd.com/staging/h5-xtc-rtos/index.html/#/vipcenter'  //开通VIP