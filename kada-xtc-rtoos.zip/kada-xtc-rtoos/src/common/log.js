"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var _system_fetch_1 = __importDefault(require("@system.fetch"));
var _system_app_1 = __importDefault(require("@system.app"));
var throttleActions = [];
var throttle = function (action, delay) {
    if (delay === void 0) { delay = 1000; }
    throttleActions.push(action);
    if (throttleActions.length > 1) {
        return function () { };
    }
    return function () {
        setTimeout(function () {
            var lastAction = throttleActions[throttleActions.length - 1];
            lastAction && lastAction();
            throttleActions = [];
        }, delay);
    };
};
var logs = [];
function default_1(_a) {
    var ip = _a.ip, id = _a.id,  _b = _a.sendDelay, sendDelay = _b === void 0 ? 1000 : _b;
    if (!ip || !id) {
        return;
    }
    function sendMessage() {
        if (logs.length === 0 || id === '') {
            return;
        }
        _system_fetch_1.default.fetch({
            url: "http://".concat(ip, ":4888/save"),
            method: "POST",
            header: { "Content-Type": "application/json" },
            data: JSON.stringify({ id: id, logs: logs }),
            responseType: "json",
        })
        logs = [];
    }
    function parseOriginLog(log) {
        return log.map(function (r) {
            return typeof r === 'string' ? r : JSON.stringify(r);
        });
    }
    console = (function (origConsole) {
        return __assign(__assign({}, origConsole), { log: function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                origConsole && origConsole.log && origConsole.log.apply(origConsole, parseOriginLog(args));
                logs.push({
                    type: 'log',
                    data: JSON.stringify(args)
                });
                throttle(sendMessage, sendDelay)();
            }, warn: function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                origConsole && origConsole.warn && origConsole.warn.apply(origConsole, parseOriginLog(args));
                logs.push({
                    type: 'warn',
                    data: JSON.stringify(args)
                });
                throttle(sendMessage, sendDelay)();
            }, error: function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                origConsole && origConsole.error && origConsole.error.apply(origConsole, parseOriginLog(args));
                logs.push({
                    type: 'error',
                    data: JSON.stringify(args)
                });
                throttle(sendMessage, sendDelay)();
            } });
    })(console);
}
exports.default = default_1;
