## 说明

目前音频需要缓存后才可播放，边下边播版本内测中，后续可支持mp3格式音频边下边播

## 音频加载逻辑

1. 加载音频A

```
audio.src = linkA; audio.play();
此时开始下载音频A，下载完成后触发事件回调，顺序为：
    1. onloadeddata：第一次获取到音频数据；可以做结束loading操作
    2. onplay：调用audio.play且音频开始播放时回调；可以做播放暂停图标切换
    3. ontimeupdate：音频播放后每秒回调一次，数据为{"duration":30(总时长),"currentTime":4(当前时长)}；可以做动态播放进度条
    4. onended：当前音频播放结束后回调；可以做续播，下一首操作
```

2. 音频A切换为音频B

```
audio.stop(); 停止当前音频播放，此时触发onstop；可以做数据上报等处理
audio.src = linkB；audio.play()；此时开始下载音频B，同上文
```

3. 用户主动触发

```
audio.pause()；暂停操作，触发onpause；可以做播放暂停图标切换
audio.play()；播放操作，触发onplay；可以做播放暂停图标切换
```
