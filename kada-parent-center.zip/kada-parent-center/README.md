# kada-parent-center

> KaDa阅读家长中心

## 页面地址

**阅读数据**

 - 测试环境 `http://10.0.10.61:38890/kada-parent-center/index.html`
 - 预发环境 `http://h5.hhdd.com/staging/kada-parent-center/index.html`
 - 生产环境 `https://h5.hhdd.com/n/kada-parent-center/index.html`

**参数说明**
 
 - 
## 项目目录说明

```sh
.
├── config
├── public
├── scripts
├── src
│   ├── components
│   ├── lib
│   ├── services
│   ├── skeleton
│   ├── styles
│   ├── utils
│   ├── views
│   ├── App.svelte
│   └── main.js
├── README.md
├── babel.config.js
├── jsconfig.json
├── package.json
├── postcss.config.js
└── svelte.config.js
```

## 项目相关文档

- [需求文档](https://www.tapd.cn/68172412/prong/stories/view/1168172412001020362?url_cache_key=from_url_story_list_c257eb0185dd6cf899404612147b7e9a&action_entry_type=stories)
- [打点文档](https://teamtgm.feishu.cn/sheets/shtcn6BhnGhdChk3uLZx1WgUEWc)
- [蓝湖设计稿](https://lanhuapp.com/web/#/item/project/detailDetach?pid=6bf190c5-dc04-4d09-bb65-489c2b3d7c5a&image_id=b769ce8e-9e86-433a-8854-4e98a3d9ef0d&project_id=6bf190c5-dc04-4d09-bb65-489c2b3d7c5a&fromEditor=true&type=image)
- [日报接口]：@冯琪

## 项目开发

性能优化仅在 `staging` 和 `production` 中实现，`test` 不做性能优化

依赖安装

```bash
npm install
```

本地开发

```bash
npm run dev
```

## 自动构建部署

功能开发使用在 `master` 上面拉取 `feature/xxx-feature` (xxx-feature代表功能英文描述)，

热修复在 `master` 上面拉取 `hotfix/xxx-bug`;

开发完成后，在Gitlab上面创建 `MR(Merge Request)`; 发送到组群里面CodeReview, 如果没问题 `Merge`

 - MR 合并到 `develop` 分支时，自动部署到 `测试环境`
 - MR 合并到 `release` 分支时，自动部署到 `预发环境`
   > 合并release之前，必须修改版本号，或执行 `npm run release` 选择版本号
 - MR 合并到 `master` 分支并打相应 `Tag`，自动部署到 `线上环境`


## 本地手动构建部署

> 不推荐本地手动构建部署，目前已经完成了CI/CD配置，请通过 MR 进行构建部署

### 项目构建

```bash
npm run build:test            ## 编译出测试环境项目包
npm run build:staging         ## 编译出预发环境项目包
npm run build:prod            ## 编译出生产环境项目包
```

### 项目部署

代码部署到相应环境

```bash
npm run deploy:test           ## 将build生成代码 部署到测试环境
npm run deploy:staging        ## 将build生成代码 部署到预发环境
npm run deploy:prod           ## 将build生成代码 部署到生产环境
```

## 发布上线

把生产环境地址中页面（伪链接）指向相应 `production` 版本中的 `html`

```bash
npm run symlink
```

**注意**：项目需按版本控制，每次发布新版本需要更新 `package.json` 中的 `version`；版本参照 [semver规范](https://semver.org/lang/zh-CN/)

**重构更改版本号`第一位`，新增页面更改`第二位`，bug修复更改`第三位`**

项目部署是在相应的环境目录下面 `staging` (预发环境) 和 `production` (生产环境) 添加一个项目目录，使用的是 `package.json` 中的 `name` 字段；

在 `production` 环境下部署时会生成此项目的版本目录 `version` 的值，正式发布上线需要执行 `yarn run symlink` 把生产环境地址的（伪链接）指向当前版本下面的 `html` 文件

### 代码静态检查

```bash
npm run lint
```

### 规范化 `git commit`

```bash
npm run commit
```

### 版本号修改

项目发布前必须修改 `package.json` 版本号，如果不知道如何定义版本号可以执行如下命令：

```bash
npm run release
```