<div class="o-center">
  <!-- {#if openId} -->
    <UserInfoCenter 
      userInfo={userInfo}
      on:nav-click={handleNavClick}
    />
    <UserInfoCard
      userInfo={userInfo}
      textInfo={textInfo}
      on:nav-click={handleNavClick}
    />
    <ReadHistory
      readData={readInfo}
      on:nav-click={handleNavClick}
    />
    <ParentMangement
      blockCount={userInfo?.blockCount || 0}
      eyeCareUseTime={userInfo?.eyeCareUseTime || 0}
      on:nav-click={handleNavClick}
    />
    <Othermanagement
      on:nav-click={handleNavClick}
    />
    <EditionNumber userId={userInfo?.userId || ''}/>
  <!-- {/if} -->
  
</div>
<script>
  import { navigateTo } from '@kada/yrv'
  import UserInfoCenter from '@/components/UserInfoCenter.svelte'
  import UserInfoCard from '@/components/UserInfoCard.svelte'
  import ReadHistory from '@/components/ReadHistory.svelte'
  import ParentMangement from '@/components/ParentMangement.svelte'
  import Othermanagement from '@/components/OtherManagement.svelte'
  import EditionNumber from '@/components/EditionNumber.svelte'
  import { showDialog } from '@/components/RenewDialog'
  import { profile } from '@/services/service'
  import { getUserInfo, isLogin, logout } from '@/services/user'
  import { openLogin } from '@/lib/wechat'
  import qs from 'qs'
  import URLParser from '@/lib/urlParser'
  import { getSimgleImge } from '@/services/level'
  import config from '@/lib/config'
  import { getCookie, removeCookie } from 'tiny-cookie'
  import { toast } from '@kada/svelte-activity-ui'
  import { formatDate } from '@kada/library/utils/datetime'
  import * as storage from '@/lib/storage'
  import { WX_GZH_LIST } from './help'
  import { sendBehavior } from '@/lib/analytics'

  const { customCenterUrl, blockList, eyecare, aboutKada, env } = config

  let locationFrom = ''

  const reloadRedirct = () => {
    const parsed = new URLParser(location.href)
    let { openId = '', from = '' } = parsed.query
    const pageQuery = qs.parse(location.search, {
      ignoreQueryPrefix: true
    })
    
    return {
      code: pageQuery.code,
      openId: openId,
      from
    }
  }

  const handleNavClick = (e) => {
    if (!isLogin()) {
      return goLogin()
    }

    const { detail } = e

    const NAV_LINK_METHODS = {
      'eyecare': () => {
        sendBehavior('ac_200200_4', { from: locationFrom })
        setBackFlag()
        location.href = eyecare
      },
      'blockList': () => {
        sendBehavior('ac_200200_5', { from: locationFrom })
        setBackFlag()
        location.href = blockList
      },
      'order': () => {
        sendBehavior('ac_200200_6', { from: locationFrom })
        navigateTo('/order')
      },
      'services': () => {
        sendBehavior('ac_200200_2', { from: locationFrom })
        location.href = customCenterUrl
      },
      'about': () => {
        sendBehavior('ac_200200_3', { from: locationFrom })
        location.href = aboutKada
      },
      'level': () => {
        sendBehavior('ac_200200_8', { from: locationFrom })
        navigateTo('/level')
      },
      'login': () => {

      },
      'outLogin': () => {
        sendBehavior('ac_200200_9', { from: locationFrom })
        sendBehavior('pgv_200500_1', { from: locationFrom })
        showDialog({
          onConfirm: async () => {
            sendBehavior('ac_200500_1', { from: locationFrom })
            if (getCookie('_HHDD_')) {
              // removeCookie('_HHDD_')
              const res = await logout()
              if (res.code === 200) {
                location.reload()
              }
            }
          }
        })
      
      },
      'report': () => {
        sendBehavior('ac_200200_7', { from: locationFrom })
        if (readInfo !== '{}' && (readInfo?.todayReadTime || readInfo?.weekReadCount || readInfo?.weekReadTime)) {
          const { currentTime } = userInfo
          const date = formatDate(currentTime, 'YYYY-MM')

          const ENV_HOST = {
            development: 'http://10.0.10.61:38890/month-report/index.html#/report',
            test: 'http://10.0.10.61:38890/month-report/index.html#/report',
            staging: 'http://h5.hhdd.com/staging/month-report/index.html#/report',
            production: 'https://h5.hhdd.com/n/month-report/index.html#/report'
          }

          const { channelId } = WX_GZH_LIST[storage.get('from')]

          location.href = `${ENV_HOST[env]}?date=${date}&channelId=${channelId}`
        } else {
          toast('无阅读记录，快让宝贝去阅读吧～')
        }
      }
    }

    NAV_LINK_METHODS[detail]()

    console.log(e)
  }
  const goLogin = () => {
    navigateTo('/login')
  }
  
  let userInfo = {}
  let readInfo = {}
  let textInfo = {}

  let pageShow = false

  const getPageData = async () => {

    const { code, openId, from } = await reloadRedirct()

    locationFrom = from || storage.get('from')

    sendBehavior('pgv_200200_1', { from: locationFrom })
  
    if (!code && !openId) {
      return openLogin()
    }
    // 页面请求参数 是否有cookie的时候页面状态
    // vipStatus
    const isLoginFlag = await isLogin()
    if (isLoginFlag) {
      const [ readDataInfo, userDataInfo, single ] = await Promise.all([profile(), getUserInfo(), getSimgleImge()])
      userInfo = userDataInfo
      readInfo = readDataInfo.data
      textInfo = single?.data.length ? single.data[0] : {}
      // pageShow = true
    }
    
  }
  getPageData()

  const getBackKey = () => `KADA_CENTER_TO_KADA_ME`
  const setBackFlag = () => sessionStorage.setItem(getBackKey(), 1)
  const getBackFlag = () => {
    const flag = +sessionStorage.getItem(getBackKey())
    if (flag) {
      sessionStorage.removeItem(getBackKey())
    }
    return !!flag
  }

  window.onpageshow = (event) => {
    console.log('window.onpageshow')
    if (getBackFlag()) {
      getPageData()
    }
  }

  document.title = '家长中心'

</script>
<style>
  .o-center {
    background: #F5F7FA;
  }
</style>