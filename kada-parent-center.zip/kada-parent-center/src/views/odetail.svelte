<div class="o-odetail">
  {#if pageShow}
    <div class="o-odetail__item">
        <div class="o-odetail__item-info">
        <div class="cover">
            <img src={orderDataInfo?.coverUrl || WECHAT_PAY_INFO_COVER_URL} alt="" srcset="">
        </div>
        <div class="info">
            <div class="produce-name">{orderDataInfo.productName}</div>
            <div class="timeline">
            {#if !orderDataInfo.status && orderDataInfo?.expireTime > 0}
                <Timer deadline={orderDataInfo?.expireTime} on:end={getOrderData} format={'HH:MM:SS'}>
                <span class="before" slot="before">等待付款：</span>
                </Timer>
            {/if}
            </div>
            <div class="price">¥{orderDataInfo.orderPrice / 100}</div>
        </div>
        </div>
        <div class="o-odetail__price">
          <span>实际支付：</span>
          <span>¥{orderDataInfo.status ? orderDataInfo.payPrice / 100 : orderDataInfo.orderPrice / 100}</span>
        </div>
        <!-- <div class="o-odetail__item-time">
        <span>创建时间</span>
        <span>待支付</span>
        </div> -->
    </div>
    <div class="o-odetail__item o-odetail__number" style="margin-top: .24rem;">
      <p>订单号：{orderDataInfo.orderNo}</p>
      <p>创建时间：{formatDate(orderDataInfo.createTime, 'YYYY-MM-DD HH:mm:ss')}</p>
      {#if !orderDataInfo.status}
        <div class="btn" on:click={payStatusOrder}>去支付</div>
      {/if}
        
       <div class="btn services" on:click={goServices}>联系客服</div>
    </div>
  {/if}
</div>
<script>
import { navigateTo } from '@kada/yrv'
import { orderInfo } from '@/services/service'
import { debounce } from '@/utils/throttle'
import { payOrder, WECHAT_PAY_INFO_COVER_URL } from '../app'
import { Timer, toast } from '@kada/svelte-activity-ui'
import URLParser from '@/lib/urlParser'
import { formatDate } from '@kada/library/utils/datetime'
import config from '@/lib/config'
import { sendBehavior } from '@/lib/analytics'
import * as storage from '@/lib/storage'

const from = storage.get('from')

const { customCenterUrl } = config

let orderDataInfo = {}
let pageShow = false

const parsed = new URLParser(location.href)
let { orderId = '' } = parsed.query

console.log(orderId)
const getOrderData = async () => {
  sendBehavior('pgv_200700_1', { from })
  try {
    const { data: orderData, code } = await orderInfo({ orderId })
    if (code === 200) {
      orderDataInfo = orderData
      pageShow = true
    }
  } catch (error) {
    console.log(error)
  }
 
}

getOrderData()

const payStatusOrder = debounce(async () => {
  sendBehavior('ac_200700_1', { from })

  if (orderDataInfo?.expireTime <= 0) {
    return toast('订单已失效')
  }
 
  const { id } = orderDataInfo
  const res = await payOrder(id)
}, 300)
 
const goServices = () => {
  location.href = customCenterUrl
}

document.title = '我的订单'
</script>
<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $page-name: 'o-odetail';

  .#{$page-name} {
    background: #F5F7FA;
    width: 100%;
    min-height: 100vh;
    padding: .4rem .2rem;

    &__item {
      border-radius: .24rem;
      background: white;
      padding: .44rem .36rem 0;
      &-time {
        padding: .18rem .36rem;
        padding-bottom: .24rem;
        border-top: .02rem solid #EEEEEE;
        border-bottom: .02rem solid #EEEEEE;
      }
      &-info {
        display: flex;
        justify-content: space-around;
        padding-bottom: .36rem;
        .cover {
          width: 1.8rem;
          height: 1.8rem;
          margin-right: .26rem;
        }

        .info {
          flex: 1;
          display: flex;
          flex-direction: column;
          .produce-name {
            color: #333333;
            font-size: .32rem;
          }
          .timeline {
            color: #333333;
            .before {
              color: #999999;
            }
          }
          .price {
            color: #FF4F48;
            margin-top: auto;
            font-size: .4rem;
          }
        }
      }
    }

    &__price {
      border-top: .02rem solid #EEEEEE;
      padding: .52rem;
      text-align: right;
      font-size: .32rem;
      span:nth-child(2) {
        font-size: .52rem;
        color: #FF4F48;
      }
    }

    &__number {
      p {
        color: #999999;
        font-size: .28rem;
        line-height: .48rem;
      }
      padding-bottom: .3rem;
      .btn {
        width: 100%;
        height: .64rem;
        background: linear-gradient(90deg, #FF8E7C 0%, #FF4742 100%);
        border-radius: .18rem;
        line-height: .64rem;
        color: white;
        text-align: center;
        font-size: .28rem;
        margin-top: .24rem;
      }
      .services {
        color: #FFC734;
        background: white;
        border: .02rem solid #FFC734;
      }
    }
  }

</style>