<svelte:window bind:scrollY={windowScrollY} />
<div>
  <div class={`o-home`}>
    {#if isPageView}
      <main class="o-home__main">
        <!-- 用户信息 -->
        <UserInfo 
          userInfo={userInfo}
          on:login={openLoginPanel}
        />
        
        <div class="o-home__main-content">
          <!-- <div class="o-home__tutorial fzlty" style={deviceInfo.android && deviceInfo.isPad ? 'margin-top: 0;' : ''}>
            <span class="fzlty-zc">会员套餐</span>
            {#if deviceInfo.ios}
              <span class="tutorial-btn" on:click={goPayCourse}>支付教程</span>
            {/if}
          </div> -->
        
          <div class="o-home__levels" bind:this={levelEl}>
              <LevelList
                activedIndex={acitivedLevelIndex}
                vipType={userInfo?.vipType}
                vipRemainTime={userInfo?.vipDaysRemain || 0}
                vipList={levelList}
                deadline={userInfo?.deadline}
                bind:this={levelCpEl}
                on:click={chooseLevel}
              />
          </div>

          <!-- {#if resourceData && resourceData.length && userInfo?.deadline && yearCardCountIndex === acitivedLevelIndex }
            <div class="o-home__sources" on:click={goRedirectUri}>
              <img src={singleImage.imgUrl} alt="">
              {#if singleImage.type}
                <div class="o-home__sources-tit fzlty-zc">
                  <div class="timer">
                    <Timer deadline={userInfo?.deadline} format={userInfo?.deadline <= DAYS_STR ? 'HH:MM:SS' : 'DD天HH:MM:SS'}>
                      <span slot="before">距离结束还剩</span>
                    </Timer>
                  </div>
                  <div class="tit main-tit">
                    {@html singleImage.mainTitle}
                    {@html singleImage.subTitle}
                  </div>
                </div>
              {/if}
            </div>
          {/if} -->
    
          <div class="o-home__paybtn">
            <PayButton
              disabled={userInfo?.level === 99 && userInfo?.vipType === 5}
              btnText={levelList[acitivedLevelIndex]?.btnText || ''}
              bind:this={payBtnlEl}
              on:click={payOrder}
            >
            </PayButton>
          </div>
    
          <div class="o-home__protcol">
            <div>
              <span on:click={goServerCenter}>开通前请阅读《会员服务协议》</span>
              {#if levelList[acitivedLevelIndex]?.payFlag}
                <span on:click={goRenewServerCenter}>《自动续费协议》</span>
              {/if}
            </div>
            <!-- {#if deviceInfo.ios} -->
              <!-- <span class="tutorial-btn" on:click={goPayCourse}>支付教程</span> -->
            <!-- {/if} -->
          </div>
          <!-- <div class="o-home__protcol" on:click={goServerCenter}>《会员服务协议》</div> -->
          
          <FooterBar
            showed={footerVisible}
          >
            <PayButton
              disabled={userInfo?.level === 99 && userInfo?.vipType === 5}
              btnText={levelList[acitivedLevelIndex]?.btnText || ''}
              on:click={payOrder}
            >
            </PayButton>
          </FooterBar>
        </div>
      </main>
      <div class="o-home__introduce max-width">
        <SliceBackground image={{
          url: '//cdn.hhdd.com/frontend/as/i/1f6ab666-c3f2-59f0-96b9-7c3a9a06a7e6.png',
          width: 750,
          height: 9618
        }}/>
        
      </div>
    {/if}
  </div>
</div>
<script lang="ts">
  // @ts-nocheck
  import { onMount, createEventDispatcher, tick } from 'svelte'
  import config from '@/lib/config'
  // import { showDialog as showTypedDialog, DIALOG_TYPE } from '@/components/TypedDialog'
  // import { showDialog as showImageSheet } from '@/components/ImageSheet/index'
  // import { showDialog as showCompleteDialog } from '@/components/CompleteDialog'
  import LevelList from '@/components/LevelList.svelte'
  import UserInfo from '@/components/UserInfo.svelte'
  import PayButton from '@/components/PayButton.svelte'
  import FooterBar from '@/components/FooterBar.svelte'

  import { showDialog as showRoleCard } from '../components/RoleCard'
  import { promiseDelay } from '@/utils/promisify'
  import SliceBackground from '@/components/SliceBackground.svelte'
  import { Timer, hideLoading, showLoading } from '@kada/svelte-activity-ui'
  import { debounce } from '@/utils/throttle'
  import { payment, openLogin, setRedPacketPopped, hasRedPacketPopped, wxPay, payOrder as payCurrentOrder } from '../app'
  import { getSimgleImge } from '../services/level'
  import { NOT_NORMAL_STATUS_BG, SVIP_PRIVILEGE, NORMAL_STATUS_BG } from './help'
  import { deviceInfo } from '@kada/library/src/device'
  import { sendBehavior } from '@/lib/analytics'
  // import config from '@/lib/config'
  import { kdCookieShim } from '@kada/cookie-shim/src/cookie-shim'
  import URLParser from '@/lib/urlParser'
  import { navigateTo } from '@kada/yrv'
  import { getUserInfo } from '@/services/user'
  import { getPayInfoList } from '@/services/level'
  import { getPreOrder } from '@/services/service'
  import * as storage from '@/lib/storage'
  import { WX_GZH_LIST } from './help'
  import { CH } from '@/lib/fetch'
  const { env } = config
  const { payCourseUrl, serviceCenterUrl, customCenterUrl, autoRenewUrl } = config

  const from = storage.get('from')

  const DAYS_STR = 24 * 60 * 60 * 1000

  // @ts-check
  const dispatch = createEventDispatcher()

  // 页面数据
  let pageData = {}
 
  // 页面是否加载完成
  export let pageLoaded: boolean = false

  // 页面是否要重新加载
  export let reload: boolean = false

  export let flag: boolean = false

  export let levelId: number = 0

  export let fromtype: string = ''
  
  // Y轴方向滚动距离
  let windowScrollY = 0
  let privilegeEl: HTMLElement = null

  let payBtnlEl: HTMLElement = null

  let levelEl: HTMLElement = null

  let levelCpEl: HTMLElement = null

  // 页面中间部分状态组件位置信息
  let payBtnRect = null

  let isPageView = false

  let resourceData = []

  let singleImage = {}

  let couponDiscount: number = 0

  $: levelIdIndex = pageData?.levelData?.vipList.findIndex((item) => item.id === levelId)

  $: defaultIndex = pageData?.levelData?.vipList.findIndex((item) => item.isDefault)

  $: acitivedLevelIndex = levelId ? ( levelIdIndex === -1 ? 0 : levelIdIndex ) : ( defaultIndex === -1 ? 0 : defaultIndex)
  $: yearCardCountIndex = pageData?.levelData?.vipList.findIndex((item) => item.isDefault && item.payType === 3)
  // 用户信息
  $: userInfo = pageData?.userInfo

  $: levelList = pageData?.levelData?.vipList || []

  // 检查用户是否挑战成功或失败，仅弹一次弹窗
  $: if(pageData) {
    if (pageLoaded && !isPageView) {
      isPageView = true
    }

    analyticsView()
  }

  // 计算属性，判断底部栏是否显示
  $: footerVisible = !payBtnRect ? false : windowScrollY >= (payBtnRect.top + payBtnRect.height * 0.8)
  console.log(footerVisible)
  // const rem = (val) => {
  //   console.log(window.kadaRemLayout.px2rem(val))
  //   return window.kadaRemLayout.px2rem(val)
  // }

  const convertTextToHTML = (ori: string): string => {
    const pattern = /<font(?: color="([^"]+)")?(?: bigger="([^"]+)")?>([^<]+)<\/font>/g
    
    if (!pattern.test(ori)) {
      return ori; // 如果文本格式不匹配，则原样返回
    }

    // const replacement= '<p style="color:$1; font-size: $2px;">$3</p>'

    // const result = ori.replace(pattern, replacement)

    // 使用正则表达式进行替换
    const output = ori.replace(pattern, function(match, color, bigger, content) {
      // console.log('color',color)
      console.log('bigger', bigger)
      // const fontSize = remJusty(+bigger);
      let fontSize = '.24'
      if (bigger === '1') {
        fontSize = '.4'
      }
      return '<span style="color:' + color + '; font-size: ' + fontSize + 'rem;">' + content + '</span>';
    })

    return output
  }

  const analyticsView = async () => {
    
    const { data } = await getSimgleImge(154)
    resourceData = data

    if (resourceData.length) {
      const { type, topTitle, mainTitle, subTitle } = resourceData[0]

      singleImage = {
        ...resourceData[0]
      }

      if (type) {
        singleImage = {
          ...resourceData[0],
          // topTitle: convertTextToHTML(singleImage.topTitle),
          mainTitle: convertTextToHTML(singleImage.mainTitle),
          subTitle: convertTextToHTML(singleImage.subTitle)
        }
      }
    }

    if (payBtnlEl) {
      const rect = payBtnlEl.getBoundingClientRect()
      payBtnRect = { top: windowScrollY + rect.top, left: rect.left, width: rect.width, height: rect.height, bottom: windowScrollY + rect.bottom, right: rect.right }
    }

    // showRoleDialog()
  }

  onMount(() => {
    const skeleton = document.querySelector('#skeleton')
    console.log(skeleton)
    if (skeleton) {
      skeleton.style.opacity = 0
      promiseDelay(400).then(() => {
        skeleton.remove()
      })
    }

    if (payBtnlEl) {
      const rect = payBtnlEl.getBoundingClientRect()
      payBtnRect = { top: windowScrollY + rect.top, left: rect.left, width: rect.width, height: rect.height, bottom: windowScrollY + rect.bottom, right: rect.right }
    }
    
    document.title = '开通会员'
    
  })


  const showRoleDialog = () => {
    // item.vipInfoId === 5 : svip档位、 item.payType === 3： 年卡档位 item.isDefault： 默认档位
    const { price = 0 } = pageData?.levelData?.vipList.find((item) => item.isDefault && item.payType === 3 && item.vipInfoId === 5) || {}
    couponDiscount = 388 - (price / 100)
    if (!couponDiscount || couponDiscount <= 0 || couponDiscount > 60 || hasRedPacketPopped(userInfo.userId) || !userInfo.deadline) return
    
    const { status, vipType, createDays, vipDaysRemain, remindExpireDays, vipStatus } = pageData.userInfo

    showRoleCard({
      type: 'success',
      title: userInfo.dialogTitle,
      deadline: userInfo.deadline,
      discount: couponDiscount,
      url: '//cdn.hhdd.com/frontend/as/i/6c3535b6-84cd-50e3-a6bd-fa3f0d1fa2cf.png',
      target: levelCpEl.getYearCardEl(),
      onShow: async () => {
        setRedPacketPopped(userInfo.userId)
        // sendBehavior('pgv_pop_1', {
        //   vip: vipType,
        //   vipStatus,
        //   status: status,
        //   time: status ? ( status === 1 ? vipDaysRemain : remindExpireDays) : createDays
        // })
      },
      onHide: () => {
        // sendBehavior('ac_pop_1', {
        //   vip: vipType,
        //   vipStatus,
        //   status,
        //   time: status ? ( status === 1 ? vipDaysRemain : remindExpireDays) : createDays
        // })
      }
    })
  }
  // onDestroy(() => {
  //   if (observer) {
  //     observer.observer?.disconnect()
  //   }
  // })
  const chooseLevel = debounce((e) => {
    acitivedLevelIndex = e.detail
    sendBehavior('ac_200402_2', { from: from, tap: acitivedLevelIndex })
    const vipType = levelList[acitivedLevelIndex]?.vipInfoId
    const { channelId, userGroupId } = pageData?.levelData?.vipTabConfig
    let stallType: number = 2

    if (vipType === 5) {
      stallType = 1
    } else if (vipType === 1) {
      stallType = 0
    }

  }, 300)

  const wxPayment = async (levelsId, sourceType) => {
    showLoading()
    const params = {
      sourceId: levelsId,
      sourceType,
      tradeType: 'JSAPI',
      orderTraceInfo: JSON.stringify({
        fromSourceId: 0,
        fromSourceType: 0,
        trace: CH
      }),
      extraParams: JSON.stringify({
        loginType: WX_GZH_LIST[from].loginType || 8
      })
    }
    const levelId = storage.get(`${levelsId}`)
    console.log(levelId)
    // return
    let orderData
    if (!storage.get(`${levelsId}`)) {
      const currentTime = new Date().getTime()
      const sixHoursInMilliseconds = 6 * 60 * 60 * 1000
      const sixHoursLater = currentTime + sixHoursInMilliseconds
      // const sixHoursLaterTimestamp = Math.floor(sixHoursLater / 1000)
      const res = await getPreOrder(params)
      if (res.code === 200) {
        orderData = res.data
        storage.set(`${levelsId}`, orderData, { expire: sixHoursLater })
      }
    } else {
      orderData = JSON.stringify(storage.get(levelsId))
    }
    
    hideLoading()
    if (orderData) {
      payCurrentOrder(JSON.parse(orderData).orderInfo.orderId)
      // wxPay(JSON.parse(orderData))
    } else {
      toast('订单不存在')
    }
  }

  const payOrder = debounce(async (e) => {
    sendBehavior('ac_200402_1', { from })
    const { id: levelsId, sourceType } = levelList[acitivedLevelIndex]
    console.log(levelsId)
    wxPayment(levelsId, sourceType)
  }, 300)

  const goRedirectUri = () => {
    if (resourceData.length && resourceData[0].redirectUri) {
      // sendBehavior('open_vip_activity_big_banner_click', { banner_id: resourceData[0].id, resource_id: 154 })
      if (!resourceData[0].redirectUri || !/^kada:\/\/pay/ig.test(resourceData[0].redirectUri)) {
        const { query: { url } } = new URLParser(resourceData[0].redirectUri)
        location.href = url
      } else {
        const { query: { levelId = 0, packageType = 6 } } = new URLParser(resourceData[0].redirectUri)
        wxPayment(+levelId, packageType)
        console.log(levelId)
        console.log(packageType)
      }
    }
  }

  const openLoginPanel = debounce(async () => {
    if (userInfo?.isLoginFlag) return

    const option = {
      openLogin: true,
      loginType: 0,
      skipUserGuide: 0,
      loginHelpVoice: false
    }

    if (fromtype && deviceInfo.isAndroidHD) {
      option.fromtype = fromtype
    }

    openLogin(option, dispatchRefresh)
  }, 300)

  const goCustom = () => {
    location.href = `kada://openurl?url=${customCenterUrl}`
  }

  const goPayCourse = () => {
    location.href = `kada://openurl?url=${payCourseUrl}`
  }

  const goServerCenter = () => {
    location.href = `${serviceCenterUrl}?mode=${userInfo?.status === 1 ? 1 : 0}`
  }

  const goRenewServerCenter = () => {
    location.href = `${autoRenewUrl}`
  }

   /**
   * 通知刷新数据
   */
  function dispatchRefresh () {
    console.log('dispatchRefresh')
    dispatch('refresh')
  }

  const initPageData = async () => {
    try {
      sendBehavior('pgv_200400_1', { from: from })

      const [ userData, levelData ] = await Promise.all([getUserInfo(), getPayInfoList()])
      userInfo = userData
      // pageData.levelData = levelData.data
      // levelList = levelData?.data?.vipList || []
      pageData = {
        userInfo,
        levelData: levelData.data
      }
      pageLoaded = true
    } catch (error) {
      console.log('getLevel:userInfo:error:', error)
    }
  }
  initPageData()
</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $page-name: 'o-home';

  .max-width {
    margin: 0 auto;
    // max-width: 9.6rem;
    max-width: 8rem;
  }

  .is-flag {
    .max-width {
      max-width: 9.6rem;
    }

    .o-home__honour {
      width: 6.75rem;
      height: .74rem;
    }
  }
  .mr-48 {
    margin-top: .48rem;
  }

  .mr-36 {
    margin-top: .36rem;
  }

  .color-o {
    color: #9D5F2C;
  }

  .ft-22 {
    font-size: .22rem;
  }

  .timer {
    position: absolute;
    left: .32rem;
    top: .12rem;
    color: white;
    font-size: .22rem;
    .sui-timer__zone {
      font-size: .24rem;
      &.is-day,
      &.is-hour,
      &.is-minute,
      &.is-second,
      &.is-ms {
        border-radius: .04rem;
        display: inline-block;
        padding: 0.06rem 0.04rem;
        color: #FE453D;
        background: #FEEFD4;
        margin: 0 0.04rem;
      }

      // &.is-ms {
      //   color: #f60;
      // }
    }
  }
  
  .#{$page-name} {
    // display: flex;
    // flex-direction: column;
    // height: 100%;
    // background-color: #FDE1BF;
    border-radius: .48rem .48rem 0 0;

    &__main {
      width: 7.5rem;
      background-color: white;
    }

    &__introduce {
      width: 100%;
      // height: 100%;
      // overflow-y: scroll;
      padding-bottom: .96rem;
    }

    .o-home__navs {
      position:relative;
      margin-top: -1.02rem;
      z-index:2;
    }

    &__main-content {
      // margin-top: ;
      width: 100%;
      // height: 100%;
      position: relative;
      margin-top: -.45rem;
      background-color: white;
      border-radius: .48rem .48rem 0 0;
      padding-top: .4rem;
    }

    &__sources {
      position: relative;
      margin: 0rem auto .48rem;
      width: 6.7rem;
      // height: 6.92rem;
      &-tit {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        text-align: left;
        font-size: .32rem;
        .tit {
          position: absolute;
          width: 100%;
        }
        .top-tit {
          top: .1rem;
        }
        .main-tit {
          left: .32rem;
          bottom: .1rem;
        }
        .sub-tit {
          font-size: .24rem;
          bottom: .1rem;
        }
      }
    }
    &__tutorial {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 .4rem;
      // margin-top: .48rem;
      span {
        color: #39364D;
        font-size: .4rem;
      }

      .tutorial-btn {
        font-size: .28rem;
        color: #5C5B5B;
      }
    }
    &__levels {
      position: relative;
      z-index: 2;
      // margin-top: -.4rem;
      width: 100%;
      // height: 100%;
      background-color: white;
      // padding-top: .48rem;
      // border-radius: .48rem .48rem 0 0;
    }

    &__paybtn {
      padding: 0 .48rem;
    }

    &__data-self {
      margin-right: .22rem;
      span {
        background-color: #FE6E41;
      }
    }

    &__honour {
      margin: .5rem auto;
      width: 5.28rem;
      height: .58rem;
      background: url(//cdn.hhdd.com/frontend/as/i/1cdd4e7e-ab2f-553e-8412-5c3d70f35adf.png) no-repeat;
      background-size: cover;
    }

    &__title {
      position: relative;
      margin: .4rem 0 .24rem;
      font-size: .4rem;
      span {
        font-size: .32rem;
      }

      .color-block {
        position: relative;
        span {
          position: relative;
          font-size: .38rem;
          z-index: 1;
        }
      }

      .color-block::after {
        content: '';
        position: absolute;
        width: 50%;
        height: .16rem;
        background-color: #FFC069;
        bottom: 0.08rem;
        right: 0;
      }

      .left::after {
        left: 0;
      }
    }

    &__join-time {
      margin: 0 auto;
      width: 5.56rem;
      height: .66rem;
      background: linear-gradient(180deg, #FFCA84 0%, #FFC983 100%);
      border-radius: 0px 0px .48rem .48rem;
      color: #A75C1D;
      font-size: .24rem;
      line-height: .66rem;
      text-align: center;
    }

    &__upgrade-tip {
      width: 100%;
      height: 1.56rem;
      
      div {
        width: 100%;
        height: 100%;
        background: url(//cdn.hhdd.com/frontend/as/i/03788f8e-4ad5-5587-b2f3-e83a6c6211f1.png?x-oss-process=image/quality,q_80) no-repeat;
        background-size: 5.6rem 1.56rem;
        background-position: center bottom;
        background-color: white;
      }
    }

    &__performance,  &__honour, &__read, &__privilege, &__books, &__intrBg, &__vip {
      padding: 0 .4rem;
    }

    &__honour-data, &__books-count, &__vip-service, &__read-wrap, &__recommend-list {
      background-color: white;
      border-radius: .2rem;
      padding: .32rem;
      font-size: .22rem;
    }

    &__read-title {
      font-size: .32rem;
      display: flex;
      align-items: center;
      .icon {
        margin-right: .16rem;
        width: .32rem;
        height: .32rem;
        background: url(//cdn.hhdd.com/frontend/as/i/920ced4d-8c2a-5076-ae00-f67ec2587753.png) no-repeat;
        background-size: cover;
      }
      .icon-book {
        background: url(//cdn.hhdd.com/frontend/as/i/f8f4a10d-780e-5e93-8179-11e4ec42326a.png) no-repeat;
        background-size: cover;
      }
    }
    &__privilege {
      padding-bottom: .4rem;
      &-tit {
        position: relative;
        margin: .66rem 0 .48rem;
        color: #9D5F2C;
        font-size: .4rem;
        text-align: center;

        .title {
          &::before {
            position: absolute;
            left: -.1rem;
            top: 0.15rem;
            content: '';
            width: .3rem;
            height: .3rem;
            border-radius: 50%;
            background: #FED194;
          }

          &::after{
            position: absolute;
            right: -0.1rem;
            top: 0.15rem;
            content: '';
            width: .3rem;
            height: .3rem;
            border-radius: 50%;
            background: #FED194;
          }
        }

        &::before {
          position: absolute;
          left: 0.1rem;
          top: 0.1rem;
          content: '';
          width: .4rem;
          height: .4rem;
          border-radius: .1rem;
          background: #FFC069;
          transform: rotate(-45deg);
          z-index: 1;
        }

        &::after{
          position: absolute;
          right: 0.1rem;
          top: 0.1rem;
          content: '';
          width: .4rem;
          height: .4rem;
          border-radius: .1rem;
          background: #FFC069;
          transform: rotate(-45deg);
          z-index: 1;
        }
      }
    }

    &__arrival-list {
      display: flex;
      flex-direction: row;
    }

    &__arrival-item {
      width: 2.02rem;
      height: 2.58rem;
      margin-right: .16rem;
    }

    &__arrival-sub {
      display: flex;
      align-items: center;
      padding-bottom: .2rem;
      span {
        display: inline-block;
        width: .1rem;
        height: .28rem;
        background: #9D5F2C;
        border-radius: .06rem; 
        margin-right: .1rem;
      }
      font-size: .32rem;
    }

    &__recommend-list {
      display: flex;
      flex-wrap: wrap;
      padding: .32rem .21rem 0;
      border-radius: .2rem .2rem 0 0;
    }

    &__recommend-item {
      // flex: 1;
      width: 1.92rem;
      // height: 2.46rem;
      margin: 0 .08rem .12rem;
      .name {
        line-height: .52rem;
        @include overflow-line(1);
      }
    }

    &__recommend-tips {
      padding: .26rem 0;
      background-color: #FFF6E6;
      border-radius: 0 0 .2rem .2rem;
      text-align: center;
      color: #FF4E4E;
      font-size: .32rem;
      span {
        font-size: .4rem;
      }
    }

    &__books-sub {
      font-size: .28rem;
      text-align: center;
    }

    &__books-item {
      display: flex;
      align-items: center;
      height: .84rem;
      background-color: #FFEFD4;
      margin: .1rem 0;
      border-radius: .08rem;

      div {
        width: 50%;
        height: 100%;
        border-radius: .08rem;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        padding-right: .3rem;
        background: linear-gradient(270deg, #5B4A38 0%, #9A7143 100%);
        margin-right: .25rem;
        font-size: .35rem;
        color: white;
      }

      .feature {
        background: linear-gradient(90deg, #FFB958 0%, #FF8640 100%);
      }
    }

    &__promote {
      margin-top: .48rem;
      text-align: center;
      padding: .32rem 0;
      font-size: .4rem;
      background: linear-gradient(141deg, #FFE6C1 0%, #FFC983 100%);
      border: .02rem solid #FFBA62;
      border-radius: .24rem;
    }

    &__protcol {
      display: flex;
      padding: 0 .4rem;
      justify-content: space-between;
      text-align: center;
      color: #C2723E;
      font-size: .24rem;
      margin-top: .38rem;
      margin-bottom: .5rem;
    }

    @media #{$padDeviceInfo} {
      overflow: hidden;
      height: 100vh;
      flex-direction: row-reverse;

      &__main {
        width: 8rem;
        overflow-y: scroll;
      }

      &__tutorial {
        padding: 0 .66rem;
      }

      &__paybtn {
        padding: 0 .68rem;
      }

      &__main-content {
      // margin-top: ;
        margin-top: 0;
        background-color: white;
        border-radius: 0;
        padding-top: 0;
      }

      &__performance {
        .o-home__title {
          span {
            font-size: .42rem;
          }
        }
      }

      &__intrBg, &__vip, &__coupon {
        .o-home__title {
          span {
            font-size: .42rem;
          }
        }
      }
    }
  }
  .is-pad {
    border-radius: 0;

    .o-home__upgrade-tip {
      padding: 0 .4rem;
      div {
        display: flex;
        justify-content: center;
        flex-direction: column;
        background: linear-gradient(180deg, #FFCA84 0%, #FFC983 100%);
        border-radius: .16rem;
        margin-top: .4rem;
        font-size: .42rem;
        // color: #FFF5CF;
        text-align: center;
      }
    }

    .o-home__main {
      width: 8rem;
    }

    .o-home__introduce {
      padding-bottom: 0;
    }
  }

  .is-home-wrap {
    display: flex;
    flex-direction: column;
    height: 100vh;
    .o-home {
      flex: 1;
    }
  }
</style>
