<div class="o-odetail">
  {#if pageShow}
    <div class="o-odetail__wrap">
      <div  class="o-odetail__wrap-head"> 
        <div style={`background: url(${headUrl || '//cdn.hhdd.com/frontend/as/i/628c8d58-ccb4-5265-9fe0-8849f271a19d.png'}) no-repeat; background-size: cover;`}></div>
      </div>
      <div class="o-odetail__wrap-info">
        <div class="user-name fzlty-zc">
          <p>{nickName}的家长</p>
        </div>
        {#if phone}
          <div class="vip-info fzlty">
            <p>{`手机号：${phone}`}</p>
          </div>
        {/if}
      </div>
    </div>
    <div class="o-odetail__item">
        <div class="o-odetail__item-info">
        <div class="cover">
            <img src={orderDataInfo?.coverUrl || WECHAT_PAY_INFO_COVER_URL} alt="" srcset="">
        </div>
        <div class="info">
            <div class="produce-name">{orderDataInfo.productName}</div>
            <div class="timeline">
            {#if !orderDataInfo.status && orderDataInfo?.expireTime > 0}
              <Timer deadline={orderDataInfo?.expireTime} format={'HH:MM:SS'} on:end={getOrderData}>
                <span class="before" slot="before">等待付款：</span>
              </Timer>
            {/if}
            </div>
            <div class="price">¥{orderDataInfo.orderPrice / 100}</div>
        </div>
        </div>
        <div class="o-odetail__price">
          <span>合计：</span>
          <span>¥{orderDataInfo.status ? orderDataInfo.payPrice / 100 : orderDataInfo.orderPrice / 100}</span>
        </div>
        <!-- <div class="o-odetail__item-time">
        <span>创建时间</span>
        <span>待支付</span>
        </div> -->
    </div>
    <div class="o-odetail__item o-odetail__number" style="margin-top: .24rem;">
      <p>订单号：{orderDataInfo?.orderNo}</p>
      <p>创建时间：{formatDate(orderDataInfo?.createTime, 'YYYY-MM-DD HH:mm:ss')}</p>
      {#if orderDataInfo?.status}
        <p>已支付</p>
      {/if}
      {#if !orderDataInfo.status}
        <div
          class="btn"
          class:is-pay={orderDataInfo.status}
          on:click={payStatusOrder}>
          {orderDataInfo.status ? '已支付' : '确认支付'}
        </div>
      {/if}
      {#if orderDataInfo.status}
       <div class="btn services" on:click={goServices}>联系客服</div>
      {/if}
    </div>
    <div class="text">
      <p>温馨提示：</p>
      <p>1、购买遇到问题，请联系客服，我们会为您解决。</p>
      <p>2、该商品为电子形式，购买后无法退款，请确定后付款。</p>
    </div>
    <EditionNumber userId={userId || ''}/>
  {/if}
</div>
<script>
import { orderInfo } from '@/services/service'
import { debounce } from '@/utils/throttle'
import { payOrder, WECHAT_PAY_INFO_COVER_URL } from '../app'
import { Timer, toast } from '@kada/svelte-activity-ui'
import URLParser from '@/lib/urlParser'
import { formatDate } from '@kada/library/utils/datetime'
import config from '@/lib/config'
import { sendBehavior } from '@/lib/analytics'
import EditionNumber from '@/components/EditionNumber.svelte'
import * as storage from '@/lib/storage'
import { WX_GZH_LIST } from './help'
import { showDialog } from '@/components/RenewDialog'

// const from = storage.get('from')

const { customCenterUrl, env } = config

let orderDataInfo = {}
let pageShow = false

let headUrl = ''
let nickName = ''
let phone = ''
let userId = ''

const parsed = new URLParser(location.href)
let { orderNo = '', from, openId = '' } = parsed.query

console.log(orderNo)
const getOrderData = async () => {
  
  const params = {
    orderNo
  }
  try {
    const { data: orderData, code } = await orderInfo(params)
    if (code === 200) {
      orderDataInfo = orderData
      headUrl = orderData?.userInfo?.headUrl
      nickName = orderData?.userInfo?.nick || '小读者'
      phone = orderData?.userInfo?.phone
      userId = orderData?.userInfo?.userId
      pageShow = true
      sendBehavior('pgv_200800_1', { from, state: orderData?.status })
    } else {
      showDialog({
        title: '订单已经失效',
        showCancel: false,
        onConfirm: async () => {
          window.WeixinJSBridge.call('closeWindow')
        },
        onClose: async () => {
          window.WeixinJSBridge.call('closeWindow')
        },
      })
      sendBehavior('pgv_200800_1', { from, state: 2 })
      // window.WeixinJSBridge.call('closeWindow')
    }
    
  } catch (error) {
    console.log(error)
  }
 
}

getOrderData()

const payStatusOrder = debounce(async () => {
  sendBehavior('ac_200800_1', { from })
  
  if (orderDataInfo?.expireTime <= 0) {
    return toast('订单已失效')
  }

  const { id } = orderDataInfo
  const extParams = {
    loginType: WX_GZH_LIST[from]?.loginType || 8,
    openId
  }
  const res = await payOrder(id, "JSAPI", extParams)
}, 300)
 
const goServices = () => {
  location.href = customCenterUrl
}

document.title = '订单支付'
</script>
<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $page-name: 'o-odetail';

  .#{$page-name} {
    background: #F5F7FA;
    width: 100%;
    min-height: 100vh;
    padding: .4rem .2rem;
    &__wrap {
      position: relative;
      display: flex;
      flex-direction: row;
      align-items: center;
      padding: 0 .2rem .4rem;
      &-head {
        position: relative;
        width: 1rem;
        height: 1rem;
        margin-right: .24rem;
        div {
          width: 100%;
          height: 100%;
          border: .02rem solid #FFFFFF;
          background: url(//cdn.hhdd.com/frontend/as/i/12529618-b189-5446-a8e5-d27ecf89e544.png) no-repeat; 
          background-size: cover;
          border-radius: 50%;
          overflow: hidden;
        }
        img {
          width: .76rem;
          height: .3rem;
          position: absolute;
          bottom: -.1rem;
          left: 50%;
          transform: translateX(-50%);
        }
      }

      &-info {
        color: #666666;
        flex: 1;

        .user-name {
          color: #333333;
          font-size: .4rem;
          display: flex;
          align-items: center;
          img {
            width: auto;
            margin-left: .1rem;
            height: .32rem;
          }
        }

        .vip-info {
          margin-top: .1rem;
          font-size: .24rem;
        }

      }

    }
    &__item {
      border-radius: .24rem;
      background: white;
      padding: .44rem .36rem 0;
      &-time {
        padding: .18rem .36rem;
        padding-bottom: .24rem;
        border-top: .02rem solid #EEEEEE;
        border-bottom: .02rem solid #EEEEEE;
      }
      &-info {
        display: flex;
        justify-content: space-around;
        padding-bottom: .36rem;
        .cover {
          width: 1.8rem;
          height: 1.8rem;
          margin-right: .26rem;
        }

        .info {
          flex: 1;
          display: flex;
          flex-direction: column;
          .produce-name {
            color: #333333;
            font-size: .32rem;
          }
          .timeline {
            color: #333333;
            .before {
              color: #999999;
            }
          }
          .price {
            color: #FF4F48;
            margin-top: auto;
            font-size: .4rem;
          }
        }
      }
    }

    &__price {
      border-top: .02rem solid #EEEEEE;
      padding: .38rem;
      text-align: right;
      font-size: .3rem;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      span:nth-child(2) {
        font-size: .52rem;
        color: #FF4F48;
      }
    }

    &__number {
      p {
        color: #999999;
        font-size: .28rem;
        line-height: .48rem;
      }
      padding-bottom: .3rem;
      .btn {
        width: 100%;
        height: .64rem;
        background: linear-gradient(90deg, #FF8E7C 0%, #FF4742 100%);
        border-radius: .18rem;
        line-height: .64rem;
        color: white;
        text-align: center;
        font-size: .28rem;
        margin-top: .24rem;
        &.is-pay {
          color: #FFC734;
          background: white;
          border: .02rem solid #FFC734;
          pointer-events: none;
        }
      }
      .services {
        color: #FFC734;
        background: white;
        border: .02rem solid #FFC734;
      }
    }
    .text {
      padding: .32rem .42rem;
      color: #999999;
      font-size: .24rem;
    }
  }

</style>