<div class="o-course">
  <div class="o-course__introduce fzlty-zc max-width">
      <div class="o-course__title">{svipPrivilege[sheetParam].title}</div>
      <SliceBackground
        image={svipPrivilege[sheetParam]}
      />
  </div>
</div>

<script lang="ts">
  import config from '@/lib/config'
  import SliceBackground from '@/components/SliceBackground.svelte'
  import { SVIP_PRIVILEGE } from './help'
  import URLParser from '@/lib/urlParser'

  const { env } = config

  const url = location.href
  const parsed = new URLParser(url)
  const { sheetParam = '', ageType = 0 } = parsed.query

  const svipPrivilege = SVIP_PRIVILEGE[ageType] || {}

</script>

<style lang="scss">
  @import '../styles/variables';
  $page-name: 'o-course';

  .max-width {
    // max-width: 12.48rem;
    max-width: 7.5rem;
    margin: 0 auto;
  }
 
  .#{$page-name} {
    display: flex;
    flex-direction: column;
    // height: 100%;
    background-color: white;
    &__introduce {
      width: 100%;
    //   height: 100%;
      // overflow-y: scroll;
    }

    &__title {
      font-size: .4rem;
      line-height: 1.2rem;
      text-align: center;
      color: #26A4FF;
    }

    @media #{$pad_landscape_query} {
      // overflow: hidden;
      // height: 100vh;
      // flex-direction: row-reverse;

      // &__levels {
      //   box-shadow: 0px 20px 30px 20px rgba(158, 158, 158, 0.2);
      // }
    }
    @media #{$media_query-notch} {
      padding-top: .6rem;
    }
  }
</style>
