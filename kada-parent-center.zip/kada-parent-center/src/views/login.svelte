<div class="o-login">
  <div class="o-login__panel">
    <div class="o-login__head">

    </div>
    <div class="o-login__wrap">
      <div class="o-login__tit fzlty-zc">欢迎登录</div>
      <div class="o-login__content">
        <input
          id="_input"
          class="inputPhone"
          maxlength="11"
          type="text"
          bind:value={phoneNumber}
          on:input={inputPhoneNumber}
          placeholder="请输入手机号" />
          <!-- {#if valiPhoneNum && ncData} -->
            <div class="validate">
              <input
                id="_inputValidate"
                class="inputValidate"
                maxlength="6"
                bind:value={smsCode}
                type="text"
                placeholder="请输入验证码" />
              <div class="line"></div>
              <button
                class="getValidate fzlty-zc"
                on:click={sendSmsCode}
                disabled={typeof valiLabel === 'number'}>
                {@html typeof valiLabel === 'number' ? `<span class="fzlty" style="color: #999999;font-size: .26rem;">已发送(${valiLabel}s)</span>` : valiLabel}
              </button>
            </div>
          <!-- {/if} -->
        <div class="slide-wrap">
          <div class="slide-text fzlty">验证滑块：</div>
          <div id="nc"></div>
        </div>
        
      </div>
      <div
        class="o-login__btn fzlty-zc"
        class:is-disabled={!isDisabled}
        on:click={inputSmsCode}
      >立即登录</div>
    </div>
  </div>
</div>
<script>
  import { onMount, createEventDispatcher, onDestroy } from 'svelte'
  import { showLoading, Popup, toast, hideLoading } from '@kada/svelte-activity-ui'
  import * as services from '@/services/service'
  import * as storage from '@/lib/storage'
  import { getClientDeviceId } from '@kada/library/src/device'
  import { sendBehavior } from '@/lib/analytics'
  import qs from 'qs'
  import { navigateTo } from '@kada/yrv'
  import { WX_GZH_LIST } from './help'
  
  const from = storage.get('from')

  let openId = ''



  $: isDisabled = true

  let ncData = null // 滑动验证返回值
  const initAwsc = () => {
    AWSC.use('nc', function (state, module) {
      // 初始化
      window.nc = module.init({
        // 应用类型标识。它和使用场景标识（scene字段）一起决定了滑动验证的业务场景与后端对应使用的策略模型。您可以在阿里云验证码控制台的配置管理页签找到对应的appkey字段值，请务必正确填写。
        appkey: 'FFFF0N0N000000006D3A',
        //使用场景标识。它和应用类型标识（appkey字段）一起决定了滑动验证的业务场景与后端对应使用的策略模型。您可以在阿里云验证码控制台的配置管理页签找到对应的scene值，请务必正确填写。
        scene: 'nc_message_h5',
        // 声明滑动验证需要渲染的目标ID。
        renderTo: 'nc',
        fontSize: '16',
        upLang: {
          'cn': {
            'SLIDE': '按住滑块，拖动至最右'
          }
        },
        //前端滑动验证通过时会触发该回调参数。您可以在该回调参数中将会话ID（sessionId）、签名串（sig）、请求唯一标识（token）字段记录下来，随业务请求一同发送至您的服务端调用验签。
        success: function (data) {
          ncData = { ...data }
          // 滑动验证完成自动发送验证码
          if (valiPhoneNum) {
            sendSmsCode()
          } else {
            toast('请输入正确的手机号')
          }
        },
        // 滑动验证失败时触发该回调参数。
        fail: function (failCode) {
          console.log('滑动验证失败时', failCode)
        },
        // 验证码加载出现异常时触发该回调参数。
        error: function (errorCode) {
          console.log('验证码加载出现异常时', errorCode)
        },
      })
    })
  }

  let popupEl
  let phoneNumber = '' // 手机号
  let smsCode = '' // 验证码
  let valiLabel = '获取验证码'

  $: valiPhoneNum = (() => {
    const reg = new RegExp(
      /^1(3[0-9]|4[01456879]|5[0-35-9]|6[2567]|7[0-8]|8[0-9]|9[0-35-9])\d{8}$/,
    )
    const valiPhoneNumRes = reg.test(phoneNumber)
    if (phoneNumber.length === 11) {
      if (!valiPhoneNumRes) {
        toast('手机号格式错误')
      }
    }
    return phoneNumber.length === 11 && valiPhoneNumRes
  })()

  /**
   * 输入验证码
   */
  const inputSmsCode = async () => {
    sendBehavior('ac_200300_2', { from: from })
    if (smsCode.length === 6) {
      openId = storage.get('openId')
      showLoading('正在验证中，请稍后')
      try {
        const res = await services.createUser({
          deviceId: getClientDeviceId(),
          ...ncData,
          phoneNumber,
          smsCode,
          wechatOpenId: openId,
        })
        if (res.code === 200) {
          toast('验证成功')
          sendBehavior('ac_200300_3', { from: from })
          // storage.set('fx_phone', phoneNumber)
          const unionId = storage.get('unionId')
          const openId = storage.get('openId')
          const type = storage.get('from')
          const { loginType = 8 } = WX_GZH_LIST[type] || {}

          const res = await services.createLink(unionId, openId, loginType, type)
          console.log(res)
          if (res.code === 200) {
            navigateTo(`/index?openId=${openId}`)
          }
          smsCodeBlur()
        //   close()
        } else {
          toast('验证码输入错误，请重新输入')
        }
        hideLoading()
      } catch (error) {
        toast(error.message)
        hideLoading()
      }
    }
  }
  /**
   * 输入手机号
   * 手机号改变，重置滑块
   */
  const inputPhoneNumber = () => {
    window.nc.reset()
    ncData = null
  }

  /**
   * 输入手机号touchend
   */
  const smsCodeBlur = () => {
    const _input = document.getElementById('_inputValidate')
    _input.style.display = 'block'
    setTimeout(() => {
      _input.blur()
    }, 150)
  }

  /**
   * 发送验证码
   */
  const sendSmsCode = async () => {
    sendBehavior('ac_200300_1', { from: from })
    if (!ncData) {
      return toast('请先拖动验证滑块')
    }

    valiLabel = 60
    const timer = setInterval(() => {
      valiLabel -= 1
      if (valiLabel === 0) {
        window.nc.reset()
        ncData = null
        valiLabel = '获取验证码'
        clearInterval(timer)
      }
    }, 1000)
    const res = await services.sendSmsCode({
      phoneNumber,
      ...ncData,
    })
    if (res.code === 200) {
      toast('验证码发送成功')
    } else {
      phoneNumber = ''
      valiLabel = '获取验证码'
      toast(res.msg)
      clearInterval(timer)
    }
  }

  const controlUI = () => {
    const _input = document.getElementById('_input')
    _input.style.display = 'block'
    setTimeout(() => {
      _input.focus()
    }, 150)
  }

  // const goLogin = () => {
  //   openLogin()
  // }
  // 页面请求参数
  const pageQuery = qs.parse(location.search, {
    ignoreQueryPrefix: true
  })

  // if (!pageQuery.code) {
  //   openLogin()
  // }
//   const close = () => {
//     popupEl && popupEl.close()
//   }

  onMount(() => {
    // popupEl && popupEl.show()
    controlUI()
    initAwsc()
    
    sendBehavior('pgv_200300_1', { from })
  })

  document.title = 'KaDa阅读'

//   onDestroy(() => {
//     ncData = null
//     dispatch('close')
//   })
</script>
<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $page-name: 'o-login';

  .#{$page-name} {
    &__panel {
      max-width: 7.5rem;
      height: 100vh;
      display: flex;
      flex-direction: column;
    }

    &__head {
      width: 100%;
      height: 3.82rem;
      background: url(//cdn.hhdd.com/frontend/as/i/d0525efb-0780-5d9f-ad23-1d5a241fa55c.png) no-repeat;
      background-size: cover;
    }

    &__wrap {
      flex: 1;
      background: white;
      border-top-left-radius: .52rem;
      border-top-right-radius: .52rem;
      margin-top: -.52rem;
    }

    &__tit {
      color: #333333;
      font-size: .44rem;
      padding-top: .7rem;
      text-align: center;
    }
    &__content {
      padding: .42rem;
      .inputPhone {
        width: 100%;
        height: 1.08rem;
        padding-left: 0.4rem;
        background-size: 100% 100%;
        background: #F6F8FB;
        border-radius: .53rem;
        // background-image: url(//cdn.hhdd.com/frontend/as/i/a275d867-148d-5b2e-ab4f-aa05cc05e014.png);
        font-size: 0.32rem;
        outline: none;
      }

      .slide-wrap {
        margin-top: .3rem;
        .slide-text {
          // width: .64rem;
          // display: flex;
          // flex-wrap: wrap;
          padding-left: .04rem;
          font-size: .32rem;
          // margin-right: .4rem;
        }
        align-items: center;
        display: flex;
      }
      #nc {
        flex : 1;
        position: relative;
        // margin-top: 0.3rem;
        height: 0.88rem;
        .nc_wrapper {
          width: 100%;
        }
        #nc_6_wrapper {
          height: .88rem;
          line-height: .88rem;
        }
        .nc_scale {
          height: .88rem;
        }
        #nc_6_n1z {
          height: .88rem;
        }
        .btn_slide, .btn_ok {
          width: .88rem;
          height: .88rem;
          line-height: .88rem;
        }

        .nc-lang-cnt {
          height: .88rem;
          line-height: .88rem;
          b {
            color: white;
          }
        }
        .nc_scale .nc-align-center.scale_text2 {
          text-indent: -20px;
        }
      }

      .validate {
        margin-top: 0.28rem;
        width: 100%;
        height: 1.08rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #F6F8FB;
        border-radius: .53rem;
        padding-right: .36rem;
        .inputValidate {
          width: 3.5rem;
          height: 100%;
          background: none;
          outline: 0;
          // line-height: 0.34rem;
          font-size: 0.32rem;
          font-weight: normal;
          outline: none;
          padding-left: 0.4rem;
        }

        .line {
          width: .02rem;
          height: .3rem;
          background: #D7D7D7;
        }

        .getValidate {
          width: 1.8rem;
          font-size: 0.32rem;
          font-weight: normal;
          color: #3398FF;
          outline: none;
          background-color: transparent;
        }
      }
    }

    &__btn {
      margin: .2rem auto 0;
      width: 6.66rem;
      height: 1.08rem;
      background: #3398FF;
      border-radius: .54rem;
      line-height: 1.08rem;
      text-align: center;
      color: white;
      font-size: .36rem;
      &.is-disabled {
        opacity: .5;
        pointer-events: none;
      }
    }
  }

</style>