<div class="o-order">
  {#if orderDataList.length}
    <div class="o-order__list">
      {#each orderDataList as item, index}
        <div class="o-order__item">
            <div class="o-order__item-time">
            <span>创建时间: {formatDate(item.createTime, 'YYYY-MM-DD HH:mm:ss')}</span>
            <span>{item.status ? '已支付' : '待支付'}</span>
            </div>
            <div class="o-order__item-info">
            <div class="cover" on:click={goDetail(item.id)}>
                <img src={item?.coverUrl || WECHAT_PAY_INFO_COVER_URL} alt="" srcset="">
            </div>
            <div class="info" on:click={goDetail(item.id)}>
                <div class="produce-name">{item.productName}</div>
                <div class="timeline">
                {#if !item.status && item?.expireTime > 0}
                    <Timer deadline={item?.expireTime} on:end={getOrderData} format={'HH:MM:SS'}>
                    <span class="before" slot="before">等待付款：</span>
                    </Timer>
                {/if}
                </div>
                <div class="price">¥{item.orderPrice / 100}</div>
            </div>
            {#if !item.status}
                <div class="btn" on:click={() => payStatusOrder(item)}>去支付</div>
            {/if}
            </div>
        </div>
      {/each}
    </div>
  {:else}
    <div class="no-data">
      <img src="//cdn.hhdd.com/frontend/as/i/1b86e22a-76bc-5902-b30b-1e8c1e22ac90.png" alt="" srcset="">
      <div>暂无订单</div>
    </div>
  {/if}
</div>
<script lang="ts">
//@ts-nocheck
import { navigateTo } from '@kada/yrv'
import { orderList } from '@/services/service'
import { formatDate } from '@kada/library/utils/datetime'
import { Timer, toast } from '@kada/svelte-activity-ui'
import { payOrder, WECHAT_PAY_INFO_COVER_URL } from '../app'
import { debounce } from '@/utils/throttle'
import { sendBehavior } from '@/lib/analytics'
import * as storage from '@/lib/storage'
// import { payOrder } from '../order'
// console.log(payOrder)
const from = storage.get('from')
let orderDataList = []

const getOrderData = async () => {
  sendBehavior('pgv_200600_1', { from })
  try {
    const { data: orderData, code } = await orderList()
    if (code === 200) {
      orderDataList = orderData
    }
  } catch (error) {
    console.log(error)
  }
 
}
getOrderData()

const payStatusOrder = debounce(async (e) => {
  const { id, createTime, orderPrice, expireTime } = e

  if (expireTime <= 0) {
    return toast('订单已失效')
  }

  sendBehavior('ac_200600_1', { from, money: orderPrice, time: createTime, order: id })
  const res = await payOrder(id)
}, 300)

const goDetail = debounce(async (e) => {
  navigateTo(`/odetail?orderId=${e}`)
})

document.title = '我的订单'
</script>
<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $page-name: 'o-order';

  .#{$page-name} {
    background: #F5F7FA;
    width: 100%;
    min-height: 100vh;
    padding: 0 .2rem .4rem;
    overflow: hidden;

    &__item {
      padding: .24rem 0;
      border-radius: .24rem;
      background: white;
      margin-top: .4rem;
      &-time {
        display: flex;
        justify-content: space-between;
        color: #999999;
        padding: 0 .36rem .24rem;
        padding-bottom: .24rem;
        border-bottom: .02rem solid #EEEEEE;
      }
      &-info {
        padding: .44rem .36rem 0;
        display: flex;
        justify-content: space-around;

        .cover {
          width: 1.8rem;
          height: 1.8rem;
          margin-right: .26rem;
        }

        .info {
          flex: 1;
          display: flex;
          flex-direction: column;
          .produce-name {
            color: #333333;
            font-size: .32rem;
          }
          .timeline {
            color: #333333;
            .before {
              color: #999999;
            }
          }
          .price {
            color: #FF4F48;
            margin-top: auto;
            font-size: .4rem;
          }
        }

        .btn {
          width: 1.6rem;
          height: .52rem;
          background: linear-gradient(90deg, #FF8E7C 0%, #FF4742 100%);
          border-radius: .36rem;
          line-height: .52rem;
          color: white;
          text-align: center;
          font-size: .28rem;
          margin-top: auto;
        }
      }
    }

    .no-data {
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      color: #666666;
      font-size: .28rem;
      img {
        width: 2.6rem;
        height: 2.6rem;
      }
    }
  }

</style>