export enum AgeType {
  AGE0_2 = 1,
  AGE3_6 = 4,
  AGE7_9 = 7,
  AGE10_UPPER = 10
}

export const NOT_NORMAL_STATUS_BG = {
  [AgeType.AGE0_2]: {
    url: '//cdn.hhdd.com/frontend/as/i/0c9bdd23-10a3-558a-805e-ba5aeb3b86cf.png',
    width: 686,
    height: 5708,
    vipImage: '//cdn.hhdd.com/frontend/as/i/d8069896-762a-52be-9b85-44921cd9985b.png'
  },
  [AgeType.AGE3_6]: {
    url: '//cdn.hhdd.com/frontend/as/i/0c9bdd23-10a3-558a-805e-ba5aeb3b86cf.png',
    width: 686,
    height: 5708,
    vipImage: '//cdn.hhdd.com/frontend/as/i/d8069896-762a-52be-9b85-44921cd9985b.png'
  },
  [AgeType.AGE7_9]: {
    url: '//cdn.hhdd.com/frontend/as/i/8e747a92-82c4-5d24-bbbf-c3e151d6edf3.png',
    width: 686,
    height: 5708,
    vipImage: '//cdn.hhdd.com/frontend/as/i/2c09c569-9c6f-57b4-ab60-3cb7db4fb8ec.png'
  },
  [AgeType.AGE10_UPPER]: {
    url: '//cdn.hhdd.com/frontend/as/i/8e747a92-82c4-5d24-bbbf-c3e151d6edf3.png',
    width: 686,
    height: 5708,
    vipImage: '//cdn.hhdd.com/frontend/as/i/2c09c569-9c6f-57b4-ab60-3cb7db4fb8ec.png'
  },
}

export const SVIP_PRIVILEGE = {
  [AgeType.AGE0_2]: {
    readPlan: '//cdn.hhdd.com/frontend/as/i/4285ca13-76ff-5892-89e5-94c5a49bc4fa.png',
    goodCourse: '//cdn.hhdd.com/frontend/as/i/c8891e22-8f0e-50c6-a267-3501b303ad15.png',
    planSheet: {
      title: '每周学习安排',
      url: '//cdn.hhdd.com/frontend/as/i/3c9c63a8-48e2-501b-8bed-52bb4d622bc2.png',
      width: 694,
      height: 7742,
    },
    courseSheet: {
      title: '学习安排',
      url: '//cdn.hhdd.com/frontend/as/i/7c6bca06-3e17-5794-b11b-e6c36a96d1e6.png',
      width: 694,
      height: 3018,
    }
  },
  [AgeType.AGE3_6]: {
    readPlan: '//cdn.hhdd.com/frontend/as/i/4285ca13-76ff-5892-89e5-94c5a49bc4fa.png',
    goodCourse: '//cdn.hhdd.com/frontend/as/i/c8891e22-8f0e-50c6-a267-3501b303ad15.png',
    planSheet: {
      title: '每周学习安排',
      url: '//cdn.hhdd.com/frontend/as/i/3c9c63a8-48e2-501b-8bed-52bb4d622bc2.png',
      width: 694,
      height: 7742,
    },
    courseSheet: {
      title: '学习安排',
      url: '//cdn.hhdd.com/frontend/as/i/7c6bca06-3e17-5794-b11b-e6c36a96d1e6.png',
      width: 694,
      height: 3018,
    }
  },
  [AgeType.AGE7_9]: {
    readPlan: '//cdn.hhdd.com/frontend/as/i/8d542901-dd38-5f5c-b1b1-b377107bcdae.png',
    goodCourse: '//cdn.hhdd.com/frontend/as/i/29cdf9d3-c43f-5b40-a7b8-c686579596c6.png',
    planSheet: {
      title: '每周学习安排',
      url: '//cdn.hhdd.com/frontend/as/i/9d33aa73-0821-5dfb-b7be-6cc7fb95eaed.png',
      width: 694,
      height: 7078,
    },
    courseSheet: {
      title: '学习安排',
      url: '//cdn.hhdd.com/frontend/as/i/87f65751-5e9a-562c-8654-b327edb35a65.png',
      width: 694,
      height: 2808,
    }
  },
  [AgeType.AGE10_UPPER]: {
    readPlan: '//cdn.hhdd.com/frontend/as/i/8d542901-dd38-5f5c-b1b1-b377107bcdae.png',
    goodCourse: '//cdn.hhdd.com/frontend/as/i/29cdf9d3-c43f-5b40-a7b8-c686579596c6.png',
    planSheet: {
      title: '每周学习安排',
      url: '//cdn.hhdd.com/frontend/as/i/9d33aa73-0821-5dfb-b7be-6cc7fb95eaed.png',
      width: 694,
      height: 7078,
    },
    courseSheet: {
      title: '学习安排',
      url: '//cdn.hhdd.com/frontend/as/i/87f65751-5e9a-562c-8654-b327edb35a65.png',
      width: 694,
      height: 2808,
    }
  },
}

export const NORMAL_STATUS_BG = {
  [AgeType.AGE0_2]: {
    url: '//cdn.hhdd.com/frontend/as/i/d516f069-c7e0-5d1c-9537-972db108e698.png',
    width: 750,
    height: 15920
  },
  [AgeType.AGE3_6]: {
    url: '//cdn.hhdd.com/frontend/as/i/d516f069-c7e0-5d1c-9537-972db108e698.png',
    width: 750,
    height: 15920
  },
  [AgeType.AGE7_9]: {
    url: '//cdn.hhdd.com/frontend/as/i/22bf8d2b-7a05-5a7b-be78-0ffaed2b1572.png',
    width: 750,
    height: 13800
  },
  [AgeType.AGE10_UPPER]: {
    url: '//cdn.hhdd.com/frontend/as/i/22bf8d2b-7a05-5a7b-be78-0ffaed2b1572.png',
    width: 750,
    height: 13800
  }
}

export const CHART_IMAGE = {
  1: {
    url: '//cdn.hhdd.com/frontend/as/i/462892d6-d6e3-5201-9286-bd72830fa8cf.png',
    percent: '83%'
  },
  2: {
    url: '//cdn.hhdd.com/frontend/as/i/1d40f9ca-25db-5533-a0e5-1695fc5b3d6a.png',
    percent: '93%'
  },
  3: {
    url: '//cdn.hhdd.com/frontend/as/i/ba7dc49b-0235-5e5d-bc5b-26c1b810e9ec.png',
    percent: '97%'
  } 
}

export enum LoginType {
  KADA_READING = '2',
  KADA_READING_CENTER = '1'
}

export const WX_GZH_LIST = {
  [LoginType.KADA_READING]: {
    loginType: 8,
    appId: 'wxcc950d7c79177fc4',
    channelId: 60,
    channel: 'wxgzhkdyd'
  },
  [LoginType.KADA_READING_CENTER]: {
    loginType: 27,
    appId: 'wxbb9a367fa74d7ca1',
    channelId: 61,
    channel: 'wxgzhkdjzh'
  }
}