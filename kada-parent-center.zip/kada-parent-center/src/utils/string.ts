/**
 * 屏蔽用户真实昵称
 */
export function maskNickName (name: string): string {
  const firstWord = name.substring(0, 1)
  const lastWord = name.length > 2 ? name.substring(name.length - 1) : ''
  const midWord = '**'

  return `${firstWord + midWord + lastWord}`
}
