/**
 * 数字格式化
 */
export function numberFormat (number: number = 0, decimals: number = 0, decPoint: string = '.', thousandsSep: string = ','): string {
  const n = !isFinite(+number) ? 0 : +number
  const prec = !isFinite(+decimals) ? 0 : Math.abs(decimals)
  const sep = thousandsSep
  const dec = decPoint
  let s: string = ''
  const toFixedFix = (n: number, prec: number): string => {
    const k = Math.pow(10, prec)

    return '' + Math.round(n * k) / k
  }

  const splited = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.')

  if (splited[0].length > 3) {
    splited[0] = splited[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep)
  }
  if ((splited[1] || '').length < prec) {
    splited[1] = splited[1] || ''
    splited[1] += new Array(prec - s[1].length + 1).join('0')
  }

  return splited.join(dec)
}
