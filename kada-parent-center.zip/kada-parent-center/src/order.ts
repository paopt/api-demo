//@ts-nocheck
import { deviceInfo } from '@kada/library/src/device'
import { continuePay } from '@/services/service'
import qs from 'qs'
import config from '@/lib/config'

const { wechat: wechatConfig } = config

const WECHAT_PAY_INFO_COVER_URL = '//cdn.hhdd.com/frontend/as/i/db41f48c-11d5-5991-a2e4-8b3e9df26210.jpg'

// 微信授权页面地址
const AUTH_PAGE = wechatConfig.authPage || 'https://h5.hhdd.com/n/wechat/auth.html'
// 页面原始地址（排除微信登录信息之后的地址）
const ORIGIN_URL = location.href.replace(/(\?|&)*(code|state)=([^&=?#]+)/ig, '')

export async function payOrder(orderId, tradeType = 'JSAPI') {
  const extraParams = {

  }
  try {
    const res = await continuePay(orderId, tradeType, extraParams)
    if (res.code === 200) {
      if (!wechatConfig.payPage) {
        throw new Error('支付页面地址不存在')
      }

      if (!res.data) {
        console.log('支付失败')
        return
      }

      wxPay(res.data, {})
    }
  } catch (error) {
    console.log(error)
  }
}

/**
 * 跳转微信支付
 * @param {Object} order 订单信息
 *
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
function wxPay (order, options) {
  if (!deviceInfo.wechat) {
    // toast('请在微信中打开')
    return
  }

  if (!wechatConfig.payPage) {
    throw new Error('支付页面地址不存在')
  }

  if (!order) {
    // toast('订单不存在，支付失败')
    return
  }

  const { appId, timeStamp, nonceStr, package: payPackage, signType, paySign, orderInfo = {} } = order

  // const { coverUrl, name, price } = _packageInfo
  const { orderNo, orderPrice, productName, coverUrl = WECHAT_PAY_INFO_COVER_URL } = orderInfo
  const [originBaseUrl, originHash = ''] = ORIGIN_URL.split(/#+/)
  const [hashPath = '', hashQuery = ''] = originHash.split(/\?+/)
  const hashQueryObj = qs.parse(hashQuery)

  const successPage = `${originBaseUrl}#${hashPath}${qs.stringify(hashQueryObj, { addQueryPrefix: true })}`
  const query = qs.stringify({
    params: JSON.stringify({
      appId: appId || wechatConfig.appId,
      timeStamp,
      nonceStr,
      package: payPackage,
      signType,
      paySign,
      coverUrl,
      name: productName,
      price: orderPrice <= 900 ? (orderPrice / 100) : Math.floor(orderPrice / 100),
      orderNo,
      // 支付成功后的跳转页
      successDirectUrl: successPage
    })
  }, { addQueryPrefix: true })

//   setAfterReloadTask(AFTER_RELOAD_TASKS_TYPES.BUY_SUCCESS, [options])
  location.href = `${wechatConfig.payPage}${query}`
}
