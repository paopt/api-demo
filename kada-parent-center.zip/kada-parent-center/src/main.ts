// @ts-nocheck
import App from './App.svelte'
import { deviceInfo } from '@kada/library/src/device'
import '@kada/reset.css/scss/reset.scss'
import { initWechatConfig } from '@/lib/wechat'

if (deviceInfo.wechat) {
  initWechatConfig()
}

const app = new App({
  target: document.body,
})

export default app
