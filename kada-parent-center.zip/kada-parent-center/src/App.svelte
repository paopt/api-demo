<div class="o-app">
  <Router hashchange>
    <div class="o-app__body">
      <Route exact path="/index">
        {#await initPage() then module}
          <svelte:component this={module} bind:this={homeEl} {pageData} reload={homeReload} pageLoaded={!pageLoading} on:refresh={handleRefresh} />
        {/await}
      </Route>
    </div>
    <Route exact redirect="/index" />
    <Route exact path="/login" component={() => import('@/views/login.svelte')} />
    <Route exact path="/level" component={() => import('@/views/level.svelte')} />
    <Route exact path="/order" component={() => import('@/views/order.svelte')} />
    <Route exact path="/odetail" component={() => import('@/views/odetail.svelte')} />
    <Route exact path="/porder" component={() => import('@/views/porder.svelte')} />
    <!-- <Route exact path="/renew" component={() => import('@/views/renew.svelte')} />
    <Route exact path="/feedback" component={() => import('@/views/feedback.svelte')} /> -->
    <Route fallback component={NotFound} />
  </Router>
</div>

<script context="module" lang="ts">
  const moduleCache = new Map<string, any>()
</script>

<script lang="ts">
  import type { SvelteComponent } from 'svelte'
  // @ts-ignore
  import { Router, Route } from '@kada/yrv'
  import NotFound from '@/views/NotFound.svelte'
  import type Home from '@/views/level.svelte'
  import { getPageData, PageData, UserInfo } from './app'
  import './styles/global.scss'
  import { deviceInfo } from '@kada/library/src/device'
  import URLParser from '@/lib/urlParser'

  // @ts-ignore
  Router.hashchange = true

  const url = location.href
  const parsed = new URLParser(url)
  const { flag = 0, levelId = 0, fromtype = '' } = parsed.query

  let homeEl: Home
  // 首页是否处于加载状态
  let pageLoading: boolean = true

  let pageData: PageData

  // 首页是否重新加载
  let homeReload = true

  /**
   * 初始化首页
   */
  async function homeLoader () {
    const moduleName = '@/views/index.svelte'
    if (moduleCache.has(moduleName)) {
      homeReload = false
      return moduleCache.get(moduleName)
    }

    const module = await import('@/views/index.svelte')

    moduleCache.set(moduleName, module.default)
    homeReload = true
    return module.default
  }

  /**
   * 初始化页面
   */
  async function initPage (): Promise<{ pageData: PageData, module: SvelteComponent }> {

    let [data, module] = await Promise.all([getPageData(true), homeLoader()])

    // @ts-ignore
    // if (typeof window.kadarem === 'function' && deviceInfo.isPad) {
    //   // @ts-ignore
    //   window.kadaRemLayout = window.kadarem({ designWidth: flag ? 2048 : 1024, maxClientWidth: 1536 })
    // }

    if (!data) {
      pageData = null
      return module
    }

    if (pageLoading) {
      pageLoading = false
    }
    pageData = data

    return module
  }

  async function handleRefresh () {
    // 刷新数据
    pageData = await getPageData(true)
  }


</script>

<style lang="scss">
  @import './styles/variables';
  $page-name: 'o-app';

  .#{$page-name} {
   
    max-width: 7.5rem;
    margin: 0 auto;
    &__body {
    }

    @media #{$pad_landscape_query} {
      &__body {

      }
    }
  }
</style>
