// @ts-nocheck 目前太多组件，暂时不检查
import { writable, get } from 'svelte/store'
import { deviceInfo } from '@kada/library/src/device'
import {
  checkLogin as checkUserLogin,
  openLogin as openLoginPanel,
  openPayOrderPannel,
  refresh,
} from '@kada/jsbridge'
import config from '@/lib/config'
import { kdCookieShim } from '@kada/cookie-shim/src/cookie-shim'

import { appDownload } from '@/utils/url'
import { getUserInfo } from '@/services/user'
import { LevelListType, getPayInfoList, getIntroduceInfo, IntroduceInfoType, getSimgleImge, SingleImgeType } from '@/services/level'
import { showTypedDialog, DIALOG_TYPE } from '@kada/svelte-activity-ui'
import { promiseDelay } from '@/utils/promisify'
import URLParser from '@/lib/urlParser'
import { formatDate } from '@kada/library/utils/datetime'
import * as storage from '@/lib/storage'
import { continuePay } from '@/services/service'
import qs from 'qs'
import { CH } from '@/lib/fetch'
import { WX_GZH_LIST } from './views/help'
// import { toast } from '@kada/svelte-activity-ui';

const url = location.href
const parsed = new URLParser(url)
let { entryType = 0, condition = 0, deviceType = 0, fromtype = '' } = parsed.query

if (entryType) {
  entryType = entryType.match(/\d+/g)[0]
}
// 页面活动信息
export type PageActivityInfo = {
  activityId: number; // 活动id
  name: string; // 活动名称
  beginTime: number; // 活动开始时间
  endTime: number; // 活动结束时间
  currentTime: number; // 当前时间
  status: ActivityStatus; // 活动状态 0:未开始 1:进行中 2:已结束
}

// 用户相关信息
export type UserInfo = {
  isLogin: boolean;
  nick: string; // 用户名
  headUrl: string; // 用户头像
  vipInfo: any; // 用户vip信息
  infoText: string[];
  status: number;
  vipType: number;
  vipStatus: number;
  payFlag: number;
  channel: number;
  withholdingTime: number;
  withholdingPayPrice: number;
  remainingDays: number;
  remindExpireDays: number;
  level: number;
  autoRenewVipInfo: any;
  phone: number;
  nickName: string;
  isLoginFlag: boolean;
}

export enum VipType {
  VIP = 1,
  STORY = 3,
  BOOK = 4,
  SVIP = 5,
  BSVIP = 6,
}

export const VipStatusMap = new Map<string, VipType>([
  [VipType.VIP, 'VIP'],
  [VipType.STORY, '听书VIP'],
  [VipType.BOOK, '绘本VIP'],
  [VipType.SVIP, 'SVIP'],
  [VipType.BSVIP, '课外书SVIP'],
])

export type PageData = {
  levelData: Readable<LevelListType>,
  userInfo: Readable<UserInfo>
  introduceData: Readable<IntroduceInfoType>
  // resourceData: Readable<SingleImgeType | []>
}

function errorDialogDone () {
  if (deviceInfo.isKadaClient) {
    window.location.href = 'kada://backtohome?site=mom'
  } else {
    appDownload()
  }
}

// 页面数据缓存
let pageDataCache: PageData
/**
 * 获取页面数据
 * @param refresh 是否强制刷新，否则使用缓存
 */
export async function getPageData (refresh: boolean = false): Promise<PageData> {
  if (pageDataCache && !refresh) {
    return pageDataCache
  }
  console.log('hello world')
  return 'hello world'
  try {
    if (deviceInfo.isKadaClient) {
      // resourceData,
      const [ response, appUserInfo, infoData, loginData ] = await Promise.all([getPayInfoList(+entryType, +deviceType, +condition), getUserInfo(), getIntroduceInfo(), checkUserLogin()])

      const { data: responseData, code, message } = response
      const { data: { loginStatus: isLogin } } = loginData

      if (!response || code !== 200 || !responseData) {
        const msg = code === 5404 ? '活动不存在' : '获取信息失败'
        showTypedDialog({
          type: DIALOG_TYPE.ERROR,
          theme: 'new2021',
          title: '数据错误',
          message: message || msg,
          onDone: errorDialogDone
        })
    
        return null
      }
    
      let usrViplist = []
      let autoRenewVip = {}
      const { vipList, userInfo: { userId = 0, nick = '小读者', headUrl = '//cdn.hhdd.com/frontend/as/i/628c8d58-ccb4-5265-9fe0-8849f271a19d.png', createDate }, currentTime, createDays } = appUserInfo
      if (vipList.length) {
        const filterVipList = vipList.filter(item => item.status === 1)
        usrViplist = filterVipList.length ? filterVipList : vipList.sort((a, b) => a.remindExpireDays - b.remindExpireDays).slice(0, 1)

        autoRenewVip = vipList.filter(item => item.payFlag)[0] || {}
      }
      console.log(usrViplist)
      const {
        status = 0,
        vipType = 0,
        remainingDays = 0,
        level = 0,
        vipStatus = 0,
        remindExpireDays = 0,
        endTime = 0,
        payFlag = 0,
        channel = 0,
        withholdingTime = 0,
        withholdingPayPrice = 0,
        autoRenewVipInfo = autoRenewVip
      } = usrViplist[0] || []
      const { discount, deadline } = calculateDiscountPrice(vipStatus, remainingDays, remindExpireDays, currentTime, createDate, endTime)
      
      // 自然日24小时倒计时剩余时间计算
      const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
      const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
      const timerDeadline = todayLastTime - nowDate.getTime()
      
      const parseUserInfo: UserInfo = {
        userId,
        isLogin,
        status,
        vipType,
        remainingDays,
        remindExpireDays,
        level,
        vipStatus,
        createDays,
        payFlag,
        channel,
        autoRenewVipInfo,
        withholdingTime,
        withholdingPayPrice,
        dialogTitle: !status ? (createDays <= 7 ? '恭喜获得新人专属红包' : '恭喜获得限时直降特权') : '恭喜获得年卡续费红包',
        deadline: !status ? (createDays <= 7 ? 7 * daysStr - (currentTime - createDate) : timerDeadline) : deadline,
        couponDiscount: discount,
        nick: (() => {
          if (!isLogin) {
            return '请登录'
          }
          
          if (!status) {
            return '开通会员'
          }

          if (status === 2) {
            return '您的会员已过期'
          }

          if (remainingDays <= 15 && remainingDays > 0) {
            return `您的${VipStatusMap.get(vipType)}仅剩${remainingDays}天`
          }

          if (status === 1 && remainingDays === 0) {
            return `您的${VipStatusMap.get(vipType)}今天到期`
          }

          return nick
        })(),
        headUrl: isLogin ? headUrl : '//cdn.hhdd.com/frontend/as/i/628c8d58-ccb4-5265-9fe0-8849f271a19d.png',
        infoText: vipList.length ? usrViplist.map(({ endTime, vipType, status, remainingDays, level, payFlag }) => {

          if (level === 99) {
            return ''
            // return `${VipStatusMap.get(vipType)}终身会员`
          }

          if (remainingDays <= 14 && remainingDays > 0) {
            return `会员到期时间：${formatDate(endTime, 'YYYY-MM-DD')}`
          }

          if (status === 1 && remainingDays === 0) {
            return `会员到期时间：${formatDate(endTime, 'YYYY-MM-DD')}`
          }

          if (payFlag) {
            return `${formatDate(endTime, 'YYYY-MM-DD')}${VipStatusMap.get(vipType)}到期(自动续费)`
          }

          if (status === 2) {
            return [VipType.BOOK, VipType.STORY].includes(vipType) ? '开通会员畅学5万+精品内容' : `已过期${remindExpireDays}天`
          }

          return `${formatDate(endTime, 'YYYY-MM-DD')}${VipStatusMap.get(vipType)}到期`
          
        }).slice(0, 1) : [isLogin ? '开通会员畅学5万+精品内容' : '登录后同步会员特权']
      }
      // }
      
      console.log(parseUserInfo)
      // 设置缓存
      pageDataCache = {
        levelData: responseData,
        userInfo: parseUserInfo,
        introduceData: infoData.data,
        // resourceData: resourceData.data
      }

      return pageDataCache
      // response = data
    } else {
      showTypedDialog({
        type: DIALOG_TYPE.APP_ONLY,
        theme: 'new2021',
        title: '当前环境不支持',
        message: '请在KaDa阅读APP内打开',
        onDone: errorDialogDone
      })
    }
  } catch (error) {
    console.log('获取档位信息失败, ERROR:', error)
  }
}

// 路由显示状态保存
const routerViewStatus = new Map<string, number>([])

/**
 * 路由显示状态
 * @param path 路由路径
 * @returns
 */
export function getRouterViewStatus(path: string) {
  return routerViewStatus.get(path) || 0
}

/**
 * 设置路由显示状态
 * @param path 路由路径
 * @param status
 */
export function setRouterViewStatus(path: string, status: number) {
  routerViewStatus.set(path, status)
}

export type LoginOptionType = {
  openLogin: boolean,
  loginType: 0 | 1 | 2
  skipUserGuide: 0 | 1
  loginHelpVoice?: string
  fromtype?: string
}

/**
 * 检查页面是否已经登录
 *
 * @param {Object} options
 * @param {Boolean} options.openLogin 如果未登录，尝试打开登录弹层, 默认为 true
 * @param {Number} options.loginType 指定优先某种登录方式 0=??? 1=??? 2=微信(v4.1.20)
 * @param {Number} options.skipUserGuide 跳过新用户注册引导 默认为 0不跳过， 1跳过
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址
 *
 * @returns {Boolean} 是否已经登录成功
 */
export async function checkLogin (options: LoginOptionType = {}, call) {
  const { openLogin: $openLogin = true, ...openLoginOptions } = options
  try {
    const res = await checkUserLogin()
    if (res.data && res.data.loginStatus) {
      // 登录状态
      return true
    }
    console.log(openLoginOptions)
    if ($openLogin) {
      return openLogin(openLoginOptions, call)
    }
  } catch (error) {
    console.error(error)
  }

  return false
}

/**
 * 打开登录弹层
 *
 * @param {Object} options 登录弹层相关配置
 * @param {Number} options.loginType 指定优先某种登录方式 0=??? 1=??? 2=微信(v4.1.20)
 * @param {Number} options.skipUserGuide 跳过新用户注册引导 默认为 0不跳过， 1跳过
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址, 默认为 true
 *
 * @returns {Boolean} 是否登录成功
 */
export async function openLogin (options: LoginOptionType = {}, call) {
  const { loginHelpVoice = false, ...openLoginPanelOptions } = options

  try {
    // 呼起登录
    const loginRes = await openLoginPanel(openLoginPanelOptions)
    console.log(loginRes)
    // jsbridge调用异常
    if (loginRes.code === -1) {
      console.log(loginRes)
    }
    if (loginRes.data && loginRes.data.loginStatus > 0) {
      // dispatch('refresh')
      // 更新登录Cookie
      kdCookieShim({
        env: config.env,
        cookie: loginRes.data.cookies
      })
      if (call && typeof call === 'function') {
        call()
      }
      await promiseDelay(500)
      return true
    }
  } catch (error) {
    console.log(error)
  }

  return false
}

/**
 * 档位支付流程
 *
 * @param {Number} levelId [必填] 礼包ID
 * @param {Object} options
 * @param {Number} options.packageType 档位类型默认 6
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 * @param {String} options.pageStatus 页面状态
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址
 * @param {() => Promise<Boolean>} options.refreshPageData 刷新礼包数据
 * @param {(type:String) => Promise<String|Number>} options.getPackageId 获取刷新后礼包ID
 *
 * @return {Boolean} 是否购买成功
 */
export async function payment (
  levelId: number,
  call,
  options = {},
  payFlag?: number,
  userGroupId?: number,
  channelId?: number,
  vipInfoId?: number,
  upgradeRuleId?: number,
  configId?: number,
  price?: number,
  ) {
  const { packageType = 6, loginHelpVoice = false, refreshMoudles } = options
  try {

    const loginParams: LoginOptionType = {
      openLogin: true,
      loginType: 0,
      skipUserGuide: 1,
      loginHelpVoice
    }
    
    if (fromtype && deviceInfo.isAndroidHD) {
      loginParams.fromtype = fromtype
    }

    const isLogin = await checkLogin(loginParams, call)
    if (!isLogin) {
      return loginFail(isLogin)
    }

    const paySuccess = await openPayPanel(
      levelId,
      packageType,
      call,
      payFlag,
      userGroupId,
      channelId,
      vipInfoId,
      upgradeRuleId,
      configId,
      price
    )
    return paySuccess
  } catch (error) {
    console.log(error)
  }

  return false
}

const loginFail = (isLogin) => isLogin

// 支付面板是否已经打开
let _isPayPanelOpened = false

export const DEFAULT_REFRESH_MOUDLES = ["talent", "vipinfo", "course", "bookHoverball", "excellentHoverball", "elf", "notify_component", "studyOperate", "redpacket", "readingplan", "study_tour", "safeDomain", "bookList"]

/**
 * 打开支付面板
 *
 * @param {Number} levelId [必填]档位Id
 * @param {Number} packageType 礼包类型 默认 6
 *
 * @returns {Boolean} 是否购买成功
 */
async function openPayPanel (
  levelId: number,
  packageType: number,
  call,
  payFlag: number,
  userGroupId?: number,
  channelId?: number,
  vipInfoId?: number,
  upgradeRuleId?: number,
  configId?: number,
  price?: number,
  ) {
  
  const hasCurrentLevelId = pageDataCache.levelData.vipList.find(({ id }) => levelId === id )
  if (!levelId || !hasCurrentLevelId) {
    // console.log('档位不存在')
    // toast('档位不存在')
    return false
  }

  try {
    const payResult = await openPayOrderPannel({ 
      type: packageType,
      collectId: levelId,
      payFlag,
      userGroupId, 
      channelId,
      vipInfoId,
      upgradeRuleId,
      configId,
      price
    })
    const { code, data } = payResult || {}
    console.log('openPayPanel: data = ', data)
    const status = data && typeof data.payStatus === 'boolean'
      ? Number(data.payStatus)
      : data && data.payStatus
        ? parseInt(data.payStatus, 10)
        : 0

    _isPayPanelOpened = false
    const paySuccess = status === 1
    // jsbridge调用异常
    if (code === -1) {
      console.log(payResult)
    }

    if (paySuccess) {
      await promiseDelay(500)
      refresh([...DEFAULT_REFRESH_MOUDLES])

      if (call && typeof call === 'function') {
        console.log(call)
        call()
      }
      
      return true
    }

    return paySuccess
  } catch (error) {
    console.log(error)
    _isPayPanelOpened = false
  }

  return false
}

// 定义不同情况下的折扣价格
const discounts = [
  { type: [2, 5], vipDays: 30, prices: [50, 40, 30] },
  { type: [3, 6], vipDays: 30, prices: [60, 50, 40] },
]

// 定义一个函数，用于计算不同情况下的折扣价格
const daysStr = 24 * 60 * 60 * 1000
function calculateDiscountPrice(vipType: number, remainingDays: number, expiredDays: number, currentTime: number, createDate: number, endTime: number) {
  const discount = discounts.find((d) => d.type.includes(vipType) && d.vipDays >= remainingDays && d.vipDays >= expiredDays);

  if (discount) {
    if (expiredDays >= 1 && expiredDays <= 14) {
      return {
        discount: discount.prices[1],
        deadline: 14 * daysStr - (currentTime - endTime)
      }
    } else if (expiredDays >= 15 && expiredDays <= 30) {
      return {
        discount: discount.prices[2],
        deadline: 30 * daysStr - (currentTime - endTime)
      }
    } else if (remainingDays >= 0 && remainingDays <= 30) {
      return {
        discount: discount.prices[0],
        deadline: endTime - currentTime
      }
    }
  }

  return {
    discount: 0,
    deadline: 0
  }
}

export const REDPACKET_POPPED_FLAG = 'REDPACKET_POPPED_FLAG_YEARVIP'

/**
 * 设置当日红包已经弹出
 * @param {Number} userId 用户ID
 */
export function setRedPacketPopped (userId: number) {
  const key = `${REDPACKET_POPPED_FLAG}_${userId}`
  const nowDate = new Date()

  storage.set(key, 1, {
    // 存储过期时间为，今天的24小时之后
    expire: (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
  })
}

/**
 * 当日红包是否已经弹出
 * @param {Number} userId 用户ID
 */
export function hasRedPacketPopped (userId: number): boolean {
  const key = `${REDPACKET_POPPED_FLAG}_${userId}`

  return !!storage.get(key)
}

export const WECHAT_PAY_INFO_COVER_URL = '//cdn.hhdd.com/frontend/as/i/db41f48c-11d5-5991-a2e4-8b3e9df26210.jpg'

const ORIGIN_URL = location.href.replace(/(\?|&)*(code|state)=([^&=?#]+)/ig, '')

const { wechat: wechatConfig } = config

export async function payOrder(orderId, tradeType = 'JSAPI', extParams = {
  loginType: WX_GZH_LIST[storage.get('from')]?.loginType || 8
}) {
  console.log(extParams)
  const extraParams = JSON.stringify(extParams)
  try {
    const res = await continuePay(orderId, tradeType, extraParams)
  
    if (res.code === 200) {
      if (!wechatConfig.payPage) {
        throw new Error('支付页面地址不存在')
      }

      if (!res.data) {
        toast('支付失败')
        return
      }

      wxPay(JSON.parse(res.data), {})
    } else {
      toast('订单已经失效')
    }
  } catch (error) {
    console.log(error)
  }
}

/**
 * 跳转微信支付
 * @param {Object} order 订单信息
 *
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.packageIdType 礼包ID在viewData中的字段
 */
export function wxPay (order, options) {
  try {
    if (!deviceInfo.wechat) {
      toast('请在微信中打开')
      return
    }

    if (!wechatConfig.payPage) {
      throw new Error('支付页面地址不存在')
    }

    if (!order) {
      toast('订单不存在，支付失败')
      return
    }

    const { appId, timeStamp, nonceStr, package: payPackage, signType, paySign, orderInfo = {} } = order

    // const { coverUrl, name, price } = _packageInfo
    const { orderNo, orderPrice, productName, coverUrl = WECHAT_PAY_INFO_COVER_URL } = orderInfo
    const [originBaseUrl, originHash = ''] = ORIGIN_URL.split(/#+/)
    const [hashPath = '', hashQuery = ''] = originHash.split(/\?+/)
    const hashQueryObj = qs.parse(hashQuery)

    const successPage = `${originBaseUrl}#${hashPath}${qs.stringify(hashQueryObj, { addQueryPrefix: true })}`
    const query = qs.stringify({
      params: JSON.stringify({
        appId: appId || wechatConfig.appId,
        timeStamp,
        nonceStr,
        package: payPackage,
        signType,
        paySign,
        coverUrl,
        name: productName,
        price: orderPrice <= 900 ? (orderPrice / 100) : Math.floor(orderPrice / 100),
        orderNo,
        // 支付成功后的跳转页
        successDirectUrl: successPage
      })
    }, { addQueryPrefix: true })

  //   setAfterReloadTask(AFTER_RELOAD_TASKS_TYPES.BUY_SUCCESS, [options])
    location.href = `${wechatConfig.payPage}${query}`
  } catch (error) {
    console.log(error)
  }
}
