import config from './config'
import engine from 'store/src/store-engine'
import localStorage from 'store/storages/localStorage'
import defaultsPlugin from 'store/plugins/defaults'
import expirePlugin from 'store/plugins/expire'

// Vite 不支持 node_modules/@kada 中require的模块，改成项目实现

const { env, project: { name: projectName } } = config

const storages = [
  localStorage
]
const plugins = [
  defaultsPlugin,
  expirePlugin
]
const store = engine.createStore(storages, plugins)

// 默认保存时长15天
const STORE_MAX_AGE = 15 * 24 * 60 * 60 * 1000
export const KEY_PREFIX = `${env}__${projectName}`
const getKey = key => `${KEY_PREFIX}__${key}`

/**
 * 获取存在数据
 * @param {String} key 存储键值
 * @param {*} defaultValue 默认数据
 * @returns {*}
 */
export const get = (key: string, defaultValue?: any): any => {
  const val = store.get(getKey(key), defaultValue)
  
  if (typeof val === 'string') {
    try {
      return JSON.parse(val)
    } catch (error) {
      console.log(`storage.get(${key}) JSON.parse, ERROR:`, val)
    }
  }

  return val
}

type storageOptions = {
  expire?: number;
  maxAge?: number;
}
/**
 * 获取存储数据
 * @param {String} key 存储键值
 * @param {*} value 存储数据
 * @param {Object} options 配置参数
 * @param {Number} options.expire 数据过期时间戳，使用值 expire 优先于 maxAge
 * @param {Number} options.maxAge 数据过期时长，默认保存时长15天
 */
export const set = (key, value, options: storageOptions = {}): void => {
  let { expire, maxAge = -1 } = options
  if (typeof expire !== 'number' || isNaN(expire)) {
    if (maxAge > 0) {
      expire = Date.now() + maxAge
    } else {
      expire = Date.now() + STORE_MAX_AGE
    }
  }

  return store.set(getKey(key), value, expire)
}

/**
 * 删除数据
 * @param {String} key 存储键值
 */
export const del = (key: string) => store.remove(getKey(key))
