import config from './config'
import { initFetch } from '@kada/library/src/fetch'
import { DT, SV } from '@kada/library/src/device'
import { WX_GZH_LIST } from '../views/help'
import URLParser from '@/lib/urlParser'
import * as storage from '@/lib/storage'

const url = location.href
const parsed = new URLParser(url)
let { from = ''} = parsed.query

export const CH = WX_GZH_LIST[from || storage.get('from')]?.channel || 'wxgzhkdyd'

const { getApi, fetch } = initFetch(config)

const AV = '8.9.0' // 为了区分档位分群，暂时写死为当前最新版KaDa阅读app版本号


const RDI = `DT=${DT};SV=${SV};AV=${AV};CH=${CH}`

fetch.defaults.headers['RDI'] = RDI

export { getApi, fetch }
