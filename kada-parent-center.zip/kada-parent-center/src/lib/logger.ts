/**
 * 项目请求接口及请求相关
 *
 * @summary 项目请求接口及请求相关
 * @author diaoling <jinjian@hhdd.com>
 *
 * Created at     : 2020-09-27 16:47:41
 * Last modified  : 2022-04-22 21:01:10
 */

import config from './config'
// @ts-ignore
import Logger from '@kada/library/src/logger'

const { env, project: { name: projectName } } = config
export const logger = new Logger({
  env,
  projectName,
  levelMap: {
    development: 'ALL', // 开发环境，打印所有日志信息
    test: 'OFF', // 测试环境，仅显示信息
    staging: 'INFO', // 预发环境，仅显示信息
    production: 'OFF' // 生产环境，不打印出信息，直接提交日志服务器
  }
})
