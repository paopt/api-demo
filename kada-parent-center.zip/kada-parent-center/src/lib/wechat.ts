// @ts-nocheck
import WechatJSSDK, { DEFAULT_API_LIST } from '@kada/wechat-jssdk/src/index'
import config from '@/lib/config'
import qs from 'qs'
import { getWechatConfig } from '@/services/partner'
import { deviceInfo } from '@kada/library/src/device'
import * as userService from '@/services/user'
import { showLoading, hideLoading, toast } from '@kada/svelte-activity-ui'
// import { showLoading, hideLoading } from '@/components/Indicator/index'
// import { toast } from '@/components/Toast/index'
import { execAfterReloadTasks } from './reload-tasks'
import * as storage from '@/lib/storage'
import { WX_GZH_LIST } from '../views/help'
import URLParser from '@/lib/urlParser'

const parsed = new URLParser(location.href)
let { openId = '', from = '' } = parsed.query

// 微信JSSDK实例
export const wechat = new WechatJSSDK({
  title: 'KaDa阅读',
  desc: '孩子都爱的少儿阅读平台',
  link: location.href,
  imgUrl: 'https://cdn.hhdd.com/frontend/as/i/22a9c41c-50a4-5023-926a-3ff62e6940a0.png',
  type: 'link',
  dataUrl: '',
  success: function () {},
  fail: function () {},
  cancel: function () {},
  trigger: function () {},
  complete: function () {}
})

/**
 * 初始化WechatJSSDK
 * @returns {Promise<boolean>}
 */
export async function initWechatConfig () {
  try {
    const { code, data = {} } = await getWechatConfig(location.href.split('#')[0])

    if (code === 200) {
      const { appId, timestamp, nonceStr, signature } = data

      wechat.initialize({
        debug: config.env === 'development', // 开启调试模式
        appId, // 公众号的唯一标识
        timestamp, // 生成签名的时间戳
        nonceStr, // 生成签名的随机串
        signature, // 签名
        beta: true,
        jsApiList: DEFAULT_API_LIST, // 需要使用的JS接口列表
        sourceUrl: '//res.wx.qq.com/open/js/jweixin-1.6.0.js',
        openTagList: ['wx-open-launch-app', 'wx-open-launch-weapp']
      })

      return true
    }
  } catch (e) {
    console.error(e)
  }

  return false
}

const { wechat: wechatConfig } = config

// 页面请求参数
const pageQuery = qs.parse(location.search, {
  ignoreQueryPrefix: true
})

// 如果url存在code，进行微信授权登录
if (pageQuery.code && deviceInfo.wechat) {
  checkLogin().then(isLogin => {
    if (!isLogin || !openId) {
      userWxAuth(pageQuery)
      pageQuery.code = ''
    }
  })
}

// 微信授权页面地址
const AUTH_PAGE = wechatConfig.authPage || 'https://h5.hhdd.com/n/wechat/auth.html'
// 页面原始地址（排除微信登录信息之后的地址）
const ORIGIN_URL = location.href.replace(/(\?|&)*(code|state)=([^&=?#]+)/ig, '')

/**
 * 用户授权登录
 *
 * @param {Object} query url中请求参数
 *
 * @return {Boolean} 是否登录成功
 */
let _wxauthLoadingHideTimer = 0
async function userWxAuth (query = {}) {
  if (!deviceInfo.wechat) {
    return false
  }

  if (_wxauthLoadingHideTimer) {
    clearTimeout(_wxauthLoadingHideTimer)
  }
  console.log('userWxAuth', query.code)
  if (!query.code) {
    _wxauthLoadingHideTimer = setTimeout(() => {
      hideLoading()
    }, 1600)
    goWxAuth(ORIGIN_URL)
  } else {
    console.log('newUrl1', openId)
    // 拿到授权
    let isLogin = true
    let res
    try {
      showLoading('努力加载中...')
      res = await userService.login(query.code, WX_GZH_LIST[from]?.loginType)
      hideLoading()
    } catch (error) {
      hideLoading()
      toast(error.message || '加载失败')
    }

    // const queryCode = query.code
    // query.code = ''
    if (isLogin) {
      execAfterReloadTasks()
    }
    console.log('newUrl2', openId)
    const newUrl = location.href.replace(/(\?|&)*(code|state)=([^&=?#]+)/ig, '')
    console.log('newUrl3', from)
    console.log('newUrl3', newUrl)
    
    if (!openId) {
      storage.set('openId', `${res.data.openId}`)
      storage.set('unionId', `${res.data.unionId}`)
      storage.set('from', from)
      location.replace(`${newUrl}&openId=${res.data.openId}`)
    }
    
    // const newUrl = location.href.replace(/(\?|&)*(code|state)=([^&=?#]+)/ig, '')
    // if (history.replaceState) {
    //   console.log('1')
    //   // history.replaceState({code: query.code}, document.title, `${newUrl}?code=${query.code}`)
    // } else {
    //   onsole.log('2')
    //   location.replace(`${newUrl}?code=${query.code}` )
    // }

    return isLogin
  }
}

/**
 * 跳转微信登录授权
 * @param {string} originalPath
 */
function goWxAuth (originalPath) {
  if (!deviceInfo.wechat) {
    toast('请在微信中打开')
    return
  }

  const appId = WX_GZH_LIST[from]?.appId || wechatConfig.appId

  console.log('appId', appId)

  // 去授权
  const state = 63560
  const time = Date.now()
  const redirectUri = encodeURIComponent(`${AUTH_PAGE}?origin=${encodeURIComponent(originalPath)}&t=${time}`)
  const url = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appId}&redirect_uri=${redirectUri}&response_type=code&scope=snsapi_userinfo&state=${state}#wechat_redirect`
  location.replace(url)
}

/**
 * 微信登录
 *
 * @return {Boolean} 是否已经登录
 */
export async function openLogin () {
  if (!deviceInfo.wechat) {
    toast('请在微信中打开此页面')
    return false
  }
  const isLogin = await userWxAuth(pageQuery)

  return isLogin || userService.isLogin()
}

/**
 * 检查页面是否已经登录
 *
 * @param {Object} options
 * @param {Boolean} options.openLogin 如果未登录，尝试打开登录弹层, 默认为 true
 *
 * @returns {Boolean}
 */
export async function checkLogin (options = {}) {
  const { openLogin: openLoginPanel = false } = options

  if (!deviceInfo.wechat) {
    return false
  }

  if (!userService.isLogin()) {
    if (openLoginPanel) {
      return openLogin()
    }

    return false
  }

  return true
}


// 尝试登录次数
const TRY_LOGIN_LIMIT_KEY = 'TRY_LOGIN_LIMIT_KEY'
// 尝试登录次数
const TRY_LOGIN_MAX_COUNT = 3
let loginTryTimer = 0

/**
 * checkLogin 尝试登录
 * @param {*} options
 */
export function tryLogin () {
  if (loginTryTimer) {
    clearTimeout(loginTryTimer)
  }

  let tryTimes = parseInt(sessionStorage.getItem(TRY_LOGIN_LIMIT_KEY), 10) || 0
  let delayTryLogin = true
  if (isNaN(tryTimes) || tryTimes <= 0) {
    tryTimes = TRY_LOGIN_MAX_COUNT
    delayTryLogin = false
    sessionStorage.setItem(TRY_LOGIN_LIMIT_KEY, tryTimes)
  }

  loginTryTimer = setTimeout(async () => {
    tryTimes--
    const isLogin = await checkLogin({
      openLogin: true
    })

    if (loginTryTimer) {
      clearTimeout(loginTryTimer)
    }

    if (isLogin) {
      sessionStorage.removeItem(TRY_LOGIN_LIMIT_KEY)
    } else {
      sessionStorage.setItem(TRY_LOGIN_LIMIT_KEY, tryTimes)
    }
  }, delayTryLogin ? 5000 : 0)
}
