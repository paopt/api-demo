import { initAnalytics } from '@kada/library/src/analytics'
import config from './config'
import { getApi } from './fetch'

const { uwebId: siteId } = config

/**
 * 用户行为上报
 * @param trackName 上报事件名称
 * @param trackData 上报内容
 * @param isPageView 是否为页面展示
 */
let analyticsInstance = null
export const sendBehavior = (trackName: string, trackData?: any, isPageView?: boolean) => {
  if (!analyticsInstance) {
    analyticsInstance = initAnalytics({
      siteId,
      commitHabitApi: getApi('habit', 'commitUserHabit.json')
    })
  }
  setTimeout(() => analyticsInstance(trackName, trackData, isPageView))
}
