<div
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['c-levels', $$restProps.class].join(' ')}
>
  <Scroller>
    <div class="c-levels__wrap">
      <div class="c-levels__content">
        {#each vipList as item, index}
        <!-- ((activedIndex === yearCardCountIndex) && deadline && (388 - (item.price / 100 ) > 0) ? 'active-year-item' :  -->
          <div
            style={`width: ${item.sourceType === UPGRADE_SVIP_LEVEL_TYPE ? 3.64 : 2.12}rem;`}
            class={`c-levels__item ${index === activedIndex ? 'active-item' : 'normal-item'}`}
            on:click={(event) => changeVipLevel(event, index)}
            bind:this={levelElItems[item.id]}>
            {#if item.superscriptColorType}
              <p
                class="level-tag"
                style={`background:${item.superscriptColorType === 1 ? viewData.redBg + ';color: #FFECCB;' : viewData.blueBg + ';color: #935803;'}`}
              >
                {item.superscriptText}
              </p>
            {/if}
            <div class="main-content">
              <p class="name fzlty-zc">{item.title}{item.sourceType === UPGRADE_SVIP_LEVEL_TYPE ? `(${parseInt(((vipRemainTime / 30) * 10).toString()) / 10}个月)` : '' }</p>
              <p class="price">¥{item.price/100}</p>
              {#if !(item.origPrice === item.price)}
                <p class="origin-price">¥{item.origPrice/100}</p>
              {/if}
            </div>
            <!-- {#if yearCardCountIndex === index && (388 - (item.price / 100 ) > 0) && deadline}
              <div class="description">
                <Timer deadline={deadline} format={deadline <= DAYS_STR ? 'HH:MM:SS' : 'DD天HH:MM:SS'}>
                  <span slot="before">仅</span>
                </Timer>
              </div>
            {:else} -->
            <!-- item.sourceType === UPGRADE_SVIP_LEVEL_TYPE ? `每月仅${decimalAdjust('ceil', (item.price / 100) / (vipRemainTime / 30), -1)}元` :  -->
            {#if item.desc}
              <div class="description">{item.desc}</div>
            {/if}
            {#if (activedIndex === yearCardCountIndex && activedIndex === index) && deadline && (388 - (item.price / 100 ) > 0)}
              <div class="item-after"></div>
            {/if}
            <!-- {/if} -->
          </div>
        {/each}
      </div>
    </div>
  </Scroller>
  {#if upgradeLevelText}
    <div class="c-levels__tips fzlty">{@html upgradeLevelText}</div>
  {/if}
</div>

<script lang="ts">
  import { createEventDispatcher } from 'svelte'
  import { object_without_properties } from 'svelte/internal'
  import { VipStatusMap } from '../app'
  import Scroller from '@/components/HScroller.svelte'
  // @ts-ignore
//   import type { UserInfo } from '../app'

  const DAYS_STR = 24 * 60 * 60 * 1000

  const dispatch = createEventDispatcher()

  // 用户信息
//   export let userInfo: UserInfo = null

  export let activedIndex = 0

  export let vipRemainTime: number = 0

  export let vipType: number = 0

  export let deadline: number = 0

  let levelElItems = {}

  console.log('activedIndex', activedIndex)
  const UPGRADE_SVIP_LEVEL_TYPE = 11

  const AUTO_RENEW_KEY = {
    MONTH: 21,
    SEASON: 22.
  }

  const AUTO_RENEW_TYPE = {
    [AUTO_RENEW_KEY.MONTH]: '月',
    [AUTO_RENEW_KEY.SEASON]: '季'
  }

  //@ts-ignore
  $: upgradeLevelText = vipList[activedIndex]?.sourceType === UPGRADE_SVIP_LEVEL_TYPE ? `原剩余${vipRemainTime}天<span style="color: black;">（约${parseInt(((vipRemainTime / 30) * 10).toString()) / 10}个月）</span>${VipStatusMap.get(vipType)}时长升级为SVIP时长` : `${[AUTO_RENEW_KEY.SEASON, AUTO_RENEW_KEY.MONTH].includes(vipList[activedIndex]?.payType) ? `到期按每${AUTO_RENEW_TYPE[vipList[activedIndex]?.payType]}${vipList[activedIndex]?.price / 100}元自动续费，可随时取消` : ''}`
  // isUpgradeLevel ? 原剩余115天（约1.8个月）VIP时长升级为SVIP时长

  $: yearCardCountIndex = vipList.findIndex((item) => item.isDefault && item.payType === 3)

  const viewData = {
    redBg: 'linear-gradient(135deg, #4F4F4F 0%, #151515 100%)',
    blueBg: '#FFCF0C',
    acitivedId: 0,
    vipAgreementUrl: ''
  }

  export let vipList = []
  // 背景图片
  
  function changeVipLevel (event: MouseEvent, index: number) {
    activedIndex = index
    dispatch('click', index)
  }

  function handleClick (event: MouseEvent) {
    dispatch('click', event)
  }

  export const getYearCardEl = () => {
    const { id } = vipList[yearCardCountIndex]
    return levelElItems[id]
  }
</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $component_name: 'c-levels';

  .#{$component_name} {
    user-select: none;
    overflow: hidden;
    .title {
      color: #39364D;
      font-weight:600;
      font-size: 0.4rem;
      margin-left: 0.4rem;
      margin-top: .4rem;
    }
    &__wrap {
      // height: 2.96rem;
    //   @include size(100%, 2.96rem);
    }
    //   overflow-y: hidden;
    &__content {
      padding: 0.2rem 0 0.2rem 0.4rem;
      text-align: center;
      @include size(100%, auto);
      display: flex;
      overflow-x: scroll;
      &::after {
        content: '*';
        opacity: 0;
      }
        -webkit-overflow-scrolling: touch;
        // padding-bottom: .4rem;
        &::-webkit-scrollbar {
          width: 0;
          height: 0;
          display: none;
        }
        .active-item, .active-year-item {
          border: .02rem solid #666666;
        //   background: linear-gradient(316deg, #FFEBA7 0%, #FFF7E4 66%, #FFECBE 100%);
          background: linear-gradient(270deg, #FFE4AA 0%, #FFF1D4 100%);
          .main-content {
            .name {
              color: #333333;
            }
            .origin-price {
              color: #999999;
            }
            .price {
              color: #333333;
              font-weight: bold;
            }
          }
          .description {
            background: #FFD988;
            color: #333333;
          }
          .level-tag {
            left: -0.04rem;
          }
        }

        .active-year-item {
          border: .04rem solid #FE4242;
          background: linear-gradient(270deg, #FE4242 0%, #FF6060 100%);

          .main-content {
            height: 1.98rem;
            border-radius: .24rem;
            background: linear-gradient(272deg, #FED888 0%, #FFEECB 100%);
          }
          .description {
            background: linear-gradient(270deg, #FE4242 0%, #FF6060 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: .18rem;
            color: white;
          }
        }
    
    }

    &__item {
      position: relative;
      @include size(2.12rem, 2.64rem);
      box-sizing: border-box;
      margin-right: 0.16rem;
      // border: .02rem solid #FFE996;
      background: #F5F5F5;
      border-radius: 0.24rem;
      z-index: 1;
      box-sizing: border-box;
      .level-tag {
        position: absolute;
        top: -0.1rem;
        left: -0.01rem;
        z-index: 999;
        height: 0.34rem;
        padding: 0 0.16rem;
        border-radius: .16rem 0 .16rem 0;
        font-size: 0.2rem;
        line-height: 0.36rem;
        color: #fff;
        @include overflow-line(1);
      }
      .main-content {
        // @include size(100%, 1.92rem);
        display: flex;
        flex-direction: column;
        border-radius: 0.24rem 0.24rem 0 0;
        .name {
          @include overflow-line(1);
          // min-width: 2.12rem;
          // padding: 0 .3rem;
          font-size: 0.28rem;
          margin-top: 0.42rem;
          line-height: 0.4rem;
          color: #333333;
        }
        .price {
          font-size: 0.48rem;
          margin-top: 0.2rem;
          line-height: 0.52rem;
          color: #333333;
        }
        .origin-price {
          text-decoration: line-through;
          margin-top: 0.16rem;
          line-height: 0.28rem;
          color: #999999;
          font-size: .24rem;
        }
      }
      .normal-content {
        background: #fff;
        color: #525252;
        .origin-price {
          color: #CE8447;
        }
      }
      .description {
        position: absolute;
        bottom: 0;
        height: .56rem;
        display: flex;
        align-items: center;
        justify-content: center;
        @include overflow-line(1);
        // @include size(100%, 0.54rem);
        width: 100%;
        // padding: 0.16rem 0;
        border-radius: 0 0 0.2rem 0.2rem;
        color: #333333;
        font-size: 0.24rem;
        background: #EEEEEE;
      }
      .item-after {
        position: absolute;
        z-index: 100;
        bottom: -.18rem;
        left: 50%;
        transform: translateX(-50%);
        width: .44rem;
        height: .2rem;
        background: url(//cdn.hhdd.com/frontend/as/i/d798754b-5e97-5bab-92dc-b5b97566f395.png) no-repeat;
        background-size: cover;
      }
    }

    &__tips {
      height: .74rem;
      line-height: .74rem;
      font-size: .24rem;
      color: #999999;
      padding-left: .4rem;
    }

    // @media #{$padDeviceInfo} {
    //   &__content {
    //     padding-left: .68rem;
    //   }

    //   &__tips {
    //     padding-left: .68rem;
    //   }
    // }
  }
</style>
