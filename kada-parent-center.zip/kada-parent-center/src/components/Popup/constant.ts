/**
 * 显示类型
 * @enum {(-1|0|1)} 显示类型
 */
 export enum POPUP_ACTIVE_TYPES {
  NONE = -1, // 不显示
  HIDE = 0, // 隐藏弹层
  SHOW = 1 // 显示弹层
}
