<div
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['sui-popup', $$restProps.class || ''].join(' ')}
  class:is-hide={active === POPUP_ACTIVE_TYPES.NONE}
  class:is-fadein={active === POPUP_ACTIVE_TYPES.SHOW}
  class:is-fadeout={active === POPUP_ACTIVE_TYPES.HIDE}
  bind:this={modal}
>
  <div class="sui-popup__mask" on:click={onMaskClick}></div>
  <div
    class="sui-popup__container"
    class:is-scalein={active === POPUP_ACTIVE_TYPES.SHOW}
    class:is-scaleout={active === POPUP_ACTIVE_TYPES.HIDE}
  >
    <slot></slot>
  </div>
</div>

<script lang="ts">
  /**
   * 弹层
   * @component Popup
   *
   * @example
   * <Popup bind:this={popup}>
   *  <div class="c-content">弹层内容</div>
   * </Popup>
   */
  import { createEventDispatcher } from 'svelte'
  import { object_without_properties } from 'svelte/internal'
  import { promiseDelay } from '@/utils/promisify'
  import { POPUP_ACTIVE_TYPES } from './constant'

  const dispatch = createEventDispatcher()

  /**
   * 是否显示弹窗
   * @type {Boolean} active
   */
  export let active: POPUP_ACTIVE_TYPES = POPUP_ACTIVE_TYPES.NONE

  /**
   * 点击遮罩是否隐藏
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide: boolean = false

  /**
   * 是否将弹窗添加到Body中
   * @type {Boolean} appendToBody
   */
  export let appendToBody: boolean = true

  // 弹窗组件引用
  let modal: HTMLElement
  // 是否锁定滚动
  let isScrollLocked: boolean = false

  // 将弹层添加到body
  $: {
    if (modal && active && appendToBody && (typeof window !== 'undefined')) {
      const el = modal
      const doc = window.document

      if (el && el.parentNode && doc.body && (el.parentNode !== doc.body)) {
        if (el.parentNode) {
          el.parentNode.removeChild(el)
        }
        doc.body.appendChild(el)
      }
    }
  }

  // 是锁定滚动
  $: if (active === POPUP_ACTIVE_TYPES.SHOW && !isScrollLocked) {
    isScrollLocked = true
  } else if (isScrollLocked) {
    isScrollLocked = false
  }

  /**
   * 点击遮罩关闭弹层
   * @event maskClick
   */
  function onMaskClick () {
    if (maskClickHide) {
      close()

      dispatch('maskClick')
    }
  }

  /**
   * 显示弹层
   * @event show
   */
  export function show () {
    active = POPUP_ACTIVE_TYPES.SHOW

    dispatch('show')
  }

  /**
   * 隐藏弹层
   * @event hide
   */
  export function hide () {
    active = POPUP_ACTIVE_TYPES.HIDE
    promiseDelay(600).then(() => {
      active = POPUP_ACTIVE_TYPES.NONE
    })
    dispatch('hide')
  }

  /**
   * 关闭弹层
   * @event destroy
   */
  export function close() {
    active = POPUP_ACTIVE_TYPES.HIDE
    promiseDelay(600).then(() => {
      active = POPUP_ACTIVE_TYPES.NONE
      setTimeout(() => dispatch('destroy'))
    })
  }
</script>

<style lang="scss">
  $component-name: 'c-popup';

  .#{$component-name} {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 9999;

    &.is-hide {
      display: none;
    }

    &.is-fadein {
      opacity: 0;
      animation: sui-popup-fade 0.25s 1 forwards alternate;
    }

    &.is-fadeout {
      opacity: 1;
      animation: sui-popup-fade-out 0.3s 0.2s 1 forwards;
    }

    &__mask {
      position: absolute;
      top: -1px;
      left: -1px;
      right: -1px;
      bottom: -1px;
      background: linear-gradient(to bottom, rgba(0, 0, 0, 0.8) 0%, rgba(0, 0, 0, 0.8) 50%, rgba(0, 0, 0, 0.9) 100%);
    }

    &__container {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 1;
      animation: popin 0.25s ease-out 1 forwards;

      :global(*),
      * {
        pointer-events: auto;
      }

      &.is-scalein {
        transform: scale(1.2);
        animation: sui-popup-scale-in 0.25s 0.05s 1 forwards alternate;
      }

      &.is-scaleout {
        transform: scale(1);
        animation: sui-popup-scale-out 0.3s 1 forwards;
      }
    }

    @keyframes sui-popup-fade {
      0% {
        opacity: 0;
      }

      100% {
        opacity: 1;
      }
    }
    @keyframes sui-popup-fade-out {
      0% {
        opacity: 1;
      }

      100% {
        opacity: 0;
      }
    }
    @keyframes sui-popup-scale-in {
      0% {
        transform: scale(1.2);
      }

      100% {
        transform: scale(1);
      }
    }
    @keyframes sui-popup-scale-out {
      0% {
        transform: scale(1);
        opacity: 1;
      }

      100% {
        transform: scale(1.2);
        opacity: 0;
      }
    }
  }
</style>
