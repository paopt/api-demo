<div class="c-other {className}"
  {style}
> 
  <div class="c-other__wrap">
    <div class="c-other__title fzlty-zc">其他服务</div>
    <div class="c-other__nav service fzlty" on:click={() => handleNavLick('services')}>专属客服</div>
    <!-- <div class="c-other__nav what fzlty" on:click={() => handleNavLick('about')}>什么事Kada阅读</div> -->
  </div>
</div>

<script lang="ts">
  import { deviceInfo } from '@kada/library/src/device'
  import { createEventDispatcher } from 'svelte'

  const dispatch = createEventDispatcher()

  /**
   * 组件样式
   * @type {String} class
   */
  export let style: string = ''

  /**
   * 组件className
   * @type {className} class
   */
  export let className: string = ''

  export let readCount: number = 0

  export let readDays: number = 0

  export let flag: boolean = false

  const handleNavLick = (e) => {
    console.log(1)
    dispatch('nav-click', e)
  }

</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $component-name: 'c-other';

  .#{$component-name} {
    padding: .32rem .4rem;
    &__wrap {
      padding: .4rem .36rem;
      background-color: white;
      border-radius: .24rem;
      box-shadow: 0px .2rem .3rem 0px rgba(0,0,0,0.02);
    }

    &__title {
      color: #666666;
      font-size: .32rem;
      padding-bottom: .32rem;
      border-bottom: .02rem solid rgba(238, 238, 238, .35);
    }
    &__nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #333333;
      font-size: .32rem;
      line-height: initial;
    //   border-top: .02rem solid #EEEEEE;
      padding-top: .32rem;
      padding-bottom: .18rem;
      &::after {
        content: '';
        width: .28rem;
        height: .28rem;
        background: url(//cdn.hhdd.com/frontend/as/i/8de792b8-a17f-5789-a36c-1ecb70ac4f48.png) no-repeat;
        background-size: cover;
        margin-left: auto;
      }
      &::before {
        content: '';
        width: .48rem;
        height: .48rem;
        background: url(//cdn.hhdd.com/frontend/as/i/b9a7e32f-7ac4-5f9e-8069-d803eede4266.png) no-repeat;
        background-size: cover;
        margin-right: .24rem;
      }
      &.service::before {
        background: url(//cdn.hhdd.com/frontend/as/i/5b595071-9c9e-5ff4-8f5c-ca472f2f0bfd.png) no-repeat;
        background-size: cover;
      }
      &.what::before {
        background: url(//cdn.hhdd.com/frontend/as/i/2ded3188-7ada-5622-b250-bf9b95b7bc49.png) no-repeat;
        background-size: cover;
      }
    }
  }
</style>
