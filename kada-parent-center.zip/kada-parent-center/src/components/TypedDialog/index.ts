/**
 * @example
 * showDialog({
 *  type: DIALOG_TYPE.ERROR,
 *  title: '错误'
 *  message: '这是错误内容'
 * })
 */
import Dialog from './Dialog.svelte'

/**
 * 显示类型
 * @enum {(-1|0|1)} 显示类型
 */
export enum POPUP_ACTIVE_TYPES {
  NONE = -1, // 不显示
  HIDE = 0, // 隐藏弹层
  SHOW = 1 // 显示弹层
}

// 对话框属性
export type DialogProps = {
  type?: DIALOG_TYPE, // 弹窗类型 @see DIALOG_TYPE
  title?: string,
  message?: string,
  buttonText?: string,
  buttonClassName?: string,
  showCloseButton?: boolean,
  maskClickHide?: boolean,
  showCloseBtn?: boolean,
  onClose?: () => void,
  onDone?: () => void,
  doneCloseDialog?: boolean,
}

/**
 * 弹窗枚举类型
 */
 export enum DIALOG_TYPE {
  FAIL = 'fail', // 失败
  SUCCESS = 'success', // 成功
  INFO = 'info', // 信息
}

/**
 * 预定义弹窗样式
 */
const DIALOG_DEFINED_STYLES: Record<DIALOG_TYPE, DialogProps> = {
  [DIALOG_TYPE.FAIL]: {
    type: DIALOG_TYPE.FAIL,
    message: `挑战失败！很遗憾<br>没有集齐15颗星，下次再战`,
  },
  [DIALOG_TYPE.SUCCESS]: {
    type: DIALOG_TYPE.SUCCESS,
    message: `太棒了，收获一颗星星`,
    buttonText: '立即收下',
  },
  [DIALOG_TYPE.INFO]: {
    type: DIALOG_TYPE.INFO,
    message: `认真阅读才能获得星星`,
    buttonText: '继续阅读',
  },
}

let dialog = null
/**
 * 创建弹窗实例
 */
function createDialog (props: DialogProps | DIALOG_TYPE): Promise<boolean> {
  let dialogProps: DialogProps = {}
  if (typeof props === 'string') {
    dialogProps = DIALOG_DEFINED_STYLES[props] || { type: props }
  } else {
    dialogProps = props
  }

  if (dialog) {
    dialog.$destroy()
  }

  dialog = new Dialog({
    target: document.body,
    props: {
      ...dialogProps,
      active: POPUP_ACTIVE_TYPES.SHOW
    }
  })

  dialog.$on('destroy', () => {
    dialog.$destroy()
  })

  return new Promise((resolve) => {
    dialog.$on('close', () => resolve(false))
    dialog.$on('done', () => resolve(true))
  })
}

/**
 * 显示弹窗
 */
export function showDialog (props: DialogProps | DIALOG_TYPE): Promise<boolean> {
  return createDialog(props)
}

/**
 * 关闭当前弹窗
 */
export function closeDialog () {
  if (dialog && dialog.close) {
    dialog.close()
  }
}

export default Dialog
