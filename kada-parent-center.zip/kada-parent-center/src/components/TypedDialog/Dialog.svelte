<Popup
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['c-typed-dlg', $$restProps.class || ''].join(' ')}
  {active}
  {rootElement}
  {maskClickHide}
  on:maskClick={handlePopupMaskClick}
  on:hide={handlePopupHide}
  on:destroy={handlePopupDestroy}
  bind:this={popupEl}
>
  <div class="c-typed-dlg__wrapper">
    <div class="c-typed-dlg__body {type ? `is-${type}` : ''}">
      <div class="close" on:click={handleCloseClick}></div>
      {#if title}<div class="title">{@html title}</div>{/if}
      {#if message}<div class="msg">{@html message}</div>{/if}
      {#if buttonText}<div class="btn {buttonClassName}" on:click={done}>{buttonText}</div>{/if}
    </div>
  </div>
</Popup>

<script lang="ts">
  // @ts-nocheck
  /**
   * 预定义样式的弹窗
   * @extends {'@kada/svelte-ui-popup'} PopupProps
   * @component TypedDialog
   */
  import { createEventDispatcher, onDestroy } from 'svelte'
  import { object_without_properties } from 'svelte/internal'
  import { Popup } from '@/components/Popup/index'
  import { POPUP_ACTIVE_TYPES, DIALOG_TYPE } from './index'

  /**
   * 滚动锁定对象
   */
  export let rootElement: HTMLElement = null

  const dispatch = createEventDispatcher()

  /**
   * 弹窗是否显示
   */
  export let active: POPUP_ACTIVE_TYPES = POPUP_ACTIVE_TYPES.NONE
  /**
   * 点击确认按钮是否关闭弹窗
   */
  export let doneCloseDialog: boolean = true
  /**
   * 弹窗类型
   */
  export let type: DIALOG_TYPE = DIALOG_TYPE.INFO
  /**
   * 通用弹窗标题
   */
  export let title: string = ''
  /**
   * 通用弹窗信息
   */
  export let message: string = ''
  /**
   * 通用弹窗按钮文案
   */
  export let buttonText: string = ''
  /**
   * 弹窗按钮样式
   */
  export let buttonClassName: string = ''
  /**
   * 是否支持点击mask关闭弹窗
   */
  export let maskClickHide: boolean = false

  /**
   * 是否显示关闭按钮
   */
  export let showCloseBtn: boolean = true

  /**
   * 点击关闭按钮回调
   */
  export let onClose: () => void = null
  /**
   * 点击确认按钮回调
   */
  export let onDone: () => void = null

  let resolve
  /**
   * 弹窗完成后处理结果
   * @type {Promise<Boolean>}
   */
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  // Popup对象
  let popupEl: Popup

  /**
   * 关闭弹窗
   * @event {Object} close 关闭事件
   */
  export function close () {
    dispatch('close')
    popupEl.close()

    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  /**
   * 点击确认按钮
   * @event {Object} done 完成事件
   */
  function done () {
    dispatch('done')
    resolve(true)
    if (typeof onDone === 'function') {
      onDone()
    }
    if (doneCloseDialog) {
      popupEl.close()
    }
  }

  /**
   * 处理点击遮罩事件
   */
  function handlePopupMaskClick () {
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  function handleCloseClick () {
    if (showCloseBtn) {
      close()
    } else {
      done()
    }
  }

  /**
   * 响应销毁
   */
  function handlePopupDestroy () {
    dispatch('destroy')
  }

  /**
   * 处理隐藏弹窗
   */
  function handlePopupHide () {
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  onDestroy(() => {
    onClose = null
    onDone = null
  })
</script>

<style lang="scss">
  @import '../../styles/mixins';

  $component-name: 'c-typed-dlg';

  .#{$component-name} {
    min-height: 100%;
    z-index: 199;

    &__wrapper {
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: max-content;
      min-height: 100%;
      transition: transform .1s ease;
    }

    &__body {
      position: relative;
      width: 7.40rem;
      height: 5.60rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      background: url(//cdn.hhdd.com/frontend/as/i/c3426276-9b52-58bf-b6d9-f0fe3cb06546.png) no-repeat 50% 0 / 100% 100%;
      padding: 2.8rem 1.4rem 1.1rem 1.4rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;

      &.is-fail {
        background-image: url(//cdn.hhdd.com/frontend/as/i/6cec54a4-7463-57d0-bd0a-ba487614db11.png);
      }

      &.is-success {
        background-image: url(//cdn.hhdd.com/frontend/as/i/a4753810-1bb6-5f73-bdae-363ed95f4630.png);
      }

      &.is-info {
        background-image: url(//cdn.hhdd.com/frontend/as/i/c3426276-9b52-58bf-b6d9-f0fe3cb06546.png);
      }

      .title {
        font-size: 0.34rem;
        color: #CC7B31;
        line-height: 1.2;
        margin-bottom: 0.14rem;
        text-align: center;
        @include overflow-line(1);
      }

      .msg {
        font-size: 0.34rem;
        color: #CC7B31;
        line-height: 1.4;
        text-align: center;
      }

      .close {
        position: absolute;
        width: 0.9rem;
        height: 0.9rem;
        border-radius: 50%;
        top: 2rem;
        right: 0.6rem;
        background: rgba(0, 0, 0, 0);
        z-index: 99;
      }

      .btn {
        width: 2.12rem;
        height: 0.74rem;
        margin: 0.24rem auto 0 auto;
        background: url(//cdn.hhdd.com/frontend/as/i/48855d62-df74-5c56-8fba-65fad9962eec.png) no-repeat 0 0 / 100% 100%;
        font-size: 0.32rem;
        color: #FFFFFF;
        line-height: 0.36rem;
        flex-shrink: 0;
        text-shadow: 0 0 3px #EC9A4E;
        text-align: center;
        padding: 0.16rem 0.3rem 0.1rem 0.3rem;
        transition: transform 0.25s ease;

        &:active {
          transform: scale(0.95);
        }
      }
    }
  }
</style>
