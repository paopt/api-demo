<div class="c-coupon {className} {deviceInfo.isPad && flag ? 'is-coupon-pad' : ''}"
  {style}
> 
  <div class="c-coupon__item">
    <div class="item">
      <p><span class="discount">{discount}</span>元</p>
      <p class="coupon-tips">—— 续费奖学金 ——</p>
    </div>
    <div class="item timer-item fzlty-zc">
      <div>
        <p>可用于</p>
        <p>SVIP年卡抵扣</p>
      </div>
      <div class="timer fzlty">
        <Timer deadline={remainingTime} format='HH:MM:SS' >
          <span slot="after">后过期</span>
        </Timer>
      </div>
    </div>
  </div>
  <div class="c-coupon__tips fzlty-zc">你的会员<span>{status === 1 ? `仅剩${remainingDays}天` : '已到期'}</span> 使用奖学金续费限时{discountPercent[discount]}折</div>
</div>

<script lang="ts">
  import { Timer } from '@kada/svelte-activity-ui'
  import { deviceInfo } from '@kada/library/src/device'
 
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 组件样式
   * @type {String} style
   */
  export let style = ''
  
  export let discount: number = 0

  export let remainingDays: number = 0

  export let status: number = 0

  export let flag: boolean = false

  const remainingTime = new Date().setHours(24, 0, 0, 0) - Date.now()

  const discountPercent = {
    50: '88',
    40: '9',
    30: '93',
    60: '85',
  }

</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $component-name: 'c-coupon';

  .#{$component-name} {
      &__item {
        width: 100%;
        background: url(//cdn.hhdd.com/frontend/as/i/0264173b-e511-5685-bf01-e753bbd9fd91.png) no-repeat;
        background-size: 100% 100%;
        height: 2.2rem;
        display: flex;
        justify-content: space-between;
        padding: .36rem 0;

        .item {
          display: flex;
          justify-content: center;
          flex-direction: column;
          align-items: center;
          line-height: 1.2;
          color: #FF440D;
          font-size: .4rem;
          font-weight: 600;
          flex: 6;

          .discount {
            font-size: 1.12rem;
          }
          .coupon-tips {
            font-size: .24rem;
            font-weight: 400;
          }

        }

        .timer-item {
          font-size: .32rem;
          color: #FFE3BD;
          text-align: center;
          line-height: .44rem;
          font-weight: 400;
          flex: 5;

          .timer {
            margin-top: .12rem;
            width: 2.22rem;
            height: .56rem;
            font-size: .26rem;
            color: #FF440D;
            background-color: #FFE8C9;
            border-radius: .28rem;
            display: flex;
            align-items: center;
            justify-content: center;
          }
        }          
      }

      &__tips {
        width: 96%;
        line-height: .8rem;
        margin: 0 auto;
        background: #FFF7EB;
        border-radius: 0 0 .24rem .24rem;
        text-align: center;
        color: #FF440D;
        font-size: .24rem;
      }
  }
  .is-coupon-pad {
      .c-coupon__item {
        height: 2.8rem;
      }
      .item {
        font-size: .48rem;
        .discount {
          font-size: 1.22rem;
        }
        .coupon-tips {
          font-size: .28rem;
        }

      }

      .timer-item {
        font-size: .38rem;

        .timer {
          width: 2.82rem;
          height: .66rem;
          border-radius: .4rem;
          font-size: .32rem;
        }
      }          

      .c-coupon__tips {
        line-height: 1rem;
        font-size: .34rem;
      }
    }
    
</style>
