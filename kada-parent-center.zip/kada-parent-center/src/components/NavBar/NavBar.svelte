<script>
  import { createEventDispatcher, onDestroy, onMount } from 'svelte'
  import colorString from 'color-string'
  import { promiseDelay } from '@/utils/promisify'
  import compareVersions from 'compare-versions'
  import { deviceInfo } from '@kada/library/src/device'
  const dispatch = createEventDispatcher()

  /**
   * 组件样式
   * @svelte-prop {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 导航栏自定义样式
   * @svelte-prop {String} style
   */
  export let style = ''
  /**
   * 是否使用fixed布局
   * @svelte-prop {Boolean} fixed
   */
  export let fixed = false
  /**
   * 是否填充满navbar所占区域
   * @svelte-prop {Boolean} fullContainer
   */
  export let fullContainer = false
  /**
   * 是否隐藏分享按钮
   * @svelte-prop {Boolean} isHideShare
   */
  export let isHideShare = false
  /**
   * 显示主题
   * @svelte-prop {String} theme 取值范围 blue --蓝色主题 gray --灰色半透明 transparent -- 透明背景
   */
  export let theme = 'blue'
  /**
   * 根据滚动设置背景透明度
   * @svelte-prop {Boolean} scrollOut
   */
  export let scrollOut = false
  /**
   * 背景色滚动目标透明度
   * @svelte-prop {Number} targetBgOpacity
   */
  export let targetBgOpacity = 1
  /**
   * 目标背景色
   * @svelte-prop {String} targetBgColor
   */
  export let targetBgColor = ''
  
  // 是否有效vip用户
  export let vipStatus = 0

  export let showSpacer = true

  $: originBgColor = colorString.get.rgb(targetBgColor)
  let navbarEl = null
  let windowScrollY = 0
  let navbarHeight = 44

  $: currentBgColor = ((scrollY, height, targetOpacity) => {
    if (!Array.isArray(originBgColor)) {
      return
    }

    const originOpacity = (originBgColor && originBgColor.length > 3) ? originBgColor[3] : 0
    const diffOpacity = targetOpacity - originOpacity
    let opacity = diffOpacity

    if (scrollY <= height) {
      opacity = Math.min(1, scrollY / height) * diffOpacity
    } else {
      opacity = 1
    }

    return colorString.to.rgb(originBgColor[0], originBgColor[1], originBgColor[2], originOpacity + opacity)
  })(windowScrollY, navbarHeight * 2.5, targetBgOpacity)

  const isAndroid = /android|adr/i.test(window.navigator.userAgent)
  const isPad = Math.min(window.screen.height, window.screen.width) >= 600 && !isAndroid
  const isAndroidHD = (/AndroidPad/i.test(window.navigator.userAgent) || (Math.min(window.screen.height, window.screen.width) >= 600 && isAndroid))
  const versionAfter4910 = deviceInfo.appVersion ? compareVersions(deviceInfo.appVersion, '4.9.1.0') >= 0 : false
  const onShareClick = () => {
    dispatch('shareClick')
  }

  onMount(() => {
    if (targetBgColor) {
      originBgColor = colorString.get.rgb(targetBgColor)
    } else if (navbarEl) {
      const style = window.getComputedStyle(navbarEl)
      originBgColor = colorString.get.rgb(style.backgroundColor || 'transparent')
    }
  })
</script>

<svelte:window bind:scrollY={windowScrollY} />
<header class="app-navbar {className} {theme ? `skin-${theme}` : ''}"
  class:is-fixed={fixed}
  class:full-container={fullContainer}
  class:is-android={isAndroid}
  class:is-android-hd={isAndroidHD && versionAfter4910}
  class:is-ipad={isPad}
  style={`${style};${scrollOut && currentBgColor ? `background-color: ${currentBgColor}` : ''};`}
  bind:this={navbarEl}
>
<!-- style={`padding-top: ${false ? 26 : 0}px;`} -->
  <div class="app-navbar__wrap" bind:clientHeight={navbarHeight}>
    <h2 class="app-navbar__title fzlty-zc">
      <slot></slot>
    </h2>
    {#if !isHideShare}
      <div
        class="app-navbar__share"
        on:click={onShareClick}
        style={`background-image: url(${vipStatus === 1 ? '//cdn.hhdd.com/frontend/as/i/3346643a-8314-5ad2-9613-045984651d24.png' : '//cdn.hhdd.com/frontend/as/i/debe65d1-9e82-5f59-86dc-df1cbbdffcf0.png'});`}>
      </div>
    {/if}
  </div>
</header>
{#if !fullContainer && fixed && showSpacer}
  <div class="app-navbar-spacer"
    class:is-android={isAndroid}
    class:is-ipad={isPad}
    class:is-android-hd={isAndroidHD && versionAfter4910}
  ></div>
  <!-- style={false ? 'height: 76px;' : ''} -->
{/if}

<style lang="scss">
  @import './variables';
  @import '../../styles/variables';

  #{$app_navbar-namespace} {
    position: relative;
    z-index: $app_navbar-zindex;
    width: 100%;
    background: $app_navbar-bgcolor;
    box-sizing: border-box;
    // 内容区全屏
    &.full-container {
      background: none;
      pointer-events: none;
    }

    &.is-fixed {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
    }

    &__wrap {
      position: relative;
      display: flex;
    }

    &__title {
      flex: 1;
      height: $app_navbar-height;
      line-height: $app_navbar-height;
      margin: 0 $app_navbar-title_margin;
      color: $app_navbar-title_color;
      font-size: $app_navbar-title_font-size;
      font-weight: 400;
      text-align: center;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      box-sizing: border-box;

      #{$app_navbar-namespace_android} & {
        height: $app_navbar-height-android;
        line-height: $app_navbar-height-android;
        margin: 0 $app_navbar-title_margin-android;
      }

      #{$app_navbar-namespace_ipad} & {
        height: $app_navbar-height-ipad;
        line-height: $app_navbar-height-ipad;
        margin: 0 $app_navbar-title_margin-ipad;
      }
      #{$app_navbar-namespace_android_hd} & {
        height: $app_navbar-height-android-hd;
        line-height: $app_navbar-height-android-hd;
      }
    }

    &__share {
      position: absolute;
      right: $app_navbar-share_right;
      z-index: $app_navbar-zindex + 3;
      display: block;
      width: $app_navbar-share_size;
      height: $app_navbar-share_size;
      background: url(#{$app_navbar-share_icon_url}) no-repeat $app_navbar-share_bgposition center;
      background-size: 70%;
      background-color: $app_navbar-share_bgcolor;
    //   border-radius: 50%;

      pointer-events: auto; // 为了防止上级容器设置pointer-events:none后分享按钮不可点
      // 处理部分机型上垂直居中失效
      // align-self: center; 该属性在部分机型上失效，故改用transform实现
      top: 50%;
      transform: translateY(-50%);

      #{$app_navbar-namespace_android} & {
        width: $app_navbar-share_size-android;
        height: $app_navbar-share_size-android;
        right: $app_navbar-share_right-android;
        background-position-x: $app_navbar-share_bgposition-android;
      }

      #{$app_navbar-namespace_ipad} & {
        width: $app_navbar-share_size-ipad;
        height: $app_navbar-share_size-ipad;
        right: $app_navbar-share_right-ipad;
        background-position-x: $app_navbar-share_bgposition-ipad;
      }
    }

    &.skin-blue {
      background: $app_navbar-bgcolor;

      #{$app_navbar-namespace} {
        &__share {
          background: $app_navbar-share_bgcolor url(#{$app_navbar-share_icon_url}) no-repeat $app_navbar-share_bgposition center / 70%;
        }
      }
    }

    &.skin-gray {
      #{$app_navbar-namespace} {
        &__share {
          background-image: url(//cdn.hhdd.com/frontend/as/i/debe65d1-9e82-5f59-86dc-df1cbbdffcf0.png);
          background-repeat: no-repeat;
          background-position: center;
          background-size: .6rem .6rem;
          background-color: transparent;
        }
      }
    }

    &.skin-transparent {
      background: transparent;

      #{$app_navbar-namespace} {
        &__share {
          background: $app_navbar-share_bgcolor url(#{$app_navbar-share_icon_url}) no-repeat $app_navbar-share_bgposition center / 70%;
        }
      }
    }

    &.skin-gray {
      background: transparent;
    }

    &.skin-white {
      background: #fff;

      #{$app_navbar-namespace} {
        &__title {
          color: #000;
        }
      }
    }
  }

  .app-navbar-spacer {
    display: block;
    height: $app_navbar-height;
    overflow: hidden;

    &.is-android {
      height: $app_navbar-height-android;
    }

    &.is-ipad {
      height: $app_navbar-height-ipad;
    }
    &.is-androidHD {
      height: $app_navbar-height-android-hd;
    }
  }

  @media #{$media_query-iphone_notch} {
    #{$app_navbar-namespace} {

      // 通过wrap包装一层，只需在外层元素上使用padding-top即可做到iphonex的适配
      &__wrap {
        @include fillNavbar();
      }
    }

    .app-navbar-spacer {
      @include fillNavbar();
    }
  }

  @media #{$padDeviceInfo} {
    .app-navbar.skin-gray {
      background: linear-gradient(180deg, #FFC669 0%, #FFD58B 100%);
      .app-navbar__share {
        // background: url(//cdn.hhdd.com/frontend/as/i/3d64cd7a-4630-5a32-bdb9-db00222d1439.png) no-repeat center / 0.96rem 0.96rem;
        background-size: 100% 100%;
      }
    }
    .app-navbar__title {
      color: #693D21;
    }
  }
</style>
