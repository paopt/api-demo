<div
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['c-ruser', $$restProps.class].join(' ')}
>
  <div class="c-ruser__wrap">
    <div
      class="c-ruser__wrap-head"
      on:click={() => handleLogin('login')}
    > 
      <div style={`background: url(${userInfo?.headUrl || '//cdn.hhdd.com/frontend/as/i/628c8d58-ccb4-5265-9fe0-8849f271a19d.png'}) no-repeat; background-size: cover;`}></div>
      {#if userInfo?.status && vipFlag[`${userInfo?.status}${userInfo?.vipType}`]}
        <img src={vipFlag[`${userInfo?.status}${userInfo?.vipType}`]} alt="">
      {/if}
    </div>
    <div class="c-ruser__wrap-info" on:click={() => handleLogin('login')}>
      <div class="user-name fzlty-zc">
        <p>{userInfo?.isLoginFlag ? `${userInfo?.nickName}的家长` : '请登录'}</p>
        <!-- <img src="" alt="" srcset=""> -->
      </div>
      <!-- {#if !userInfo.payFlag || renew} -->
        <div class="vip-info fzlty">
          <!-- {#each userInfo?.infoText || [] as item} -->
          <p>{userInfo?.isLoginFlag ? `手机号：${userInfo?.phone || ''}` : '登录后享受更多权益'}</p>
          <!-- {/each} -->
        </div>
      <!-- {:else} -->
        <!-- <div class="vip-info fzlty" on:click={handleRenew}>
         <p>连续包{userInfo.vipStatus === 21 ? '月' : '季'}生效中 ></p>
        </div> -->
      <!-- {/if} -->
    </div>
    {#if userInfo?.isLoginFlag}
      <div class="c-ruser__wrap-btn fzlty-zc" on:click={() => handleLogin('outLogin')}>退出登录</div>
    {/if}
  </div>
</div>
<script lang="ts">
  import { createEventDispatcher } from 'svelte'
  import { object_without_properties } from 'svelte/internal'
  // @ts-ignore
  import type { UserInfo } from '../app'
  import { VipType } from '../app'

  enum VIP_STATUS {
    VALID = 1,
    EXPIRE = 2
  }

  const vipFlag = {
    [`${VIP_STATUS.VALID}${VipType.VIP}`]: '//cdn.hhdd.com/frontend/as/i/12d7ef3b-3ae7-5af3-bd78-2e5ce1ab87dc.png',
    [`${VIP_STATUS.VALID}${VipType.STORY}`]: '//cdn.hhdd.com/frontend/as/i/157d7992-72f7-5809-aa7e-740d5979748e.png',
    [`${VIP_STATUS.VALID}${VipType.BOOK}`]: '//cdn.hhdd.com/frontend/as/i/a7f63412-3f71-5f4b-ba76-df1eafa1ce2d.png',
    [`${VIP_STATUS.VALID}${VipType.SVIP}`]: '//cdn.hhdd.com/frontend/as/i/a956fdd1-21f6-5f4a-8c74-01b9db0ca429.png',
    [`${VIP_STATUS.VALID}${VipType.BSVIP}`]: '//cdn.hhdd.com/frontend/as/i/0abb326b-e80b-5a4a-983a-71f2374db274.png',
    [`${VIP_STATUS.EXPIRE}${VipType.VIP}`]: '//cdn.hhdd.com/frontend/as/i/05aa1960-04ed-59a4-a7b5-625e4222fcd5.png',
    [`${VIP_STATUS.EXPIRE}${VipType.STORY}`]: '//cdn.hhdd.com/frontend/as/i/687c0690-8c88-5035-b03b-2b5332be3c3c.png', // //cdn.hhdd.com/frontend/as/i/cce081fa-19d5-5b44-8eec-276c8e859d02.png
    [`${VIP_STATUS.EXPIRE}${VipType.BOOK}`]: '//cdn.hhdd.com/frontend/as/i/80bf615c-8a46-504c-9985-9353155016b8.png', // //cdn.hhdd.com/frontend/as/i/cb4a683b-0ac5-5801-8a76-8196d22088f9.png
    [`${VIP_STATUS.EXPIRE}${VipType.SVIP}`]: '//cdn.hhdd.com/frontend/as/i/338452cd-a3b1-58a5-985d-25e6e02ef46a.png',
    [`${VIP_STATUS.EXPIRE}${VipType.BSVIP}`]: '//cdn.hhdd.com/frontend/as/i/b2b585c3-7593-5deb-afa8-6e9244edc7a5.png',
  }

  const dispatch = createEventDispatcher()

  export let userInfo: UserInfo = null

  console.log('userInfoCen', userInfo)

  const handleLogin = (e) => {
    dispatch('nav-click', e)
  }

</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import './NavBar/variables';
  @import '../styles/mixins';
  $component_name: 'c-ruser';

  .#{$component_name} {
    &__wrap {
      position: relative;
      display: flex;
      flex-direction: row;
      align-items: center;
      padding: 1.32rem .4rem .4rem;
      margin-top: -1.1rem;
      &-head {
        position: relative;
        width: 1rem;
        height: 1rem;
        margin-right: .24rem;
        div {
          width: 100%;
          height: 100%;
          border: .02rem solid #FFFFFF;
          background: url(//cdn.hhdd.com/frontend/as/i/12529618-b189-5446-a8e5-d27ecf89e544.png) no-repeat; 
          background-size: cover;
          border-radius: 50%;
          overflow: hidden;
        }
        img {
          width: .76rem;
          height: .3rem;
          position: absolute;
          bottom: -.1rem;
          left: 50%;
          transform: translateX(-50%);
        }
      }

      &-info {
        color: #666666;
        flex: 1;

        .user-name {
          color: #333333;
          font-size: .4rem;
          display: flex;
          align-items: center;
          img {
            width: auto;
            margin-left: .1rem;
            height: .32rem;
          }
        }

        .vip-info {
          margin-top: .1rem;
          font-size: .24rem;
        }

      }

      &-btn {
        width: 1.76rem;
        height: .64rem;
        margin-left: auto;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #666666;
        border-radius: .36rem;
        background: rgba(153, 153, 153, 0.10);
        border: .04rem solid rgba(255,255,255,0.5);
      }
      
      // .line {
      //   position: absolute;
      //   bottom: 0;
      //   left: 0;
      //   height: .02rem;
      //   width: 100%;
      //   background-color: #F7F7F7;
      // }
    }
    @media #{$padDeviceInfo} {
      &__wrap {
        padding: .72rem .64rem .34rem;
        // background: #FFFFFF;
        margin-top: 0rem;
        &-head {
          width: 1.12rem;
          height: 1.12rem;
          border: none;
        }

        &-info {
          color: #3F3F3F;
          .vip-info {
            color: #999999;
          }
        }

        // .line {
        //   width: 6.72rem;
        //   left: .66rem;
        //   margin-bottom: .4rem;
        // }
      }
    }

    @media #{$media_query-iphone_notch} {
      margin-top: -1.8rem;

      &__wrap {
        padding-top: 2rem;
      }
    }
  }
</style>