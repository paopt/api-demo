<div class="c-read {className}"
  {style}
  class:is-flag={flag && deviceInfo.isPad}
  class:is-pad={deviceInfo.isPad}
> 
  <div class="c-read__data">
    <div class="c-read__data-item">
      <div><span>{deviceInfo.isKadaClient ? readDays : '???'}</span>天</div>
      <div class="description fzlty-zc">坚持阅读</div>
    </div>
    <div class="c-read__data-item">
      <div><span>{deviceInfo.isKadaClient ?readCount : '???'}</span>本</div>
      <div class="description fzlty-zc">累计读完</div>
    </div>
    <div class="c-read__data-item">
      <div><span>{deviceInfo.isKadaClient ? (((readCount || 0) * 1500) / 10000).toFixed() : '???'}</span>万</div>
      <div class="description fzlty-zc">阅读文字量</div>
    </div>
  </div>
</div>

<script lang="ts">
  import { deviceInfo } from '@kada/library/src/device'
  /**
   * 组件样式
   * @type {String} class
   */
  export let style: string = ''

  /**
   * 组件className
   * @type {className} class
   */
  export let className: string = ''

  export let readCount: number = 0

  export let readDays: number = 0

  export let flag: boolean = false

</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $component-name: 'c-read';

  .#{$component-name} {
    &__data {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 .28rem .4rem;

      &-item {
        width: 1.8rem;
        margin: 0 .1rem;
        color: #3F3F3F;
        text-align: center;
        background-color: #FFFFFF;
        border-radius: .24rem;
        border: .04rem solid #FFCF0C;

        span {
          font-size: .56rem;
          color: #FE6E41;
          font-weight: 600;
        }

        .description {
          width: 100%;
          height: .7rem;
          line-height: .8rem;
         
          background: url(//cdn.hhdd.com/frontend/as/i/afe57229-7c5e-507b-b54a-89ec41716d46.png) no-repeat;
          background-size: 100% 100%;
        }
      }

    }
  }
  .is-pad {
    .c-read__data {
      padding: 0 .38rem .6rem;

      .c-read__data-item {
        border-radius: .32rem;
        flex: 1;
        
        span {
          // font-size: .9rem;
          color: #FE6E41;
        }

        .description {
          line-height: 1rem;
          height: .9rem;
          font-size: .32rem;
        }
      }

    }
  }

  .is-flag {
    .c-read__data {
      .c-read__data-item {
        span {
          font-size: .68rem;
        }
      }

    }
  }
</style>
