<div class="c-redpacket-btn {className}"
  class:is-show={isBlinkShowed || showed}
  class:is-disabled={disabled}
  on:click={handleClick}
  {style}
>
  <slot></slot>
</div>

<script>
  import { createEventDispatcher, afterUpdate } from 'svelte'
  import { promiseDelay } from '@/utils/promisify'

  const dispatch = createEventDispatcher()

  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 组件样式
   * @type {String} style
   */
  export let style = ''

  /**
   * 按钮是否禁止
   * @type {Boolean} disabled
   */
  export let disabled = false

  /**
   * 是否显示按钮
   * @type {Boolean} showed
   */
  export let showed = false

  let isBlinkShowed = false

  export async function blinkShow () {
    isBlinkShowed = true

    return promiseDelay(2000).then(() => {
      isBlinkShowed = false
      return promiseDelay(100)
    })
  }

  const handleClick = event => {
    dispatch('click', event)
  }

  let isShowed = false
  afterUpdate(() => {
    if (showed) {
      if (showed !== isShowed) {
        isShowed = true
      }
    }

    isShowed = showed
  })
</script>

<style lang="scss" global>
  $component-name: 'c-redpacket-btn';

  .#{$component-name} {
    position: fixed;
    display: block;
    left: 0;
    bottom: 0rem;
    width: 100%;
    height: 1.56rem;
    background: white;
    transition: transform 0.25s, opacity 0.25s;
    padding: .3rem .46rem;
    transform: translateY(150%);
    z-index: 10;

    &.is-disabled {
      pointer-events: none;
    }

    &.is-show {
      transform: translateY(0);
    }

    &:active {
      transform: scale(0.98);
    }
  }
</style>
