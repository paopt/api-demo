<div class="c-pay-btn {className} fzlty-zc"
  class:is-disabled={disabled}
  class:ani-breath2={!disabled}
  on:click={handleClick}
  bind:this={panelEl}
  {style}
>
  {disabled ? '您已经是SVIP终身会员了' : btnText}
</div>

<script lang="ts">
  import { createEventDispatcher, afterUpdate } from 'svelte'

  const dispatch = createEventDispatcher()
  let panelEl: HTMLElement = null
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 组件样式
   * @type {String} style
   */
  export let style = ''
  
  /**
   * 按钮文案
   * @type {String} style
   */
   export let btnText = '立即开通'
  
  /**
   * 按钮是否禁止
   * @type {Boolean} disabled
   */
  export let disabled = false

  /**
   * 获取组件位置信息
   *
   * @returns {Rectangle}
  */
  export function getBoundingClientRect () {
    return panelEl ? panelEl.getBoundingClientRect() : null
  }

  const handleClick = event => {
    dispatch('click', event)
  }
</script>

<style lang="scss" global>
  @import '../styles/animation';
  $component-name: 'c-pay-btn';

  .#{$component-name} {
    background: linear-gradient(135deg, #4F4F4F 0%, #151515 100%);
    border-radius: .52rem;
    color: #FFECCB;
    font-size: .36rem;
    text-align: center;
    line-height: .96rem;

    &.is-disabled {
      pointer-events: none;
      opacity: 0.5;
    }
  }
</style>
