<Popup active="{active}"
  class="dlg-role-card {status === STATUS_MAP.HIDING ? 'is-hiding' : ''} {isSuccess ? 'is-success' : ''}"
  on:mask-click="{() => hide()}"
  bind:this="{popEl}"
>
  <div class="dlg-role-card__container">
    <!-- <div class="hiding-elm"> -->
      <!-- <div class="bg-light"></div> -->
      <div class="title fzlty-zc">{title}</div>
    <!-- </div> -->
    <div class="card" flex="col:center row:center" bind:this="{cardEl}">
      <div class="discount">
        <p><span>立减</span><em>{discount}</em><span>元</span></p>
      </div>
      <div class="timer fzlty-zc">
        <p>优惠仅剩</p>
        <Timer class="dlg-role-card__timer" deadline={deadline} format={deadline <= DAYS_STR ? 'HH时MM分SS秒' : 'DD天HH时MM分SS秒'} >
        </Timer>
      </div>
      <div class="bottom fzlty-zc" >
        <div class="bottom-btn" on:click="{typeHide}" flex="col:center row:center">立即使用</div>
      </div>
    </div>
    <div class="dlg-role-card__close" on:click="{typeHide}"></div>
  </div>
 
</Popup>

<script>
  import Popup from './Popup.svelte'
  import { promiseDelay, promiseLoadImage } from '@/utils/promisify'
  import { onDestroy, tick, onMount } from 'svelte'
  import { IS_LOWER_DEVICE } from '@/lib/detect-low-device'
  import { Timer } from '@kada/svelte-activity-ui'

  const DAYS_STR = 24 * 60 * 60 * 1000

  const STATUS_MAP = {
    SHOWING: 1, // 展示中（播放显示动画过程）
    SHOWED: 2, // 已展示（显示动画播放完成并展示）
    HIDING: 3, // 隐藏中（播放隐藏动画过程）
    HIDDEN: 4 // 已隐藏（隐藏动画播放完成并隐藏）
  }

  /**
   * 卡片地址
   * @type {string}
   */
  export let url = ''

  /**
   * 显示模式
   * @type {string}
   */
  export let type = 'error' // or 'success'

  /**
   * 目标元素
   * @type {HTMLElement}
   */
  export let target = null

  /**
   * 是否需要在隐藏过程中解锁滚动
   * @type {boolean}
   */
  export let isNeedLockScroll = true

  /**
   * 关闭回调
   * @type {function}
   */
  export let onHide = null

  // 弹窗展示回调
  export let onShow = null

  export let deadline = 0

  export let discount = 0

  export let title = ''

  $: isSuccess = type === 'success'

  let popEl
  let cardEl
  let active = false
  let status = STATUS_MAP.HIDDEN

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  $: if (url) loadImage()

  let closeSid = 0
  const loadImage = async () => {
    if (status !== STATUS_MAP.HIDDEN) return
    status = STATUS_MAP.SHOWING

    await promiseLoadImage(url)
    active = true
    await tick()

    onCardAnimationEnded(async () => {
      // 在卡片动画播放完成后，延迟400ms再标记状态
      await promiseDelay(400)
      status = STATUS_MAP.SHOWED

      if (closeSid) {
        clearTimeout(closeSid)
      }
      // closeSid = setTimeout(() => typeHide(), 100)
    })
  }

  const computedHidingStyle = () => {
    const cardRect = cardEl.getBoundingClientRect()
    const targetRect = target.getBoundingClientRect()
    // 计算卡片相对于目标元素中心点坐标[X,Y]的偏移量
    const offsetAxisX = ((cardRect.left + cardRect.width / 2) - (targetRect.left + targetRect.width / 2)) * -1
    const offsetAxisY = ((cardRect.top + cardRect.height / 2) - (targetRect.top + targetRect.height / 2)) * -1
    const keyframeName = 'roleCardZoomOut'
    const keyframes = `${keyframeName} {
      0% {
        -webkit-transform: translate3d(0, 0, 0) scale(1);
        transform: translate3d(0, 0, 0) scale(1);

        -webkit-transform-origin: center center;
        transform-origin: center center;
      }
      50% {
        opacity: 1;
      }
      100% {
        opacity: 0;
        -webkit-transform: translate3d(${offsetAxisX}px, ${offsetAxisY}px, 0) scale(0);
        transform: translate3d(${offsetAxisX}px, ${offsetAxisY}px, 0) scale(0);
      }
    }`
    const animation = `${keyframeName} 0.7s cubic-bezier(.68,-0.82,.80,.45) both`

    return `
      @-webkit-keyframes ${keyframes}
      @keyframes ${keyframes}

      .dlg-role-card__container .card {
        position: fixed;
        top: ${cardRect.top}px;
        left: ${cardRect.left}px;
        -webkit-animation: ${animation};
        animation: ${animation};
      }`
  }

  let cardHideStyleEl
  const hide = () => {
    if (closeSid) {
      clearTimeout(closeSid)
    }

    if (status !== STATUS_MAP.SHOWED) return
    status = STATUS_MAP.HIDING

    if (isNeedLockScroll) {
      popEl.unlockScroll()
    }

    if (typeof onHide === 'function') {
      onHide()
    }

    if (IS_LOWER_DEVICE) {
      return destory()
    }

    if (!cardHideStyleEl) {
      cardHideStyleEl = document.createElement('style')
    }
    cardHideStyleEl.textContent = computedHidingStyle()

    onCardAnimationEnded(() => destory())
    document.head.appendChild(cardHideStyleEl)
  }

  /**
   * 卡片元素动画结束事件回调封装
   * @param {function} handler
   */
  const onCardAnimationEnded = (handler) => {
    if (!cardEl || typeof handler !== 'function') return

    const eventHandler = () => {
      if (cardEl) {
        cardEl.removeEventListener('webkitAnimationEnd', eventHandler, { passive: true })
      }
      handler()
    }
    cardEl.addEventListener('webkitAnimationEnd', eventHandler, { passive: true })
  }
  const typeHide = () => {
    if (isSuccess) {
      hide()
    } else {
      destory()
    }
  }
  export const destory = () => {
    active = false
    status = STATUS_MAP.HIDDEN
    if (closeSid) {
      clearTimeout(closeSid)
    }
    if (cardHideStyleEl) {
      document.head.removeChild(cardHideStyleEl)
      cardHideStyleEl = null
    }
    resolve()
  }
  onMount(() => {
    if (typeof onShow === 'function') {
      onShow()
    }
  })
  onDestroy(destory)
</script>

<style lang="scss" global>
  @import '../../styles/variables';
  @import "../../styles/mixins";
  $namespace: 'dlg-role-card';

  .#{$namespace} {
    &.is-hiding {
      .c-popup__mask,
      .hiding-elm,
      .title,
      .dlg-role-card__close {
        animation: hideFadeOut 0.3s ease both;
        @keyframes hideFadeOut {
          0% {
            opacity: 1;
          }
          100% {
            opacity: 0;
          }
        }
      }
    }

    &__timer {
      .sui-timer__zone {
        &.is-day,
        &.is-hour,
        &.is-minute,
        &.is-second {
          display: inline-block;
          padding: 0.1rem 0.1rem;
          color: #FE453D;
          background: white;
          border-radius: 0.1rem;
          margin: 0 0.06rem;
        }

        &.is-ms {
          color: #f60;
        }
      }
    }

    &__container {
      position: relative;
      // top: -1.7rem;
      // @include size(7.5rem, 9.08rem);

      .title {
        width: 100%;
        text-align: center;
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        color: #FFE6B5;
        font-size: .48rem;
        line-height: 2.5;
        z-index: 2;
        margin: 0 auto;
      }

      .card {
        // @include absBlock(3.4rem, 1.8rem, 5);
        @include size(12.6rem, 11.52rem);
        animation: flipIn 0.7s ease both;
        border-radius: 0.5rem;
        overflow: hidden;
          
        @keyframes flipIn {
          0% {
            transform: rotateY(200deg) scale(0.1) translateZ(2px);
          }

          100% {
            transform: rotateY(0) scale(1) translateZ(2px);
          }
        }

        // img {
        //   @include size(3.01rem, 3.01rem);
        // }
      }

      .discount {
        position: absolute;
        width: 100%;
        text-align: center;
        left: 50%;
        transform: translateX(-50%);
        font-size: .6rem;
        top: 1.3rem;
        color: #FF440D; 
        font-weight: bold;
        p {
          display: flex;
          justify-content: center;
          align-items: flex-end;
          padding-top: .4rem;
        }

        em {
          font-size: 1.4rem;
          margin: 0 .1rem;
          line-height: 1;
        }

      }

      .timer {
        position: absolute;
        top: 4.2rem;
        left: 50%;
        transform: translateX(-50%);
        color: white;
        text-align: center;

        p {
          margin-bottom: .2rem;
        }
      }

      .bottom {
        position: absolute;
        top: 5.8rem;
        z-index: 999;
        width: 100%;
        color: #915703;
        font-size: .32rem;
        text-align: center;
        line-height: .8rem;
        // top: 8rem;
        .bottom-btn {
          @include size(4.64rem, .8rem);
          margin: 0 auto;
          background: url(//cdn.hhdd.com/frontend/as/i/2054af7e-6ccd-529a-a931-55eab706606c.png) no-repeat;
          background-size: 100% 100%;
        }
      }
    }

    &__close {
      width: .86rem;
      height: .84rem;
      background: url(//cdn.hhdd.com/frontend/as/i/c655789f-feaf-5dfb-9b7b-b24ec8e1f6a8.png) no-repeat;
      background-size: cover;
      position: absolute;
      top: 8rem;
      left: 50%;
      transform: translateX(-50%);
      z-index: 99;
    }

    &.is-success {
      .#{$namespace}__container {
        .card {
          @include size(7.5rem, 8.84rem);
          @include bgBlock('//cdn.hhdd.com/frontend/as/i/5a96997e-af34-5730-8436-17541d0ef596.png');
        }
      }
    }

    @media #{$padDeviceInfo} {
      &__container {
        padding-top: 1rem;
        .title {
          top: 1.1rem;
          font-size: .64rem;
        }
        .card {
          // @include absBlock(2.84rem, 6.5rem);
          // @include size(4.34rem, 4.34rem);
          // background-size: cover;
          // border-radius: 0.4rem;
          // overflow: hidden;
          
          // img {
          //   @include size(3.54rem, 3.54rem);
          // }
        }

        .discount {
          font-size: .78rem;
          top: 1.7rem;
          p {
            padding-top: .5rem;
          }
          em {
            font-size: 1.82rem;
          }
        }

        .timer {
          top: 5.4rem;
          font-size: .32rem;
          p {
            margin-bottom: .3rem;
          }
        }

        .bottom {
          top: 7.4rem;
          font-size: .42rem;
          line-height: 1.04rem;
          .bottom-btn{
            @include size(6.04rem, 1.04rem);
            background: url(//cdn.hhdd.com/frontend/as/i/76b9bd91-3931-5e0f-aad0-54d6ba4ee7c4.png) no-repeat;
            background-size: 100% 100%;
          }
        }
        .tipmsg {
          font-size: 0.32rem;
          margin-top: 8.36rem;
        }
      }

      &__close {
        top: 10.8rem;
      }

      &.is-success {
        .#{$namespace}__container {
          .title {
            // @include bgBlock('//cdn.hhdd.com/frontend/as/i/01249299-8385-5a22-af79-a148cd02433d.png');
          }
          .bg-light {
            background-image: url('//cdn.hhdd.com/frontend/as/i/2fc31e5c-8422-5ec8-8b51-aa0d4149e8bf.png');
          }
          .card {
            @include size(12.6rem, 11.52rem);
            @include bgBlock('//cdn.hhdd.com/frontend/as/i/7c077f0d-0072-5bf5-80bc-d3502b884b68.png');
          }
        }
      }
    }

    // 低端设备，禁用动画
    @include lowDevice {
      &__container {
        .bg-light,
        .card {
          will-change: transform;
        }

        .bg-stars {
          .star i {
            animation: none !important;
            opacity: 1;
          }
        }
      }
    }
  }
</style>
