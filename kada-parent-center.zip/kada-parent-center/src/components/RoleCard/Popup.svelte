<svelte:options accessors />

{#if active}
  <div class="c-popup is-active {className}" style="{style}" bind:this="{modal}">
    <div class="c-popup__mask" on:click="{onMaskClick}"></div>
    <div class="c-popup__container {aniName ? `ani-${aniName}` : ''}">
      <slot />
    </div>
  </div>
{/if}

<script>
  import { lock, unlock } from 'tua-body-scroll-lock'
  import { createEventDispatcher, onDestroy } from 'svelte'

  /**
   * 组件样式
   * @svelte-prop {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 组件样式
   * @svelte-prop {String} style
   */
  export let style = ''

  export let active = true

  export let maskClickHide = false

  export let appendToBody = true

  /**
   * 组件弹窗动画
   * @svelte-prop {String['wobble']} aniName
   */
  export let aniName = ''

  let modal
  let isScrollLocked = false

  const dispatch = createEventDispatcher()

  $: {
    if (modal && active && appendToBody) {
      modal.parentNode.removeChild(modal)
      document.body.appendChild(modal)
    }
  }
  $: if (active && !isScrollLocked) {
    lock()
    isScrollLocked = true
  } else {
    unlockScroll()
  }

  function onMaskClick() {
    dispatch('mask-click')
    if (maskClickHide) {
      close()
    }
  }

  function close() {
    unlockScroll()
    dispatch('destroy')
    active = false
  }

  export function unlockScroll () {
    if (isScrollLocked) {
      unlock()
      isScrollLocked = false
    }
  }

  onDestroy(() => {
    unlockScroll()
  })
</script>

<style lang="scss">
  $component-name: 'c-popup';

  .#{$component-name} {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1000;

    &__mask {
      position: absolute;
      top: -1px;
      left: -1px;
      right: -1px;
      bottom: -1px;
      background: rgba(0, 0, 0, 0.8);
    }

    &__container {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 1;
      opacity: 0;
      animation: popin 0.25s ease-out 1 forwards;

      &.ani-wobble {
        animation-name: popin-wobble;
        animation-duration: 0.4s;
      }

      > :global(*) {
        pointer-events: auto;
      }
    }

    &.is-active {
      display: block;
    }
  }

  @keyframes popin {
    0% {
      opacity: 0;
      transform: scale(0.5);
    }
    100% {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes popin-wobble {
    0% {
      opacity: 0;
      transform: scale(0.5);
    }
    60% {
      transform: scale(1.05);
    }
    80% {
      transform: scale(0.95);
    }
    100% {
      opacity: 1;
      transform: scale(1);
    }
  }
</style>
