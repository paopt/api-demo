import RoleCard from './RoleCard.svelte'

let dialog = null
export function showDialog (props) {
  if (dialog) {
    dialog.$destroy()
  }

  dialog = new RoleCard({
    target: document.body,
    props
  })

  dialog.$on('destroy', () => {
    dialog.$destroy()
  })

  return dialog.promise
}
export function closeDialog () {
  if (dialog) {
    dialog.$destroy()
  }
}

RoleCard.showDialog = showDialog

export default RoleCard
