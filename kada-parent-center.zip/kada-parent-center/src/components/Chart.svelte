<div class="c-chart {className} fzlty-zc"
  {style}
> 
  <div class="c-chart__title">阅读量已超过<span class="color-o">{deviceInfo.isKadaClient ? CHART_IMAGE[readExpressType].percent : '大部分'}</span>的「{userProvince || '全球'}」{@html computedText(age || 0)}</div>
  <div class="c-chart__tip fzlty">*{userProvince || '全球'}各年龄段儿童平均阅读量</div>
  <div class="c-chart__img">
    <img src="//cdn.hhdd.com/frontend/as/i/92f2b928-c129-5b41-88df-f35ece2fdecc.png" alt="">
  </div>
  <div class="c-chart__tag">
    {#each getTagArr(age) as item}
      <div class="tag-item">{item}</div>
    {/each}
  </div>
</div>

<script lang="ts">
  import { deviceInfo } from '@kada/library/src/device'
  import { CHART_IMAGE } from '../views/help'
  /**
   * 组件样式
   * @type {String} class
   */
  export let style: string = ''

  /**
   * 组件className
   * @type {className} class
   */
  export let className: string = ''

  export let userProvince: string = ''

  export let readExpressType: number = 0

  export let age: number = 0

  const computedText = (age: number): string => {
    // if (age === 0) {
    //   return '达到教纲要求水平'
    // }

    if (age <= 2) {
      return `0-2岁小朋友接近「<span style="color: #FE6E41;">3岁</span>」平均水平`;
    } else if (age >=3 && age <= 14) {
      switch (age) {
        case 3:
          return `3岁小朋友 接近「<span style="color: #FE6E41;">幼儿园小班</span>」平均水平`;
        case 4:
          return `幼儿园小班小朋友 接近「<span style="color: #FE6E41;">幼儿园中班</span>」平均水平`;
        case 5:
            return `幼儿园中班小朋友 接近「<span style="color: #FE6E41;">幼儿园大班</span>」平均水平`;
        case 6:
            return `幼儿园大班小朋友 接近「<span style="color: #FE6E41;">小学一年级</span>」平均水平`;
        case 7:
            return `小学一年级小朋友 接近「<span style="color: #FE6E41;">小学二年级</span>」平均水平`;
        case 8:
            return `小学二年级小朋友 接近「<span style="color: #FE6E41;">小学三年级</span>」平均水平`;
        case 9:
            return `小学三年级小朋友 接近「<span style="color: #FE6E41;">小学四年级</span>」平均水平`;
        case 10:
            return `小学四年级小朋友 接近「<span style="color: #FE6E41;">小学五年级</span>」平均水平`;
        case 11:
            return `小学五年级小朋友 接近「<span style="color: #FE6E41;">小学六年级</span>」平均水平`;
        case 12:
            return `小学六年级小朋友 接近「<span style="color: #FE6E41;">初一</span>」平均水平`;
        case 13:
            return `初一小朋友 接近「<span style="color: #FE6E41;">初二</span>」平均水平`;
        case 14:
            return `初二小朋友 接近「<span style="color: #FE6E41;">初三</span>」平均水平`;
        default: 
          return "";
      }
    }
    
  }

  const arr = ['0岁', '1岁', '2岁', '3岁', '小班', '中班', '大班', '一年级', '二年级', '三年级', '四年级', '五年级', '六年级', '初一', '初二', '初三']

  const getTagArr = (age): string[] => {
    const start = Math.max(0, age - 2)
    const end = Math.min(arr.length, age <= 2 ? 4 : age + 2)

    return age > 14 ? [] : arr.slice(start, end)
  }

</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $component-name: 'c-chart';

  .#{$component-name} {
    width: 100%;
    margin-bottom: .2rem;

    &__title {
      margin: .2rem 0;
      padding: 0 .38rem;
      font-size: .32rem;
    }

    &__tip {
      padding: 0 .38rem;
      font-size: .24rem;
    }

    &__img {
      margin: 0 auto;
      width: 100%;
      // height: 2.8rem;
      background: url(//cdn.hhdd.com/frontend/as/i/92f2b928-c129-5b41-88df-f35ece2fdecc.png) no-repeat;
      background-size: 100% 100%;
      background-repeat: no-repeat;
    }

    &__tag {
      margin: 0.1rem auto 0;
      width: 6rem;
      display: flex;
      justify-content: space-around;
      font-size: .26rem;
    }

    @media #{$padDeviceInfo} {
      &__tip {
        font-size: .28rem;
      }
      &__title {
        font-size: .36rem;
      }
      &__img {
        // width: 7.68rem;
        // height: 3.6rem;
        // width: 6.6;
        // height: 3.08;
      }

      &__tag {
        width: 100%;
        font-size: .3rem;
      }
    }

    .color-o {
      color: #FE6E41;
    }
  }
</style>
