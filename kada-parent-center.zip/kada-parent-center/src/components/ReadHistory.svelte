<div class="c-read {className}"
  {style}
> 
  <div class="c-read__wrap">
    <div class="c-read__title fzlty-zc">阅读记录</div>
    <div class="c-read__data">
      <div class="c-read__data-item">
        <div class="description fzlty">今日阅读</div>
        <div><span>{readData?.todayReadTime ? (readData?.todayReadTime / 60).toFixed() : 0}</span>分钟</div>
      </div>
      <div class="c-read__data-item">
        <div class="description fzlty">本周阅读</div>
        {#if readData?.weekReadTime < 3600}
          <div><span>{readData?.weekReadTime ? (readData?.weekReadTime < 60 ? 1 :readData?.weekReadTime / 60).toFixed() : 0}</span>分钟</div>
        {:else}
          <div><span>{readData?.weekReadTime ? (readData?.weekReadTime < 60 ? 1 : readData?.weekReadTime / 60 / 60).toFixed(1) : 0}</span>小时</div>
        {/if}
        <!-- <div><span>{readData?.weekReadTime ? (readData?.weekReadTime / 60 / 60).toFixed() : 0}</span>小时</div> -->
      </div>
      <div class="c-read__data-item">
        <div class="description fzlty">本周阅读本数</div>
        <div><span>{readData?.weekReadCount ? readData?.weekReadCount : 0}</span>本</div>
      </div>
    </div>
    <div class="c-read__report fzlty" on:click={() => handleNavLick('report')}>阅读报告</div>
  </div>
</div>

<script lang="ts">
  import { deviceInfo } from '@kada/library/src/device'
  import { createEventDispatcher } from 'svelte'

  const dispatch = createEventDispatcher()
  /**
   * 组件样式
   * @type {String} class
   */
  export let style: string = ''

  /**
   * 组件className
   * @type {className} class
   */
  export let className: string = ''

  export let readData = null

  // export let todayReadTime: number = 0

  // export let weekReadCount: number = 0

  // export let weekReadTime: number = 0

  const handleNavLick = (e) => {
    dispatch('nav-click', e)
  }

</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $component-name: 'c-read';

  .#{$component-name} {
    padding: .32rem .4rem;
    &__wrap {
      padding: .4rem .36rem;
      background-color: white;
      border-radius: .24rem;
      box-shadow: 0px .2rem .3rem 0px rgba(0,0,0,0.02);
    }

    &__title {
      color: #666666;
      font-size: .32rem;
      padding-bottom: .32rem;
      border-bottom: .02rem solid rgba(238, 238, 238, .35);
    }
    &__data {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: .38rem 0.2rem;

      &-item {
        // width: 1.8rem;
        // margin: 0 .1rem;
        color: #666666;
        text-align: center;

        span {
          font-size: .56rem;
          font-weight: 600;
          margin-right: .08rem;
        }

        .description {
          // width: 100%;
          // height: .7rem;
          // line-height: .8rem;
        }
      }

    }
    &__report {
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #333333;
      font-size: .32rem;
      border-top: .02rem solid rgba(238, 238, 238, .35);
      padding-top: .32rem;
      &::after {
        content: '';
        width: .28rem;
        height: .28rem;
        background: url(//cdn.hhdd.com/frontend/as/i/8de792b8-a17f-5789-a36c-1ecb70ac4f48.png) no-repeat;
        background-size: cover;
      }
    }
  }
</style>
