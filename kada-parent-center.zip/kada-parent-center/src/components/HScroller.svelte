<div
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['c-hscroller', $$restProps.class].join(' ')}
  class:is-start={isScrollStart}
  class:is-end={isScrollEnd}
  style={scrollerStyle}
>
  <div
    class="c-hscroller__inner"
    style={scrollerInnerStyle}
    bind:clientWidth={wrapperWidth}
    on:scroll={handleScroll}
  >
    <div class="c-hscroller__content" bind:offsetWidth={contentWidth} bind:offsetHeight={contentHeight}>
      <slot></slot>
    </div>
  </div>
</div>

<script lang="ts">
  import { object_without_properties } from 'svelte/internal'
  // 横向滚动组件
  // 内容高度
  let contentHeight: number = 0
  // 容器宽度
  let wrapperWidth: number = 0
  // 内容宽度
  let contentWidth: number = 0
  // 横向滚动位置
  let scrollX: number = 0

  $: maxScrollX = contentWidth - wrapperWidth
  $: scrollerStyle = contentHeight > 0 ? `height: ${contentHeight}px` : ''
  $: scrollerInnerStyle = contentHeight > 0 ? `height: ${contentHeight + 50}px` : ''
  $: isScrollStart = scrollX <= 0
  $: isScrollEnd = scrollX >= maxScrollX - 5

  function handleScroll (event: UIEvent): void {
    const target = event.currentTarget as HTMLElement

    scrollX = target.scrollLeft
  }
</script>

<style lang="scss" global>
  $component_name: 'c-hscroller';

  .#{$component_name} {
    position: relative;
    overflow: hidden;

    &::before,
    &::after {
      content: '';
      display: block;
      position: absolute;
      top: 0;
      bottom: 0;
      width: 2rem;
      pointer-events: none;
      z-index: 5;
      opacity: 1;
      transition: opacity 0.3s ease;
    }

    // &::before {
    //   left: 0;
    //   background: linear-gradient(to right, #fffdf6 0%, #fffdf6 50%, rgba(255, 253, 246, 0) 100%);
    // }

    // &::after {
    //   right: 0;
    //   background: linear-gradient(to left, #fffdf6 0%, #fffdf6 50%, rgba(255, 253, 246, 0) 100%);
    // }

    &.is-start::before {
      opacity: 0;
    }

    &.is-end::after {
      opacity: 0;
    }

    &__inner {
      box-sizing: content-box;
      width: 100%;
      overflow-y: hidden;
      overflow-x: scroll;
    }

    &__content {
      box-sizing: content-box;
      width: max-content;
    }
  }
</style>
