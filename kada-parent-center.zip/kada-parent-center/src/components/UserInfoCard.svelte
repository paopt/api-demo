<div
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['c-card', $$restProps.class].join(' ')}
>
  <div
    class="c-card__wrap"
    class:is-vip={userInfo?.status === 1}
    class:is-disvip={userInfo?.status === 2}
    on:click={() => handleLogin('level')}
  > 
    <div class="c-card__wrap-top">
      <div
        class="c-card__wrap-head"
        style={`background: url(//cdn.hhdd.com/frontend/as/i/ac4ca241-9b98-5031-a79f-850951db919e.png) no-repeat; background-size: cover;`}
      >
      </div>
      <div class="c-card__wrap-info">
        <div class="user-name fzlty-zc">
            <p>{userCard.title}</p>
        </div>
          <div class="vip-info fzlty">
            <p>{userCard.description}</p>
          </div>
      </div>
      {#if !mainTitle && userCard.btnText}
        <div class="c-card__wrap-btn fzlty-zc">{userCard.btnText}</div>
      {/if}
    </div>
    {#if mainTitle}
      <div class="c-card__wrap-bottom fzlty-zc">
        <div>{@html mainTitle}</div>
        <div class="btn">{userCard.btnText}</div>
      </div>
    {/if}
  </div>
</div>
<script lang="ts">
  import { createEventDispatcher } from 'svelte'
  import { object_without_properties } from 'svelte/internal'
  // @ts-ignore
  import type { UserInfo } from '../app'
  import { VipType, VipStatusMap } from '../app'
  import { formatDate } from '@kada/library/utils/datetime'

  export let textInfo: any = {}

  enum VIP_STATUS {
    VALID = 1,
    EXPIRE = 2
  }

  const vipFlag = {
    [`${VIP_STATUS.VALID}${VipType.VIP}`]: '//cdn.hhdd.com/frontend/as/i/b0c738f3-d858-5586-833a-d2a123680605.png',
    [`${VIP_STATUS.VALID}${VipType.STORY}`]: '//cdn.hhdd.com/frontend/as/i/4783f9f8-a22a-50ef-89fa-46d78eb8068a.png',
    [`${VIP_STATUS.VALID}${VipType.BOOK}`]: '//cdn.hhdd.com/frontend/as/i/6ca0a296-1ba7-599e-9ae7-581ff3f8cf15.png',
    [`${VIP_STATUS.VALID}${VipType.SVIP}`]: '//cdn.hhdd.com/frontend/as/i/97d667d1-08d7-5a8b-9f8d-b8298c500450.png',
    [`${VIP_STATUS.EXPIRE}${VipType.VIP}`]: '//cdn.hhdd.com/frontend/as/i/f75f0679-cfdd-54d0-a91a-0fec28357daa.png',
    [`${VIP_STATUS.EXPIRE}${VipType.STORY}`]: '', // //cdn.hhdd.com/frontend/as/i/cce081fa-19d5-5b44-8eec-276c8e859d02.png
    [`${VIP_STATUS.EXPIRE}${VipType.BOOK}`]: '', // //cdn.hhdd.com/frontend/as/i/cb4a683b-0ac5-5801-8a76-8196d22088f9.png
    [`${VIP_STATUS.EXPIRE}${VipType.SVIP}`]: '//cdn.hhdd.com/frontend/as/i/c992d4e0-ee3f-5feb-848a-dde1a01de238.png',
  }

  const convertTextToHTML = (ori: string): string => {
    if (!ori) {
      return ''
    }
    const pattern = /<font(?: color="([^"]+)")?(?: bigger="([^"]+)")?>([^<]+)<\/font>/g
    
    if (!pattern.test(ori)) {
      return ori; // 如果文本格式不匹配，则原样返回
    }

    // const replacement= '<p style="color:$1; font-size: $2px;">$3</p>'

    // const result = ori.replace(pattern, replacement)

    // 使用正则表达式进行替换
    const output = ori.replace(pattern, function(match, color, bigger, content) {
      // console.log('color',color)
      console.log('bigger', bigger)
      // const fontSize = remJusty(+bigger);
      let fontSize = '.24'
      if (bigger === '1') {
        fontSize = '.4'
      }
      return '<span style="color:' + color + '; font-size: ' + fontSize + 'rem;">' + content + '</span>';
    })

    return output
  }

  $: mainTitle = convertTextToHTML(textInfo.mainTitle)

  const dispatch = createEventDispatcher()

  export let userInfo: any = {}

  $: userCard = computedCardInfo(userInfo)

  const computedCardInfo = (userInfo) => {

    const { status = 0, vipDaysRemain = 0, remindExpireDays = 0, level = 0, vipInfoId, endTime } = userInfo
    // return `${formatDate(endTime, 'YYYY-MM-DD')}${VipStatusMap.get(vipType)}到期(自动续费)`
    if (!status) {
      return {
        title: '开通SVIP会员',
        description: '会员畅学5万+精品内容',
        btnText: '立即开通'
      }
    } else {
      if (status === 1) {
        if (level === 99) {
          return {
            title: `${VipStatusMap.get(vipInfoId)}会员`,
            description: '',
            btnText: vipInfoId !== 5 ? '升级会员' : ''
          } 
        }

        if (vipDaysRemain >= 15) {
          return {
            title: `${VipStatusMap.get(vipInfoId)}会员`,
            description: `会员到期：${formatDate(endTime, 'YYYY.MM.DD')}`,
            btnText:  vipInfoId !== 5 ? '升级会员' : '续费会员'
          } 
        }

        if (vipDaysRemain > 0 && vipDaysRemain <= 14) {
          return {
            title: `${VipStatusMap.get(vipInfoId)}会员仅剩${vipDaysRemain}天`,
            description: `会员到期：${formatDate(endTime, 'YYYY.MM.DD')}`,
            btnText:  '立即续费'
          } 
        }

        if (vipDaysRemain === 0 && status ===  1) {
          return {
            title: `${VipStatusMap.get(vipInfoId)}今天到期`,
            description: `会员到期：${formatDate(endTime, 'YYYY.MM.DD')}`,
            btnText:  '立即续费'
          } 
        }
      } else {
        if (remindExpireDays <= 14 && remindExpireDays > 0) {
          return {
            title: `会员已过期`,
            description: `已过期${remindExpireDays}天`,
            btnText:  '立即续费'
          } 
        }

        if (remindExpireDays > 15) {
          return {
            title: `会员已过期`,
            description: `会员过期：${formatDate(endTime, 'YYYY.MM.DD')}`,
            btnText:  '立即续费'
          } 
        }
      }
    }

    return {
      title: '开通SVIP会员',
      description: '会员畅学5万+精品内容',
      btnText:  '立即开通'
    }
  }

  console.log('userCard', userCard)

  const handleLogin = (e) => {
    dispatch('nav-click', e)
  }

</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import './NavBar/variables';
  @import '../styles/mixins';
  $component_name: 'c-card';

  .#{$component_name} {
    padding: 0 .4rem;
    &__wrap {
      position: relative;
      padding: .28rem .2rem;
      
      border-radius: .24rem;
      color: #FFE96E;
      background: linear-gradient(360deg, #303030 0%, #4E3922 100%);
      
      &-top {
        display: flex;
        flex-direction: row;
        align-items: center;
      }

      &-bottom {
        margin-top: .18rem;
        padding-left: .28rem;
        padding-right: .16rem;
        width: 100%;
        height: .8rem;
        background: linear-gradient(149deg, #FF7A74 0%, #FF3D38 100%);
        border-radius: .16rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        .btn {
          width: 1.76rem;
          height: .56rem;
          line-height: .56rem;
          color: #E81E1E;
          border-radius: .45rem;
          text-align: center;
          background: linear-gradient(135deg, #FFEC78 0%, #FFD055 100%);
        }
      }

      &-head {
        width: .96rem;
        height: .96rem;
        overflow: hidden;
        background: url(//cdn.hhdd.com/frontend/as/i/12529618-b189-5446-a8e5-d27ecf89e544.png) no-repeat; 
        background-size: cover;
        margin-right: .24rem;
      }

      &-info {
        flex: 1;

        .user-name {
          font-size: .32rem;
          display: flex;
          align-items: center;
          img {
            width: auto;
            margin-left: .1rem;
            height: .32rem;
          }
        }

        .vip-info {
          margin-top: .1rem;
          font-size: .24rem;
        }

      }

      &-btn {
        width: 1.92rem;
        height: .72rem;
        line-height: .72rem;
        margin-left: auto;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #FFFFFF;
        border-radius: .36rem;
        background: linear-gradient(149deg, #FF7A74 0%, #FF3D38 100%);
        &::after {
          content: '';
          background: url(//cdn.hhdd.com/frontend/as/i/fa6e7087-ffb9-55ca-bc45-3e7505493136.png) no-repeat;
          background-size: 100% 100%;
          width: .28rem;
          height: .28rem;
          margin-left: .08rem;
        }
      }
      
      // .line {
      //   position: absolute;
      //   bottom: 0;
      //   left: 0;
      //   height: .02rem;
      //   width: 100%;
      //   background-color: #F7F7F7;
      // }

      &.is-vip {
        color: #915703;
        background: linear-gradient(139deg, #FFF8ED 0%, #FFE7C8 100%);
        border: .02rem solid #FFD8A3;
      }
      &.is-disvip {
        color: #333333;
        background: linear-gradient(139deg, #F7F7F7 0%, #E6E6E6 100%);
        border: .02rem solid #E5E5E4;
      }
    }
    @media #{$padDeviceInfo} {
      &__wrap {
       
        // .line {
        //   width: 6.72rem;
        //   left: .66rem;
        //   margin-bottom: .4rem;
        // }
      }
    }
  }
</style>