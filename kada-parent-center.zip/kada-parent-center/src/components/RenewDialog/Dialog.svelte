<Popup class="c-rulesdlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-rulesdlg__body" on:touchmove|stopPropagation|preventDefault bind:this={rulesBodyEl}>
    <!-- <div class="close" on:click={close}></div> -->
    <div class="title fzlty-zc">{title}</div>
    <!-- <div class="title-sub fzlty-zc">取消后您将在会员到期后失去以下权益</div> -->
    <div class="c-rulesdlg__bgrp fzlty-zc">
      {#if showCancel}
        <div class="cancel" on:click={handleClose}>取消</div>
      {/if}
      <div class="confirm" on:click={handleConfirm}>确定</div>
    </div>
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  const dispatch = createEventDispatcher()
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 通用弹窗标题
   * @type {String} title
   */
  export let title = '确定要退出当前账号？'

  /**
   * 通用弹窗标题
   * @type {String} title
   */
  export let type = ''

  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = false

  /**
   * 点击取消按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  /**
   * 点击确定按钮回调
   * @type {Function} onClose
   */
  export let onConfirm = null

  export let showCancel = true

  let _content = ''

  let popupEl
  // 活动规则弹窗滚动内容
  let rulesBodyEl
  // 内容模块
  let contentEl
  // 内容区域滚动示例
  let contentScroll

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  function handleClose () {
    dispatch('close')

    if (typeof onClose === 'function') {
      onClose()
    }
    close()
  }

  function handleConfirm () {
    dispatch('confirm')
    if (typeof onConfirm === 'function') {
      onConfirm()
    }
    close()
  }

  function close () {
    popupEl && popupEl.close()
    resolve(false)
  }

  onMount(() => {
    popupEl && popupEl.show()
  })

  onDestroy(() => {
    if (contentScroll) {
      contentScroll.destroy()
      contentScroll = null
    }
  })
</script>

<style lang="scss">
  $component-name: 'c-rulesdlg';

  :global {
    .#{$component-name} {
      z-index: 99999999;
      &__body {
        position: relative;
        width: 5.6rem;
        height: 2.92rem;
        padding-top: 0.74rem;
        background: white;
        border-radius: .32rem;
        z-index: 999;
        text-align: center;
        .title {
          font-size: 0.36rem;
          font-weight: 500;
          color: #333333;
          line-height: 1;
        }

        .title-sub {
          margin-top: .24rem;
          font-size: .28rem;
          color: #5D5D5D;
        }

        .close {
          position: absolute;
          width: 0.9rem;
          height: 0.9rem;
          left: 50%;
          bottom: -.2rem;
          margin-left: -0.45rem;
          background: {
            repeat: no-repeat;
            position: 50% 50%;
            size: 100% 100%;
            image: url('//cdn.hhdd.com/frontend/as/i/ce360163-bc41-5954-9b20-732b2503e620.png');
          }
          z-index: 99;
        }
      }

      &__content {
        position: relative;
        display: flex;
        justify-content: space-around;
        margin: .66rem auto 0;
        // padding: 0.05rem .26rem 0.1rem;
        width: 5.36rem;
        height: 1.8rem;
        display: flex;
        flex-wrap: wrap;
        background: url(//cdn.hhdd.com/frontend/as/i/4a586233-ce11-5c33-a207-07ba3c8948a5.png) no-repeat;
        background-size: cover;
        div {
          text-align: center;
          p:nth-child(1) {
            font-size: .28rem;
            margin-top: .16rem;
          }
          p:nth-child(2) {
            color: #5D5D5D;
            font-weight: bold;
            margin-top: .08rem;
            .number {
              font-size: .48rem;
            }
          }
          p:nth-child(3) {
            // font-size: .28rem;
            margin-top: -.12rem;
          }
        }
        div:nth-child(2) {
          color: #FE4242;
          p:nth-child(1) {
            color: #333333;
          }
          p:nth-child(2) {
            color: #FE4242;
          }

        }
        ::after {
          z-index: 1111;
          content: '';
          position: absolute;
          top: -.2rem;
          right: .2rem;
          width: 1.08rem;
          height: .36rem;
          line-height: .36rem;
          color: white;
          font-size: .2rem;
          background: url(//cdn.hhdd.com/frontend/as/i/fde8f628-8723-5cb9-8e57-aa9ef24ef0b1.png) no-repeat;
          background-size: cover;
        }
      }

      &__bgrp {
        margin-top: .66rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 .4rem;
        div {
          flex: 1;
          margin: 0 .08rem;
          height: .88rem;
          line-height: .88rem;
          border-radius: .44rem;
          font-size: .32rem;
        }
        .cancel {
          border: .02rem solid #3398FF;
          color: #3398FF;
        }
       .confirm {
          color: white;
          background: linear-gradient(310deg, #3398FF 0%, #61C7FF 100%);
        }
      }
    }
  }
</style>
