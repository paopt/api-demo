<div class="c-parent {className}"
  {style}
> 
  <div class="c-parent__wrap">
    <div class="c-parent__title fzlty-zc">家长管理</div>
    <div class="c-parent__nav fzlty" on:click={() => handleNavLick('eyecare')}>
      <span>护眼管理</span>
      <span class="tip">{eyeCareUseTime <= 0 ? '未限制时长' : `一次控制在${eyeCareUseTime / 60}分钟内`}</span>
    </div>
    <div class="c-parent__nav block-list fzlty" on:click={() => handleNavLick('blockList')}>
      <span>内容黑名单</span>
      <span class="tip">已屏蔽{blockCount}个内容</span>
    </div>
    <div class="c-parent__nav order fzlty" on:click={() => handleNavLick('order')}>
      <span>我的订单</span>
      <span class="tip"> </span>
    </div>
  </div>
</div>

<script lang="ts">
  import { createEventDispatcher } from 'svelte'
  import { deviceInfo } from '@kada/library/src/device'

  const dispatch = createEventDispatcher()
  /**
   * 组件样式
   * @type {String} class
   */
  export let style: string = ''

  /**
   * 组件className
   * @type {className} class
   */
  export let className: string = ''

  export let eyeCareUseTime: number = 0

  export let blockCount: number = 0

  const handleNavLick = (e) => {
    dispatch('nav-click', e)
  }

</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $component-name: 'c-parent';

  .#{$component-name} {
    padding: 0 .4rem;
    &__wrap {
      padding: .4rem .36rem;
      background-color: white;
      border-radius: .24rem;
      box-shadow: 0px .2rem .3rem 0px rgba(0,0,0,0.02);
    }

    &__title {
      color: #666666;
      font-size: .32rem;
      padding-bottom: .32rem;
      border-bottom: .02rem solid rgba(238, 238, 238, .35);
    }
    &__nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #333333;
      font-size: .32rem;
      line-height: initial;
    //   border-top: .02rem solid #EEEEEE;
      padding-top: .32rem;
      padding-bottom: .18rem;
      &::after {
        content: '';
        width: .28rem;
        height: .28rem;
        background: url(//cdn.hhdd.com/frontend/as/i/8de792b8-a17f-5789-a36c-1ecb70ac4f48.png) no-repeat;
        background-size: cover;
        // margin-left: auto;
      }
      &::before {
        content: '';
        width: .48rem;
        height: .48rem;
        background: url(//cdn.hhdd.com/frontend/as/i/b9a7e32f-7ac4-5f9e-8069-d803eede4266.png) no-repeat;
        background-size: cover;
        margin-right: .24rem;
      }
      &.block-list::before {
        background: url(//cdn.hhdd.com/frontend/as/i/c5e67805-ef56-564b-bca4-8ea71915fdff.png) no-repeat;
        background-size: cover;
      }
      &.order::before {
        background: url(//cdn.hhdd.com/frontend/as/i/3446b2c6-e7c8-562f-a6ed-0e108ae6598f.png) no-repeat;
        background-size: cover;
      }
      .tip {
        font-size: .28rem;
        color: #999999;
        margin-left: auto;
        text-align: right;
      }
    }
  }
</style>
