<div class={`item ${deviceInfo.isPad ? 'is-pad' : ''} ${deviceInfo.isPad && flag ? 'is-flag-pad' : ''}`}>
  <div class="box">
    <div class="content">
      <div class="header">
        <div class="header-url">
          <img src={headUrl} alt="">
        </div>
        <div class="head-user fzlty-zc">恭喜「{userName}」宝贝荣获</div>
      </div>
      <slot name="header"></slot>
      <i class="dot-left"></i>
      <i class="dot-right"></i>
    </div>

    <div class="content" style={`${!(age <= 14) ? 'border: 0;' : ''}`}>
      {#if age <= 14}
        <slot name="content"></slot>
      {/if}
      {#if couponDiscount && couponDiscount <= 60}
        <i class="dot-left"></i>
        <i class="dot-right"></i>
      {/if}
    </div>
    

    {#if couponDiscount && couponDiscount <= 60}
      <div class="footer">
        <div class="c-footer__title fzlty-zc">特奖励续费奖学金</div>
        <Coupon
          flag={flag}
          discount={couponDiscount}
          remainingDays={remainingDays}
          status={status}
        ></Coupon>
        <!-- <slot name="footer"></slot> -->
        <!-- <div class="footer-label">使用说明</div>
        <div>请在指定门店兑换</div> -->
      </div>
    {/if}
  </div>
</div>
 <script lang="ts">
  import { deviceInfo } from '@kada/library/src/device'
  import Coupon from './Coupon.svelte'

  export let couponDiscount: number = 0
  export let remainingDays: number = 0
  export let status: number = 0
  export let headUrl: string = ''
  export let userName: string = ''
  export let age: number = 0
  export let flag: boolean = false
  console.log(age)
 </script>
<style lang="scss">
  @import '../styles/variables';
  @import '../styles/mixins';
.item {
  position: relative;
  margin-top: 1.5rem;
  width: 100%;
  padding: .2rem;
  background: #FFC037;
  /* height: 14.96rem; */
  /* overflow: hidden; */
  margin-bottom: 10px;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  border-radius: .4rem;
}

.header-url {
  width: 1.25rem;
  height: 1.25rem;
  border-radius: 50%;
  overflow: hidden;
  position: absolute;
  z-index: 10;
  left: 50%;
  transform: translateX(-50%);
  top: .48rem;
}
.box {
  flex: 1;
  width: 100%;
  /* margin: 0 auto; */
  border-radius: .4rem;
  background: #FFF4D7;
}

.header {
  margin: -1.5rem auto 0;
  width: 100%;
  height: 4.8rem;
  background: url(//cdn.hhdd.com/frontend/as/i/4eee5178-a099-55d8-8b76-5d64bc5fb041.png) no-repeat;
  background-size: cover;
  background-position: center center;
}

.head-user {
  position: absolute;
  width: 100%;
  text-align: center;
  top: 2rem;
  color: white;
  font-size: .28rem;
}

.item .dot-left,.item .dot-right {
  display: block;
  width: .36rem;
  height: .36rem;
  border-radius: 50%;
  background: #FFC037;
  position: absolute;
  z-index: 999;
}
.item .dot-left {
  bottom: -.18rem;
  left: -.18rem;
}
.item .dot-right {
  bottom: -.18rem;
  right: -.18rem;
}

.item .content {
  /* height: 290px; */
  flex: 1;
  border-bottom: .04rem dotted #FFCC3A;
  position: relative;
  z-index: 2;
}
.footer {
  padding: 0 .38rem;
}

.c-footer__title {
  margin: .4rem 0 .16rem;
  font-size: .4rem;
}
/* .footer-label {
  line-height: 24px;
} */
.is-pad {
  .header {
    margin: -1.4rem auto 0;
    width: 6.6rem;
    height: 4.8rem;
  }

  .header-url {
    // width: 1.62rem;
    // height: 1.62rem;
    top: .48rem;
  }

  .head-user {
    font-size: .3rem;
    top: 2rem;
  }

  .c-footer__title {
    font-size: .52rem;
  }
}
.is-flag-pad {
  .header {
    margin: -1.4rem auto 0;
    width: 8.2rem;
    height: 5.4rem;
  }

  .header-url {
    width: 1.58rem;
    height: 1.58rem;
    top: .29rem;
  }

  .head-user {
    font-size: .32rem;
    top: 2.25rem;
  }

  .c-footer__title {
    font-size: .52rem;
  }
}
</style>