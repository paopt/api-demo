<div
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['c-user', $$restProps.class].join(' ')}
>
  <div class="c-user__wrap">
    <div
      class="c-user__wrap-head"
      on:click={handleLogin}
      style={`background: url(${userInfo?.headUrl || ''}) no-repeat; background-size: cover;`}
    >
    </div>
    <div class="c-user__wrap-info">
      <div class="user-name fzlty-zc" on:click={handleLogin}>
        <p>{userInfo?.nick}</p>
        <!-- {#if userInfo?.status && vipFlag[`${userInfo?.status}${userInfo?.vipType}`]} -->
        <img src={vipFlag[`${userInfo?.status}${userInfo?.vipType}`] || '//cdn.hhdd.com/frontend/as/i/711d7754-7da0-5cbe-9c5e-6663e40e574c.png'} alt="">
        <!-- {/if} -->
        <!-- <img src="" alt="" srcset=""> -->
      </div>
      <!-- {#if !userInfo.payFlag || renew} -->
        <div class="vip-info fzlty">
          {#each userInfo?.infoText || [] as item}
            <p>{item}</p>
          {/each}
          {#if userInfo?.autoRenewVipInfo?.payFlag}
            <p>连续包{userInfo.vipStatus === 21 ? '月' : '季'}生效中 ></p>
          {/if}
        </div>
      <!-- {:else} -->
      <!-- {#if userInfo.payFlag}
        <div class="vip-info fzlty" on:click={handleRenew}>
         <p>连续包{userInfo.vipStatus === 21 ? '月' : '季'}生效中 ></p>
        </div>
      {/if} -->
    </div>
    <!-- {#if !userInfo?.isLogin}
      <div class="c-user__wrap-btn" on:click={handleLogin}>登录</div>
    {/if} -->
    <!-- <div class="line"></div> -->
  </div>
  <div class="c-user__intro">
    <PrivilegeList
      isVip={userInfo?.vipType === VipType.VIP}
    />
  </div>
</div>
<script lang="ts">
  import { createEventDispatcher } from 'svelte'
  import { object_without_properties } from 'svelte/internal'
  // @ts-ignore
  import type { UserInfo } from '../app'
  import { VipType } from '../app'
  import PrivilegeList from './PrivilegeList.svelte'

  enum VIP_STATUS {
    VALID = 1,
    EXPIRE = 2
  }

  const vipFlag = {
    [`${VIP_STATUS.VALID}${VipType.VIP}`]: '//cdn.hhdd.com/frontend/as/i/6658c5d3-2459-5dab-901a-7fb07b8600f1.png',
    [`${VIP_STATUS.VALID}${VipType.STORY}`]: '//cdn.hhdd.com/frontend/as/i/a97fe927-6f41-57d7-82c0-31e5ec5afbe9.png',
    [`${VIP_STATUS.VALID}${VipType.BOOK}`]: '//cdn.hhdd.com/frontend/as/i/6658c5d3-2459-5dab-901a-7fb07b8600f1.png',
    [`${VIP_STATUS.VALID}${VipType.SVIP}`]: '//cdn.hhdd.com/frontend/as/i/711d7754-7da0-5cbe-9c5e-6663e40e574c.png',
    [`${VIP_STATUS.VALID}${VipType.BSVIP}`]: '//cdn.hhdd.com/frontend/as/i/54823b06-bb10-51d2-991b-167d627317dc.png',
    [`${VIP_STATUS.EXPIRE}${VipType.VIP}`]: '//cdn.hhdd.com/frontend/as/i/711d7754-7da0-5cbe-9c5e-6663e40e574c.png',
    [`${VIP_STATUS.EXPIRE}${VipType.STORY}`]: '//cdn.hhdd.com/frontend/as/i/711d7754-7da0-5cbe-9c5e-6663e40e574c.png', // //cdn.hhdd.com/frontend/as/i/cce081fa-19d5-5b44-8eec-276c8e859d02.png
    [`${VIP_STATUS.EXPIRE}${VipType.BOOK}`]: '//cdn.hhdd.com/frontend/as/i/711d7754-7da0-5cbe-9c5e-6663e40e574c.png', // //cdn.hhdd.com/frontend/as/i/cb4a683b-0ac5-5801-8a76-8196d22088f9.png
    [`${VIP_STATUS.EXPIRE}${VipType.SVIP}`]: '//cdn.hhdd.com/frontend/as/i/711d7754-7da0-5cbe-9c5e-6663e40e574c.png',
    [`${VIP_STATUS.EXPIRE}${VipType.BSVIP}`]: '//cdn.hhdd.com/frontend/as/i/54823b06-bb10-51d2-991b-167d627317dc.png',
  }

  const dispatch = createEventDispatcher()

  export let userInfo: UserInfo = null

  export let renew: boolean = false

  const handleLogin = () => {
    dispatch('login')
  }

  const handleRenew = () => {
    dispatch('renew')
  }
</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import './NavBar/variables';
  @import '../styles/mixins';
  $component_name: 'c-user';

  .#{$component_name} {
    // height: 100%;
    // overflow: hidden;
    padding: .22rem 0 .8rem .4rem;
    background: linear-gradient(129deg, #4F4F4F 0%, #151515 100%);
    &__wrap {
      position: relative;
      display: flex;
      flex-direction: row;
      align-items: center;
      padding: 0 .32rem;
      width: 6.7rem;
      height: 1.92rem;
      // margin-top: -1.1rem;
      background: url(//cdn.hhdd.com/frontend/as/i/4d3408ed-f50a-5855-8afb-299d7d029c56.png) no-repeat;
      background-size: cover;
      // background-size: 6.7rem 1.92rem;
      // background-position: .4rem 1.22rem;
      // background: linear-gradient(135deg, #4F4F4F 0%, #0C0C0C 100%);

      &-head {
        border: .02rem solid #FAEBD1;
        width: .96rem;
        height: .96rem;
        border-radius: 50%;
        overflow: hidden;
        background: url(//cdn.hhdd.com/frontend/as/i/12529618-b189-5446-a8e5-d27ecf89e544.png) no-repeat; 
        background-size: cover;
        margin-right: .24rem;
      }

      &-info {
        color: #000000;
        flex: 1;

        .user-name {
          font-size: .32rem;
          display: flex;
          align-items: center;
          img {
            position: absolute;
            width: auto;
            min-width: 1.56rem;
            max-width: 2.16rem;
            right: .34rem;
            top: .2rem;
            height: .36rem;
          }
        }

        .vip-info {
          font-size: .26rem;
        }

      }

      &-btn {
        width: 1.28rem;
        height: .64rem;
        margin-left: auto;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        border-radius: .36rem;
        background: linear-gradient(90deg, #FF7C6B 0%, #FF4242 100%);
        border: .04rem solid rgba(255,255,255,0.5);
      }
      
      .line {
        position: absolute;
        bottom: 0;
        left: 0;
        height: .02rem;
        width: 100%;
        background-color: #F7F7F7;
      }
    }

    &__intro {
      width: 100%;
      height: 3.36rem;
    }
    // @media #{$padDeviceInfo} {
    //   &__wrap {
    //     padding: .72rem .64rem .64rem;
    //     background: #FFFFFF;
    //     margin-top: 0rem;
    //     &-head {
    //       width: 1.12rem;
    //       height: 1.12rem;
    //       border: none;
    //     }

    //     &-info {
    //       color: #3F3F3F;
    //       .vip-info {
    //         color: #999999;
    //       }
    //     }

    //     .line {
    //       width: 6.72rem;
    //       left: .66rem;
    //       margin-bottom: .4rem;
    //     }
    //   }
    // }

    @media #{$media_query-iphone_notch} {
      // margin-top: -1.8rem;

      &__wrap {
        // padding-top: 2rem;
      }
    }
  }
</style>