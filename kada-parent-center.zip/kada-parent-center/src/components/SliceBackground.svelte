<div {...object_without_properties($$restProps, [ 'class' ])} class={['sui-sliced-bg', $$restProps.class || ''].join(' ')} bind:this={slicedBgEl}>
  <slot name="before"></slot>
  {#each splitedImages as item, index (item.url)}
    <!-- 如果页面已经是存在懒加载示例，刷新背景图时不使用懒加载 -->
    <!-- width: ${item.width / 100}rem; -->
    {#if index < 2}
      <img
        key={index}
        class="sui-sliced-bg__item"
        style={`height: ${remJusty(item.height / remPixel)};
          `}
        src={item.url}
        draggable="false"
        alt=""
      />
    {:else}
      <img
        key={index}
        class="sui-sliced-bg__item lazy"
        style={`height: ${remJusty(item.height / remPixel)};
         `}
        data-src={item.url}
        draggable="false"
        alt=""
      />
    {/if}
  {/each}
  <slot></slot>
</div>

<script>
  import { onMount, tick, onDestroy } from 'svelte'
  import { object_without_properties } from 'svelte/internal'
  import { PropType, convertPropType } from '../utils/propstype'
  import lozad from 'lozad'
  import { deviceInfo } from '@kada/library/src/device'

  export let h5Flag = false

  const remPixel = deviceInfo.isPad && h5Flag ? 80 : 100

  let _imageInfo
  /**
   * 页面背景图片
   * @type {Object|Array<Object>} image
   */
  export { _imageInfo as image }
  $: image = convertPropType(_imageInfo, PropType.object)

  // 背景 DOM
  let slicedBgEl

  function sliceImage (image) {
    const imageInfo = (!Array.isArray(image)) ? [ image ] : image

    const images = []
    imageInfo.forEach(imageItem => {
      if (!imageItem) {
        return
      }

      const { url: imageUrl, width: imageWidth, height: imageHeight, sliceExtra = '' } = imageItem
      const splitHeight = 800
      const len = Math.ceil(imageHeight / splitHeight)
      let ossProcessExtra = sliceExtra

      const hasFormat = ossProcessExtra.match(/.*format,([^/]+)?/)
      const hasQuality = ossProcessExtra.match(/.*quality,[^/]+/)
      const slash = /\/$/.test(ossProcessExtra) ? '' : '/'
      if (!hasFormat) {
        ossProcessExtra += `${slash}`
      }

      if (!hasQuality) {
        ossProcessExtra += `${slash}quality,q_80`
      }

      for (let i = 0; i < len; i++) {
        const itemHeight = Math.max(0, Math.min(imageHeight - splitHeight * i, splitHeight))
        images.push({
          url: `${imageUrl}?x-oss-process=image/resize,w_${imageWidth}/crop,x_0,y_${i * splitHeight},h_${itemHeight+2},w_${imageWidth}${ossProcessExtra}`,
          width: imageWidth,
          height: itemHeight
        })
      }
    })

    return images
  }

  function remJusty (value) {
    if (typeof value !== 'number' || isNaN(value) || typeof window === 'undefined' || !window.kadaRemLayout || typeof window.kadaRemLayout.rem2px !== 'function' || isNaN(window.kadaRemLayout.rem)) {
      return value + 'rem'
    }

    const px = Math.round(window.kadaRemLayout.rem2px(value))

    if (isNaN(px)) {
      return value + 'rem'
    }

    return window.kadaRemLayout.px2rem(px % 2 === 0 ? px : px + 1) + 'rem'
  }

  let splitedImages = sliceImage(image)

  let _image = image
  // 背景是否重置
  $: if (JSON.stringify(image) !== JSON.stringify(_image)) {
    splitedImages = sliceImage(image)

    if (typeof window !== 'undefined') {
      tick().then(() => {
        if (lazyInstace && lazyInstace.observer) {
          lazyInstace.observer.disconnect()
        }

        if (slicedBgEl) {
          lazyInstace = lozad(slicedBgEl.querySelectorAll('.lazy'))
          lazyInstace.observe()
        }

      })
    }

    _image = image
  }

  let lazyInstace
  onMount(() => {
    if ((typeof window !== 'undefined') && slicedBgEl) {
      const lazyInstace = lozad(slicedBgEl.querySelectorAll('.lazy'))
      lazyInstace.observe()
    }
  })

  onDestroy(() => {
    if (lazyInstace && lazyInstace.observer) {
      lazyInstace.observer.disconnect()
    }
  })
</script>

<style lang="scss">
  $ui-prefix-name: 'sui-';
  $target-env: 'webcomponent';

  $component-name: 'sui-sliced-bg';

  @mixin component-style () {
    img {
      margin: 0 auto;
      display: block;
      padding: 0;
      border: 0;
      -webkit-user-drag: none;
      pointer-events: none;
    }

    &__item {
      margin-top: var(--item-margin-top, -1px);
      transition: opacity var(--item-fade-duration, 0.15s) ease-in;

      &::first-child {
        margin: 0;
      }

      &.lazy {
        opacity: 0;
      }

      &[data-loaded] {
        opacity: 1;
      }
    }

    .sui-sliced-bg__item {
      margin-top: -1px;
    }
  }

  @if $target-env == 'webcomponent' {
    :host {
      --item-margin-top: -1px;
      --item-fade-duration: 0.15s;

      display: block;
    }

    .#{$component-name} {
      @include component-style();
    }
  } @else {
    :global {
      .#{$component-name} {
        --item-margin-top: -1px;
        --item-fade-duration: 0.15s;
        display: block;

        @include component-style();
      }
    }
  }

</style>
