<div
  {...object_without_properties($$restProps, [ 'class' ])}
  class={['c-privilege', $$restProps.class].join(' ')}
>
  <div class="c-privilege__list">
    {#each privilegeList as item}
      <div class="c-privilege__list-item">
        <img src={item.icon} alt="">
        <p>{item.slogan}</p>
        {#if item?.range && isVip}
          <div class="range">
            <img src={item.range} alt="">
          </div>
        {/if}
      </div>
    {/each}
    
  </div>
</div>
<script lang="ts">
  import { createEventDispatcher } from 'svelte'
  import { object_without_properties } from 'svelte/internal'

  export let isVip = false

  const privilegeList = [
    {
      icon: '//cdn.hhdd.com/frontend/as/i/400065b6-0212-555f-82b6-c032c00feeb0.png',
      slogan: '20000+好书'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/ffbeb5a6-048b-548e-a6b9-3db67a577d45.png',
      slogan: '15000+听书'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/8eaf068b-63d5-5083-aa20-baaf2a9be2ac.png',
      slogan: '15000+课程',
      range: '//cdn.hhdd.com/frontend/as/i/0e7baddf-27e7-56f5-99e6-ac059ad1125a.png'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/604348aa-20c6-5596-a144-8425d7df0ecd.png',
      slogan: '小学同步课',
      range: '//cdn.hhdd.com/frontend/as/i/0e7baddf-27e7-56f5-99e6-ac059ad1125a.png'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/e763e487-8ad4-5d69-bd5f-7879ef23c036.png',
      slogan: '每月上新'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/ad1bc9e8-eeaa-5ded-af03-b2c4b1566c62.png',
      slogan: '精品书单'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/f30ea37a-448a-5482-906d-273cd2a6678c.png',
      slogan: '专属客服'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/30cc1b40-f2ea-5885-846c-14a784ef9da7.png',
      slogan: '阅读训练营',
      range: '//cdn.hhdd.com/frontend/as/i/0e7baddf-27e7-56f5-99e6-ac059ad1125a.png'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/ce17bdac-a29e-5d49-8ca6-2a72e820c86d.png',
      slogan: '名师领读课',
      range: '//cdn.hhdd.com/frontend/as/i/0e7baddf-27e7-56f5-99e6-ac059ad1125a.png'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/19e8b75d-39e9-50b2-9f7f-18655ec4f755.png',
      slogan: '多设备通用'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/250e2d98-d7b4-5126-b26d-e976a0adce07.png',
      slogan: 'KaDa币双倍'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/96138b9a-4d52-574d-891e-f8a721ac00e9.png',
      slogan: '尊贵标识'
    },
    {
      icon: '//cdn.hhdd.com/frontend/as/i/09e2e240-cab1-579d-9fc7-fb5d84b51a2c.png',
      slogan: '专属勋章'
    }
  ]
</script>

<style lang="scss" global>
  @import '../styles/variables';
  @import '../styles/mixins';
  $component_name: 'c-privilege';
  
  .#{$component_name} {
    width: 100%;
    overflow-x: scroll;

    -webkit-overflow-scrolling: touch;
    // padding-bottom: .4rem;
    &::-webkit-scrollbar {
      width: 0;
      height: 0;
      display: none;
    }
    &__list {
      display: flex;
      padding-top: .32rem;
      width: 11.6rem;
    //   justify-content: space-between;
      flex-wrap: wrap;
      &-item {
        position: relative;
        width: 1.62rem;
        display: flex;
        flex-direction: column;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
        margin-bottom: .32rem;
        img {
          width: .8rem;
          height: .8rem;
        }
        p {
          color: #E8D6B9;
          font-size: .24rem;
        }

        .range {
          position: absolute;
          right: .1rem;
          top: 0;
          width: .6rem;
          height: .24rem;
          img {
            width: 100%;
            height: 100%;
          }
        }
      }
    }
  }
</style>