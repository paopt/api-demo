<div class="c-edition">
  {#if userId}
    <p>ID：{userId}</p>
  {/if}
  ©2023 KaDa阅读
</div>
<script>
  export let userId = ''
</script>
<style>
.c-edition {
  color: #999999;
  padding: .48rem .68rem;
  text-align: center;
}
</style>