import { deviceInfo } from '@kada/library/src/device'
import { getApi, fetch } from '@/lib/fetch'
import { getAuthorization, getRDI, JSBRdiInfo } from '@kada/jsbridge'

type LevelListTypeItem = {
  id: number, // 档位ID
  vipInfoId: string, // 会员档位类型 1-综合VIP 3-听书VIP 4-绘本VIP 5-SVIP
  configId: number, // 档位配置ID
  tabType: number, // 内容归类类型 0-混推档位 1-vipTab  2-SVIPTab（v6.5.0+非混推模式存在）
  title: string, // 档位标题
  price: number, // 售价
  origPrice: number, // 原始价格
  priority: number, // 优先级（0....N)，值越大优先级越高
  isDefault: number, // 是否默认选中档位
  coverUrl: string, // 会员图片
  deductionType: number, // 红包抵扣类型 0 不支持，1 存在红包抵扣
  redPacketsPay: number, // 红包实际可抵扣金额
  redPacketsDeductionAmount: number, // 红包最大抵扣金额
  btnText: string, // 按钮文字
  appleProId: string, // 苹果产品ID（内购标记）
  appleChProId: string, // 亲子版proid
  upgradeRuleId: number, // 子会员升级规则ID
  payFlag: number, // 支付标志(0:普通支付 ,1：自动续费)
  payType: number, // 支付类型（1：1个月、2:3个月、3:12个月、4:24月、5:15天、6:1天、7：5年卡、8：半年卡、9: 10年卡、10：3年卡、21:连续包月、22:连续包季、23:连续包年、28:付费兑换码、29:终身会员、30:免费兑换，31:活动赠送，40:充值赠送 41:HD灰度赠送，42:课程激励  44:HD留存活动赠送  时间规则，1天，半月15天，月按31天，季按92天，半年卡186天，年365天, 五年卡1825天，终身卡36500天，3年卡1095
  firstPrice: number, // 自动续费首次支付
  discountInfo: DiscountInfoType, // 显示优惠信息
  sourceType: number, // 6:vip档位，9:升级VIP（次级升级超级）11：升级SVIP
  redPacketsList: {}
  desc: string, // 档位描述
  superscriptColorType: number, // 角标类型 1 红色，2 蓝色
  superscriptText: string
}

type DiscountInfoType = {
  id: string, // 优惠配置id
  time: string, // 优惠剩余时长
  price: string // 优惠价格
}

type VipTabConfigType = {
  operationMode: number, // 档位运营模式 0-混推 1-非混推
  defaultTab: number, // 默认Tab类型 Tab类型 0-混推档位 1-阅读会员VIPTab  2-超级学习会员SVIPTab
  vipRecommend: number, // VIP推荐文案
  sVipRecommend: string,  // SVIP推荐文案
  channelId: number, // 渠道类型
  userGroupId: number, // 档位规则ID
  vipContentReferral: number, // VIP内容简介
  sVipContentReferral: number, // SVIP内容简介
}

export type LevelListType = {
  vipList: LevelListTypeItem[],
  vipTabConfig: VipTabConfigType
}

// 获取档位信息
// @see: http://10.0.10.52:8090/pages/viewpage.action?pageId=39027064
export async function getPayInfoList (): Promise<ServerResponse<LevelListType>> {
  const api = getApi('kd', 'vip/getPayInfoList.json?deviceType=' + 0)
  // return {}
  return fetch.get(api).then((res) => {
    if (res.data && res.data.vipList) {
      return {
        code: 200,
        data: {
          ...res.data,
          vipList: res.data.vipList.filter(item => !item.payFlag)
        },
        msg: '请求成功'
      }
    } else {
      return {
        code: 200,
        data: null,
        msg: '请求失败'
      }
    }
  })
}

export enum H5TYPE {
  // 普通
  NORMAL = 1,
  // 临期 ｜｜ 过期
  RENEW = 2,
  // 升级
  UPGRADE = 3
}

export type IntroduceInfoType = {
  h5Type: H5TYPE, // 1:普通、 2: 临期 & 过期、 3: 升级
  ageType: number, // 用户所属年龄段
  vipBeginTime: string, // 用户vip开始时间
  vipType: number, // 用户vip身份： 1：vip 3：听书vip，4：绘本 5：svip 
  payType: number, // 用户vip类型（1：1个月、2:3个月、3:12个月、4:24月、5:15天、6:1天、7：5年卡、8：半年卡、9: 10年卡、10：3年卡、11：15月 、21:连续包月、22:连续包季、23:连续包年、28:付费兑换码、29:终身会员、30:免费兑换
  readDays: number, // 阅读天数
  readCount: number, // 阅读本数
  targetReadDays: number, // 目标平均天数
  targetReadCount: number, // 目标平均阅读本数
  readExpressScore: number, // 阅读表现分数
  readExpress: string, // 阅读表现文案 --成为会员的日子里，你已发生了很大变化
  recentReadCount: number, // 累计阅读次数
  recentReadTime: number, // 平均阅读时长
  userProvince: string, // 用户所属省份
  readExpressType: true, // 表现好或不好 0: 不好， 1: 好

}

// http://10.0.10.52:8090/pages/viewpage.action?pageId=42041468
export async function getIntroduceInfo (): Promise<ServerResponse<IntroduceInfoType>> {
  const api = getApi('userrs', 'vipopen/info.json')
  const { data } = await getRDI() as { data: JSBRdiInfo }
  // @ts-ignore
  const authorizationData = await getAuthorization({
    pathname: '/userrs/vipopen/info.json',
    method: 'GET',
    body: '',
    accept: '*/*',
    contentType: '',
    RDI: data.raw
  })

  console.log(authorizationData.data)
  if (!authorizationData.data) return

  return fetch.get(api, {
    headers: {
      'Accept': '*/*',
      'Content-Type': 'application/json',
      authorization: authorizationData.data,
      RDI: data.raw
    }
  }).then((res) => {
    if (res.data && res.data) {
      return {
        code: 200,
        data: res.data,
        msg: '请求成功'
      }
    } else {
      return {
        code: 200,
        data: null,
        msg: '请求失败'
      }
    }
  })
}

export type ArrivalItemType = {
  sourceId: number, // 资源id
  sourceType: number, // 资源类型 1、绘本 2、听书 4、听书合辑 5、绘本合辑 8、课程 14、漫画 15、电子书 16、阅读计划
  name: string, // 名称
  coverUrl: number, // 封面地址
  kadaProtocol: string, // kada协议地址
  extFlag: number, // 扩展字段
  vipFlag: number, // vip标记
  svipFlag: number, // svip标记
  publishType: number, // 更新类型 1、上新 2、更新
  publishCount: number, // 上新个数，publishType=1时使用
  lastPublishTime: number, // 最后更新时间戳
  publishInWeek: number, // 是否本周更新
}

export type ArrivalType = ArrivalItemType[]

export async function getNewArrival(): Promise<ServerResponse<ArrivalItemType>> {
  const api = getApi('source', 'publish/currentMonth.json')
  const { data } = await getRDI() as { data: JSBRdiInfo }

  // @ts-ignore
  const authorizationData = await getAuthorization({
    pathname: `/source/publish/currentMonth.json`,
    method: 'GET',
    body: '',
    accept: '*/*',
    contentType: '',
    RDI: data.raw
  })
  console.log(authorizationData.data)
  if (!authorizationData.data) return

  return fetch.get(api, {
    headers: {
      'Accept': '*/*',
      'Content-Type': 'application/json',
      authorization: authorizationData.data,
      RDI: data.raw
    }
  }).then((res) => {
    if (res.data && res.data.sources) {
      return {
        code: 200,
        data: res.data.sources.slice(0, 10),
        msg: '请求成功'
      }
    } else {
      return {
        code: 200,
        data: null,
        msg: '请求失败'
      }
    }
  })
}

export type RecommendItemType = {
  sourceId: number,
  sourceType: number,
  image: string,
  name: string,
  subscribe: number,
  extFlag: number,
  count: number,
  onlineCount: number,
  bookVip: number
}

export type RecommendType = [
  RecommendItemType
]


export async function getRecommend(): Promise<ServerResponse<RecommendType>> {
  const api = getApi('subscribe', 'reading/latest.json')
  const { data } = await getRDI() as { data: JSBRdiInfo }

  // @ts-ignore
  const authorizationData = await getAuthorization({
    pathname: `/subscribe/reading/latest.json`,
    method: 'GET',
    body: '',
    accept: '*/*',
    contentType: '',
    RDI: data.raw
  })
  console.log(authorizationData.data)
  if (!authorizationData.data) return

  return fetch.get(api, {
    headers: {
      'Accept': '*/*',
      'Content-Type': 'application/json',
      authorization: authorizationData.data,
      RDI: data.raw
    }
  }).then((res) => {
    return res
  })
}

export type SingleImgeType = {
  id: number,
  title: string,
  imgUrl: string,
  sourceKey: string,
  qrcodeTitle: string,
  soundUrl: string,
  redirectUri: string,
  commonParam: string,
  type: number,
  topTitle: string,
  mainTitle: string,
  subTitle: string,
}

export async function getSimgleImge(resourceLocationId = 157): Promise<ServerResponse<SingleImgeType | []>> {
  const api = getApi('kd', `conf/operRes/singleImg.json?resourceLocationId=${resourceLocationId}`)

  return fetch.get(api).then((res) => {
    return res
  })
}