import { getApi, fetch } from '@/lib/fetch'
import config from '@/lib/config'
import { WX_GZH_LIST } from '../views/help'
import URLParser from '@/lib/urlParser'
import { initWechatConfig } from '@/lib/wechat'

const parsed = new URLParser(location.href)
let { openId = '', from = '' } = parsed.query

const { loginType: defaultLoginType } = config.wechat

/**
 * 获取签名数据
 * @param {String} url 当前网页的URL，不包含hash部分
 * @see http://note.youdao.com/noteshare?id=a8db729f722c9879a81f5e063d018417&sub=ED166E6A07644FEC8A062F72443940C4
 */
export function getWechatConfig (url: string): Promise<ServerResponse<any>> {
  if (!url) {
    throw Error('请求参数[url]不存在！')
  }
  const { loginType } = WX_GZH_LIST[from] || defaultLoginType
  const params = {
    url,
    loginType
  }

  return fetch.post(getApi('partner', 'js/ticket/wechat.json'), params)
}
