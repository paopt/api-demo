
// @ts-nocheck
import { getCookie, removeCookie } from 'tiny-cookie'
import { getClientDeviceId, setDeviceId, getDeviceId, RDI as rdi } from '@kada/library/src/device'
import { getApi, fetch } from '@/lib/fetch'
import config from '@/lib/config'
import { formatDate } from '@kada/library/utils/datetime'
import * as storage from '@/lib/storage'
import URLParser from '@/lib/urlParser'

const url = location.href
const parsed = new URLParser(url)
let { openId = '' } = parsed.query
/**
 * @private
 * GET 微信登陆
 * @see http://note.youdao.com/noteshare?id=a8db729f722c9879a81f5e063d018417&sub=ED166E6A07644FEC8A062F72443940C4
 */
const wxLogin = params => {
  const api = getApi('weixin', 'openId/get.json')

  return fetch.get(api, {
    params,
  })
}

export async function login (code, loginType) {
  const params = {
    code,
    deviceId: getClientDeviceId(),
    loginType: loginType
  }

  // 获取JSSDK需要的签名认证信息
  // await getTicket()
  // 微信登陆
  const res = await wxLogin(params)

  if (res.code === 200 && res.data) {
    setDeviceId(res.data)
    setTimeout(() => doLoginTask(), 0)
    return res
  }

  const error = new Error(res.msg || '登录失败')
  error.code = res.code
  throw error
}

/**
 * @private
 * GET 退出登录
 * @see http://10.0.10.51:3000/project/38/interface/api/8216
 */
export const logout = () => {
  const api = getApi('user', 'logout.json')

  return fetch.get(api)
}

const state = {
  userInfo: null
}

export enum VipType {
  VIP = 1,
  STORY = 3,
  BOOK = 4,
  SVIP = 5,
  BSVIP = 6,
}

export const VipStatusMap = new Map<string, VipType>([
  [VipType.VIP, 'VIP'],
  [VipType.STORY, '听书VIP'],
  [VipType.BOOK, '绘本VIP'],
  [VipType.SVIP, 'SVIP'],
  [VipType.BSVIP, '课外书SVIP'],
])

export async function getUserInfo () {
  // if (state.userInfo && Object.keys(state.userInfo)) {
  //   return state.userInfo
  // }

  const isLoginFlag = await isLogin()


  const api = getApi('user', 'getUserInfo.json')

  return fetch.get(api).then(res => {
    if (res.code === 200) {
      state.userInfo = {
        ...res.data,
        vipInfoList: reorderVipList(res.data.vipInfoList),
        // vipInfoList: res.data.vipInfoList.sort((a ,b) => b.vipInfoId - a.vipInfoId)
      }
    } else {
      state.userInfo = null
    }
    console.log(state)
    let usrViplist = []
    const { userInfo: { userId = 0, nick = '小读者', loginName, phone = '', headUrl = '//cdn.hhdd.com/frontend/as/i/628c8d58-ccb4-5265-9fe0-8849f271a19d.png', createDate, vipInfoList: vipList, currentTime, registeredDays: createDays, blockCount, eyeCareUseTime } } = state
    if (vipList.length) {
      const filterVipList = vipList.filter(item => item.status === 1)
      usrViplist = filterVipList.length ? filterVipList : vipList.sort((a, b) => a.remindExpireDays - b.remindExpireDays).slice(0, 1)

      // autoRenewVip = vipList.filter(item => item.payFlag)[0] || {}
    }
    console.log(usrViplist)
    const {
      status = 0,
      vipInfoId = 0,
      vipDaysRemain = 0,
      level = 0,
      vipStatus = 0,
      remindExpireDays = 0,
      endTime = 0,
    } = usrViplist[0] || []
    const { discount, deadline } = calculateDiscountPrice(vipStatus, vipDaysRemain, remindExpireDays, currentTime, endTime)
    
    // 自然日24小时倒计时剩余时间计算
    const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
    const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
    const timerDeadline = todayLastTime - nowDate.getTime()
    
    const parseUserInfo: UserInfo = {
      userId,
      nickName: nick,
      isLoginFlag,
      status,
      vipInfoId,
      vipType: vipInfoId,
      vipDaysRemain,
      remindExpireDays,
      level,
      vipStatus,
      createDays,
      loginName,
      phone,
      blockCount,
      eyeCareUseTime,
      currentTime,
      endTime,
      dialogTitle: !status ? (createDays <= 7 ? '恭喜获得新人专属红包' : '恭喜获得限时直降特权') : '恭喜获得年卡续费红包',
      deadline: !status ? (createDays <= 7 ? 7 * daysStr - (currentTime - createDate) : timerDeadline) : deadline,
      couponDiscount: discount,
      nick: (() => {
        if (!isLoginFlag) {
          return '请登录'
        }
        
        if (!status) {
          return '开通会员'
        }

        if (status === 2) {
          return '您的会员已过期'
        }

        if (vipDaysRemain <= 14 && vipDaysRemain > 0) {
          // 您的${VipStatusMap.get(vipInfoId)}
          return `您的会员仅剩${vipDaysRemain}天`
        }

        if (status === 1 && vipDaysRemain === 0) {
          // ${VipStatusMap.get(vipInfoId)}
          return `您的会员今天到期`
        }

        return nick
      })(),
      headUrl: isLoginFlag ? headUrl : '//cdn.hhdd.com/frontend/as/i/628c8d58-ccb4-5265-9fe0-8849f271a19d.png',
      infoText: vipList.length ? usrViplist.map(({ endTime, vipInfoId, status, vipDaysRemain, level, payFlag }) => {

        if (level === 99) {
          return ''
          // return `${VipStatusMap.get(vipType)}终身会员`
        }

        if (vipDaysRemain <= 14 && vipDaysRemain > 0) {
          return `会员到期时间：${formatDate(endTime, 'YYYY.MM.DD')}`
        }

        if (status === 1 && vipDaysRemain === 0) {
          return `会员到期时间：${formatDate(endTime, 'YYYY.MM.DD')}`
        }

        // if (payFlag) {
        //   return `会员到期时间：${formatDate(endTime, 'YYYY.MM.DD')}`
        // }

        if (status === 2) {
          return [VipType.BOOK, VipType.STORY].includes(vipInfoId) ? '开通会员畅学5万+精品内容' : `已过期${remindExpireDays}天`
        }

        // return `${formatDate(endTime, 'YYYY.MM.DD')}${VipStatusMap.get(vipType)}到期`
        return `会员到期时间：${formatDate(endTime, 'YYYY.MM.DD')}`
        
      }).slice(0, 1) : [isLoginFlag ? '开通会员畅学5万+精品内容' : '登录后同步会员特权']
    }
    // }
    
    console.log('parseUserInfo', parseUserInfo)
    return parseUserInfo
  })
}

function reorderVipList(vipList) {
  const vipType3Index = vipList.findIndex(item => item.vipType === 3)
  const vipType6Index = vipList.findIndex(item => item.vipType === 6)

  if (vipType3Index !== -1 && vipType6Index !== -1) {
    // 如果同时存在 vipType === 3 和 vipType === 6
    const vipType6Item = vipList.splice(vipType6Index, 1)[0] // 取出 vipType === 6 的项
    vipList.splice(vipType3Index, 0, vipType6Item); // 将 vipType === 6 的项插入到 vipType === 3 的前面
  }

  return vipList
}

export function getUserCookie (name) {
  const rawCookie = getCookie('_HHDD_') || ''
  let userCookie = null

  if (rawCookie) {
    try {
      userCookie = JSON.parse(rawCookie)
      // 保证一些特殊情况下，cookie是多层字符串
      if (typeof userCookie === 'string') {
        userCookie = JSON.parse(userCookie)
      }
    } catch (e) {
      console.error('service/user::getUserCookie parseUserCookie Error: ', e, rawCookie)
      userCookie = null
    }
  }

  if (name && userCookie) {
    return userCookie[name]
  }

  return userCookie
}

const pendingTask = []

/**
 * 设置登录成功等待队列
 *
 * @param {Function} task
 */
export function addLoginTask (task) {
  pendingTask.push(task)
}

/**
 * 执行登录任务队列
 * @private
 */
function doLoginTask () {
  while (pendingTask.length) {
    const task = pendingTask.shift()
    if (typeof task === 'function') {
      task()
    }
  }
}

export function isLogin () {
  const hhddCookie = getUserCookie()
  // console.log(localStorage.getItem('openId'))
  const openIdStr = openId || storage.get('openId')
  console.log('openId,sss', openId)

  if (openIdStr !== hhddCookie?.openId) {
    removeCookie('_HHDD_')
    return false
  }

  return hhddCookie && hhddCookie.userKey && openIdStr === hhddCookie.openId && getDeviceId() ? true : false
}

export function getUserId () {
  const hhddCookie = getUserCookie()

  return hhddCookie && hhddCookie.userId
}

// 定义不同情况下的折扣价格
const discounts = [
  { type: [2, 5], vipDays: 30, prices: [50, 40, 30] },
  { type: [3, 6], vipDays: 30, prices: [60, 50, 40] },
]

// 定义一个函数，用于计算不同情况下的折扣价格
const daysStr = 24 * 60 * 60 * 1000
function calculateDiscountPrice(vipStatus: number, vipDaysRemain: number, expiredDays: number, currentTime: number, endTime: number) {
  const discount = discounts.find((d) => d.type.includes(vipStatus) && d.vipDays >= vipDaysRemain && d.vipDays >= expiredDays);
  console.log(discount)
  if (discount) {
    if (expiredDays >= 1 && expiredDays <= 14) {
      return {
        discount: discount.prices[1],
        deadline: 14 * daysStr - (currentTime - endTime)
      }
    } else if (expiredDays >= 15 && expiredDays <= 30) {
      return {
        discount: discount.prices[2],
        deadline: 30 * daysStr - (currentTime - endTime)
      }
    } else if (vipDaysRemain >= 0 && vipDaysRemain <= 30) {
      return {
        discount: discount.prices[0],
        deadline: endTime - currentTime
      }
    }
  }

  return {
    discount: 0,
    deadline: 0
  }
}

export const REDPACKET_POPPED_FLAG = 'REDPACKET_POPPED_FLAG_YEARVIP'

/**
 * 设置当日红包已经弹出
 * @param {Number} userId 用户ID
 */
export function setRedPacketPopped (userId: number) {
  const key = `${REDPACKET_POPPED_FLAG}_${userId}`
  const nowDate = new Date()

  storage.set(key, 1, {
    // 存储过期时间为，今天的24小时之后
    expire: (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
  })
}

/**
 * 当日红包是否已经弹出
 * @param {Number} userId 用户ID
 */
export function hasRedPacketPopped (userId: number): boolean {
  const key = `${REDPACKET_POPPED_FLAG}_${userId}`

  return !!storage.get(key)
}