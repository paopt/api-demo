/* eslint-disable no-unreachable */
/* eslint-disable no-unused-vars */
/**
 * @see http://10.0.10.52:8090/pages/viewpage.action?pageId=34635846
 */
import { getApi, fetch } from '@/lib/fetch'
import { RDI } from '@kada/library/src/device'
import { getClientDeviceId } from '@kada/library/src/device'

/**
 * 发送验证码
 * @see http://10.0.10.51:3000/project/119/interface/api/7644
 *
 * @param {Number} phoneNumber 手机号
 */
export const sendSmsCode = ({ phoneNumber, sessionId, sig, token }) => {
  const url = getApi('phone', 'sms/send.json')
  return fetch.post(url, {
    phoneNumber,
    sessionId,
    sig,
    token,
    scene: 'nc_message_h5',
  })
  return {
    code: 200,
    message: '发送验证码成功',
  }
}

/**
 * 创建或登录
 * @see http://10.0.10.51:3000/project/119/interface/api/7637
 *
 * @param {Number} deviceId 设备id
 * @param {Number} phoneNumber 手机号
 * @param {Number} smsCode 验证码
 * @param {Number} wechatOpenId 微信端授权
 */
export const createUser = ({ deviceId, phoneNumber, smsCode, wechatOpenId }) => {
  const url = getApi('phone', 'login.json')
  return fetch.post(url, {
    deviceId,
    phoneNumber,
    smsCode,
    wechatOpenId,
    loginType: 8,
  })
  return {
    code: 200,
    data: {
      newUser: 0,
      deviceId: 'ksahdfkjhsadfhkasdfkn',
      avatar: '//cdn.hhdd.com/frontend/as/i/0743f092-4590-5288-b579-f14f08100c11.png',
      userNick: '用户昵称',
    },
  }
}

/**
 * 用户信息
 * @see http://10.0.10.51:3000/project/119/interface/api/7016
 */
export const fetchUserInfo = () => {
  const url = getApi('user', 'getUserInfo.json')
  return fetch.get(url, {
    params: {
      s: new Date().getTime(),
    }
  })
  return {
    code: 200,
    data: {
      newUser: 0,
      deviceId: 'ksahdfkjhsadfhkasdfkn',
      avatar: '//cdn.hhdd.com/frontend/as/i/0743f092-4590-5288-b579-f14f08100c11.png',
      userNick: '用户昵称',
    },
  }
}
/**
 * 查询订单状态
 * @see http://10.0.10.51:3000/project/119/interface/api/7658
 */
export const checkPayStatus = orderId => {
  const url = getApi('pay', 'order/status.json')
  return fetch.get(url, {
    params: {
      orderId,
    },
  })
}

/**
 * 获取openid
 * @see http://10.0.10.51:3000/project/38/interface/api/7667
 */
export const getOpenId = code => {
  const url = getApi('weixin', 'openId/get.json')
  return fetch.get(url, {
    params: {
      code,
      loginType: 8,
    },
  })
}

/**
 * 查询用户阅读数据(家长中心)
 * @see http://10.0.10.51:3000/project/38/interface/api/9164
 */
export const profile = code => {
  const url = getApi('reading', 'report/profile.json')
  return fetch.get(url)
}

/**
 * 订单列表接口
 * @see http://10.0.10.51:3000/project/38/interface/api/9143
 */
export const orderList = code => {
  const url = getApi('pay', 'order/list.json')
  return fetch.get(url)
}

/**
 * 订单详情接口
 * @see http://10.0.10.51:3000/project/38/interface/api/9176
 */
export const orderInfo = params => {
  const url = getApi('pay', 'order/info.json')
  return fetch.get(url, {
    params
  })
}

/**
 * 订单列表接口
 * @see http://10.0.10.51:3000/project/38/interface/api/9146
 */
export const continuePay = (orderId, tradeType, extraParams) => {
  const url = getApi('pay', 'order/continuePay.json')
  return fetch.post(url, {
    orderId,
    tradeType,
    extraParams,
  })
}

/**
 * 订单列表接口
 * @see http://10.0.10.51:3000/project/38/interface/api/9179
 */
export const createLink = (unionId, openId, loginType, type) => {
  const url = getApi('user', 'official/relation/create.json')
 
  const data = {
    unionId,
    openId,
    loginType,
    type
  }
  
  return fetch.post(url, data, {
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

/* 微信预下单操作 */
/**
 * @public
 * POST params
 * @see https://note.youdao.com/share/?id=a8db729f722c9879a81f5e063d018417&type=note#/
 */
export const getPreOrder = async (params = {}, channelId = '') => {
  // const params = {
  //   sourceId: levelsId,
  //   sourceType: 6,
  //   tradeType: 'JSAPI',
  //   orderTraceInfo: JSON.stringify({
  //     fromSourceId: this.$route.query.collectId,
  //     fromSourceType: 2,
  //     trace: ''
  //   })
  // }
  const api = getApi('pay', 'order/create.json')
  const deviceId = getClientDeviceId()
  const data = Object.assign({
    deviceId
  }, params)
  // let options = {}
  // if (channelId) {
    // options = {
    //   headers: {
    //     'Content-Type': 'application/x-www-form-urlencoded',
    //     partnerId: channelId
    //   }
    // }
  // }
  let res = await fetch.post(api, data)
  if (res.code !== 200) {
    const event = new Error(res.msg || '创建订单失败')
    event.code = res.code
    throw event
  }

  return res
}
