module.exports = {
  parser: '@babel/eslint-parser',
  parserOptions: {
    ecmaVersion: 2019,
    sourceType: 'module'
  },
  env: {
    es6: true,
    node: true,
    browser: true
  },
  extends: [ // then, enable whichever type-aware rules you want to use
    // 'eslint:recommended',
  ],
  plugins: [
    'svelte3',
    'standard'
  ],
  overrides: [
    {
      files: ['*.svelte'],
      processor: 'svelte3/svelte3'
    }
  ],
  rules: {
    'no-console': 'off',
    'no-debugger': 'error',
    "no-undef": "error",
    "no-extra-boolean-cast": "off",
    "unused-export-let": "off"
  },
  settings: {
    'import/extensions': ['.js', '.jsx'],
    "svelte3/ignore-styles": () => true
  },
  globals: {
    __ENV_CONFIG__: true
  }
}
