const webpack = require('webpack')
const chalk = require('chalk')
const WebpackDevServer = require('webpack-dev-server')
const devConfig = require('./webpack/dev')

devConfig().then(webpackConfig => {
  console.log(webpackConfig.devtool)
  const { devServer } = webpackConfig

  const compiler = webpack(webpackConfig)
  const devServerOptions = Object.assign({}, devServer, {
    open: false
  })
  const server = new WebpackDevServer(compiler, devServerOptions)

  const { port = process.env.PORT || 8080 } = devServer

  server.listen(port, '0.0.0.0', (error) => {
    if (error) {
      console.log(chalk.red(`Server start error at: http://localhost:${port}`))
      throw error
    }
  })
})
