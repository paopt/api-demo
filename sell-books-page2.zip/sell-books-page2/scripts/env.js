const fs = require('fs')
const path = require('path')
const _ = require('lodash')
const glob = require('glob')
const yaml = require('js-yaml')
const urljoin = require('url-join')
const UglifyJS = require('uglify-js')
const address = require('address')
const pkg = require('../package.json')

const projectDir = path.resolve(__dirname, '../')
const env = process.env.NODE_ENV || 'development'
const projectName = pkg.name
const projectVersion = pkg.version

const configDir = path.join(projectDir, './config')
const srcDir = path.join(projectDir, './src')
const distDir = path.join(projectDir, './dist')
const publicDir = path.join(projectDir, './public')
const defaultEnvFilename = path.resolve(configDir, 'env.yaml')
const configFilename = path.resolve(configDir, `env.${env}.yaml`)
const defaultEnv = defaultEnvFilename ? yaml.safeLoad(fs.readFileSync(defaultEnvFilename, 'utf8')) : {}
const envConfig = configFilename ? yaml.safeLoad(fs.readFileSync(configFilename, 'utf8')) : {}
const globalConfig = _.merge({}, defaultEnv, envConfig)

const deployConfigFilename = path.resolve(projectDir, '.kadadeployrc.js')
const deployConfig = require(deployConfigFilename)

// baseUrl & entryBaseUrl
const staticBaseUrl = globalConfig.staticBaseUrl && env !== 'development' ? urljoin(globalConfig.staticBaseUrl, projectName, '/') : (globalConfig.staticBaseUrl || '')
const entryBaseUrl = globalConfig.entryBaseUrl && env !== 'development' ? urljoin(globalConfig.entryBaseUrl, projectName, '/') : (globalConfig.entryBaseUrl || '')

// html rem-layout script code
const nodeModulesPath = path.resolve('node_modules', '@kada/kada-rem-layout/lib/index.iife.js')
const remLayoutData = nodeModulesPath ? fs.readFileSync(nodeModulesPath, { encoding: 'utf-8' }) : null
const { code: remLayoutCode } = remLayoutData ? UglifyJS.minify(remLayoutData) : null

// Reset.css浏览器样式重置
const resetCssPath = path.resolve('node_modules', '@kada/reset.css/css/reset.min.css')
const resetCssCode = resetCssPath ? fs.readFileSync(resetCssPath, { encoding: 'utf-8' }) : null

// mutle pages
const pagesDir = path.join(projectDir, 'src/page')
const pagePaths = glob.sync('page.json', {
  cwd: pagesDir
})

const pagesConfig = {}
const pages = pagePaths.reduce((obj, filename) => {

  const moduleName = projectName
  const configDirname = pagesDir
  const configFilename = path.resolve(configDirname, 'page.json')
  const entryFile = path.join('src/page', filename)
  let config = entryFile

  if (fs.existsSync(configFilename)) {
    const pageConfig = require(configFilename)
    const newConfig = {}
    Object.keys(pageConfig).forEach(key => {
      if (['entry', 'template', 'filename', 'skeleton'].indexOf(key) >= 0) {
        let p = pageConfig[key]

        if (/^~\//.test(p)) {
          p = p.replace(/^~\//, '')
        } else {
          p = path.resolve(configDirname, p)
        }
        if (key !== 'entry') {
          newConfig[key] = path.relative(projectDir, p)
        } else {
          newConfig[key] = p
        }
      } else {
        newConfig[key] = pageConfig[key]
      }
    })

    const { entry = entryFile, template, filename = `index.html`, title, chunks, skeleton, ...otherConfig } = newConfig
    let skeletonObject
    if (skeleton && env !== 'development') {
      const skeletonFilename = path.resolve(projectDir, skeleton)
      skeletonObject = require(skeletonFilename) || {}
    }

    pagesConfig[moduleName] = Object.assign(pagesConfig[moduleName] || {}, otherConfig)
    config = { entry, template, filename, skeleton: skeletonObject, title, chunks }
  }

  obj[moduleName] = config

  return obj
}, {})

const devServerConfig = (globalConfig && globalConfig.devServer) || {}
const { port = 8080, disableHostCheck, proxy } = devServerConfig

module.exports = {
  env,
  pages,
  packageConfig: pkg,
  deployConfig,
  globalConfig,
  codes: {
    remLayoutCode,
    resetCssCode
  },
  dirs: {
    project: projectDir,
    config: configDir,
    pages: pagesDir,
    src: srcDir,
    dist: distDir,
    public: publicDir
  },
  baseUrl: {
    assets: staticBaseUrl,
    entry: entryBaseUrl
  },
  project: {
    name: projectName,
    version: projectVersion
  },
  devServer: {
    host: address.ip(),
    port,
    disableHostCheck,
    proxy
  }
}
