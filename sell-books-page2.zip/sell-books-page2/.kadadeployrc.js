const env = process.env.NODE_ENV || 'development'

let pathPrefix = ''

switch (env) {
  case 'production':
    pathPrefix = 'wepage'
    break
  case 'staging':
    pathPrefix = 'wepage-staging'
    break
  case 'test':
    pathPrefix = 'wepage'
    break
  case 'development':
  default:
    pathPrefix = ''
}

let entries = ['index.html']
module.exports = {
  pathPrefix,
  entries,
  headers: entries.map(item => {
    const rules = `${item.replace(/\./g, '\\.')}$`
    return {
      rules,
      headers: {
        'cache-control': 'no-cache'
      }
    }
  }).concat({
    rules: `service-worker.js|service.appcache`,
    headers: {
      'cache-control': 'no-cache'
    }
  })
}
