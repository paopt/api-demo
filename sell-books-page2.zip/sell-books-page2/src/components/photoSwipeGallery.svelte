<script>
  import { createEventDispatcher } from "svelte"
  const dispatch = createEventDispatcher()

  export let galleryList = [
    {
      type: "mind",
      width: 3508,
      height: 2480,
      content: `//cdn.hhdd.com/frontend/as/i/82b57adc-6380-5480-976e-8d346c15f79a.jpg`,
    },
    {
      type: "mind",
      width: 3508,
      height: 2480,
      content: `//cdn.hhdd.com/frontend/as/i/82b57adc-6380-5480-976e-8d346c15f79a.jpg`,
    },
    {
      type: "mind",
      width: 3508,
      height: 2480,
      content: `//cdn.hhdd.com/frontend/as/i/82b57adc-6380-5480-976e-8d346c15f79a.jpg`,
    },
    {
      type: "mind",
      width: 3508,
      height: 2480,
      content: `//cdn.hhdd.com/frontend/as/i/82b57adc-6380-5480-976e-8d346c15f79a.jpg`,
    },
    {
      type: "mind",
      width: 3508,
      height: 2480,
      content: `//cdn.hhdd.com/frontend/as/i/82b57adc-6380-5480-976e-8d346c15f79a.jpg`,
    },
    {
      type: "mind",
      width: 3508,
      height: 2480,
      content: `//cdn.hhdd.com/frontend/as/i/82b57adc-6380-5480-976e-8d346c15f79a.jpg`,
    },
  ]

  const grlleryItemClick = (index) => {
    console.log(index)
    dispatch('preview-click', index)
  }
</script>

<div class="c-mind pswp-gallery" id="my-gallery">
  {#each galleryList as item, index}
    <div
      class="mind-item"
      key={index}
      on:click={() => { grlleryItemClick(index) }}
    >
      <img src={item.content} alt="" />
      <div class="text fzlty">{ item.name}</div>
      <div class="item-btn"></div>
    </div>
  {/each}
</div>
<div class="pswp-gallery" />

<style lang="scss">
  @import "../../styles/mixins";
  $component-name: "c-mind";

  .#{$component-name} {
    display: flex;
    flex-wrap: wrap;
    padding: 0 0.59rem;
    justify-content: space-between;
    .mind-item {
      position: relative;
      width: 3.03rem;
      height: 2.23rem;
      margin: 0.1rem 0;
      border: 0.02rem solid #499BF6;
      border: 0.04rem solid #499BF6;
      border-radius: 0.25rem;
      overflow: hidden;

      img {
        width: 100%;
        height: 100%;
      }

      .text {
        width: 100%;
        height: 0.66rem;
        position: absolute;
        bottom: 0;
        background-color: #499BF6;
        color: white;
        font-size: 0.26rem;
        text-align: center;
        line-height: .66rem;
      }

      .item-btn {
        position: absolute;
        width: 0.43rem;
        height: 0.43rem;
        background: url(//cdn.hhdd.com/frontend/as/i/fd56687d-c403-5796-9e6d-70548e6dcba6.png) no-repeat;
        background-size: cover;
        right: 0;
        bottom: 0.66rem;
      }
    }

  }

</style>
