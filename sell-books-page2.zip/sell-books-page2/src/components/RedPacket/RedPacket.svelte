<Popup class={['c-packetdlg', className, theme ? `theme-${theme}` : ''].join(' ')} {maskClickHide} {onClose} {outPosition} bind:this={popupEl}>
  <div class="c-packetdlg__body">
    <div class="c-packetdlg__bg" style={`${bgImage ? `background-image: url(${bgImage});` : ''}`}></div>

    {#if showCloseButton}
      <div class="c-packetdlg__close" on:click={handleCloseButtonClick}>x</div>
    {/if}

    <div class="c-packetdlg__footer">
      {#if showDoneButton}
        <div class="c-packetdlg__button" on:click={handleButtonClick} on:touchstart={(event) =>{ event.stopPropagation() }}>
          {@html buttonText}<CountDown style="opacity: 0;" max={3} unit="S" bind:this={countDownEl} on:end={handleCountDownEnd}></CountDown>
        </div>
      {/if}
    </div>

    <canvas class="c-packetdlg__canvas" width="750" height="1008" bind:this={canvasEl}></canvas>
  </div>
</Popup>

<script>
  import { Downloader, Parser, Player } from 'svga.lite'
  import { createEventDispatcher, onMount } from 'svelte'
  import { Popup, CountDown } from '@kada/svelte-activity-ui'
  import { promiseDelay } from '@/utils/promisify'
  import config from '@/lib/config'

  const { staticBaseUrl, env, project: { name: projectName = '' } } = config

  const assetsPathname = `${staticBaseUrl}${env === 'development' ? '' : `${projectName}/`}`

  const dispatch = createEventDispatcher()
  let canvasEl
  let lotteryImage = '/assets/newuser-firstorder/fireworks.svga'
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = false

  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  /**
   * 点击按钮是否关闭弹窗
   * @type {Function} onClose
   */
  export let doneCloseDialog = true

  /**
   * 点击按钮回调
   * @type {Function} onClose
   */
  export let onDone = null

  /**
   * 动画退出位置
   * @type {Boolean} outPosition
   */
  export let outPosition = [0, 0]

  /**
   * 背景图片列表
   * @type {Array<String>} bgImages
   */
  export let bgImage = ''

  /**
   * 按钮文字或图片
   * @type {String} buttonText
   */
  export let buttonText = ''

  /**
   * 是否显示关闭按钮
   * @type {Boolean} showCloseButton
   */
  export let showCloseButton = false

  /**
   * 是否显示确定按钮
   * @type {Boolean} showDoneButton
   */
  export let showDoneButton = false

  /**
   * 组件样式主题
   * @type {String} theme
   */
  export let theme = ''

  let countDownEl = null
  let popupEl = null
  let visible = false

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  const downloader = new Downloader()
  const parser = new Parser()
  let lotteryPlayer

  async function playLottery () {
    if (!canvasEl) {
      return
    }
    let isLotteryInited = false

    if (!lotteryPlayer) {
      lotteryPlayer = new Player(canvasEl)

      lotteryPlayer
        .$on('start', async () => {
          if (!isLotteryInited) {
            // 等待第一帧画面出现
            popupEl && popupEl.show()
            isLotteryInited = true

            lotteryPlayer.resume()
          }
        })
    }

    const fileData = await downloader.get(`${assetsPathname}${lotteryImage.replace(/^\//g, '')}`)
    const svgaData = await parser.do(fileData)
    lotteryPlayer.set({ loop: 1 })
    await lotteryPlayer.mount(svgaData)

    // 开始播放动画
    await lotteryPlayer.start()
  }

  function close() {
    dispatch('close')
    visible = false
    popupEl && popupEl.close()
    lotteryPlayer && lotteryPlayer.pause()
    resolve(false)
  }
  const playOutAnimation = (duration = 1000) => {
    const el = document.querySelector('.c-packetdlg__bg')
    const confirmBtnEl = document.querySelector('.c-packetdlg__button')
    if (!el) {
      return true
    }
    if (confirmBtnEl) {
      confirmBtnEl.style.opacity = 0
    }
    el.style.transition = `transform ${duration}ms cubic-bezier(.93,-0.32,.86,.95)`
    el.style.transform = 'translate(0, 0) scale(1)'
    setTimeout(() => {
      const outPos = config.isPad ? [-3, 0] : [-2, 1.5]
      el.style.transform = `translate(${outPos[0]}rem, ${outPos[1]}rem) scale(0)`
    }, 50)
    return promiseDelay(duration)
  }
  const handleButtonClick = async () => {
    if (countDownEl) {
      countDownEl.pause()
    }
    if (doneCloseDialog) {
      // 关闭前 先播放动效
      await Promise.race([playOutAnimation(800), new Promise(resolve => setTimeout(resolve, 1000))])
      popupEl && popupEl.close()
    }
    resolve(true)
    if (typeof onDone === 'function') {
      onDone()
    }
  }

  const handleCloseButtonClick = () => {
    close()
  }

  const handleCountDownEnd = () => {
    if (visible) {
      handleButtonClick()
    }
  }

  onMount(() => {
    promiseDelay(500).then(() => {
      if (countDownEl) {
        countDownEl.start()
      }
    })
    popupEl && popupEl.show()
    visible = true
    if (document.body.animate) {
      playLottery()
    }
  })
</script>

<style lang="scss" global>
  @import "../../styles/mixins";

  $component-name: 'c-packetdlg';

  .#{$component-name} {
    z-index: 999;

    &__body {
      position: relative;
      top: -0.1rem;
      width: 7.50rem;
    }

    &__bg {
      position: relative;
      width: 7.50rem;
      height: 11.72rem;
      background: url(//cdn.hhdd.com/frontend/as/i/8e15406d-53c1-58dd-9e22-e469ce2b626a.png) no-repeat 50% 0 / 100% 100%;
      z-index: 2;
    }

    &__progress {
      position: absolute;
      top: 7.74rem;
      left: 50%;
      width: 4.8rem;
      transform: translateX(-50%);
      z-index: 10;
    }

    &__footer {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 12;
    }

    &__button {
      position: relative;
      display: flex;
      width: 5.34rem;
      height: 1.52rem;
      background-image: url('//cdn.hhdd.com/frontend/as/i/d2727911-d586-5d7e-989e-5fa2a71dbe4f.png');
      background-repeat: no-repeat;
      background-size: 100% 100%;
      margin: 0 auto;
      justify-content: center;
      align-items: center;
      transition: transform 0.25s;
      line-height: 1;
      text-align: center;
      top: -1rem;

      &:active {
        transform: scale(0.98);
      }

      .text-image {
        width: 2.79rem;
        height: 0.74rem;
      }
    }

    &__close {
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      bottom: 0.24rem;
      width: 0.76rem;
      height: 0.76rem;
      color: transparent;
      background: url(//cdn.hhdd.com/frontend/as/i/ce360163-bc41-5954-9b20-732b2503e620.png) no-repeat 50% 50% / 100% 100%;
      z-index: 99;
    }

    &.theme-simple {
      .#{$component-name} {
        &__bg {
          background: url(//cdn.hhdd.com/frontend/as/i/8e15406d-53c1-58dd-9e22-e469ce2b626a.png) no-repeat 50% 0 / 100% 100%;
        }

        &__button {
          display: none;
        }
      }
    }

    &__canvas {
      position: absolute;
      left: 0;
      width: 100%;
      top: 0;
      height: auto;
      pointer-events: none;
      transition: opacity 0.3s ease;
      z-index: 10;

      &.is-hide {
        opacity: 0;
      }
    }
  }
</style>
