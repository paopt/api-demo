/**
 * 快速滑动卡片
 * @param {*} options 
 */
const rem2px = window.kadaRemLayout && window.kadaRemLayout.rem2px ? window.kadaRemLayout.rem2px : (rem) => rem * 50
export function slideCard(options) {
  const { containerEle, listEle, space } = options
  if (!containerEle || !listEle) {
    return
  }
  // 手指开始位置
  let startX = 0
  let startY = 0
  // 滑动元素translateX位置
  let elementX = 0
  let translateX = 0
  // 快速滑屏
  let quickLastTime = 0
  let quickLastX = 0
  let quickDisTime = 0
  let quickDisX = 0
  // 滑动范围
  let min = 0
  let max = 0
  // 防抖动
  let isX = true
  let isFirst = true

  const touchstartFn = e => {
    // e.preventDefault()
    const listRect = listEle.getBoundingClientRect()
    const padding = rem2px(space)

    // 滑动范围
    const contrainerRect = containerEle.getBoundingClientRect()
    min = contrainerRect.width - listRect.width - padding * 2
    max = 0

    // 开始位置
    startX = e.changedTouches[0].clientX
    startY = e.changedTouches[0].clientY
    elementX = translateX

    // 快速滑动参数初始化
    quickLastTime = Date.now()
    quickLastX = startX
    quickDisTime = 0
    quickDisX = 0

    // 防抖动初始化
    isX = true
    isFirst = true

    listEle.style.transition = 'none'
  }
  const touchmoveFn = e => {
    if (!isX) {
      return
    }
    e.preventDefault()
    const x = e.changedTouches[0].clientX
    const y = e.changedTouches[0].clientY
    // const contrainerRect = containerEle.getBoundingClientRect()
    // const { left, top, bottom, right } = contrainerRect
    // // 移出滑动区域
    // if (y < top || y > bottom || x < left || x > right) {
    //   console.log('移出滑动区域')
    //   isMoving = false
    //   return
    // }

    let disX = x - startX
    let disY = y - startY
    // 第一次滑动，判断方向
    if (isFirst) {
      isFirst = false
      if (Math.abs(disX) < Math.abs(disY)) {
        isX = false
        console.log('滑动方向：y')
        return
      }
      console.log('滑动方向：x')
    }

    // 滑动范围处理
    let dis = elementX + disX
    if (dis > max) {
      dis = max
    }
    if (dis < min) {
      dis = min
    }

    // 快速滑动c参数更新
    let nowTime = Date.now()
    let nowX = x
    quickDisTime = nowTime - quickLastTime
    quickDisX = nowX - quickLastX
    quickLastTime = nowTime
    quickLastX = nowX

    // 滑动
    translateX = dis
    listEle.style.transform = `translateX(${dis}px)`
    requestAnimationFrame(() => {
    })
  }
  const touchendFn = (e) => {
    // 快速滑屏处理
    if (quickDisX !== 0 && quickDisTime !== 0) {
      let speed = quickDisX / quickDisTime
      if (Math.abs(speed) < 0.5) {
        return
      }
      console.log('滑动结束，快速滑屏开始', speed)
      let dis = translateX + speed * 200
      // let time = Math.abs(speed) * 0.2
      // time = time < 0.5 ? 0.5 : time
      // time = time > 1 ? 1 : time
      let time = 0.5

      if (dis >= max) {
        dis = max
      }
      if (dis <= min) {
        dis = min
      }
      translateX = dis
      listEle.style.transform = `translateX(${dis}px)`
      listEle.style.transition = `transform ${time}s`
      requestAnimationFrame(() => {
      })
    }
  }

  listEle.addEventListener('touchstart', touchstartFn)
  listEle.addEventListener('touchmove', touchmoveFn)
  listEle.addEventListener('touchend', touchendFn)

  return () => {
    listEle.removeEventListener('touchstart', touchstartFn)
    listEle.removeEventListener('touchmove', touchmoveFn)
    listEle.removeEventListener('touchend', touchendFn)
  }
}