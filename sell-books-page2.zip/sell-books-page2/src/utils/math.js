/**
 * 矩形区域是否相交，用于检测区块在容器内是否可见
 * @param {{top:Number, left:Number, width:Number, height:Number}} rect1 子版块区域
 * @param {{top:Number, left:Number, width:Number, height:Number}} rect2 容器区域
 *
 * @returns {Number} 相对子版块显示比率
 */
export function getIntersectionRatio (rect1, rect2) {
  const xMin = Math.max(rect1.left, rect2.left)
  const yMin = Math.max(rect1.top, rect2.top)
  const xMax = Math.min(rect1.left + rect1.width, rect2.left + rect2.width)
  const yMax = Math.min(rect1.top + rect1.height, rect2.top + rect2.height)

  const width = Math.min(xMax - xMin, rect1.width)
  const height = Math.min(yMax - yMin, rect1.height)

  if (width <= 0 || height <= 0) {
    return 0
  }

  const crossSquare = width * height

  return crossSquare / (rect1.width * rect1.height)
}

/**
 * 计算字符串长度，汉字两个字符
 * @param {*} str
 * @returns
 */
 export function splitString(str, len) {
  if (str) {
    if (len < str.length) {
      return str.slice(0, len) + '...'
    } else {
      return str
    }
  } else {
    return ''
  }
}
