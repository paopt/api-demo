import {getAnalyticsIdByName} from "@/shared/scheme/page-config"
import { KADA_APP_DOWNLOAD_URL, KADA_APP_OPEN_IN_APPSTORE } from '@/shared/internal/constants'
import { showTypedDialog, DIALOG_TYPE, DIALOG_THEMES} from "@kada/svelte-activity-ui"
import { deviceInfo} from "@kada/library/src/device"
import {sendBehavior} from "@/shared/internal"

/**
 * 根据资源类型跳转对应的kada协议
 * @param {*} sourceType 
 * @param {*} sourceId 
 * @param {*} isNew 
 */
export function goKadaBySourceType(isNew, sourceType, sourceId, sourceId2) {
  if (!deviceInfo.isKadaClient) {
    showUnSupportDialog()
    return
  }
  const urlMap = {
    1: 'kada://openbook?bookId=${sourceId}',
    2: 'kada://openstory?storyId=${sourceId}',
    4: 'kada://openstorycollection2?collectionId=${sourceId}&removeCookie=false',
    5: 'kada://openbookcollection2?collectionId=${sourceId}&removeCookie=false',
    8: 'kada://opennewcoursedetail?courseId=${sourceId}',
    14: 'kada://opencartooncollection?comicId=${sourceId}',
    15: 'kada://openebook?ebookId=${sourceId}',
    16: 'kada://openreadplan?planId=${sourceId}',
    19: 'kada://openmixcourse?courseId=${sourceId}&unitId=${sourceId2}'
  }
  let url = urlMap[sourceType]
  if (url) {
    url = url.replace('${sourceId}', sourceId)
    url = url.replace('${sourceId2}', sourceId2)
    if (isNew) {
      url += '&fromLocation=1'
    }
    location.href = url
  }
}

  /**
   * 显示当前环境不支持，app内打开
  */
  const showUnSupportDialog = (close = true) => {
    // clearBodyLocks()
    const staIdView = getAnalyticsIdByName('dialog.downloadDialog.view')
    if (staIdView) sendBehavior(staIdView)
    showTypedDialog({
      type: DIALOG_TYPE.APP_ONLY,
      theme: DIALOG_THEMES.NEW2021,
      title: '当前环境不支持',
      message: '请在KaDa阅读APP内打开哦～',
      showCloseButton: close,
      maskClickHide: close,
      onDone: () => {
        if (deviceInfo.wechat) {
          location.href = KADA_APP_DOWNLOAD_URL
        } else {
          if (deviceInfo.ios) {
            location.href = KADA_APP_OPEN_IN_APPSTORE
          } else {
            location.href = KADA_APP_DOWNLOAD_URL
          }
        }
      }
    })
  }