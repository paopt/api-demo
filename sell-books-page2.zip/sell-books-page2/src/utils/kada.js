/**
 * 根据资源类型跳转对应的kada协议
 * @param {*} sourceType 
 * @param {*} sourceId 
 * @param {*} isNew 
 */
export function goKadaBySourceType(sourceType, sourceId, isNew) {
  const urlMap = {
    1: 'kada://openbook?bookId=${sourceId}',
    2: 'kada://openstory?storyId=${sourceId}',
    4: 'kada://openstorycollection2?collectionId=${sourceId}&removeCookie=false',
    5: 'kada://openbookcollection2?collectionId=${sourceId}&removeCookie=false',
    8: 'kada://opennewcoursedetail?courseId=${sourceId}',
    14: 'kada://opencartooncollection?comicId=${sourceId}',
    15: 'kada://openebook?ebookId=${sourceId}',
    16: 'kada://openreadplan?planId=${sourceId}'
  }
  let url = urlMap[sourceType]
  if (url) {
    url = url.replace('${sourceId}', sourceId)
    if (isNew) {
      url += '&fromLocation=1'
    }
  }
  location.href = url
}