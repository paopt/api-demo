import {getExtname} from '@kada/library/utils/image'

export function compressImage(url) {
  let extname = getExtname(url)
  return `${url}?x-oss-process=image/quality,q_80/format,${extname}`
}
