import { SvelteComponent } from 'svelte/internal'

/**
 * 判断是否为SvelteComponent
 * @param {Object} object
 * @returns {Boolean}
 */
export function isSvelteComponent (object) {
  return !!((typeof object === 'function')
    && (
      Object.prototype.isPrototypeOf.call(SvelteComponent, object)
      || object.prototype instanceof SvelteComponent
    )
  )
}

/**
 * 是否为Function
 * @param {Object} object
 * @returns {Boolean}
 */
export function isFunction (object) {
  return typeof object === 'function'
}

/**
 * 是否为Promise
 * @param {Object} object
 * @returns {Boolean}
 */
export function isPromise (obj) {
  return !!obj && (typeof obj === 'object' || isFunction(obj)) && isFunction(obj.then)
}
