/**
 * 检查设备性能
 */
import { deviceInfo } from '@kada/library/src/device'
import compareVersions from 'compare-versions'

// 是否为性能机型
export const IS_LOW_DEVICE = deviceInfo.android && compareVersions(deviceInfo.os.version, '5.2') < 0
