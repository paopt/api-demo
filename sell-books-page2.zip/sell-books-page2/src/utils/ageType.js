// 不同年龄段对应的阅读目标
export let ageTypeMap = {
  1: {
    label: '0~1岁'
  },
  2: {
    label: '2岁'
  },
  3: {
    label: '3岁'
  },
  4: {
    label: '小班'
  },
  5: {
    label: '中班'
  },
  6: {
    label: '大班'
  },
  7: {
    label: '一年级'
  },
  8: {
    label: '二年级'
  },
  9: {
    label: '三年级'
  },
  10: {
    label: '四年级'
  },
  11: {
    label: '五年级'
  },
  12: {
    label: '六年级'
  },
  13: {
    label: '初一'
  },
  14: {
    label: '初二'
  },
  15: {
    label: '初三及以上'
  }
}