<div class="address">
  <!-- 标题 -->
  <header class="header">
    <div class="title">{title}</div>
  </header>
  <section>
    <div class="container">
      <div class="list">
        <label for="recipient">收货人</label>
        <input id="recipient" type="text" placeholder="请输入收货人" bind:value={formData.recipient}>
      </div>
      <div class="list">
        <label for="phone">手机号码</label>
        <input id="phone" type="number" placeholder="请输入手机号码" bind:value={formData.phone}>
      </div>
      <div class="list">
        <label for="region">地区</label>
        <input id="region" type="text" readonly placeholder="请选择区域" bind:value={formData.region} on:click={pickArea}>
      </div>
      <div class="list">
        <label for="address">地址详情</label>
        <input id="address" type="text" placeholder="请输入地址详情" bind:value={formData.address}>
      </div>
    </div>
    <div class="backup">
      备注：收货地址仅限中国大陆地址，港澳台地区、海外地址暂不支持
    </div>
  </section>
  <div class="confirm">
    <div class="btn-confirm" on:click={handleEdit}>保存</div>
  </div>
</div>

<script>
  import {showLoading, hideLoading, PickerAreaSheet, toast} from "@kada/svelte-activity-ui"
  import {router} from '@kada/yrv'
  import { onMount } from "svelte";
  import * as service from '../../../page/service'
  import {regExp} from '@/shared/internal/constants'

  let area = []
  let formData = { id: '', recipient: '', phone: '', region: '', address: '' }
  let validate = () => {
    let errMsg = ''
    if (!formData.recipient) {
      errMsg = '请输入收货人'
    } else if (!regExp.zhCn.test(formData.recipient)) {
      errMsg = '收货人仅支持中英文'
    } else if (!formData.phone) {
      errMsg = '请输入手机号'
    } else if (!regExp.phone.test(formData.phone)) {
      errMsg = '请输入正确格式的手机号'
    } else if (!formData.region) {
      errMsg = '请选择地区'
    } else if (!formData.address) {
      errMsg = '请输入地址详情'
    }
    if (errMsg) {
      toast(errMsg)
      return false
    }
    return true
  }

  $:title = formData.id ? '编辑地址' : '新增地址'
  $:if (Array.isArray(area) && area.length > 0) {
    formData.region = area.map(a => a.name).join(" ")
    formData.province = area[0]?.name
    formData.city = area[1]?.name
    formData.area = area[2]?.name
    formData.areaCode = area[2]?.code
  }

  onMount(() => {
    let {query: {id}} = $router
    if (parseInt(id)) {
      showLoading()
      service.userAddressDetail({id}).then(res => {
        hideLoading()
        let {code, data} = res
        if (code == 200) {
          let {id, recipient, region, address, phone} = data
          formData = Object.assign({}, {id, recipient, region, address, phone})
        }
      }).catch(e => {
        hideLoading()
        console.log(e)
      })
    } else {
      delete formData.id
    }
  })

  function handleEdit() {
    if (validate()) {
      showLoading()
      service.saveUserAddress(formData).then(res => {
        hideLoading()
        let {code} = res
        if (code == 200) {
          window.history.go(-1)
        }
      })
    }
  }

  //选择区域
  async function pickArea() {
    const data = await service.getAreaData()
    const areaPicker = new PickerAreaSheet({
      target: document.body,
      props: { areaList: data, showInput: false, visible: true }
    })
    areaPicker.$on('confirm', e => {
      console.log('选择地址', e)
      area = e?.detail?.data
    })
  }

</script>

<style lang="scss" scoped>
  @import '../../../styles/variables';
  @import '../../../styles/mixins';
  .address {
    --item-width: 6.86rem;
    position: relative;
    height: 100vh;
    box-sizing: border-box;
    border: 1px solid transparent;
    margin: 0 auto;
    background: #F6F8FB;
    font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    --header-height: 1rem;
    header {
      width: 100%;
      line-height: var(--header-height);
      height: var(--header-height);
      background: #FFFFFF;
      text-align: center;
      position: fixed;
      top: 0;
      z-index: 1;

      @media #{$media_query-notch} {
        top: constant(safe-area-inset-top); /* iOS 11.0 */
        top: env(safe-area-inset-top); /* iOS 11.2 */
      }
    }
    section {
      margin-top: var(--header-height);
      @media #{$media_query-notch} {
        margin-top: calc(var(--header-height) + constant(safe-area-inset-top));
        margin-top: calc(var(--header-height) + env(safe-area-inset-top));
      }
      .container {
        margin-top: var(--header-height);
        width: var(--item-width);
        height: auto;
        background: #FFFFFF;
        border-radius: 0.08rem;
        margin-top: 0.2rem;
        padding: 0rem 0.2rem 0rem 0.2rem;
        .list {
          border-bottom: 1px solid #F6F8FB;
          padding: 0.3rem 0;
          label {
            display: inline-block;
            width: 1.5rem;
          }
          input {
            border: 0;
            outline: 0;
            user-select: text;
            appearance: none;
            width: 4.56rem;
          }
        }
      }
      .backup {
        width: var(--item-width);
        padding: 0.32rem 0;
        font-size: 0.24rem;
        color: #666666;
      }
    }
    .confirm {
      .btn-confirm {
        width: 6.94rem;
        height: 0.84rem;
        line-height: 0.84rem;
        margin: 0.14rem auto;
        background: linear-gradient(180deg, #F94368 0%, #FF35A8 100%);
        border-radius: 0.42rem;
        font-size: 0.32rem;
        color: #FFFFFF;
        text-align: center;
      }
    }
  }
</style>
