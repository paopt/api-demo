<div class="address">
  <!-- 标题 -->
<header class="header">
  <div class="title">选择地址</div>
</header>
  <!-- 添加按钮 -->
  <div class="plus-add" on:click={() => handleEditAddr()}></div>
  {#if hasUserAddr}
    <div class="container">
      {#each addressList as a, i}
        <div class="list">
          <div class="content" on:click={() => activeIndex = i}>
            <div class="check" class:active={i === activeIndex}></div>
            <div class="detail">
              <div class="title"><span>{a.recipient}</span> <span class="phone">{a.phone}</span></div>
              <div class="location">{a.region} {a.address}</div>
            </div>
          </div>
          <div class="button">
            <div class="edit" on:click={() => handleDelete(a.id)}>删除</div>
            <div class="delete" on:click={() => handleEditAddr(a.id)}>编辑</div>
          </div>
        </div>
      {/each}
    </div>
    <div class="tips">
      <div class="btn-add" on:click={() => handleEditAddr()}>添加地址</div>
      <div class="tip">
        注：选择邮寄地址后需确认邮寄地址，确认后，若需更改需
        <a href="https://h5.hhdd.com/n/h5-macqueen/service-center.html#/home?openChat=1">联系客服</a>，请谨慎填写。
      </div>
    </div>
  {:else}
    <div class="noaddress-tip">
      <div>您还没有邮寄地址</div>
      <div>快去添加邮寄地址吧～</div>
  </div>
  {/if}
  <div class="confirm">
    <div class="btn-confirm"
      class:disabled={hasUserAddr && activeIndex == -1}
      on:click={() => confirmAddress()}>{hasUserAddr ? '确认邮寄地址' : '添加邮寄地址'}</div>
  </div>
</div>

<script>
  import {navigateTo, router} from '@kada/yrv'
  import {onMount} from 'svelte'
  import {showLoading, hideLoading, toast, Dialog} from "@kada/svelte-activity-ui"
  import * as service from '../../../page/service'
  import { context } from '@/shared/internal'

  const {confirm} = Dialog
  export const configId = ''            //活动编号
  export const pageContext = null       //活动信息

  //地址列表
  let addressList = []
  //当前选中的地址
  let activeIndex = -1
  //是否已有用户地址
  $:hasUserAddr = Array.isArray(addressList) && addressList.length > 0

  let getAddressList = () => {
    showLoading()
    service.userAddressList().then(res => {
      hideLoading()
      let {data, code} = res
      if (code == 200) {
        addressList = data
      }
    }).catch(e => {
      hideLoading()
      console.log(e)
    })
  }

  onMount(() => {
    getAddressList()
  })


  function handleDelete(id) {
    confirm('确定删除此地址吗？').then(ok => {
      if (ok) {
        showLoading()
        service.delUserAddress({id}).then(res => {
          hideLoading()
          let {code} = res
          if (code == 200) {
            getAddressList()
          }
        })
      }
    })
  }

  function handleEditAddr(id = '') {
    const params = {...$router.query}
    // 去掉多余的参数
    Reflect.deleteProperty(params, 'activityKey')
    Reflect.deleteProperty(params, 'type')
    parseInt(id) ? navigateTo('/address/edit/', {queryParams: {...params, id}}) : navigateTo('/address/edit/', {queryParams: {...params}})
  }

  function confirmAddress() {
    if (hasUserAddr) {
      //确认邮寄地址
      if (activeIndex > -1 && activeIndex < addressList.length) {
        let {recipient, region, address, phone} = addressList[activeIndex]
        let {query: {activityKey, type}} = $router
        if (activityKey) {
          let location = {activityKey, type, recipient, region, address, phone}
          showLoading()
          service.saveExchangeAddress(location).then(res => {
            hideLoading()
            let {code} = res
            if (code == 200) {
              toast('确认邮寄地址成功')
              if (context) {
                context.viewData.userInfo.writeAddressFlag = 1
              }
              const params = {...$router.query}
              // 去掉多余的参数
              Reflect.deleteProperty(params, 'activityKey')
              Reflect.deleteProperty(params, 'type')
              navigateTo(`/home/${activityKey}`, {queryParams: params})
            }
          }).catch(() => {
            hideLoading()
          })
        } else {
          console.log('no activityKey included in $router', $router)
        }
      }
    } else {
      //添加用户地址
      handleEditAddr()
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../styles/variables';
  @import '../../../styles/mixins';
  .address {
    position: relative;
    min-height: 100vh;
    margin: 0 auto;
    box-sizing: border-box;
    border: 1px solid transparent;
    padding-bottom: 1.12rem;
    background: #F6F8FB;
    font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
    --header-height: 1rem;

    header {
      width: 100%;
      line-height: var(--header-height);
      height: var(--header-height);
      background: #FFFFFF;
      text-align: center;
      position: fixed;
      top: 0;
      z-index: 1;
      @media #{$media_query-notch} {
        top: constant(safe-area-inset-top); /* iOS 11.0 */
        top: env(safe-area-inset-top); /* iOS 11.2 */
      }
    }
    .plus-add {
      --plus-Wth: 0.73rem;
      width: var(--plus-Wth);
      height: var(--plus-Wth);
      padding: 0.1rem;
      margin-left: calc(100% - var(--plus-Wth) - 0.1rem);
      background: center/100% no-repeat url('//cdn.hhdd.com/frontend/as/i/f201f214-b7ac-5692-a08e-27ccde030d7b.png');
      margin-top: var(--header-height);
      @media #{$media_query-notch} {
        margin-top: calc(var(--header-height) + constant(safe-area-inset-top));
        margin-top: calc(var(--header-height) + env(safe-area-inset-top));
      }
    }
    .container {
      padding-top: 0.2rem;
      .list {
        width: 6.86rem;
        height: auto;
        background: #FFFFFF;
        border-radius: 0.32rem;
        margin: 0 auto;
        padding: 0.32rem;
      }
      .list:not(:last-child) {
        margin-bottom: 0.2rem;
      }
      .content {
        display: flex;
        flex-direction: row;
        align-items: center;
        .check {
          width: 0.48rem;
          height: 0.48rem;
          background: center/100% no-repeat url('//cdn.hhdd.com/frontend/as/i/35a2c82b-f1bb-5c87-a821-1f1b378caae8.png');
        }
        .active {
          background: center/100% no-repeat url('//cdn.hhdd.com/frontend/as/i/dc7c2c49-5223-5c81-82ef-96ee345fdf6c.png')
        }
        .detail {
          margin-top: 0.08rem;
          margin-left: 0.2rem;
          width: 5.54rem;
          font-size: 0.28rem;
          font-weight: normal;
          color: #666666;
          line-height: 0.4rem;
          .title {
            font-size: 0.32rem;
            color: #3F3F3F;
            line-height: 0.36rem;
            .phone {
              margin-left: 0.1rem;
            }
          }
        }
      }
      .button {
        margin-top: 0.28rem;
        display: flex;
        flex-direction: row;
        justify-content: flex-end;
        .delete, .edit {
          width: 1.28rem;
          height: 0.56rem;
          line-height: 0.56rem;
          border-radius: 0.3rem;
          border: 0.02rem solid #D7D7D7;
          font-size: 0.24rem;
          text-align: center;
        }
        .edit {
          color: #999999;
          margin-right: 0.24rem;
        }
      }
    }
    .tips {
      width: 6.86rem;
      margin: 0 auto;
      .btn-add {
        margin-top: 0.32rem;
        display: inline-block;
        height: 0.56rem;
        line-height: 0.56rem;
        border-radius: 0.3rem;
        border: 0.02rem solid #FD3A94;
        font-size: 0.24rem;
        text-align: center;
        color: #FD3A94;
        padding: 0 0.4rem;
      }
      .tip {
        padding: 0.32rem 0;
        font-size: 0.26rem;
        color: #666666;
        a {
          color: #FD3A94;
        }
      }
    }
    .noaddress-tip {
      text-align: center;
      margin-top: 4rem;
    }
    .confirm {
      position: fixed;
      z-index: 1;
      height: 1.3rem;
      width: 100%;
      bottom: 0;
      background: #FFFFFF;
      .btn-confirm {
        width: 6.94rem;
        height: 0.84rem;
        line-height: 0.84rem;
        margin: 0.14rem auto;
        background: linear-gradient(180deg, #F94368 0%, #FF35A8 100%);
        border-radius: 0.42rem;
        font-size: 0.32rem;
        color: #FFFFFF;
        text-align: center;
      }
      .disabled {
        opacity: 0.2;
      }
    }
  }
</style>
