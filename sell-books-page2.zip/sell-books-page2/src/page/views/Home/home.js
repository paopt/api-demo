import Context from '@/shared/internal/context'
import { DAY_TIME } from '@kada/library/utils/datetime'
import { getActivityInfo, receiveGift, draw, drawDetail} from '../../service'
import { parsedActivityRawConfig } from '../../app'
import { setContext, getPageData } from '@/shared/internal'
import * as pageConfig from '../../config'
import{ initPageConfig, updatePageConfig } from '@/shared/scheme/page-config'
import { hasSupportOnlineService, hasNewTabbarApp } from '@/shared/utils/detecter'
import {deviceInfo} from '@kada/library/src/device'
import URLParser from "@/lib/urlParser"
import * as storage from '@/lib/storage'
import { wxAuthLogin } from '@/shared/internal/wechat'

const parsed = new URLParser(location.href)
export let userIdStr = parsed.query.u || parsed.query.userIdStr
console.log("页面参数：", userIdStr)

// 活动页面上下文
let context = null

/**
 * 将接口 getActvityInfo 和 getPackageInfo 接口数据合并
 *
 * @param {Number} activityKey 活动ID
 * @return {Promise<Object>}
 */
const getDataService = async (activityKey) => {
  try {
    // const responseInfo = await getActivityInfo(activityKey, userIdStr).then((res) => (res || {}))
    // 测试数据 活动数据
    const responseInfo = {"msg":"成功","data":{"activityInfo":{"id":93,"activityName":"新人体验活动测试","crc32Name":28334079,"payInfoId":0,"packageType":6,"startTime":1699891200000,"endTime":1731599999000,"operator":"huangzhiwen","status":1,"modifyTime":1699946033000,"createTime":1699943581000,"buyAudioUrl":"","upGradeAudioUrl":"","svipAudioUrl":"","orderAudioUrl":"https://image.hhdd.com/activity/offline/cover/52a0db7178f54ed984b289c4e2e838c8.mp3","identityFlag":3,"activityPart":[{"id":3671,"crc32Name":28334079,"type":17,"sort":1,"typeSort":1701,"status":1,"classificationId":1,"subSort":1,"modifyTime":1699946032000,"createTime":1699943582000,"content":"{\"content\":[{\"coverUrl\":\"https://image.hhdd.com/books/cover/bc0698f5-9d49-4a3d-ad49-0680c5b2fffb.jpg\",\"introduction\":\"\",\"recommend\":\"\",\"showName\":\"绘本单本\",\"sourceId\":62264,\"sourceName\":\"2.空中擒敌\",\"sourceType\":1,\"title\":\"2.空中擒敌\"},{\"coverUrl\":\"https://story.hhdd.com/story/cover/26439/59d26f7a-5756-4490-a95f-5a7232330291.jpg\",\"introduction\":\"https://cdn.hhdd.com/collectIntroduction-body-empty.html\",\"recommend\":\"风靡小学的校园故事\",\"showName\":\"听书合辑\",\"sourceId\":26439,\"sourceName\":\"米小圈上学记全集\",\"sourceType\":4,\"title\":\"米小圈上学记全集\"},{\"coverUrl\":\"https://story.hhdd.com/story/cover/20314/b4af5966-f53a-41e5-8599-7a52963de274.jpg\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/test/collectIntroduction20314_79c10573-5f32-4e14-a942-3f6da3b1bbc6.html\",\"recommend\":\"孩子在成长过程中如何与人沟通？\",\"showName\":\"听书合辑\",\"sourceId\":20314,\"sourceName\":\"小马宝莉连载\",\"sourceType\":4,\"title\":\"小马宝莉连载\"},{\"coverUrl\":\"https://story.hhdd.com/story/cover/21039/6f588889-a938-49f0-98d0-10b18bd71960.jpg\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/test/collectIntroduction21039_5d5cb452-6f13-4d41-b5cc-17c7d67ea3a6.html\",\"recommend\":\"多妈钢琴曲，小艺术家的第一课！\",\"showName\":\"听书合辑\",\"sourceId\":21039,\"sourceName\":\"多妈钢琴曲\",\"sourceType\":4,\"title\":\"多妈钢琴曲\"},{\"coverUrl\":\"https://story.hhdd.com/story/cover/23141/17ad8318-d8d7-4763-a0fc-c944c245c8b0.jpg\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction-md/test/md_collectIntroduction23141_457b5cd2-e38b-409d-b43d-5fd8b62c44d3.html\",\"recommend\":\"小小牛顿幼儿馆，知识造就小天才\",\"showName\":\"听书合辑\",\"sourceId\":23141,\"sourceName\":\"小小牛顿幼儿馆\",\"sourceType\":4,\"title\":\"小小牛顿幼儿馆\"},{\"coverUrl\":\"https://story.hhdd.com/story/cover/31725/daf6caf8-9301-4076-8009-c7731506e54c.jpg\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/test/collectIntroduction31725_8d7bc509-ccf9-43d3-8d4e-3762ff29f688.html\",\"recommend\":\"为孩子专门定制的睡前童话\",\"showName\":\"听书合辑\",\"sourceId\":31725,\"sourceName\":\"百篇原创童话广播剧\",\"sourceType\":4,\"title\":\"百篇原创童话广播剧\"}],\"id\":3671,\"subTitle\":\"二年级推荐内容\",\"title\":\"二年级\"}"},{"id":3672,"crc32Name":28334079,"type":18,"sort":2,"typeSort":1802,"status":1,"classificationId":1,"subSort":1,"modifyTime":1699946032000,"createTime":1699943582000,"content":"{\"content\":[{\"coverUrl\":\"https://image.hhdd.com/offline/course/cover/e339b993-295b-4094-9896-7e18323cf269.png\",\"introduction\":\"\",\"recommend\":\"一部打开就会爱上的“动画百科全书”\",\"showName\":\"课程\",\"sourceId\":92092,\"sourceName\":\"摩登大自然\",\"sourceType\":8,\"title\":\"摩登大自然\"},{\"coverUrl\":\"https://image.hhdd.com/offline/course/cover/53bfa716-c122-40b7-a974-dfcb459af61c.png\",\"introduction\":\"\",\"recommend\":\"好课推荐\",\"showName\":\"课程\",\"sourceId\":90503,\"sourceName\":\"限免课程-20210202\",\"sourceType\":8,\"title\":\"限免课程-20210202\"},{\"coverUrl\":\"https://image.hhdd.com/offline/course/cover/49f8709f-07a8-4021-bfa4-7aa679d78a35.png\",\"introduction\":\"\",\"recommend\":\"这是课程推荐语\",\"showName\":\"课程\",\"sourceId\":92043,\"sourceName\":\" svip纯视频课程\",\"sourceType\":8,\"title\":\" svip纯视频课程\"},{\"coverUrl\":\"https://image.hhdd.com/ebook/offline/cover/ff8e7be12fa648c5b234f8df5f5f99f1.jpg\",\"introduction\":\"张小开是个电脑天才，但在体育方面，却不擅长，上学期五项达标测验竟然有四项不及格。张小开不得不把许多上网的时间花在了体育锻炼上。现在虽然是三伏天的下午，但他依然挥汗如雨地在操场上练着长跑。\",\"recommend\":\"\",\"showName\":\"电子书\",\"sourceId\":10044,\"sourceName\":\"变身少年\",\"sourceType\":15,\"title\":\"变身少年\"},{\"coverUrl\":\"https://image.hhdd.com/ebook/offline/cover/5661f61b5e864a7bb2311682fed22fdc.png\",\"introduction\":\"\",\"recommend\":\"\",\"showName\":\"电子书\",\"sourceId\":10368,\"sourceName\":\"svip云梦泽的怪兽（鬼谷学校 升级版9）\",\"sourceType\":15,\"title\":\"svip云梦泽的怪兽（鬼谷学校 升级版9）\"},{\"coverUrl\":\"https://image.hhdd.com/books/cover/d458b9b3-41a9-41bb-9e34-3aaff4d7cfc2.jpg\",\"introduction\":\"漫画，是一种艺术形式，是用简单而夸张的手法来描绘生活或时事的图画。\\n一般运用变形、比喻、象征、暗示、影射的方法。构成幽默诙谐的画面或画面组，以取得讽刺或歌颂的效果。\\n漫画作为绘画作品经历了一个发展过程，从最初作为少数人的兴趣爱好，已成为人们的普遍读物，更是深受学生喜爱，有不少人成为了漫画控。近年来的漫画主导作品一般为日本漫画和美国漫画。\\n漫画，是一种艺术形式，是用简单而夸张的手法来描绘生活或时事的图画。\\nqweqwe!@#$%^&*()\\ndfsdfsdfsfsd\",\"recommend\":\"321\",\"showName\":\"漫画\",\"sourceId\":10006,\"sourceName\":\"神奇校车\",\"sourceType\":14,\"title\":\"神奇校车\"},{\"coverUrl\":\"https://image.hhdd.com/offline/comic/cover/1625a72b80ab4f8e82c5e88ea954d0d1.jpeg\",\"introduction\":\"漫画，是一种艺术形式，是用简单而夸张的手法来描绘生活或时事的图画。一般运用变形、比喻、象征、暗示、影射的方法。构成幽默诙谐的画面或画面组，以取得讽刺或歌颂的效果。漫画作为绘画作品经历了一个发展过程，从最初作为少数人的兴趣爱好，已成为人们的普遍读物，更是深受学生喜爱，有不少人成为了漫画控。近年来的漫画主导作品一般为日本漫画和美国漫画。\\n阿撒飒飒\\nsasasas1\",\"recommend\":\"测试推荐语\",\"showName\":\"漫画\",\"sourceId\":10070,\"sourceName\":\"svip条漫切割测试\",\"sourceType\":14,\"title\":\"svip条漫切割测试\"},{\"coverUrl\":\"https://image.hhdd.com/online/comic/cover/fa465169a8cb4f978fa5fa36d2240c50.jpg\",\"introduction\":\"什么？建国以后妖怪不能成精？那以前的妖怪怎么办……好吧还是乖乖适应现代社会和人类和平共处为上。哈？一群妖怪和和平日常？拜托我们非人类怎么可能有正常的日常……那就用条漫来说说我们的日常生活好了，嗯，脑洞好像大了一些不过我想各位不会介意的，早到上古妖怪，下到两百年而已的九尾狐，看看我们是怎么在现代社会生活的吧。\\n《非人哉》是一本四格漫画，以漫画的形式，展开对中国古代传统神话故事中那些神话人物的日常生活想象。是一本国产吐槽漫画，作者对古代妖怪脑洞大开的解读。讲述了建国以后与时俱进的欢脱妖怪们日常生活的故事。\",\"recommend\":\"国产吐槽漫画\",\"showName\":\"漫画\",\"sourceId\":10077,\"sourceName\":\"条漫竖屏-非人哉vip漫画\",\"sourceType\":14,\"title\":\"条漫竖屏-非人哉vip漫画\"}],\"id\":3672,\"subTitle\":\"新人推荐\",\"title\":\"新人\"}"},{"id":3673,"crc32Name":28334079,"type":19,"sort":3,"typeSort":1903,"status":1,"classificationId":1,"subSort":1,"modifyTime":1699946032000,"createTime":1699943582000,"content":"{\"totalWeek\":4,\"stage\":\"365天年度阅读计划\",\"weekTitle\":\"战胜怕黑培养勇气\",\"planId\":1000001,\"openCount\":1297,\"coverUrls\":[\"https://image.hhdd.com/books/cover/5c52d630-25c2-4993-a420-4caf3fb3ccbb.jpg\",\"https://image.hhdd.com/books/cover/aaa2484e-7fff-43c9-a5c7-f7052853b222.jpg\",\"https://image.hhdd.com/books/cover/c1c74576-17d2-44a1-aaa0-ae76a1b01c10.jpg\"],\"planTitle\":\"阅读写作训练营\"}"}],"currentTime":1699953904489,"jumpType":0,"jumpData":"","shareJumpUrl":"","shareImgUrl":"https://image.hhdd.com/activity/offline/cover/d04aeb737661473c8ad73950e1771eaa.png","shareTitle":"","shareSubTitle":"","joinJumpUrl":"","phoneShareImg":"","hdShareImg":"","awardType":1,"award":"","shareFlag":0,"countdown":1,"loginType":1,"classificationFlag":0,"welfareEndTime":1701326761000},"userInfo":{"headUrl":"http://image.hhdd.com/user/systemHead/0/2/0/geometry6.png","nick":null,"ageType":5,"isVip":0,"isSvip":0,"vipDays":0,"svipDays":0,"isVisitor":0,"isJoin":0,"turntableNumber":1,"drawFlag":0,"awardType":0,"awardUrl":"","awardName":"","userId":60067024,"isLifeVip":0,"isLifeSvip":0,"isReceived":0,"isGiveVip":0,"isOverUser":0,"overUserInfo":null,"wyExchangeCode":null,"thirdCodeInfos":null,"writeAddressFlag":0,"giftPart":null}},"code":200}
    // 异常情况，默认都显示未参数错误 44400
    let { code = 44400, msg = '', data } = responseInfo

    if (data) {
      let { userInfo, activityInfo } = data

      // mock
      // activityInfo.countdown = 2
      if (!userInfo) {
        data.userInfo = userInfo = {}
      }

      if (!activityInfo) {
        data.activityInfo = activityInfo = {}
      }

      const { endTime, startTime, currentTime } = activityInfo

      // 根据服务端返回数据生成计算状态
      if (currentTime < startTime) { // 活动未开始
        code = 5406
      } else if (currentTime >= endTime) { // 活动已经结束
        code = 5405
      }
      // 自然日24小时倒计时剩余时间计算
      // const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
      // const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
      let timerDeadline = endTime - currentTime
      if (isNaN(timerDeadline)) {
        timerDeadline = 0
      }

      // 计算活动结束时间，单位天
      const endRemainTime = Math.floor((endTime - currentTime) / 1000) * 1000
      const expireDays = isNaN(endRemainTime) ? 0 : Math.max(0, Math.ceil(endRemainTime / DAY_TIME))

      let computedStatus = 5

      const {
        isLifeSvip,
        isLifeVip,
        vipDays,
        isVip,
        isSvip,
        isVisitor,
        isJoin,
        isOverUser
      } = userInfo

      if (isVisitor) {
        computedStatus = 0
      }
      if ((isVip && vipDays >= 30)) {
        computedStatus = 1
      }
      if (isLifeVip) {
        computedStatus = 2
      }
      if (isSvip || isLifeSvip) {
        computedStatus = 3
      }

      if (isJoin) {
        computedStatus = 4
      }

      if (isOverUser === 0
        && Array.isArray(activityInfo.activityPart)
        && activityInfo.activityPart.some(p => p.type == 9)) {
        computedStatus = 7             //未参加续费活动，不是过期30天以内用户，且不是临期30天以内用户
      }

      activityInfo.expireDays = expireDays // 活动剩余天数
      activityInfo.expire = endRemainTime // 活动剩余毫秒数
      userInfo.computedStatus = computedStatus // 计算状态
      userInfo.timerDeadline = timerDeadline // 自然日剩余时长
      activityInfo.isSvip = isSvip
    }


    return {
      code,
      msg,
      data
    }
  } catch (error) {
    console.error('dataService Error: ', error)
  }

  return null
}



/**
 * 获取初始活动相关数据
 * @param {Object} options 相关配置
 * @param {String} options.activityKey 活动ID
 * @param {String} options.channelId 渠道ID
 */
export async function onInitPageData ({ activityKey, channelId } = {}) {
  const [isSupportOnlineService, isNewTabbarApp] = await Promise.all([hasSupportOnlineService(), hasNewTabbarApp()])

  context = new Context({
    activityKey,
    channelId,
    dataService: getDataService,
    parseViewData: (pageStatus, reponseBody) => {
      if (!reponseBody || reponseBody.code !== 200 || !reponseBody.data) {
        return null
      }

      const { activityInfo, userInfo } = reponseBody.data
      if (!activityInfo) {
        return null
      }

      if (!userInfo) {
        return null
      }
      // 解析活动原始配置
      parsedActivityRawConfig(activityInfo, userInfo)
      // 更新页面配置
      updatePageConfig(pageConfig, context)
      let {shareTitle, shareSubTitle, shareImgUrl, shareJumpUrl, crc32Name, identityFlag} = activityInfo
      console.log('timerDeadline', userInfo.timerDeadline)
      return {
        activityKey, //活动编号
        expireDays: activityInfo.expireDays, // 距活动结束还有几天
        timerDeadline: userInfo.timerDeadline, // 自然日倒计时剩余时长
        // packageId: activityInfo.payInfoId || 0, // 默认购买礼包
        packageId: activityInfo.identityFlag === 0 ? activityInfo.jumpData : activityInfo.payInfoId,
        packageType: activityInfo.packageType || 6, // 支付类型
        identityFlag: activityInfo.identityFlag || 0, // 是否区分用户（用于用户跳转逻辑）
        jumpType: activityInfo.jumpType || 0, // 用户跳转类型
        jumpExtraData: activityInfo.jumpData || '', // 用户跳转额外信息 档位id，kada协议，小程序链接
        isSupportOnlineService, // 是否支持在线客服
        isNewTabbarApp, // 是否为新版界面App
        joinJumpUrl: activityInfo.joinJumpUrl, //已参加活动跳转
        shareData: {
          shareTitle,
          shareSubTitle,
          shareImgUrl,
          shareJumpUrl,
          crc32Name,
          identityFlag,
          canUseShare:  activityInfo.shareFlag === 1 // shareFlag: 1 可以分享，0不可以。
        },
        userInfo: userInfo,
        countdown: activityInfo.countdown, // 倒计时：1、最后三天倒计时；2、每天倒计时
        isSvip: activityInfo.isSvip,
        loginType: activityInfo.loginType, // 登录类型：1手机号登录，2微信登录
        welfareEndTime: activityInfo.welfareEndTime - activityInfo.currentTime, // 新人体验倒计时
        currentTime: activityInfo.currentTime,
      }
    }
  })

  // 初始化页面配置
  initPageConfig(pageConfig, context)
  // 设置礼包购买逻辑上下文
  setContext(context)

  //调用ajax获取页面配置信息
  await getPageData(false)
  if (deviceInfo.wechat) {
    if (context?.viewData?.loginType === 2) {
      await wxAuthLogin()
    } else {
      const openId = storage.get('openId')
      if (!openId) {
        await wxAuthLogin()
        return
      }
    }
  }

  return {
    context,
    pageConfig
  }
}


// 去领取书单
export async function gotoReceiveGift() {
  try {
    const responseInfo = await receiveGift()
    const { code } = responseInfo
    if (code !== 200) {
      throw new Error(responseInfo)
    }
    return true
  } catch (error) {
    console.error('receiveGift Error: ', error)
    return false
  }
}

/**
 * 去抽哦讲
 * @param {*} activityKey 活动编号
 */
export async function goDraw(activityKey) {
  return await draw(activityKey)
}

/**
 * 查看抽中奖品
 * @param {*} activityKey 活动编号
 * @returns
 */
export async function checkDrawDetail(activityKey) {
  return await drawDetail(activityKey)
}

/**
 * 去掉url中的newUser
 */
export function removeUrlParam(param) {
  const newUrl = location.href.replace(/(\?|&)*(newUser)=([^&=?#]+)/ig, '')
  if (history.replaceState) {
    history.replaceState(param, document.title, newUrl)
  } else {
    location.replace(newUrl)
  }
}
