require('svelte/register')

const App = require('./skeleton.svelte').default

const { html, css, head } = App.render()

module.exports = {
  html,
  css: css.code,
  head
}
