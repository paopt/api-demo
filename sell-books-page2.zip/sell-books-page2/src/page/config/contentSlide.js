export function getContentSlideConfig(config) {
  return config
}