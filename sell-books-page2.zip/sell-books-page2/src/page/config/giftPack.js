export function getGiftPackConfig (configs) {
  if (!configs) {
    return
  }
  const { image, list, dataSource } = configs
  return {
    image,
    list,
    dataSource
  }
}
