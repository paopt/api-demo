import { mapSwitch } from '@/shared/utils/config-helper'
import { PAGE_STATUS } from './status'
import {compressImage} from '@/utils/image'
import { DAY_TIME } from '@kada/library/utils/datetime'

export function getMemberBannerConfig (config, options) {
  if (!config) return
  
  const {
    buyHeadUrl,
    buyButtonUrl,
    buyAfterButtonUrl,
    bubbleButtonUrl,
    priceFontsColor,
    payInfoId,
    originPrice,
    realPrice
  } = config

  const context = options.context || {}
  const viewData = context?.viewData || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN

  const userInfo = viewData?.userInfo || {}
  const {isJoin} = userInfo

  // 更新全局packageId
  context.packageId = payInfoId
  viewData.packageId = payInfoId

  const button = mapSwitch([
    [
      [PAGE_STATUS.NORMAL, PAGE_STATUS.NOT_LOGIN].includes(pageStatus) || isJoin == 0,
      {
        action: 'buyPackage',
        imgUrl: compressImage(buyButtonUrl),
        className: 'ani-breath',
      }
    ],
    [
      [PAGE_STATUS.BOUGHT_PACKAGE].includes(pageStatus),
      {
        action: 'bought',
        imgUrl: compressImage(buyAfterButtonUrl),
        className: '',
      }
    ]
  ])

  const op = Math.floor(originPrice / 100)
  const rp = Math.floor(realPrice / 100)
  const dc = Math.floor(op - rp)

  // 倒计时处理
  const { countdown, currentTime, timerDeadline } = viewData
  let timer = {
    label: '活动仅剩',
    format: 'D天HH小时MM分SS秒',
    timerDeadline: timerDeadline,
    show: false
  }
  const SHOW_COUNTDOWN_DAY_TIME = 3 * DAY_TIME
  // 最后三天且未购买显示倒计时
  if (timerDeadline >= 0 && timerDeadline <= SHOW_COUNTDOWN_DAY_TIME && button.action === 'buyPackage') {
    timer.show = true
  }
  // 每天倒计时
  if (countdown === 2 && button.action === 'buyPackage') {
    const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
    const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
    const deadline = todayLastTime - nowDate.getTime()
    timer = {
      label: '仅剩',
      format: 'HH小时MM分SS秒',
      timerDeadline: deadline,
      show: true
    }
  }

  return {
    buyHeadUrl: buyHeadUrl,
    bubbleButtonUrl: bubbleButtonUrl,
    showBubble: button?.action === 'buyPackage' && bubbleButtonUrl, // 未购买用户且配置了气泡，才显示气泡
    showPrice: button?.action === 'buyPackage',
    button,
    style: `color: ${priceFontsColor}`,
    payInfoId,
    originPrice: op,
    realPrice: rp,
    discount: dc,
    timer,
  }
}