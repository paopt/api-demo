//获取分享海报配置
export function getSharePosterConfig(config, options) {
  if (!config) {
    return
  }
  const context = options.context || {}
  let {shareJumpUrl} = config
  let {userId = '' } = context?.responseBody?.data?.userInfo || {}
  let {identityFlag = 0} = context?.responseBody?.data?.activityInfo || {}
  let {activityKey} = context
  let sharUrl = shareJumpUrl ? shareJumpUrl : window.location.href
  if (identityFlag == 2
    && userId
    && activityKey
    && !['inviteUserId=', 'inviteActivityKey='].some(s => config.shareJumpUrl.includes(s))) {
      config.shareJumpUrl = `${sharUrl}?inviteUserId=${userId}&inviteActivityKey=${activityKey}`
  } else {
    config.shareJumpUrl = sharUrl
  }
  return config
}
