export function getNewReadPlanConfig(config) {
  return config
}