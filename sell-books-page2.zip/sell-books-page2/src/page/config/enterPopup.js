
//进入页面弹框
export function getEnterPopupConfig(config) {
  if (!config) {
    return
  }
  return config
}
