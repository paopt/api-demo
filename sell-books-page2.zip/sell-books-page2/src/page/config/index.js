import { parsedActivityConfig } from '../app'
import { getMarqueeConfig } from './marquee'
import { getBannerConfig } from './banner'
import { getSectionsConfig } from './sections'
import { getFooterBarConfig } from './footerBar'
import { getGiftPackConfig } from './giftPack'
import { getStatePanelConfig, getStatePanelCountdownConfig } from './statePanel'
import { getDrawConfig } from './drawPannel'
import { PAGE_STATUS } from './status'
import { mapSwitch } from '@/shared/utils/config-helper'
import { getSharePosterConfig } from './sharePoster'
import { getEnterPopupConfig } from './enterPopup'
import { getRenewBannerConfig } from './renewBanner'
import { getLotteryConfig } from './lottery'
import { getMemberBannerConfig } from './memberBanner'

/**
 * 服务端返回状态转页面状态
 *
 * @param {ConfigOptions} options
 *
 * @returns {{
 *  boughtStatus: Array<String>,
 *  openedStatus: Arrray<String>,
 *  responseToPageStatus: {
 *    code: Object,
 *    status: Object
 *  }
 * }}
 */
export function useStatus (options = {}) {
  const context = options.context || {}
  const viewData = context?.viewData || {}
  const { identityFlag } = viewData

  return {
    boughtStatus: [ // 已购买礼包的状态
      PAGE_STATUS.BOUGHT_PACKAGE,
    ],
    openedStatus: [],
    responseToPageStatus: { // 服务端返回结果映射成页面状态
      code: {
        4403: PAGE_STATUS.NOT_LOGIN,
        5406: PAGE_STATUS.ACTIVITY_NOT_START,
        5405: PAGE_STATUS.ACTIVITY_ENDED,
        5404: PAGE_STATUS.ACTIVITY_NOT_FOUND,
        5401: PAGE_STATUS.USER_NOT_FOUND,
        5410: PAGE_STATUS.OPENED,
        9001: PAGE_STATUS.BOUGHT_PACKAGE,
        8014: PAGE_STATUS.NOT_TIYAN
      },
      status: {
        1: PAGE_STATUS.NOT_LOGIN,
        2: PAGE_STATUS.NORMAL,
        3: PAGE_STATUS.OPENED_LIFEVIP,
        4: PAGE_STATUS.BOUGHT_PACKAGE,
      },
      computedStatus: {
        0: PAGE_STATUS.NOT_LOGIN,
        1: PAGE_STATUS.YEARVIP,
        2: PAGE_STATUS.OPENED_LIFEVIP,
        3: PAGE_STATUS.SUBVIP,
        4: PAGE_STATUS.BOUGHT_PACKAGE,
        5: PAGE_STATUS.NORMAL,
        6: PAGE_STATUS.DRAWED,         //已参加活动，已抽奖
        7: PAGE_STATUS.ISOVER_USER
      }
    },
    pageStatus: PAGE_STATUS,
    canbuy: { // 页面状态下是否可以购买礼包
      [PAGE_STATUS.NETWORK_ERROR]: false,
      [PAGE_STATUS.ACTIVITY_NOT_START]: false,
      [PAGE_STATUS.ACTIVITY_ENDED]: false,
      [PAGE_STATUS.ACTIVITY_NOT_FOUND]: false,
      [PAGE_STATUS.USER_NOT_FOUND]: false,
      [PAGE_STATUS.NOT_LOGIN]: true,
      [PAGE_STATUS.TIME_ENDED]: false,
      [PAGE_STATUS.NORMAL]: true,
      [PAGE_STATUS.OPENED]: false,
      [PAGE_STATUS.YEARVIP]: true,
      [PAGE_STATUS.OPENED_LIFEVIP]: !identityFlag,
      [PAGE_STATUS.BOUGHT_PACKAGE]: false,
      [PAGE_STATUS.SUBVIP]: !identityFlag,
      [PAGE_STATUS.ISOVER_USER]: false
    }
  }
}

/**
 * 页面状态对应的音频
 *
 * @param {ConfigOptions} options
 *
 * @returns {{
 *  welcome: String,
 *  bought: String,
 *  momLogin: String
 * }}
 */
export function useAudio (options = {}) {
  const context = options.context || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN
  if (!parsedActivityConfig?.audio) {
    return
  }
  return {
    welcome: mapSwitch([
      [
        [PAGE_STATUS.NOT_LOGIN, PAGE_STATUS.NORMAL].includes(pageStatus),
        parsedActivityConfig.audio['canbuy']?.audio.url
      ],
      [
        [PAGE_STATUS.SUBVIP].includes(pageStatus),
        parsedActivityConfig.audio['svip']?.audio.url
      ],
      [
        [PAGE_STATUS.YEARVIP, PAGE_STATUS.OPENED_LIFEVIP].includes(pageStatus),
        parsedActivityConfig.audio['upgrade']?.audio.url
      ]
    ], '')
  }
}
/**
 * 页面状态对应的对话框配置
 *
 * @param {ConfigOptions} options
 *
 * @returns {Object}
 */
 export function useDialog (options = {}) {
  const deviceInfo = options.deviceInfo || {}
  const isAppOrWechat = deviceInfo.isKadaClient || deviceInfo.wechat
  return {
    // 活动规则弹窗内容
    rulesDialog: null,

    // 微信中购买成功对话框
    successDialog: null,
    // 当页面某个状态时，显示的弹窗配置信息
    whenStatus: {
      [PAGE_STATUS.ACTIVITY_NOT_START]: {
        type: 'error',
        title: '活动未开始',
        message: '快去APP首页参加其他精彩活动吧~',
        buttonText: '立即查看',
        showTimes: 'always',
      },
      [PAGE_STATUS.ACTIVITY_ENDED]: {
        type: 'ended',
        title: '活动已结束',
        message: '快去APP首页参加其他精彩活动吧~',
        buttonText: '立即查看',
        showTimes: 'always',
      },
      [PAGE_STATUS.ACTIVITY_NOT_FOUND]: {
        type: 'error',
        title: '该活动未找到',
        message: '快去APP首页参加其他精彩活动吧~',
        buttonText: '立即查看',
        showTimes: 'always',
      },
      [PAGE_STATUS.TIME_ENDED]: {
        type: 'ended',
        title: '活动已结束',
        message: '快去APP首页参加其他精彩活动吧~',
        buttonText: '立即查看',
        showTimes: 'always',
      },
      [PAGE_STATUS.OPENED]: {
        type: 'error',
        title: '你已享有该活动权益',
        message: '无需参加本活动哦~',
        buttonText: '立即阅读',
        showTimes: 'always',
      },
      // [PAGE_STATUS.OPENED_LIFEVIP]: {
      //   type: 'lifevip',
      //   title: '你已经是终身会员啦！',
      //   message: '无需参加本活动哦~',
      //   buttonText: '立即阅读',
      //   showTimes: 'always',
      // },
      [PAGE_STATUS.ISOVER_USER]: {
        type: 'error',
        title: isAppOrWechat ? '无法参加本活动' : '',
        message: isAppOrWechat ? '快去APP首页参加其他精彩活动吧~' : '请在KaDa阅读APP内查看哦~',
        buttonText: isAppOrWechat ? '我知道啦' : '马上打开',
        showTimes: 'always',
      },
      [PAGE_STATUS.NOT_TIYAN]: {
        type: 'error',
        title: '无法参加新人体验活动',
        message: isAppOrWechat ? '快去APP首页参加其他精彩活动吧~' : '请在KaDa阅读APP内查看哦~',
        buttonText: isAppOrWechat ? '我知道啦' : '马上打开',
        showTimes: 'always',
      }
    },
  }
}

/**
 * APP内支持分享功能
 *
 * @param {context} options
 *
 * @returns {Object}
 */
 export function useShareConfig (option) {
  let shareConfig = {
    title: 'KaDa阅读',
    desc: '好故事都在这儿',
    imgUrl: 'https://cdn.hhdd.com/frontend/assets/img/icon-app-logo-square.png',
    link: location.href.replace(/(\?|&)*(code|state)=([^&=?#]+)/ig, ''),
    type: 'link',
    canUseShare: false
  }

  const context = option?.context
  const viewData = context?.viewData || {}
  if (viewData?.shareData) {
    let {shareData, userInfo, activityKey} = context?.viewData
    let {shareTitle, shareSubTitle, shareImgUrl, shareJumpUrl, identityFlag, canUseShare} = shareData
    let {userId} = userInfo

    if (shareTitle) shareConfig.title = shareTitle
    if (shareSubTitle) shareConfig.desc = shareSubTitle
    if (shareImgUrl) shareConfig.imgUrl = shareImgUrl

    //邀请类活动
    if (identityFlag == 2 && userId && activityKey) {
      shareConfig.link = `${shareJumpUrl || location.href}?inviteUserId=${userId}&inviteActivityKey=${activityKey}`
    } else {
      shareConfig.link = shareJumpUrl || location.href
    }

    shareConfig.canUseShare = canUseShare;
  }
  return shareConfig
}

/**
 * 页面基本配置信息
 *
 * @param {ConfigOptions} options
 *
 * @returns {{
 *  title: String,
 *  activity: Object,
 *  routes: Object
 * }}
 */
export function useMates () {
  return {
    title: ''
  }
}


/**
 * 页面打点信息
 *
 * @param {ConfigOptions} options
 *
 * @returns {Object}
 */
 export function useAnalytics () {
  return {
    pageView: 'ac_view',
    statusMainPanelButtonView: 'top_button_view',
    statusMainPanelButtonClick: 'top_button_click',
    footerBarButtonView: 'lower_button_view',
    footerBarButtonClick: 'lower_button_click',
    drawPanelButtonView: 'ac_prize_view',
    drawPanelButtonClick: 'ac_prize_click',
    pictureSectionView: 'ac_picture_view',
    pictureSectionClick: 'ac_picture_click',
    videoSectionView: 'ac_video_view',
    videoSectionClick: 'ac_video_click',
    giftView: 'gift_view',
    giftClick: 'gift_click',
    topButtonView: 'top_button_view',
    topButtonClick: 'top_button_click',
    dialog: {
      giftDialog: {
        view: 'ac_gift_pop_view',
        doneClick: 'ac_gifted_pop_view',
      },
      upgradeDialog: {
        view: 'ac_low_version_pop_view',
        doneClick: 'ac_low_version_pop_click',
      },
      bookListDialog: {
        view: 'ac_parents_pop_view',
        doneClick: 'ac_parents_pop_click'
      },
      rulesDialog: {
        view: 'ac_rule_pop_view',
      },
      downloadDialog: {
        view: 'ac_wx_download_pop_view',
        click: 'ac_wx_download_pop_click'
      },
      [PAGE_STATUS.OPENED_LIFEVIP]: {
        view: 'ac_purchased_pop_view',
        click: 'ac_purchased_pop_click'
      },
      [PAGE_STATUS.OPENED]: {
        view: 'ac_purchased_pop_view',
        doneClick: 'ac_purchased_pop_click'
      },
      [PAGE_STATUS.ACTIVITY_ENDED]: {
        view: 'ac_finish_pop_view',
        doneClick: 'ac_finish_pop_click',
      },
      setAgeDialog: {
        view: 'ac_age_pop_view',
        click: 'ac_age_pop_click'
      },
      guideDrawDialog: {
        view: 'ac_prizeguide_pop_view',
        click: 'ac_prizeguide_pop_click'
      },
      inviteListDialog: {
        view: 'ac_invite_record_pop_view',
        click: 'ac_invite_record_pop_click'
      },
      aliPayAccountDialog: {
        view: 'ac_pay_information_pop_view',
        doneClick: 'ac_pay_information_pop_click'
      }
    }
  }
}

/**
 * 界面框架相关配置
 *
 * @param {ConfigOptions} options
 * @returns {Object}
 */
 export function useFrameView () {

  return {
    // 全局样式列表
    styleSheet: '',
    // 页面背景样式
    // body: {
    //   style: deviceInfo.wechat ? `background: #fffdd3;` : `background: #fffdd3;`,
    // },
    body: null,
    // 导航栏相关配置
    navbar: {
      theme: 'gray',
      isHideShare: false,
      fullContainer: true,
      hideTitle: true
    }
  }
}

export function useBody (options = {}) {
  const context = options.context || {}
  const {
    banner,
    marquee,
    giftPack,
    sections,
    statePanelButton,
    statePanelCountdown,
    footerButton,
    drawPanel,
    sharePoster,
    enterPopup,
    renewBanner,
    lottery,
    memberBanner,
  } = parsedActivityConfig

  return {
    banner: getBannerConfig(banner, { context }),
    marquee: getMarqueeConfig(marquee),
    giftPack: getGiftPackConfig(giftPack),
    sections: getSectionsConfig(sections, { context }),
    statePanel: getStatePanelConfig(statePanelButton, { context }),
    statePanelTimer: getStatePanelCountdownConfig(statePanelCountdown, {context}),
    drawPannel: getDrawConfig(drawPanel, {context}),
    footerBar: getFooterBarConfig(footerButton, { context }),
    sharePoster: getSharePosterConfig(sharePoster, {context}),
    enterPopup: getEnterPopupConfig(enterPopup, { context }),
    renewBanner: getRenewBannerConfig(renewBanner, { context }),
    lottery: getLotteryConfig(lottery, { context }),
    memberBanner: getMemberBannerConfig(memberBanner, { context }),
  }
}
