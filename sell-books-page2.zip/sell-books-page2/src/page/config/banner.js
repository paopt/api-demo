import { mapSwitch } from '@/shared/utils/config-helper'
import { PAGE_STATUS } from './status'
import { DAY_TIME } from '@kada/library/utils/datetime'

export function getBannerConfig (config, options) {
  if (!config) {
    return
  }
  const {
    imgUrl,
    buyButtonUrl,
    boughtButtonUrl,
    upGradeButtonUrl,
    svipButtonUrl
  } = config
  const context = options.context || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN
  
  // 按钮处理
  const button = mapSwitch([
    [
      [PAGE_STATUS.NORMAL, PAGE_STATUS.NOT_LOGIN].includes(pageStatus),
      {
        action: 'buyPackage',
        params: {
          packageIdType: 'packageIdLifevip',
        },
        imgUrl: buyButtonUrl,
        className: 'ani-breath'
      },
    ],
    [
      [PAGE_STATUS.BOUGHT_PACKAGE].includes(pageStatus),
      {
        action: 'bought',
        imgUrl: boughtButtonUrl
      },
    ],
    [
      [PAGE_STATUS.YEARVIP, PAGE_STATUS.OPENED_LIFEVIP].includes(pageStatus),
      {
        action: 'toVipCharge',
        imgUrl: upGradeButtonUrl,
        className: 'ani-breath',
      },
    ],
    [
      [PAGE_STATUS.SUBVIP].includes(pageStatus),
      {
        action: 'toRead',
        imgUrl: svipButtonUrl,
        className: 'ani-breath'  //SVIP状态支持呼吸效果
      },
    ]
  ])

  // 倒计时处理
  const viewData = context?.viewData || {}
  const { countdown, currentTime, timerDeadline } = viewData

  let timer = {
    label: '活动仅剩',
    format: 'D天HH小时MM分SS秒',
    timerDeadline: timerDeadline,
    show: false
  }
  const SHOW_COUNTDOWN_DAY_TIME = 3 * DAY_TIME
  // 最后三天且未购买显示倒计时
  if (timerDeadline >= 0 && timerDeadline <= SHOW_COUNTDOWN_DAY_TIME && button.action === 'buyPackage') {
    timer.show = true
  }

  // 每天倒计时
  if (countdown === 2 && button.action === 'buyPackage') {
    const nowDate = new Date(Math.floor(currentTime / 1000) * 1000)
    const todayLastTime = (new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 24, 0, 0)).getTime()
    const deadline = todayLastTime - nowDate.getTime()
    timer = {
      label: '仅剩',
      format: 'HH小时MM分SS秒',
      timerDeadline: deadline,
      show: true
    }
  }

  return {
    imgUrl,
    button,
    timer
  }
}
