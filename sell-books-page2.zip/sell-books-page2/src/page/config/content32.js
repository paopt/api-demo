export function getContent32Config(config) {
  return config
}