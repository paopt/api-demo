import { mapSwitch } from '@/shared/utils/config-helper'
import { PAGE_STATUS } from './status'
import {getMarqueeConfig} from '@/page/config/marquee'


//获取抽奖样式及图片
export function getLotteryConfig(config, options) {
  // console.log('getDrawConfig-config', config)
  if (!config) {
    return
  }
  const context = options.context || {}
  const pageStatus = context?.pageStatus || PAGE_STATUS.UNKNOWN
  let { turntableNumber = 0, isJoin = 0} = context?.responseBody?.data?.userInfo || {}
  const { prizeData = {}} = config
  const winner = getMarqueeConfig({text: '已购买'}).dataSource.map(d => d.nickName)
  // console.log(`getDrawConfig-config`, winner)
  // drawFlag = 1
  // awardUrl = 'https://image.hhdd.com/activity/offline/cover/558d2d5c91274205aabedcde6d67e76d.png'
  let getRandomIntInclusive = (min, max) => {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min
  }
  let getWinnerList = () => {
    if (Array.isArray(prizeData) && prizeData.length > 0) {
      let winnerList = [],
        listCount = 50,
        prizeLength = prizeData.length

      while(winnerList.length < listCount) {
        for (let i = 0; i < prizeLength; i++) {
          for (let j = 0; j <= i; j++) {
            if (winnerList.length >= listCount) {
              break
            }
            let randomIndex = getRandomIntInclusive(0, winner.length - 1)
            if (prizeData[j].awardType) {
              winnerList.push({
                packageName: prizeData[j].awardName,
                nickName: winner[randomIndex],
                prefix: '恭喜',
              })
            }
           
          }
          if (winnerList.length >= listCount) {
            break
          }
        }
      }
      return winnerList
    }
  }
  console.log('getWinnerList', config)
  return {
    isJoin,
    turntableNumber,
    ...config,
    className: '',
    // 按状态显示按钮
    button: mapSwitch([
      //已抽奖查看奖品
      [
        turntableNumber === 0 && isJoin === 1,
        {
          action: 'noChance',
        }
      ],
      //未抽奖
      [
        turntableNumber !== 0 && isJoin === 1,
        {
          action: 'toLottery',
        }
      ],
      //引导下单
      [
        [PAGE_STATUS.NORMAL, PAGE_STATUS.NOT_LOGIN].includes(pageStatus) || isJoin === 0,
        {
          action: 'toGuide',
          orderAudioUrl: context?.responseBody?.data?.activityInfo?.orderAudioUrl || '',
        }
      ]
    ]),
    // 中奖名单跑马灯数据
    winPrizeMarquee: {
      dataSource: getWinnerList() || []
    },
    // 奖品列表跑马灯
    prizeMarquee: {
      dataSource: (Array.isArray(prizeData) && prizeData.length > 0) ?
      prizeData.map(p => ({name: p.awardName, imageUrl: p.awardUrl})) : []
    }
  }
}
