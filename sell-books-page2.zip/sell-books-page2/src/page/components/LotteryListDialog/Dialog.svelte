<Popup class="c-history-dlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-history-dlg__body" on:touchmove|stopPropagation|preventDefault>
    <div class="c-history-dlg__title fzlty-zc">我的奖品</div>
    <div class="c-history-dlg__content fzlty-zc needsclick" bind:this={contentEl}>
      {#if lotteryList.length}
        <div>
          <p><span>奖品名称</span><span>抽奖时间</span></p>
          {#each lotteryList as item, index}
            <p><span>{item.awardName}</span><span>{formatDate(item.createTime, 'YYYY-MM-DD')}</span></p>
          {/each}
        </div>
      {:else}
        <div style="color: #3277EE;font-size: .44rem;">您还没有中奖哦</div>
      {/if}
      
    </div>
    <div class="close" on:click={close}></div>
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  import IScroll from 'iscroll/build/iscroll-lite'
  import { promiseDelay } from '@/utils/promisify'
  import { formatDate } from '@/utils/timer'
  // import { PRIZE_NAME } from '../../config/home'

  const dispatch = createEventDispatcher()
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 通用弹窗信息
   * @type {String} message
   */
  export let content = `<img src="//cdn.hhdd.com/frontend/as/i/b57c923a-b21f-569f-abc2-99ed8c98ca46.png" alt="" />`

  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = true

  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  /**
   * 点击确认按钮回调
   * @svelte-prop {Function} onDone
   */
  // export let onDone = null

  /**
   * 中奖地址
   * @type {string}
   */
  // export let address = ''

  /**
   * 是否抽中过实体奖品
   * @type {number} drawEntityPrizeId: 0 | 1 | 2
   */
  // export let drawEntityPrizeId = 0

  let popupEl
  let contentEl
  // 内容区域滚动示例
  let contentScroll
  let resolve

  let _content = ''

  $: if (content !== _content) {
    promiseDelay(600).then(() => {
      if (!contentScroll && contentEl) {
        contentScroll = new IScroll(contentEl, {
          scrollY: true,
          scrollX: false,
          bindToWrapper: true,
        })
      }

      if (contentScroll) {
        contentScroll.refresh()
      }
    })
  }

  export const promise = new Promise((fulfil) => (resolve = fulfil))
  
  export let lotteryList = [
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    },
    {
      name: 'kada币',
      time: '2021.01.29'
    }
  ]

  function close() {
    dispatch('close')
    popupEl && popupEl.close()

    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  onMount(() => {
    popupEl && popupEl.show()
  })
  onDestroy(() => {
    if (contentScroll) {
      contentScroll.destroy()
      contentScroll = null
    }
  })
</script>

<style lang="scss">
  $component-name: 'c-history-dlg';
  @import '../../../styles/variables';
  :global {
    .#{$component-name} {
      z-index: 999;
      &__body {
        position: relative;
        width: 5.7rem;
        margin: 0 auto;
        border-radius: 0.3rem;
        font-family: 'Yuanti SC', 'PingFang SC';
        z-index: 999;
        height: 6.8rem;
        background-color: white;
        padding: .48rem .4rem 0;
        // background: url(//cdn.hhdd.com/frontend/as/i/7587ded6-2c01-5d22-8fb7-84f1e7665e13.png) no-repeat 50% 0 / 100% 100%;
        z-index: 2;
        .close {
          position: absolute;
          width: 0.3rem;
          height: 0.3rem;
          bottom: -0.6rem;
          margin-right: -0.15rem;
          right: 50%;
          background: {
            repeat: no-repeat;
            position: 50% 50%;
            size: 100% auto;
            image: url('//cdn.hhdd.com/frontend/as/i/0179dab3-9bbe-59dd-8efb-4b2e78427639.png');
          }
          z-index: 99;
        }
      }

      &__title {
        font-size: .32rem;
        margin-bottom: .4rem;
      }

      &__content {
        position: relative;
        font-size: 0.28rem;
        margin: 0 auto;
        // width: 5.91rem;
        max-height: 5.2rem;
        overflow: hidden;
        border-radius: .12rem .12rem 0px 0px;
        div {
          height: max-content;
          p {
            line-height: .6rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: .01rem solid #BABABA;
            text-align: center;
            // padding: 0 0.3rem;
            span {
              flex: 1;
              border: .01rem solid #BABABA;
            }
            span:nth-child(1) {
              border-right: none;
            }
          }
          p:nth-child(1) {
            background-color: #3277EE;
            color: white;
            line-height: .8rem;
            border: none;
            span {
              border: none;
            }
          }
        }
      }

      &__address {
        bottom: 1.3rem;
        left: 1.5rem;
        position: absolute;
        z-index: 3;
        color: #DADADA;
        font-size: .24rem;
        text-shadow: 0px 3px 2px rgba(19, 89, 10, 0.6);
      }

      &__button {
        position: absolute;
        right: 2.01rem;
        bottom: 0.06rem;
        width: 3.26rem;
        height: 1.23rem;
        color: transparent;
        background: url(//cdn.hhdd.com/frontend/as/i/120db591-e4f5-5452-ac52-57627cb7d3c0.png) no-repeat center center / 100% 100%;
        transition: transform 0.25s;
        z-index: 3;

        &:active {
          transform: scale(0.98);
        }
      }
      // @media #{$pad_landscape_query} {
      //   &__title {
      //     font-size: .46rem;
      //   }

      //   &__body {
      //     width: 10.7rem;
      //     height: 9.8rem;
      //   }

      //   &__content {
      //     max-height: 7.2rem;
      //     div {
      //       p {
      //         line-height: .8rem;
      //         font-size: .36rem;
      //         // padding: 0 1rem;
      //       }
      //       p:nth-child(1) {
      //         line-height: 1rem;
      //       }
      //     }
          
      //   }

      //   // &__address {
      //   //   bottom: 2.36rem;
      //   //   left: 2rem;
      //   //   font-size: .33rem;
      //   // }

      //   // &__button {
      //   //   right: 2.94rem;
      //   //   bottom: 0.76rem;
      //   //   width: 4.49rem;
      //   //   height: 1.75rem;
      //   //   background-image: url(//cdn.hhdd.com/frontend/as/i/585782a2-9b2a-5c2c-ae75-00906208e6f2.png);
      //   // }
      // }
    }
  }
</style>
