<!-- 选择年龄弹框 -->
<Popup class="c-chooseagedlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-chooseagedlg__body" on:touchmove|stopPropagation|preventDefault>
    <div class="title">选择阅读阶段</div>
    <div class="container">
      <div class="sub-title">学龄前</div>
      <div class="content">
        {#each ageRange[0] as item, i}
          <div class="item"
            class:active={selectedAge[0] == 0 && selectedAge[1] == i}
            on:click={() => selectedAge = [0, i]}>{item.title}</div>
        {/each}
      </div>


      <div class="sub-title">小学</div>
      <div class="content">
        {#each ageRange[1] as item, i}
          <div class="item"
            class:active={selectedAge[0] == 1 && selectedAge[1] == i}
            on:click={() => selectedAge = [1, i]}>{item.title}</div>
        {/each}
      </div>


      <div class="sub-title">初中</div>
      <div class="content">
        {#each ageRange[2] as item, i}
          <div class="item"
          class:active={selectedAge[0] == 2 && selectedAge[1] == i}
          on:click={() => selectedAge = [2, i]}>{item.title}</div>
        {/each}
      </div>
    </div>
    <div class="btn-confirm" on:click={handleConfirmClick}>确定</div>
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup, toast } from '@kada/svelte-activity-ui'
  import { getAnalyticsIdByName } from '@/shared/scheme/page-config'
  import { sendBehavior } from "@/shared/internal"
  const dispatch = createEventDispatcher()
  //组件样式
  let className = ''
  export { className as class }

  //是否支持点击mask关闭弹窗
  export let maskClickHide = false

  //点击关闭按钮回调
  export let onClose = null

  //点击确定回调函数
  export let onDone = null

  let popupEl

  let ageRange = [
    //学龄前
    [
      {title: '1岁', value: 1},
      {title: '2岁', value: 2},
      {title: '3岁', value: 3},
      {title: '小班', value: 4},
      {title: '中班', value: 5},
      {title: '大班', value: 6},
    ],
    //小学
    [
      {title: '一年级', value: 7},
      {title: '二年级', value: 8},
      {title: '三年级', value: 9},
      {title: '四年级', value: 10},
      {title: '五年级', value: 11},
      {title: '六年级', value: 12},
    ],
    //初中
    [
      {title: '初一', value: 13},
      {title: '初二', value: 14},
      {title: '初三以上', value: 15},
    ]
  ]

  let selectedAge = [-1, -1]

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  //打点信息
  let setAgeDialog = getAnalyticsIdByName('dialog.setAgeDialog')

  function close() {
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  function handleConfirmClick() {
    if (selectedAge[0] == -1 || selectedAge[1] == -1 || !ageRange[selectedAge[0]][selectedAge[1]]) {
      return toast('请选择年龄')
    }
    if (typeof onDone === 'function') {
      onDone(ageRange[selectedAge[0]][selectedAge[1]])
      sendBehavior(setAgeDialog.click)
    }
    close()
  }

  onMount(() => {
    popupEl && popupEl.show()
    sendBehavior(setAgeDialog.view)
  })

  onDestroy(() => {

  })
</script>

<style lang="scss">
  $component-name: 'c-chooseagedlg';

  :global {
    .#{$component-name} {
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      z-index: 999;
      &__body {
        position: absolute;
        width: 100%;
        height: 11rem;
        background-color: #FFFFFF;
        bottom: 0;
        border-top-left-radius: 0.3rem;
        border-top-right-radius: 0.3rem;
        padding: 0.38rem 0.46rem;
        .title {
          font-size: 0.44rem;
          font-weight: normal;
          color: #3F3F3F;
        }
        .container {
          .sub-title {
            font-size: 0.28rem;
            height: 0.28rem;
            line-height: 0.28rem;
            font-weight: normal;
            color: #999999;
            border-left: 0.08rem solid #22C5FF;
            padding-left: 0.12rem;
            margin: 0.35rem auto 0.35rem 0;
          }
          .content {
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            justify-content: space-around;
            .item {
              width: 1.96rem;
              height: 0.8rem;
              line-height: 0.8rem;
              text-align: center;
              background: #F6F7F9;
              border-radius: 0.4rem;
              margin-bottom: 0.3rem;
              color: #3F3F3F;
              font-size: 0.32rem;
            }
            .active {
              background-color: #24B3FF;
              color: #FFFFFF;
            }
          }
        }
        .btn-confirm {
          margin: 0.1rem auto;
          text-align: center;
          width: 6.38rem;
          height: 1rem;
          line-height: 1rem;
          background: #3277EE;
          border-radius: 0.5rem;
          font-size: 0.4rem;
          font-weight: 500;
          color: #FFFFFF;
        }
      }
    }
  }
</style>
