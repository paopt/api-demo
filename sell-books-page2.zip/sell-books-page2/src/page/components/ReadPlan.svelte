<div class="c-read-plan">
  {#each config.content as book}
  <div class="book" style={`background-image:url(${book.bottomUrl})`}>
    <div class="book__index">{book.serialDescribe}</div>
    <div class="book__title">{book.title}</div>
    <div class="book__description">{book.introduction}</div>
    <div class="book__cover">
      <img src={book.coverUrl} alt="">
    </div>
  </div>
  {/each}
  <!-- <div class="btn">查看完整学习安排</div> -->
</div>

<script>
  export let config = null

  $: if (config) {
    console.log('阅读计划组件', config)
  }

</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-read-plan {
    padding: 0 0.7rem;

    .book:nth-child(2n) {
      margin-left: 0.3rem;
    }
  }

  .book {
    position: relative;
    display: inline-block;
    width: 2.89rem;
    height: 4.56rem;
    margin-bottom: 0.4rem;
    padding: 0 0.18rem 0 0.3rem;
    background-image: url(//cdn.hhdd.com/frontend/as/i/81bf486a-860e-5674-996b-6af2a4bd341e.png);
    background-size: 100%;
    overflow: hidden;
    border-radius: 0.3rem;

    &__index {
      position: absolute;
      top: 0;
      left: 0;
      width: 1.58rem;
      height: 0.66rem;
      padding: 0.1rem 0 0 0.3rem;

      font-size: 0.28rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #914515;
      line-height: 0.34rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/93d9b8bf-461f-5e25-8baa-538ae93f6d94.png);
      background-size: 100%;
      background-repeat: no-repeat;
    }

    &__title {
      margin-top: 0.86rem;
      font-size: 0.32rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #303030;
      line-height: 0.36rem;
      @include overflow-line(1);
    }

    &__description {
      // padding: 0 0.34rem;
      margin-top: 0.16rem;
      font-size: 0.24rem;
      font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
      font-weight: normal;
      color: #4E4E4E;
      line-height: 0.34rem;
      @include overflow-line(2);
    }

    &__cover {
      position: absolute;
      top: 1.98rem;
      right: 0.14rem;
      width: 2.32rem;
      height: 2.96rem;
      background: #D8D8D8;
      box-shadow: -0.06rem 0.1rem 0px 0px #BAE58C;
      border-radius: 0.16rem;
      border: 0.04rem solid #FFFFFF;
      transform: rotate(-7deg);
      transform-origin: right top;
      overflow: hidden;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }

  // .btn {
  //   display: flex;
  //   align-items: center;
  //   justify-content: center;
  //   width: 5.26rem;
  //   height: 1.04rem;
  //   margin: 0.3rem auto 0 auto;
  //   background: linear-gradient(90deg, #FD8D55 0%, #FD5F65 100%);
  //   border-radius: 0.52rem;
  //   font-size: 0.34rem;
  //   font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
  //   font-weight: normal;
  //   color: #FFFFFF;
  // }
</style>
