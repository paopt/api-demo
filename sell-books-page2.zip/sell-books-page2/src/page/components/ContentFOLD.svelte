<div class="c-content-card">
  {#each config.content as book}
    <div class="book" style={`background-image:url(${book.bottomUrl})`}>
      <div class="book__index">{book.serialDescribe}</div>
      <div class="book__left">
        <div class="book__title">{book.title}</div>
        <div class="book__recommend">{book.recommend}</div>
        <div class="book__description">
          <div class="label">{book.introduction}</div>
        </div>
      </div>
      <div class="book__right">
        <div class="book__cover">
          <img src={book.coverUrl} alt="">
        </div>
      </div>
    </div>
  {/each}
  <!-- <div class="btn">查看老师近期精讲内容</div> -->
</div>

<script>
  export let config = null

  $: if (config) {
    console.log('内容折叠组件', config)
  }

</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-content-card {
    padding: 0 0.7rem;

    .book + .book {
      margin-top: 0.5rem;
    }
  }

  .book {
    position: relative;
    display: flex;
    width: 6.09rem;
    height: 2.95rem;
    padding: 0 0.35rem 0 0.44rem;
    background-image: url(//cdn.hhdd.com/frontend/as/i/37cbd73c-e0af-513a-bd93-33be0ce84fad.png);
    background-size: 100%;

    &__index {
      position: absolute;
      top: 0;
      left: -0.03rem;
      width: 1.58rem;
      height: 0.66rem;
      padding: 0.1rem 0 0 0.32rem;
      font-size: 0.28rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FFFFFF;
      line-height: 0.34rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/db38a0db-90d4-5bd8-9533-99b67a28ac67.png);
      background-size: 100%;
      background-repeat: no-repeat;
    }

    &__left {
      flex: 1;
      margin-right: 0.2rem;
      overflow: hidden;
    }

    &__right {
      width: 2.07rem;
    }

    &__title {
      height: 0.34rem;
      margin-top: 0.76rem;
      font-size: 0.3rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FDEBC6;
      line-height: 0.34rem;
      @include overflow-line(1);
    }

    &__recommend {
      height: 0.42rem;
      margin-top: 0.14rem;
      font-size: 0.22rem;
      font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
      font-weight: normal;
      color: #FDEBC6;
      line-height: 0.34rem;
      @include overflow-line(1);
    }

    &__description {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 2.76rem;
      height: 0.88rem;
      margin-top: 0.09rem;
      padding: 0 0.16rem;
      background: linear-gradient(90deg, #FDECC7 0%, #FFE1AF 99%);
      border-radius: 0.24rem;

      .label {
        font-size: 0.24rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #904123;
        line-height: 0.36rem;
        @include overflow-line(2);
      }
    }

    &__cover {
      width: 2.07rem;
      height: 2.62rem;
      background: #D8D8D8;
      border-radius: 0.16rem;
      border: 0.05rem solid #FFFFFF;
      overflow: hidden;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }

  // .btn {
  //   display: flex;
  //   align-items: center;
  //   justify-content: center;
  //   width: 5.26rem;
  //   height: 1.04rem;
  //   margin: 0.5rem auto 0 auto;
  //   font-size: 0.34rem;
  //   font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
  //   font-weight: normal;
  //   color: #FFFFFF;
  //   line-height: 0.38rem;
  //   background: linear-gradient(90deg, #FD8D55 0%, #FD5F65 100%);
  //   border-radius: 0.52rem;
  // }
</style>
