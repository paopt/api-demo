<div class="c-banner"  bind:this={panelEl}>
  <img class="c-banner__img" src={config.imgUrl} alt="" on:load={handleLoad}>
  <div class="c-banner__footer">
    <!-- 按钮 -->
    {#if config.button}
      <div class="button {config.button.className}" on:click={handleClick} id="mainBtn">
        <img class="button__img" src={config.button.imgUrl} alt="">
      </div>
    {/if}
    <!-- 定时器 -->
    <div class="timer">
      {#if config.timer.show}
        <Timer
          class="timer-new"
          deadline={config.timer.timerDeadline}
          format={config.timer.format}
          millisecond>
          <span slot="before" class="before">{config.timer.label}</span>
        </Timer>
      {/if}
    </div>
  </div>
</div>

<script>
  import { onMount, tick, onDestroy, createEventDispatcher } from "svelte"
  import { Timer } from "@kada/svelte-activity-ui"

  export let config = null

  let panelEl

  const dispatch = createEventDispatcher()

  /**
   * 获取组件位置信息, 由Home页面使用
   *
   * @returns {Rectangle}
   */
  export function getBoundingClientRect () {
    return panelEl ? panelEl.getBoundingClientRect() : null
  }

  function handleClick () {
    dispatch('banner-click')
  }

  function handleLoad() {
    console.log('banner img loaded')
  }

  onMount(() => {
    console.log('banner onmount')
  })
</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-banner {
    position: relative;

    &__img {
      display: block;
      width: 100%;
      padding: 0;
      border: 0;
      -webkit-user-drag: none;
      pointer-events: none;
    }

    &__footer {
      position: absolute;
      bottom: 0;
      width: 100%;

      .button {
        position: relative;
        width: 7.2rem;
        height: 1.6rem;
        margin: 0 auto;
      }

      .button__img {
        display: block;
        width: 100%;
        height: 100%;
      }
      
      .timer {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 0.8rem;
      }

      .timer-info {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 4.44rem;
        height: 0.48rem;
        background: rgba(0, 0, 0, 0.5);
        border-radius: 0.32rem;
        font-size: 0.24rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #FFFFFF;
      }
    }

    .timer-new {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0 0.44rem 0 0.58rem;
      height: 0.66rem;
      background: rgba(0, 0, 0, 0.5);
      border-radius: 0.33rem;
      font-size: 0.32rem;
      font-weight: normal;
      color: #FFFFFF;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      .before {
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-size: 0.32rem;
      }
      .sui-timer__zone {
        margin-left: 0.06rem;
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-size: 0.32rem;
      }
    }
  }
</style>
