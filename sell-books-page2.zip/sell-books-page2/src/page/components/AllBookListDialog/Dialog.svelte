<Popup class="c-signupdlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-signupdlg__body" on:touchmove|stopPropagation|preventDefault>
    <div class="c-signupdlg__content needsclick" bind:this={contentEl}>{@html content}</div>
    <div class="close" on:click={close}></div>
    <!-- <div class="c-signupdlg__footer">
      <div class="btn-confirm" on:click={handleButtonClick}>{@html buttonText}</div>
    </div> -->
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  import IScroll from 'iscroll/build/iscroll-lite'
  import { promiseDelay } from '@/utils/promisify'

  const dispatch = createEventDispatcher()
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 通用弹窗标题
   * @type {String} title
   */
  // export let title = '去精选页开始打卡'
  /**
   * 通用弹窗信息
   * @type {String} message
   */
  export let content = `<img src="//cdn.hhdd.com/frontend/as/i/b57c923a-b21f-569f-abc2-99ed8c98ca46.png" alt="" />`

  /**
   * 弹窗按钮文案
   * @type {HTML|String} buttonText
   */
  // export let buttonText = '立刻去精选页'

  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = true

  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  /**
   * 点击确认按钮回调
   * @svelte-prop {Function} onDone
   */
  export let onDone = null

  let popupEl
  let contentEl
  // 内容区域滚动示例
  let contentScroll
  let resolve

  let _content = ''

  $: if (content !== _content) {
    promiseDelay(600).then(() => {
      if (!contentScroll && contentEl) {
        contentScroll = new IScroll(contentEl, {
          // disablePointer: false,
          zoom: true,
          zoomMax: 4,
          // click: true,
          scrollY: true,
          scrollX: false,
          // disableMouse: true,
          bindToWrapper: true,
          doubleTapZoom: 2,
        })
      }

      if (contentScroll) {
        contentScroll.refresh()
      }
    })
  }

  export const promise = new Promise((fulfil) => (resolve = fulfil))

  const zoomClick = () => {
    console.log(11)
  }

  function close() {
    dispatch('close')
    popupEl && popupEl.close()

    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }
  window.addEventListener('ondblclick', () => {console.log(222), true})
  onMount(() => {
    popupEl && popupEl.show()
    contentEl.addEventListener('ondblclick', zoomClick, true)
  })
  onDestroy(() => {
    if (contentScroll) {
      contentScroll.destroy()
      contentScroll = null
    }
  })
</script>

<style lang="scss">
  $component-name: 'c-signupdlg';
  @import '../../../styles/variables';
  :global {
    .#{$component-name} {
      z-index: 999;
      &__body {
        position: relative;
        width: 6.38rem;
        top: -1rem;
        border-radius: 0.3rem;
        font-family: 'Yuanti SC', 'PingFang SC';
        z-index: 999;
        .title {
          height: 1rem;
        }

        .close {
          position: absolute;
          width: 0.3rem;
          height: 0.3rem;
          bottom: -0.6rem;
          margin-right: -0.15rem;
          right: 50%;
          background: {
            repeat: no-repeat;
            position: 50% 50%;
            size: 100% auto;
            image: url('//cdn.hhdd.com/frontend/as/i/0179dab3-9bbe-59dd-8efb-4b2e78427639.png');
          }
          z-index: 99;
        }
      }

      &__content {
        font-size: 0.22rem;
        font-weight: 400;
        color: #39364d;
        max-height: 92vh;
        overflow: hidden;
        div {
          height: max-content;
        }
      }

      &__footer {
        padding: 0.38rem 0.4rem 0.64rem 0.4rem;

        .btn-confirm {
          display: block;
          width: 4rem;
          height: 0.96rem;
          // background: linear-gradient(321deg, #14C3FF 0%, #6ECFFF 100%);
          box-shadow: 0 0.12rem 0.24rem 0 rgba(0, 170, 229, 0.21);
          border-radius: 0.48rem;
          margin: 0 auto;
          padding: 0.24rem 0.48rem 0.2rem 0.48rem;
          text-align: center;
          font-size: 0.36rem;
          font-weight: 500;
          color: #FFF;
          line-height: 0.5rem;
        }
      }
    }
  }
</style>
