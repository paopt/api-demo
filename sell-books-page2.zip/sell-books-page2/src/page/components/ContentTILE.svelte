<div class="c-content-card">
  {#each config.content as book}
  <div class="book" style={`background-image:url(${book.bottomUrl})`}>
    <div class="book__left">
      <div class="book__awards">
        <img class="icon-left" src="//cdn.hhdd.com/frontend/as/i/784b8b31-a2a4-57e2-9a4e-37ef4029dd04.png" alt="">
        <span class="label">{book.recommend}</span>
        <img class="icon-right" src="//cdn.hhdd.com/frontend/as/i/4c67af0c-1194-5af8-a7b4-e595dab3f7af.png" alt="">
      </div>
      <div class="book__title">{book.title}</div>
      <div class="book__description">{book.introduction}</div>
    </div>
    <div class="book__right">
      <div class="book__cover">
        <img class="icon" src={book.coverUrl} alt="">
      </div>
    </div>
    <div class="book__index">{book.serialDescribe}</div>
    <div class="book__category">{book.showName}</div>
  </div>
  {/each}
  <!-- <div class="btn">查看本月全部新书(30+)</div> -->
</div>

<script>
  export let config = null

  $: if (config) {
    console.log('内容平铺组件', config)
  }

</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-content-card {
    padding: 0 0.72rem;

    .book + .book {
      margin-top: 0.5rem;
    }
  }

  .book {
    display: flex;
    position: relative;
    width: 6.09rem;
    height: 3.7rem;
    padding: 0 0.34rem;
    border-radius: 0.3rem;
    background-size: 100%;
    overflow: hidden;

    &__index {
      position: absolute;
      right: 0;
      top: 0;
      width: 1.58rem;
      height: 0.66rem;
      padding: 0.1rem 0 0 0.46rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/a08c5206-af50-5ee0-a5ee-884fe5667a75.png);
      background-size: 100%;
      background-repeat: no-repeat;
      font-size: 0.28rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #914515;
      line-height: 0.34rem;
    }
    &__category {
      display: flex;
      align-items: center;
      justify-content: center;
      position: absolute;
      left: 0;
      bottom: 0;
      width: 1.46rem;
      height: 0.46rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/244c66b5-f8bd-5dc8-bc76-de3bf6444350.png);
      background-size: 100%;
      background-repeat: no-repeat;
      font-size: 0.26rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FFFFFF;
    }

    &__left {
      flex: 1;
      margin-right: 0.28rem;
      overflow: hidden;
    }

    &__right {
      display: flex;
      align-items: center;
      width: 1.76rem;
    }

    &__awards {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 0.6rem;
      margin-top: 0.36rem;
      .icon-left {
        width: 0.24rem;
        height: 0.36rem;
      }

      .icon-right {
        width: 0.24rem;
        height: 0.36rem;
      }

      .label {
        max-width: 2.6rem;
        padding: 0 0.1rem;
        font-size: 0.26rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #FFDC8B;
        line-height: 0.3rem;
        text-align: center;
        white-space: pre-wrap;
        @include overflow-line(2);
      }
    }

    &__title {
      margin-top: 0.28rem;
      font-size: 0.28rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #FFFFFF;
      line-height: 0.34rem;
      text-align: center;
      @include overflow-line(1);
    }

    &__description {
      margin-top: 0.2rem;
      font-size: 0.22rem;
      font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
      font-weight: normal;
      color: #FFFFFF;
      line-height: 0.34rem;
      @include overflow-line(4);
    }

    &__cover {
      width: 1.76rem;
      height: 2.22rem;
      margin-top: 0.2rem;
      background: #D8D8D8;
      border: 0.05rem solid #FFFFFF;
      border-radius: 0.16rem;
      overflow: hidden;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }

  // .btn {
  //   display: flex;
  //   align-items: center;
  //   justify-content: center;
  //   width: 5.26rem;
  //   height: 1.04rem;
  //   margin: 0.6rem auto 0 auto;
  //   background: linear-gradient(90deg, #FD8D55 0%, #FD5F65 100%);
  //   border-radius: 0.52rem;
  //   font-size: 0.34rem;
  //   font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
  //   font-weight: normal;
  //   color: #FFFFFF;
  // }
</style>
