<!-- 赠品组件填地址提示弹框 -->
<Popup class="c-filladdressdlg {className}" {maskClickHide} bind:this={popupEl}>
  <div class="c-filladdressdlg__body" on:touchmove|stopPropagation|preventDefault>
    <div class="label">恭喜你获得SVIP权益</div>
    <img class="img1" src="//cdn.hhdd.com/frontend/as/i/952208ac-70ec-5aea-a688-9d9d346c97d3.png" alt="">
    <img class="img2" src="//cdn.hhdd.com/frontend/as/i/f4c5abf2-29dc-5c38-8888-776f14f64f2d.png" alt="">
    <img class="img3" src="//cdn.hhdd.com/frontend/as/i/e3a2e0fa-23da-5f04-a447-ff9e2de74ee0.png" alt="">
    <img class="btn" src="//cdn.hhdd.com/frontend/as/i/6dae68ae-6c3f-588a-a190-fe7d3797b0a8.png" alt="" on:click={() => close(1)}>
    <img
      class="close"
      on:click={close}
      src="//cdn.hhdd.com/frontend/as/i/9e874488-034b-5246-b31f-ce9e5ab81b38.png"
      alt=""
    />
  </div>
</Popup>

<script>
  import { createEventDispatcher, onMount, onDestroy } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  const dispatch = createEventDispatcher()
  //组件样式
  let className = ''
  export { className as class }

  //是否支持点击mask关闭弹窗
  export let maskClickHide = true

  //点击关闭按钮回调
  export let onClose = null

  let popupEl

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  function close(flag) {
    console.log('flag', flag)
    dispatch('close')
    popupEl && popupEl.close()
    resolve(false)
    if ((typeof onClose === 'function') && flag === 1) {
      onClose()
    }
  }

  onMount(() => {
    popupEl && popupEl.show()
  })

  onDestroy(() => {
  })
</script>

<style lang="scss" scoped>
  $component-name: 'c-filladdressdlg';

  :global {
    .#{$component-name} {
      z-index: 999;
      &__body {
        position: relative;
        width: 7.5rem;
        height: 9.48rem;

        .label {
          position: absolute;
          top: -0.48rem;
          width: 100%;
          font-size: 0.48rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #FFDFBC;
          text-align: center;
          line-height: 1;
        }

        .img1 {
          position: absolute;
          left: -1.12rem;
          width: 9.72rem;
          height: 9.48rem;
          z-index: 1;
        }
        .img2 {
          position: absolute;
          left: -0.74rem;
          width: 8.98rem;
          height: 9rem;
          z-index: 2;
        }
        .img3 {
          position: absolute;
          top: 0.3rem;
          left: 50%;
          transform: translateX(-50%);
          width: 6.66rem;
          height: 7.78rem;
          z-index: 3;
        }
        .btn {
          position: absolute;
          top: 5.88rem;
          left: 50%;
          transform: translateX(-50%);
          width: 3.58rem;
          height: 1.14rem;
          z-index: 4;
        }
        .close {
          position: absolute;
          width: 0.72rem;
          height: 0.72rem;
          bottom: 0;
          left: 50%;
          transform: translateX(-50%);
          z-index: 5;
        }
      }
    }
  }
</style>
