<div class="c-member-banner"  bind:this={panelEl}>
  <img class="c-member-banner__img" src={config.buyHeadUrl} alt="">
  <div class="c-member-banner__footer">
    <!-- 气泡 -->
    {#if config.showBubble}
      <div class="bubble" >
        <img class="bubble__img" src={config.bubbleButtonUrl} alt="">
        <span class="bubble__price" style={config.style}>{config.discount}</span>
      </div>
    {/if}
    <!-- 按钮 -->
    {#if config.button}
      <div class="button {config.button.className}" on:click={handleClick} id="mainBtn">
        <img class="button__img" src={config.button.imgUrl} alt="">
        {#if config.showPrice}
          <span class="price__symbol" style={config.style}>¥</span>
          <span class="price__value" style={config.style}>{config.realPrice}</span>
        {/if}
      </div>
    {/if}
    <!-- 定时器 -->
    <div class="timer">
      {#if config.timer.show}
        <Timer
          class="timer-new"
          deadline={config.timer.timerDeadline}
          format={config.timer.format}
          millisecond>
          <span slot="before" class="before">{config.timer.label}</span>
        </Timer>
      {/if}
    </div>
  </div>
</div>

<script>
  import { onMount, tick, onDestroy, createEventDispatcher } from "svelte"
  import { Timer } from "@kada/svelte-activity-ui"

  export let config = null

  let panelEl

  const dispatch = createEventDispatcher()

  /**
   * 获取组件位置信息, 由Home页面使用
   *
   * @returns {Rectangle}
   */
  export function getBoundingClientRect () {
    return panelEl ? panelEl.getBoundingClientRect() : null
  }

  function handleClick () {
    dispatch('member-click')
  }
</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-member-banner {
    position: relative;

    &__img {
      display: block;
      width: 100%;
      padding: 0;
      border: 0;
      -webkit-user-drag: none;
      pointer-events: none;
    }

    &__footer {
      position: absolute;
      bottom: 0;
      width: 100%;
      .bubble {
        position: relative;
        width: 5.2rem;
        height: 0.7rem;
        margin: 0 auto;
      }

      .bubble__img {
        display: block;
        width: 100%;
        height: 100%;
      }

      .bubble__price {
        position: absolute;
        left: 3.16rem;
        top: 0.12rem;
        width: 0.8rem;
        font-size: 0.4rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #FF4B44;
        line-height: 0.46rem;
        text-align: center;
      }


      .button {
        position: relative;
        width: 7.2rem;
        height: 1.6rem;
        margin: 0 auto;
      }

      .button__img {
        display: block;
        width: 100%;
        height: 100%;
      }

      .price__symbol {
        position: absolute;
        left: 1.94rem;
        top: 0.68rem;
        font-size: 0.46rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #F7223A;
        line-height: 0.54rem;
        letter-spacing: 0.01rem;
      }

      .price__value {
        position: absolute;
        left: 2.44rem;
        top: 0.46rem;
        font-size: 0.72rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #F7223A;
        line-height: 0.84rem;
        letter-spacing: 0.01rem;
      }
      
      .timer {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 0.8rem;
      }

      // @media #{$pad_landscape_query} {
      //   .bubble {
      //     width: 7.28rem;
      //     height: 0.98rem;
      //   }
      //   .bubble__price {
      //     left: 4.42rem;
      //     top: 0.16rem;
      //     width: 1.12rem;
      //     height: 0.64rem;
      //     font-size: 0.56rem;
      //     line-height: 0.64rem;
      //   }

      //   .button {
      //     width: 9.9rem;
      //     height: 2.2rem;
      //   }
      //   .price__symbol {
      //     left: 2.62rem;
      //     top: 0.94rem;
      //     font-size: 0.65rem;
      //     line-height: 0.76rem;
      //   }
      //   .price__value {
      //     left: 3.24rem;
      //     top: 0.62rem;
      //     font-size: 1rem;
      //     line-height: 1.16rem;
      //     letter-spacing: 0.02rem;
      //   }
      //   .timer {
      //     height: 1.04rem;
      //   }
      //   .timer-info {
      //     width: 5.92rem;
      //     height: 0.64rem;
      //     font-size: 0.28rem;
      //   }
      // }
    }

    .timer-new {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0 0.44rem 0 0.58rem;
      height: 0.66rem;
      background: rgba(0, 0, 0, 0.5);
      border-radius: 0.33rem;
      font-size: 0.32rem;
      font-weight: normal;
      color: #FFFFFF;
      font-family: FZLANTY_ZHONGCUJW--GB1;
      .before {
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-size: 0.32rem;
      }
      .sui-timer__zone {
        margin-left: 0.06rem;
        font-family: FZLANTY_ZHONGCUJW--GB1;
        font-size: 0.32rem;
      }
    }
  }
</style>
