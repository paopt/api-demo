<Popup class={['c-winprizedlg', className, theme ? `theme-${theme}` : ''].join(' ')} {maskClickHide} {onClose} {outPosition} bind:this={popupEl}>
  <div class="c-winprizedlg__body">
    <div class="c-winprizedlg__redpacket c-redpack-dialog"
      class:is-end={isHideAnimating}>
      <div class="c-redpack-dialog__wrapper">
        <!-- 免单卡奖品 -->
        {#if prize?.awardType == 6}
          <SvgaPlayer svgaUrl={prize?.cardUrl} playerConfig={playerConfig} class={"win-invite_card"} on:click={handleReceivedAwardClick}></SvgaPlayer>
        {:else}
          <p class="c-redpack-dialog__header">{headerTit}</p>
          <div class="c-redpack-dialog__body c-winprizedlg__redpacket-body">
            <img class="c-redpack-dialog__halo" src="//cdn.hhdd.com/frontend/as/i/2f9f99e8-b1c4-578a-82cf-4e5b174cda19.png" alt="">
            <img class="c-redpack-dialog__light" src="//cdn.hhdd.com/frontend/as/i/fe2feadf-091f-5625-8854-85432c04bc92.png" alt="">
            <div class="c-redpack-dialog__content c-winprizedlg__redpacket-content"
              style={`background-image: url(${contentImage});`}
            >
              {#if prize.awardName}
                <div class="prize">
                  {prize.awardName}
                </div>
              {:else}
                <div class="prize" style="color: #5470F6;">{prize?.text || ''}</div>
              {/if}
              <!-- <p class="c-redpack-dialog__time">{formatDate(new Date(`${systemDate.getFullYear()}/${systemDate.getMonth() + 1}/${systemDate.getDate()} 23:59:59`), 'YYYY-MM-DD HH:mm:ss')}过期</p> -->
              <button class="c-redpack-dialog__confirm c-winprizedlg__redpacket-confirm fzlty-zc"
                style={`background-image: url(${btnImage});`}
                on:click={handleReceivedAwardClick}>
              </button>
            </div>
          </div>
        {/if}
      </div>
    </div>
  </div>
</Popup>

<script>
  import { onMount } from 'svelte'
  import { Popup } from '@kada/svelte-activity-ui'
  import { promiseDelay } from '@/utils/promisify'
  import SvgaPlayer from '@/page/components/SvgaPlayer.svelte'

  //svg播放器配置
  let playerConfig = { loop: 0 }

  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 是否支持点击mask关闭弹窗
   * @type {Boolean} maskClickHide
   */
  export let maskClickHide = true

  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  /**
   * 点击按钮是否关闭弹窗
   * @type {Function} onClose
   */
  export let doneCloseDialog = true

  /**
   * 点击按钮回调
   * @type {Function} onClose
   */
  export let onDone = null

  /**
   * 动画退出位置
   * @type {Boolean} outPosition
   */
  export let outPosition = [0, 0]

  /**
   * 奖品类型
   * @type {Number} prize
   */
  export let prize = {}

  /**
   * 弹窗标题文案
   * @type {string} headerTit
   */
  export let headerTit = '恭喜中奖啦!'

  /**
   * 按钮文案
   * @type {string} btnText
   */
  export let btnImage = '//cdn.hhdd.com/frontend/as/i/97c281de-5865-5488-848f-5bc5f4511718.png'

  export let contentImage = '//cdn.hhdd.com/frontend/as/i/f93308fd-b622-5ac2-9524-1a96d1c26a8a.png'

  /**
   * 组件样式主题
   * @type {String} theme
   */
  export let theme = ''

  let countDownEl = null
  let popupEl = null
  let visible = false
  let isHideAnimating = false

  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))

  function done() {
    if (countDownEl) {
      countDownEl.pause()
    }
    if (doneCloseDialog) {
      popupEl && popupEl.close()
    }
    resolve(true)
    if (typeof onDone === 'function') {
      onDone()
    }
  }
  // const handleButtonClick = async () => {
  //   done()
  // }

  async function handleReceivedAwardClick () {
    isHideAnimating = true
    await promiseDelay(600)
    done()
  }

  onMount(() => {
    promiseDelay(500).then(() => {
      if (countDownEl) {
        countDownEl.start()
      }
    })
    popupEl && popupEl.show()
    visible = true
  })
</script>

<style lang="scss" global>
  @import "../../../styles/_variables.scss";
  @import "../../../styles/mixins";

  $component-name: 'c-winprizedlg';

  .#{$component-name} {
    z-index: 999;

    &__body {
      position: relative;
      top: -0.1rem;
      width: 7.50rem;

      .c-redpack-dialog {
        width: 100%;
        height: 100vh;
        opacity: 1;
        display: flex;
        justify-content: center;
        align-content: center;
        align-items: center;
        flex-direction: column;
        &.is-end {
          animation: redpackFly 0.7s cubic-bezier(.49,-0.46,.97,.85) both;
        }
        &__wrapper {
          margin-top: -0.5rem;
          animation: scaleIn 0.8s cubic-bezier(.31,1.26,.27,1.22) both;
        }
        &__invite_card {
          width: 6rem;
        }
        &__header {
          font-size: 0.48rem;
          font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
          // font-family: 'FZLANTY_JW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
          font-weight: normal;
          color: #FFDFBC;
          text-align: center;
        }
        &__body {
          margin-top: 0.24rem;
        }
        &__halo, &__light {
          position: absolute;
          margin: auto;
          top: 0;
          right: 0;
          bottom: 0;
          left: 0;
        }
        &__halo {
          width: 9.72rem;
          height: 9.48rem;
          margin-left: -1.6rem;
          animation: rotate360 6s linear infinite;
        }
        &__light {
          width: 8.98rem;
          height: 9rem;
          margin-left: -1.25rem;
          animation: rotate360 4s linear infinite;

        }
        &__content {
          background-image: url('//cdn.hhdd.com/frontend/as/i/ea6dea58-c22f-543b-a8d4-505fe7ed8a6a.png');
          background-repeat: no-repeat;
          background-size: 100% 100%;
          width: 6.66rem;
          height: 7.78rem;
          position: relative;
          margin: auto;
        }
        &__time {
          position: absolute;
          bottom: 2.5rem;
          text-align: center;
          width: 100%;
          font-size: 0.22rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #fff;
        }
        &__confirm {
          position: absolute;
          bottom: 1rem;
          background: transparent;
          right: 0;
          left: 0;
          margin: auto;
          background-image: url('//cdn.hhdd.com/frontend/as/i/97c281de-5865-5488-848f-5bc5f4511718.png');
          background-repeat: no-repeat;
          background-size: 100% 100%;
          width: 3.58rem;
          height: 1.14rem;
          &:active {
            transform: scale(0.96);
          }
        }

        // @media #{$pad_landscape_query} {
        //   &__header {
        //     font-size: 0.62rem;
        //     padding-bottom: 0.3rem;
        //   }
        //   &__body {
        //     transform: scale(1.1) translateZ(0);
        //   }
        // }
      }

      @keyframes scaleIn {
        0% {
          transform: scale(0);
        }
        100% {
          transform: scale(1);
        }
      }
      @keyframes rotate360 {
        0% {
          transform:rotate(0deg);
        }
        100% {
          transform:rotate(360deg);
        }
      }
      @keyframes redpackFly {
        0% {
          transform: translate(0, 0) scale(1);
        }
        100% {
          transform: translate(-2.5rem, 3rem) scale(0);
        }
      }
    }

    &__close {
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      bottom: 0.24rem;
      width: 0.76rem;
      height: 0.76rem;
      color: transparent;
      background: url(//cdn.hhdd.com/frontend/as/i/ce360163-bc41-5954-9b20-732b2503e620.png) no-repeat 50% 50% / 100% 100%;
      z-index: 99;
    }

    :global(.sui-popup__mask) {
      background-color: rgba(0, 0, 0, 0.7);
    }
    &__redpacket {
      // &-body {

      // }
      &-content {
        background-image: url('//cdn.hhdd.com/frontend/as/i/f93308fd-b622-5ac2-9524-1a96d1c26a8a.png');
        width: 6.66rem !important;
        height: 7.4rem !important ;
        .prize {
          position: absolute;
          width: 5rem;
          text-align: center;
          top: 3.3rem;
          right: 0;
          left: 0;
          margin: auto;
          color: #fff;
          letter-spacing: 0.05rem;
          font-size: 0.58rem;
          font-weight: bold;
          font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
          &.is-small {
            top: 3.5rem;
            font-size: 0.85rem;
          }
          b {
            font-size: 0.4rem;
          }
        }
      }
      &-confirm {
        bottom: 1.05rem !important;
      }
    }
  }

</style>
