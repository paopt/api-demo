<div class="c-content-slide {context?.viewData?.identityFlag === 3 ? 'inTiYan' : ''}" id="slide-container">
  <div class="c-content-slide__header">
    <div class="title">{config.title}</div>
    <div class="subtitle">{config.subTitle}</div>
  </div>
  <div class="c-content-slide__content" id="slide-list">
    {#each config.content as item, index}
    <div class="card {item.card.class}">
      {#if item.card.isAlbum}
        <div class="card__bg1" style={`background-image: url(${item.coverUrl});`}>
          <div class="card__bg2">
          </div>
        </div>
      {/if}
      <div class="card__content" on:click={handleClick(item, index)}>
        <div class="cover-border"></div>
        <img class="cover" src={item.coverUrl} alt="">
        {#if item.card.showVideoIcon}
          <img class="vedio" src="//cdn.hhdd.com/frontend/as/i/b0f01ec8-2534-513e-b7dd-3ff62e4d06ab.png" alt="">
        {/if}
        {#if item.card.tag}
          <div class="tag">
            <span class="tag__title">{item.card.tag}</span>
            {#if item.card.showHeadsetIcon}
              <img class="tag__icon" src="//cdn.hhdd.com/frontend/as/i/201d0a00-e818-519c-bd7f-ded7f470a181.png" alt="">
            {/if}
            {#if item.card.showVolumeIcon}
              <img class="tag__icon" src="//cdn.hhdd.com/frontend/as/i/7bc721b1-cf4b-59f4-9a82-7711ac988b24.png" alt="">
            {/if}
          </div>
        {/if}
      </div>
      <div class="card__footer">
        {item.sourceName}
      </div>
    </div>
    {/each}
  </div>
</div>

<script>
  import { onMount, onDestroy } from 'svelte'
  import { slideCard } from  '@/utils/slide'
  import { goKadaBySourceType } from '@/utils/kada'
  import { debounce } from "@/utils/throttle"
  import { sendBehavior } from "@/lib/analytics"

  export let config = null
  export let context = null

  const cardMap = {
    1: {
      tag: '绘本',
      showVolumeIcon: true, // 音量图标
      class: 'is-book'
    },
    2: {
      tag: '听书',
      showHeadsetIcon: true, // 耳机图标
      class: 'is-story'
    },
    4: {
      tag: '听书合辑',
      showHeadsetIcon: true, // 耳机图标
      class: 'is-storyalbum',
      isAlbum: true, // 合辑
    },
    5: {
      tag: '绘本合辑',
      showVolumeIcon: true, // 音量图标
      class: 'is-bookalbum',
      isAlbum: true, // 合辑
    },
    8: {
      tag: '',
      showVideoIcon: true, // 视频图标
      class: 'is-course'
    },
    14: {
      tag: '',
      class: 'is-comic'
    },
    15: {
      tag: '',
      class: 'is-ebook'
    },
    19: {
      tag: '',
      showVideoIcon: true, // 视频图标
      class: 'is-course'
    },
  }

  let clearEvent = null

  $: if (config) {
    console.log('侧滑组件', config)
    config.content = config.content || []
    config.content.forEach((item) => {
      item.card = cardMap[item.sourceType] || cardMap[15]
    })
  }

  onMount(() => {
    clearEvent = slideCard({
      containerEle: document.querySelector('#slide-container'),
      listEle: document.querySelector('#slide-list'),
      space: 0.32
    })
  })

  onDestroy(() => {
    if (clearEvent) {
      clearEvent()
    }
  })

  const handleClick = debounce((item, index) => {
    sendBehavior(`acac_${context.activityKey}_${index+1}_${item.sourceType}_${item.sourceId}`)

    localStorage.setItem('NEW_TY_SCROLL', window.scrollY)
    if (item.sourceType === 19) {
      goKadaBySourceType(context?.viewData?.identityFlag === 3, item.sourceType, item.courseId, item.sourceId)
    } else {
      goKadaBySourceType(context?.viewData?.identityFlag === 3, item.sourceType, item.sourceId)
    }
  }, 1000)

</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';
  .c-content-slide {
    position: relative;
    height: 4rem;
    padding-left: 0.32rem;
    overflow: hidden;
    margin-top: 0.48rem;
    // &.inTiYan {
    //   margin-top: 0.48rem;
    // }
    &__header {
      display: flex;
      align-items: center;
      height: 0.48rem;
      .title {
        margin-right: 0.24rem;
        font-size: 0.4rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.48rem;
      }
      .subtitle {
        font-size: 0.26rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #999999;
        line-height: 1;
        @include overflow-line(1);
        flex: 1;
      }
    }
    &__content {
      position: absolute;
      left: 0.32rem;
      height: 3.2rem;
      margin-top: 0.16rem;
      white-space: nowrap;
      font-size: 0;
    }

    .card {
      position: relative;
      width: 2.5rem;
      height: 3.2rem;
      display: inline-block;
      vertical-align: top;

      &__bg1 {
        position: absolute;
        width: 2.4rem;
        height: 3.06rem;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        border-radius: 0.16rem;
      }

      &__bg2 {
        width: 100%;
        height: 100%;
        opacity: 0.85;
        border-radius: 0.16rem;
      }

      &__content {
        position: relative;
        width: 2.5rem;
        height: 3.2rem;
        // border: 0.02rem solid rgba(0,0,0,0.08);
        box-sizing: border-box;
        border-radius: 0.16rem;
        overflow: hidden;
        .cover {
          width: 100%;
          height: 100%;
          border-radius: 0.16rem;
        }
        .cover-border {
          position: absolute;
          width: 100%;
          height: 100%;
          border-radius: 0.16rem;
          border: 0.04rem solid rgba(0,0,0,0.08);
          box-sizing: border-box;
          background-color: transparent;
        }
        .vedio {
          position: absolute;
          right: 0;
          bottom: 0;
          width: 1rem;
        }
        .tag {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          position: absolute;
          right: 0;
          bottom: 0;
          background-size: 100% 100%;
          background-repeat: no-repeat;

          &__title {
            font-size: 0.2rem;
            font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
            font-weight: normal;
            color: #FFFFFF;
            line-height: 0.24rem;
            margin-right: 0.04rem;
          }
          &__icon {
            width: 0.2rem;
            height: 0.2rem;
            margin-right: 0.08rem;
          }
        }
      }
    }
    .is-bookalbum {
        .card__bg2 {
          background-color: #66B3FF;
        }
        .tag {
          width: 1.28rem;
          height: 0.36rem;
          background-image: url(//cdn.hhdd.com/frontend/as/i/b30bd849-7fb0-51fa-8a62-950690727510.png);
        }
      }

      .is-storyalbum {
        .card__bg2 {
          background-color: #FFD072;
        }
        .tag {
          width: 1.38rem;
          height: 0.36rem;
          right: -0.02rem;
          background-image: url(//cdn.hhdd.com/frontend/as/i/3afef965-8339-56e2-a19a-a0f977e04bb6.png);
        }
      }
      .is-book {
        .tag {
          width: 1.36rem;
          height: 0.36rem;
          right: -0.02rem;
          bottom: -0.02rem;
          background-image: url(//cdn.hhdd.com/frontend/as/i/9d3eb09e-909a-5fac-a0bf-e03b701ae921.png);
        }
      }
      .is-story {
        .tag {
          width: 1.28rem;
          height: 0.36rem;
          right: -0.02rem;
          bottom: -0.02rem;
          background-image: url(//cdn.hhdd.com/frontend/as/i/3ce43322-e4ac-55bc-89f7-fdba66fb29d0.png);
        }
      } 

      .is-bookalbum, .is-storyalbum {
        .card__content {
          width: 2.4rem;
          height: 3.06rem;
          margin-left: 0.1rem;
          margin-top: 0.14rem;
        }
      }

    .card + .card {
      margin-left: 0.16rem;
    }
  }
</style>