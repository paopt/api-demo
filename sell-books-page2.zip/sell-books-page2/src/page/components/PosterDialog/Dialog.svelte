<!-- 分享海报 -->
<div bind:this={posterEl} class="c-share-poster {className}" class:is-show={isShow}>
  <!-- 头像 -->
  <img class="c-share-poster__avatar" src={avatarUrl || DEFAULT_AVATAR_URL} alt="">
  <!-- 标题 -->
  <p class="c-share-poster__title">{nickName || DEFAULT_NICK_NAME}<span>邀你<br>一起学习</span></p>
  <!-- 海报背景图 -->
  <img style="width: 100%" src={sharePosterImg || DEFAULT_POSTER_IMG} alt="">
  <!-- 二维码 -->
  <div id="sharePosterQrcode" class="c-share-poster__qrcode">
    <!-- <img class="c-share-poster__qrcode" src="//cdn.hhdd.com/frontend/as/i/00932450-bf7c-57e1-b162-f95dd73ed35d.png" alt=""> -->
  </div>
</div>
<!-- 弹窗形式 -->
{#if isShowDialog}
  <div class="c-poster-dialog" class:is-show={isShowDialog}>
    <div class="c-poster-dialog__wrap">
      <img class="c-poster-dialog__poster" src={posterImage} alt="">
      <p class="c-poster-dialog__tip">微信扫码分享好友赚现金</p>
      <div class="c-poster-dialog__close" on:click={close}></div>
    </div>
  </div>
{/if}


<script>
  import { createEventDispatcher, onMount, tick } from 'svelte'
  import html2canvas from 'html2canvas'
  import { toast } from '@kada/svelte-activity-ui'
  import { sharePoster } from '@kada/jsbridge'
  import { deviceInfo } from '@kada/library/src/device'

  const dispatch = createEventDispatcher()
  const DEFAULT_ACTIVITYKEY = 123585
  const DEFAULT_NICK_NAME = 'KaDa小读者'
  const DEFAULT_AVATAR_URL = '//cdn.hhdd.com/frontend/as/i/6cd9fcd8-f6ef-5261-9b36-cab3e4d2263f.png'
  const DEFAULT_POSTER_IMG = '//cdn.hhdd.com/frontend/as/i/392e9d57-b6ea-5350-82c8-79fcbf9d14e4.jpg'
  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  export let nickName = DEFAULT_NICK_NAME

  export let avatarUrl = DEFAULT_AVATAR_URL

  export let qrcodeUrl = ''

  export let sharePosterImg = ''

  export let shareTitle = ''

  /**
   * 点击关闭按钮回调
   * @type {Function} onClose
   */
  export let onClose = null

  /**
   * 海报渲染完成回调
   * @type {Function} onRendered
   */
  export let onRendered = null

  let posterEl
  let isShow = false

  let posterImage = ''
  let isShowDialog = false

  let qrcodeIntance = null


  let resolve
  export const promise = new Promise((fulfil) => (resolve = fulfil))


  function close() {
    dispatch('close')
    isShow = false
    isShowDialog = false
    resolve(false)
    if (typeof onClose === 'function') {
      onClose()
    }
  }

  async function showPoster () {
    const canvasDom = await html2canvas(posterEl, {
      allowTaint: true,
      scrollX: 0,
      scrollY: 0,
      useCORS: true
    })
    const canvasData = canvasDom.toDataURL('image/jpeg')
    if (!canvasData) {
      toast('海报生成失败')
      return
    }
    if (typeof onRendered === 'function') {
      onRendered()
    }
    posterImage = canvasData
    if (deviceInfo.isAndroidHD) {
      isShowDialog = true
      return
    }
    const shareInfo = {
      title: shareTitle,
      image: canvasData,
      activityId: DEFAULT_ACTIVITYKEY, // 随便填写一个数字，不能不传！app端要求
      buttonList: [{ type: 0 },{ type: 1 }, { type: 2 }] // 0=微信好友, 1=朋友圈, 2=保存到本地, 不传显示3个
    }
    // // shareMoment: 1:分享成功， 0:分享失败, androidHD不支持分享！
    const { data: { cancel, saveLocal, shareMoment, shareFriend } } = await sharePoster(shareInfo)
    // console.log('saveLocal', saveLocal, 'cancel', cancel, 'shareMoment', shareMoment, 'shareFriend', shareFriend)
    if (cancel || saveLocal || shareMoment || shareFriend) {
      close()
    }
  }

  async function generateQrcode() {
    // const FOLLOW_KADA_WECHAT_URL = {
    //   'development': 'http://10.0.10.61:38890/wepage/wechat-official-account/indexV2.html#/',
    //   'test': 'http://10.0.10.61:38890/wepage/wechat-official-account/indexV2.html#/',
    //   'staging': 'http://h5.hhdd.com/wepage-staging/wechat-official-account/indexV2.html#/',
    //   'production': 'https://h5.hhdd.com/w/wechat-official-account/indexV2.html#/',
    // }
    // const runtimeEnv = process.env.NODE_ENV
    // const fromLocation = 'day21hd' // hd专属location
    // const followType = 2 // 私域导流目前都为2
    // const queryParams = `userId=${userId}&type=${followType}&fromLocation=${fromLocation}`
    // const qrcodeUrl = `${FOLLOW_KADA_WECHAT_URL[runtimeEnv]}?${queryParams}`
    // console.log('hd wechat qrcode url:', qrcodeUrl)
    // 动态import 避免一次性加载
    const module = await import('@/lib/qrcode')
    const QRCode = module.default
    // 检查是否存在二维码实例  不存在则新new  否则clear更新
    console.log('海报二维码分享地址：', qrcodeUrl)
    if (!qrcodeIntance) {
      qrcodeIntance = new QRCode('sharePosterQrcode', {
        text: qrcodeUrl,
        width : 128,
        height : 128,
      })
    } else {
      qrcodeIntance.clear()
      qrcodeIntance.makeCode(qrcodeUrl)
    }
    return true
  }

  onMount(() => {
    isShow = true
    tick().then(async () => {
      await generateQrcode()
      showPoster()
    })
  })
</script>

<style lang="scss" global>
  @import "../../../styles/variables";
  .c-share-poster {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    margin: auto;
    z-index: -1000;
    width: 7.5rem;
    height: 13.34rem;
    display: none;
    pointer-events: none;
    &.is-show {
      display: block;
    }
    &__avatar {
      width: 0.92rem;
      height: 0.92rem;
      position: absolute;
      top: 0.48rem;
      left: 0.38rem;
      margin: auto;
      background: #fff;
      border-radius: 50%;
    }

    &__title {
      position: absolute;
      top: 0.54rem;
      text-align: left;
      left: 1.5rem;
      min-width: 3rem;
      display: inline-block;
      &, & span {
        font-size: 0.28rem;
        font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
        font-weight: normal;
        color: #FFFFFF;
        line-height: 0.38rem;
      }
    }

    &__qrcode {
      position: absolute;
      bottom: 0.5rem;
      right: 0.6rem;
      width: 1.45rem;
      height: 1.43rem;
      overflow: hidden;
      @media #{$media_query-phone678} {
        bottom: 0.48rem;
        right: 0.8rem;
      }
      // @media #{$pad_landscape_query} {
      //   bottom: 0.28rem;
      //   right: 0.4rem;
      // }
      img {
        width: 100%;
        height: 100%;
        object-fit: contain;
      }
      canvas {
        width: 100%;
        height: 100%;
      }
    }
  }

  .c-poster-dialog {
    position: fixed;
    top: 0;
    width: 100%;
    height: 100%;
    left: 0;
    z-index: 10000;
    background: #000;
    display: none;
    &.is-show {
      display: block;
    }
    &__wrap {
      display: flex;
      justify-content: center;
      align-content: center;
      align-items: center;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    &__poster {
      width: 6rem;
      display: block;
      border-radius: 0.1rem;
    }
    &__tip {
      font-size: 0.3rem;
      color: #fff;
      font-family: 'FZLANTY_ZHONGCUJW--GB1', 'Yuanti SC', 'PingFang SC', 'Avenir', Helvetica Neue, Roboto, Microsoft Yahei, sans-serif;
      text-align: center;
      margin-top: 0.2rem;
    }
    &__close {
      display: block;
      width: 0.9rem;
      height: 0.9rem;
      margin-top: 0.2rem;
      background: {
        repeat: no-repeat;
        position: 50% 50%;
        size: 100% 100%;
        image: url('//cdn.hhdd.com/frontend/as/i/7a2006a1-d2a0-5f22-ba57-76723ba672b4.png');
      }
      z-index: 99;
      position: absolute;
      // @media #{$pad_landscape_query} {
      //   top: 0.5rem;
      //   right: -7rem;
      //   left: 0;
      //   margin: auto;
      // }
    }
  }
</style>
