<div class="c-content-32 {context?.viewData?.identityFlag === 3 ? 'inTiYan' : ''}">
  <div class="c-content-32__header">
    <div class="title">{config.title}</div>
    <div class="subtitle">{config.subTitle}</div>
  </div>
  <div class="c-content-32__content">
    {#each config.content as item, index}
      <div class="card {item.card.rowGap} {item.card.colGap} {item.card.class}" on:click={handleClick(item, index)}>
        {#if item.card.isAlbum}
          <div class="card__bg1" style={`background-image: url(${item.coverUrl});`}>
            <div class="card__bg2">
            </div>
          </div>
        {/if}
        <div class="card__content">
          <div class="cover-border"></div>
          <img class="cover" src={item.coverUrl} alt="">
          {#if item.card.showVideoIcon}
            <img class="vedio" src="//cdn.hhdd.com/frontend/as/i/b0f01ec8-2534-513e-b7dd-3ff62e4d06ab.png" alt="">
          {/if}
          {#if item.card.tag}
            <div class="tag">
              <span class="tag__title">{item.card.tag}</span>
              {#if item.card.showHeadsetIcon}
                <img class="tag__icon" src="//cdn.hhdd.com/frontend/as/i/201d0a00-e818-519c-bd7f-ded7f470a181.png" alt="">
              {/if}
              {#if item.card.showVolumeIcon}
                <img class="tag__icon" src="//cdn.hhdd.com/frontend/as/i/7bc721b1-cf4b-59f4-9a82-7711ac988b24.png" alt="">
              {/if}
            </div>
          {/if}
        </div>
        <div class="card__footer">
          {item.sourceName}
        </div>
      </div>
    {/each}
  </div>
</div>

<script>
  import { onMount } from 'svelte'
  import { goKadaBySourceType } from '@/utils/kada'
  import { debounce } from "@/utils/throttle"
  import { sendBehavior } from "@/lib/analytics"
  
  export let config = null
  export let context = null

  const cardMap = {
    1: {
      tag: '绘本',
      showVolumeIcon: true, // 音量图标
      class: 'is-book'
    },
    2: {
      tag: '听书',
      showHeadsetIcon: true, // 耳机图标
      class: 'is-story'
    },
    4: {
      tag: '听书合辑',
      showHeadsetIcon: true, // 耳机图标
      class: 'is-storyalbum',
      isAlbum: true, // 合辑
    },
    5: {
      tag: '绘本合辑',
      showVolumeIcon: true, // 音量图标
      class: 'is-bookalbum',
      isAlbum: true, // 合辑
    },
    8: {
      tag: '',
      showVideoIcon: true, // 视频图标
      class: 'is-course'
    },
    14: {
      tag: '',
      class: 'is-comic'
    },
    15: {
      tag: '',
      class: 'is-ebook'
    },
    19: {
      tag: '',
      showVideoIcon: true, // 视频图标
      class: 'is-course'
    },
  }

  $: if (config) {
    console.log('32组件', config)
    config.content = config.content || []
    config.content.forEach((item, index) => {
      item.card = cardMap[item.sourceType] || cardMap[15]
      item.card = {...item.card}
      item.card.rowGap = ''
      item.card.colGap = ''
      if (index > 2) {
        item.card.rowGap = 'row-gap'
      }
      if ((index + 1) % 3 !== 0) {
        item.card.colGap = 'col-gap'
      }
      // sendBehavior(`acpv_${context.activityKey}_${config.id}_${index+1}_${item.sourceType}_${item.sourceId}`)
    })
  }

  onMount(() => {
  })

  const handleClick = debounce((item, index) => {
    sendBehavior(`acac_${context.activityKey}_${index+1}_${item.sourceType}_${item.sourceId}`)

    localStorage.setItem('NEW_TY_SCROLL', window.scrollY)
    if (item.sourceType === 19) {
      goKadaBySourceType(context?.viewData?.identityFlag === 3, item.sourceType, item.courseId, item.sourceId)
    } else {
      goKadaBySourceType(context?.viewData?.identityFlag === 3, item.sourceType, item.sourceId)
    }
  }, 1000)

</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-content-32 {
    position: relative;
    padding: 0 0.32rem;
    margin-top: 0.48rem;
    // &.inTiYan {
    //   margin-top: 0.48rem;
    // }
    &__header {
      display: flex;
      align-items: center;
      height: 0.48rem;
      .title {
        margin-right: 0.24rem;
        font-size: 0.4rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.48rem;
      }
      .subtitle {
        font-size: 0.26rem;
        font-family: FZLANTY_JW--GB1-0, FZLANTY_JW--GB1;
        font-weight: normal;
        color: #999999;
        line-height: 1;
        @include overflow-line(1);
        flex: 1;
      }
    }
    &__content {
      display: flex;
      flex-wrap: wrap;
      margin-top: 0.32rem;
    }

    .card {
      position: relative;
      width: 2.18rem;
      height: 3.21rem;
      &__bg1 {
        position: absolute;
        width: 2.08rem;
        height: 2.69rem;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        border-radius: 0.16rem;
      }

      &__bg2 {
        width: 100%;
        height: 100%;
        border-radius: 0.16rem;
        opacity: 0.85;
      }

      &__content {
        position: relative;
        width: 2.18rem;
        height: 2.79rem;
        // border: 0.02rem solid rgba(0,0,0,0.08);
        box-sizing: border-box;
        border-radius: 0.16rem;
        overflow: hidden;
        .cover {
          width: 100%;
          height: 100%;
          border-radius: 0.16rem;
        }
        .cover-border {
          position: absolute;
          width: 100%;
          height: 100%;
          border-radius: 0.16rem;
          border: 0.04rem solid rgba(0,0,0,0.08);
          box-sizing: border-box;
          background-color: transparent;
        }
        .vedio {
          position: absolute;
          right: 0;
          bottom: 0;
          width: 1rem;
        }
        .tag {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          position: absolute;
          right: 0;
          bottom: 0;
          background-size: 100% 100%;
          background-repeat: no-repeat;

          &__title {
            font-size: 0.2rem;
            font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
            font-weight: normal;
            color: #FFFFFF;
            line-height: 0.24rem;
            margin-right: 0.04rem;
          }
          &__icon {
            width: 0.2rem;
            height: 0.2rem;
            margin-right: 0.08rem;
          }
        }
      }
      &__footer {
        margin-top: 0.14rem;
        font-size: 0.24rem;
        font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
        font-weight: normal;
        color: #333333;
        line-height: 0.28rem;
        @include overflow-line(1);
      }
    }
    .row-gap {
      margin-top: 0.34rem;
    }
    .col-gap {
      margin-right: 0.16rem;
    }
    .is-bookalbum {
        .card__bg2 {
          background-color: #66B3FF;
        }

        .tag {
          width: 1.28rem;
          height: 0.36rem;
          right: -0.04rem;
          bottom: -0.02rem;
          background-image: url(//cdn.hhdd.com/frontend/as/i/b30bd849-7fb0-51fa-8a62-950690727510.png);
        }
    }
    .is-storyalbum {
      .card__bg2 {
        background-color: #FFD072;
      }
      .tag {
        width: 1.38rem;
        height: 0.36rem;
        right: -0.02rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/3afef965-8339-56e2-a19a-a0f977e04bb6.png);
      }
    }
    .is-book {
      .tag {
        width: 1.36rem;
        height: 0.36rem;
        right: -0.02rem;
        bottom: -0.02rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/9d3eb09e-909a-5fac-a0bf-e03b701ae921.png);
      }
    }
    .is-story {
      .tag {
        width: 1.28rem;
        height: 0.36rem;
        right: -0.02rem;
        bottom: -0.02rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/3ce43322-e4ac-55bc-89f7-fdba66fb29d0.png);
      }
    } 
    .is-bookalbum, .is-storyalbum {
      .card__content {
        width: 2.08rem;
        height: 2.69rem;
        margin-top: 0.1rem;
        margin-left: 0.1rem;
      }
    }
  }
</style>