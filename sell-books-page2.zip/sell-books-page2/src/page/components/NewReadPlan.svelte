<div class="c-new-read-plan {context?.viewData?.identityFlag === 3 ? 'inTiYan' : ''}">
  <div class="c-new-read-plan__title">
    {config.stage}·{config.planTitle}
  </div>
  <div class="c-new-read-plan__content">
    <div class="weeks">
      <div class="weeks__count">共{config.totalWeek}周</div>
    </div>
    <div class="covers">
      <div class="covers__1">
        <div class="cover scale">
          <div class="cover__img1"></div>
          <img class="cover__img2" src={config.coverUrls[1]} alt="">
        </div>
      </div>
      <div class="covers__2">
        <div class="cover">
          <div class="cover__img1"></div>
          <img class="cover__img2" src={config.coverUrls[0]} alt="">
        </div>
      </div>
      <div class="covers__3">
        <div class="cover scale">
          <div class="cover__img1"></div>
          <img class="cover__img2" src={config.coverUrls[2]} alt="">
        </div>
      </div>
    </div>
    <div class="info">
      <div class="week-title">第1周 { config.weekTitle}</div>
      <div class="read-btn" on:click={goReadPlan}>开始阅读</div>
      <div class="read-people">已有{config.openCount}人开始学习</div>
    </div>
  </div>
</div>

<script>
  import { goKadaBySourceType } from '@/utils/kada'
  import { debounce } from "@/utils/throttle"

  export let config = null
  export let context = null

  $: if (config) {
    console.log('新人体验阅读计划', config)
  }

  const goReadPlan = debounce(() => {
    localStorage.setItem('NEW_TY_SCROLL', window.scrollY)
    goKadaBySourceType(context?.viewData?.identityFlag === 3, 16, config.planId)
  }, 1000)
</script>

<style lang="scss" scoped>
  @import "../../styles/variables";
  @import "../../styles/animation.scss";
  @import '../../styles/mixins';

  .c-new-read-plan {
    padding: 0 0.32rem;
    margin-top: 0.48rem;
    // &.inTiYan {
    //   margin-top: 0.48rem;
    // }
    &__title {
      height: 0.48rem;
      font-size: 0.4rem;
      font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
      font-weight: normal;
      color: #333333;
      line-height: 0.48rem;
      @include overflow-line(1);
    }
    &__content {
      position: relative;
      width: 6.7rem;
      height: 2.68rem;
      margin-top: 0.32rem;
      background-image: url(//cdn.hhdd.com/frontend/as/i/8f421df1-3f62-56fa-aa26-6d990ca1646b.png);
      background-size: 100% 100%;
      background-repeat: no-repeat;

      .weeks {
        position: absolute;
        top: 0;
        right: 0;
        width: 1.1rem;
        height: 1.1rem;
        background-image: url(//cdn.hhdd.com/frontend/as/i/bb279f79-c098-5759-acc0-594059283880.png);
        background-size: 100% 100%;
        background-repeat: no-repeat;

        &__count {
          position: absolute;
          top: 0.34rem;
          left: 0.34rem;
          font-size: 0.2rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #3CAD86;
          transform: rotate(45deg);
          line-height: 1;
        }
      }

      .covers {
        position: relative;

        &__1 {
          position: absolute;
          top: 0.48rem;
          left: 0.16rem;
          transform: rotate(-8deg);
          transform-origin: left top;
          z-index: 1;
          .scale {
            transform: scale(0.9);
            transform-origin: left top;
          }
        }
        &__2 {
          position: absolute;
          top: 0.16rem;
          left: 0.62rem;
          z-index: 2;
        }
        &__3 {
          position: absolute;
          top: 0.48rem;
          left: 1.08rem;
          transform: rotate(8deg);
          transform-origin: right top;
          z-index: 1;
          .scale {
            transform: scale(0.9);
            transform-origin: right top;
          }
        }
        .cover {
          position: relative;
          width: 1.84rem;
          height: 2.2rem;
          background-image: url(https://cdn.hhdd.com/frontend/as/i/63b42ae6-4b31-5b25-a637-4595b4bfc5e3.png);
          overflow: hidden;
          background-size: 100% 100%;
          background-repeat: no-repeat;
          &__img1 {
            position: absolute;
            top: 0;
            left: 0;
            width: 0.13rem;
            height: 2.2rem;
            background: linear-gradient(90deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.3) 100%);
            box-shadow: 0px 0.08rem 0.18rem 0px rgba(0,0,0,0.15);
            background-image: url(https://cdn.hhdd.com/frontend/as/i/d1c89937-f286-5b26-a19c-e38ba7165088.png);
            background-repeat: no-repeat;
            background-size: 100% 100%;
            // border-radius: 15px 0 0 15px;
            z-index: 1;
            overflow: hidden;
          }
          &__img2 {
            position: absolute;
            width: 1.7rem;
            height: 2.2rem;
            border-radius: 0.18rem 0.2rem 0.2rem 0.18rem;
            overflow: hidden;
          }
        }
      }
      .info {
        margin-left: 3.06rem;
        .week-title {
          width: 3.2rem;
          padding-top: 0.44rem;
          font-size: 0.28rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #333333;
          @include overflow-line(1);
        }
        .read-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 3.2rem;
          height: 0.64rem;
          margin-top: 0.4rem;
          background: linear-gradient(270deg, #33BB96 0%, #78CB76 100%);
          border-radius: 0.34rem;
          font-size: 0.32rem;
          font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
          font-weight: normal;
          color: #FFFFFF;
        }
        .read-people {
          width: 3.2rem;
          margin-top: 0.08rem;
          font-size: 0.2rem;
          font-family: FZLANTY_ZHUNJW--GB1-0, FZLANTY_ZHUNJW--GB1;
          font-weight: normal;
          color: #999999;
          line-height: 0.24rem;
          text-align: center;
        }
      }
    }
  }
</style>