<div class={[
  'c-statpanel',
  (className || ''),
  theme ? `theme-${theme}` : ''
].join(' ')}
style={style || ''}
bind:this={panelEl}
>
{#if $$slots.header}
  <div class="c-statpanel__header">
    <slot name="header"></slot>
  </div>
{/if}
<div class="c-statpanel__body">
  {#if statusConfig}
    {#if statusConfig.badge}
      <div class="badge" style={statusConfig.badge.style || ''}>
        {@html statusConfig.badge.content || ''}
      </div>
    {/if}
    {#if statusConfig.info}
      {#if Array.isArray(statusConfig.info)}
      {#each statusConfig.info as item}
        <div
          class="info {item.className || ''}"
          style={item.style || ''}
          on:click={handleButtonClick(item.action, item.params)}
        >
          {#if item.type === 'html'}
            <div class="message">{@html item.content || ''}</div>
          {:else}
            <div class="message">{item.content || ''}</div>
          {/if}
        </div>
      {/each}
      {:else}
        <div
          class="info {statusConfig.info.className || ''}"
          style={statusConfig.info.style || ''}
        >
          {#if statusConfig.info.type === 'html'}
            <div class="message">{@html statusConfig.info.content || ''}</div>
          {:else}
            <div class="message">{statusConfig.info.content || ''}</div>
          {/if}
        </div>
      {/if}
    {/if}
    {#if Array.isArray(buttonOptions)}
      {#each buttonOptions as item, index}
        <div class="btn is-min {item.className || ''}"
          style={[
            `background-image: url(${item.image})`,
            `width: ${item.width / 100}rem`,
            `height: ${item.height / 100}rem`,
            item.left ? `left: ${item.left / 100}rem` : '',
            item.top ? `top: ${item.top / 100}rem` : '',
            `margin-left: ${item.width / -200}rem`,
            item.style || ''
          ].join(';')}
          on:click={handleButtonClick(item.action, item.params)}>
          {#if item.type === 'html'}
            {@html item.content || ''}
          {:else}
            {item.content || ''}
          {/if}
        </div>
      {/each}
    {:else if typeof buttonOptions === 'object'}
      <div class="btn-wrapper" class:is-hd={appConfig.isPad} id="mainBtn">
        <div class="btn is-normal {buttonOptions.className || ''}"
          style={[
            buttonOptions.image ? `background-image: url(${buttonOptions.image})` : '',
            buttonOptions.width ? `width: ${buttonOptions.width / 100}rem` : '',
            buttonOptions.height ? `height: ${buttonOptions.height / 100}rem` : '',
            buttonOptions.left ? `left: ${buttonOptions.left / 100}rem` : '',
            buttonOptions.top ? `top: ${buttonOptions.top / 100}rem` : '',
            buttonOptions.width ? `margin-left: ${buttonOptions.width / -200}rem` : '',
            buttonOptions.style || ''
          ].join(';')}
          on:click={handleButtonClick(buttonOptions.action, buttonOptions.params)}>
          {#if buttonOptions.type === 'html'}
            {@html buttonOptions.content || ''}
          {:else}
            {buttonOptions.content || ''}
          {/if}
        </div>
      </div>
    {/if}
  {/if}
</div>
{#if $$slots.footer}
  <div class="c-statpanel__footer" class:is-hd={appConfig.isPad} style={statusConfig.footer && statusConfig.footer.style}>
    {#if statusConfig.footer}
      {#if statusConfig.footer.type === 'html'}
        {@html statusConfig.footer.content || ''}
      {:else}
        {statusConfig.footer.content || ''}
      {/if}
    {/if}
    <slot name="footer"></slot>
  </div>
{/if}
</div>

<script>
  import { createEventDispatcher } from 'svelte'
  import appConfig from '@/lib/config'

  const dispatch = createEventDispatcher()

  /**
   * 组件样式
   * @type {String} class
   */
  let className = ''
  export { className as class }

  /**
   * 自定义内联样式
   * @type {String} style
   */
  export let style = ''

  /**
   * 组件样式主题
   * @type {String} theme
   */
  export let theme = ''

  /**
   * FootBar配置信息
   * @type {Object} config
   */
  export let config = null

  $: statusConfig = config || {}

  $: buttonOptions = statusConfig && statusConfig.button

  let panelEl = null

  /**
   * 获取组件位置信息
   *
   * @returns {Rectangle}
   */
  export function getBoundingClientRect () {
    return panelEl ? panelEl.getBoundingClientRect() : null
  }

  /**
   * 事件处理方法
   */
  const handleButtonClick = (action = 'buyPackage', params) => {
    dispatch('button-click', { action, params })
  }
</script>

<style lang="scss" global>
  @import '../../styles/animation';
  @import '../../styles/variables';
  $component-name: 'c-statpanel';

  .#{$component-name} {
    position: relative;
    display: flex;
    width: 7.50rem;
    flex-direction: column;
    color: #FD4243;
    background: rgba(0, 0, 0, 0) no-repeat 50% 0 / 100% 100%;

    &__body {
      position: relative;
      flex: 1;

      :global(.badge) {
        position: absolute;
        top: 0.38rem;
        right: 0.08rem;
        width: 6em;
        height: 1em;
        color: #FFFDF1;
        font-size: 0.22rem;
        line-height: 1;
        text-align: center;
        transform: rotate(40deg);
      }

      :global(.info) {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 7.5rem;
        height: 4.4rem;
        background: {
          repeat: no-repeat;
          position: 50% 0;
          size: 100% 100%;
        }
      }

      :global(.message) {
        font-size: 0.36rem;
        font-weight: bold;
        line-height: 1.5;
      }

      :global(strong) {
        font-weight: bolder;
      }

      :global(.fz-46) {
        font-size: 0.46rem;
      }

      :global(.fz-43) {
        font-size: 0.43rem;
      }

      :global(.fz-36) {
        font-size: 0.36rem;
      }

      :global(.fz-30) {
        font-size: 0.3rem;
      }

      :global(.mb-11) {
        margin-bottom: 0.11rem;
      }

      :global(.mb-22) {
        margin-bottom: 0.22rem;
      }

      :global(.btn-wrapper) {
        position: absolute;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-wrap: nowrap;
        left: 0;
        right: 0;
        margin: auto;
      }

      :global(.btn) {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 7.2rem;
        height: 1.6rem;
        background-repeat: no-repeat;
        background-size: cover;
      }
    }

    &__header {
      padding: 0 0.2rem;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 0.70rem;
      line-height: 1;
      font-size: 0.3rem;
      font-weight: bold;
      overflow: hidden;
      z-index: 2;
    }

    &__footer {
      position: absolute;
      display: flex;
      justify-content: center;
      left: 0.2rem;
      right: 0.2rem;
      bottom: -1.64rem;
      font-size: 0.22rem;
      line-height: 1;
      font-weight: 500;
      color: #FFFDF1;
      text-align: center;
      pointer-events: none;
      &.is-hd {
        bottom: 0.64rem;
      }

      :global(em) {
        font-style: normal;
        font-size: 0.32rem;
      }
    }

    &.theme-bought {
      height: 4.24rem;

      .#{$component-name} {
        &__footer {
          display: none;
        }
      }
    }

    // pad适配
    // @media #{$pad_landscape_query} {
    //   :global(.btn-wrapper) {
    //     bottom: 0.4rem;
    //   }
    //   :global(.btn) {
    //     width: 9.08rem;
    //     height: 2.2rem;
    //   }
    // }
  }
</style>
