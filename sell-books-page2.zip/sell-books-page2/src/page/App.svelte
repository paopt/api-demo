{#if isKadaClient && navbarConfig}
  <Navbar fixed {...navbarConfig} on:shareClick={handleShareClick}>
    {#if !navbarConfig.hideTitle}
      <div class="o-navbar-title">{pageTitle}</div>
    {/if}
  </Navbar>
{/if}
<Router>
  <Route exact redirect={`/home/${defaultActivityKey}`} />
  <Route fallback component={NotFound} />
  {#each routes as item}
    <Route exact path={item.path} let:router>
      {#if !isSvelteComponent(item.component)}
        {#await Promise.all([isPromise(item.component) ? item.component : item.component(), getActivityData(router.params && router.params[item.loadConfig])])}
          {#if item.loading}
            <svelte:component this={item.loading} {...router.params} {...router.query} />
          {:else}
            <Loading />
          {/if}
        {:then data}
          <svelte:component this={data[0].default || data[0]} {...router.params} {...router.query} pageContext={data[1]} />
        {/await}
      {:else}
        <svelte:component this={item.component} {...router.params} {...router.query} />
      {/if}
    </Route>
  {/each}
</Router>

<script>
  import { onMount, onDestroy } from 'svelte'
  import { Router, Route, router, navigateTo } from '@kada/yrv'
  import { isSvelteComponent, isPromise } from '@/utils/lang'
  import NotFound from '@/views/NotFound.svelte'
  import Loading from '@/views/Loading.svelte'
  import { Navbar } from '@kada/svelte-activity-ui'
  import { deviceInfo, compareVersion } from '@kada/library/src/device'
  import { openShare, isClientOpen, setFeatures, getFeatureStatus, onBack as onNativeBack, close as closeWebView, remove as removeEvent } from '@kada/jsbridge'
  import { DEFAULT_ACTIVITYKEY } from './service'
  import wechat from '@/lib/wechat'
  import routes from './routes.js'
  import appConfig from '@/lib/config'
  import { onInitPageData } from './views/Home/home'
  import { INNER_APP_NAME_ENUM } from '@kada/lib-ua-parser/src/ua-parser'
  import { getShareConfig } from "@/shared/scheme/page-config"
  import { removeCookie } from 'tiny-cookie'


  function touchFn() {
    console.log('touch')
  }
  function clickFn() {
    console.log('click')
  }
  const FEATURE_STATUS = {
    UNKNOWN: -1, // 未知
    ENABLE: 1, // 启用
    DISABLE: 0 // 禁用
  }

  const FEATURES = {
    INTERCEPT_BACK_EVENT: 'interceptBackEvent' // 拦截返回事件
  }

  /**
 * 操作符枚举
 * @readonly
 * @typedef {( -1 | 0 | 1 )} FeatureOperator
 */
export const FEATURE_OPERATOR = {
  ENABLE: FEATURE_STATUS.ENABLE,
  DISABLE: FEATURE_STATUS.DISABLE
}

  Router.hashchange = true

  const CONFIG_STYLE_ID = '_config_style_id'

  let pageTitle = document.title || ''
  // 当前页面活动ID
  let defaultActivityKey = DEFAULT_ACTIVITYKEY

  // 分享文案
  let shareConfig = null

  // 导航栏样式
  let navbarConfig = null

  let isKadaClient = false


  // 最小支持阅读计划的App版本
  const MIN_SUPPORT_BACKEVNET_VERSION = {[INNER_APP_NAME_ENUM.KADA]: { version: '6.8.0', operator: '<' }}

  let onNativeBackEventId = 0

  isClientOpen().then(() => {
    isKadaClient = true
  }).catch(() => {
    isKadaClient = false
  })

  if (history.scrollRestoration) {
    history.scrollRestoration = 'manual';
  }

  const handleShareClick = () => {
    if (deviceInfo.isKadaClient) {
      shareConfig = getShareConfig()
      openShare(shareConfig)
    }
  }

  // 初始化分享信息
  try {
    if (deviceInfo.wechat) {
      wechat.share(shareConfig)
    }
  } catch (error) {
    console.error(error)
  }

  // 缓存活动数据
  let promise
  function getActivityData(id) {
    // 第一次进入或id变了
    if (!promise || (defaultActivityKey !== id)) {
      promise = getContextData(id)
    } else {
      promise = promise.then(res => {
        console.log('activity promise', res)
        if (!res && location.hash.includes('/home')) {
          return getContextData(id)
        }
        return res
      })
    }
    return promise
  }

  /**
   * 获取配置信息
   * @param {Number|String} id 配置ID
   * @returns {Object}
   */
  async function getContextData (id) {
    //除home页之外的页面不需要根据活动ID取活动配置
    if (id && $router?.path.startsWith('/home')) {
      if (!deviceInfo.isKadaClient) {
        const loginSuccess = window.sessionStorage.getItem('loginSuccess')
        if (!loginSuccess) {
          await clearCookie()
        }
      }
      defaultActivityKey = id || DEFAULT_ACTIVITYKEY
      try {
        const { pageConfig, context } = await onInitPageData({ activityKey: id })
        initPageViewConfig(pageConfig)
        context.subscribe('viewData', () => {
          initPageViewConfig(pageConfig, context.getData())
          if (context?.viewData?.identityFlag === 3) {
            navbarConfig.hideTitle = false
            navbarConfig.theme = 'white'
            pageTitle = '新人即时体验'
          }
        })
        console.log($router.query)
        return context
      } catch (error) {
        console.log(`getContextData id: ${id} error: `, error)
      }
    } else {
      return null
    }
  }

  function initPageViewConfig (config, data) {
    const contextOptions = {
      deviceInfo,
      env: appConfig.env,
      context: data
    }

    const [metaConfig, _shareConfig, frameViewConfig] = [
      config.useMates(contextOptions),
      config.useShareConfig(contextOptions),
      config.useFrameView(contextOptions),
    ]

    shareConfig = _shareConfig

    // 更新meta配置信息
    if (metaConfig) {
      document.title = pageTitle = metaConfig.title || ''
    }

    // 更新界面框架配置，ipad，Android pad隐藏分享
    if (frameViewConfig) {
      navbarConfig = frameViewConfig.navbar
      if ((navbarConfig && deviceInfo.isPad) || !shareConfig.canUseShare) {
        navbarConfig.isHideShare = true
      }

      const bodyStyle = frameViewConfig.body?.style

      if (typeof bodyStyle === 'string') {
        document.body.style.cssText += bodyStyle
      }

      // 添加配置文件中的样式
      const customStyle = frameViewConfig.styleSheet
      if (customStyle) {
        let styleEl = document.getElementById(CONFIG_STYLE_ID)

        if (!styleEl) {
          styleEl = document.createElement('style')
          styleEl.id = CONFIG_STYLE_ID
          styleEl.textContent = customStyle
          document.head.appendChild(styleEl)
        } else {
          styleEl.textContent = customStyle
        }
      }
    }
  }

  //校验返回拦截状态
  const hasBackStatus = status => getFeatureStatus(FEATURES.INTERCEPT_BACK_EVENT) === status

  //设置返回拦截
  const setBackStatus = status => setFeatures({[FEATURES.INTERCEPT_BACK_EVENT]: status})

  //移除返回拦截事件
  const removeNativeBackEvent = eventId => removeEvent('onBack', eventId)

  //添加返回拦截事件
  const addNativeBackEvent = () => onNativeBack(navigator =>  {
    if (location.hash.includes('/home')) {
      !!navigator ? navigator.close() : closeWebView()
    } else {
      if (history.length > 1) {
        if (location.hash.includes('/address/edit')) {
          history.back()
        } else {
          navigateTo(`/home/${defaultActivityKey}`)
        }
      } else {
        !!navigator ? navigator.close() : closeWebView()
      }
    }
  }, false).then(id => {
    onNativeBackEventId = id
    return id
  })

  //注册原生返回拦截功能
  const initNativeBackFeature = () => {
    if (hasBackStatus(FEATURE_STATUS.ENABLED)) {
      return addNativeBackEvent()
    } else {
      return setBackStatus(FEATURE_OPERATOR.ENABLE).then(() => addNativeBackEvent())
    }
  }

  //注销原生返回拦截功能
  const destoryNativeBackFeature = () => {
    if (hasBackStatus(FEATURE_STATUS.DISABLE)) {
      removeNativeBackEvent(onNativeBackEventId)
      onNativeBackEventId = 0
      return
    }
    setBackStatus(FEATURE_OPERATOR.DISABLE).then(() => {
      removeNativeBackEvent(onNativeBackEventId)
      onNativeBackEventId = 0
    })
  }

  onMount(() => {
    console.log('全局配置', appConfig)
    console.log($router.params)
    router.subscribe(r => {
      console.log('路由参数', r)
      let {path} = r
      // 其他页面隐藏分享按钮
      if (navbarConfig) {
        if (path.includes('/address') || path.includes('/redeemCode')) {
          navbarConfig.isHideShare = true
        }
      }
      //app内，分流页跳转过来，左上角后退，直接回到app
      if (deviceInfo.isKadaClient && path.includes('/home')) {
        //判断是否支持返回拦截功能
        if (deviceInfo.isKadaClient && !compareVersion(MIN_SUPPORT_BACKEVNET_VERSION)) {
          initNativeBackFeature()
        }
      }
    })
  })

  onDestroy(() => {
    window.sessionStorage.removeItem('loginSuccess')
    const styleEl = document.getElementById(CONFIG_STYLE_ID)
    const {path} = $router

    if (styleEl) {
      styleEl.parentElement.removeChild(styleEl)
    }
    //销毁左上角回退按钮事件监听
    path.includes('/home') && destoryNativeBackFeature()
  })

  async function clearCookie() {
    console.log('删除cookie前:', document.cookie)
    removeCookie('_HHDD_')
    if (appConfig.env === 'test') {
      removeCookie('_HHDD_', { domain: '.guoshileilei.com'})
      removeCookie('_HHDD_', { domain: '.daily38890.ngrok-kada.guoshileilei.com'})
    } else {
      removeCookie('_HHDD_', { domain: '.hhdd.com'})
    }
    console.log('删除后cookie: ', document.cookie)
  }
</script>

<style lang="scss" global>
  @import '../styles/variables';
  html {
    width: 100%;
    height: 100%;
  }

  body {
    width: 100%;
    max-width: 100%;
    min-height: 100%;
    overflow-x: hidden;
    user-select: none;
    -webkit-user-drag: none;
  }
  button:focus {
    outline: none;
  }
  .o-navbar-title {
    font-size: 0.36rem;
    font-family: FZLANTY_ZHONGCUJW--GB1-0, FZLANTY_ZHONGCUJW--GB1;
    font-weight: normal;
    color: #3F3F3F;
  }
</style>
