/**
 * 客户端升级提示判断模块
 *
 * @summary 客户端升级提示判断模块
 * @author diaoling <jinjian@hhdd.com>
 */
import { isClientOpen, openMarketAppDetail, close as closeWebView } from '@kada/jsbridge'
import { compareVersion, deviceInfo } from '@kada/library/src/device'
import { showDialog, DIALOG_TYPE } from '../ui/index'
import { KADA_APP_OPEN_IN_APPSTORE, KADA_APP_DOWNLOAD_URL, APP_SUPPORT_PACKAGE_PAYMENT, HD_SUPPORT_PACKAGE_PAYMENT } from './constants'
import { getAnalyticsIdByName, getDialogOptionsByName } from '../scheme/page-config'
import { sendBehavior } from './index'

/**
 * 检查当前客户端版本，提示是否升级，检查是否在微信内打开
 * @param {Object} options 相关配置
 * @param {Object} options.version 支持最低版本，默认为 4.7.0
 */
export async function upgradeNotifier (options = {}) {
  const { version: baseVersion = deviceInfo.isAndroidHD ? HD_SUPPORT_PACKAGE_PAYMENT : APP_SUPPORT_PACKAGE_PAYMENT, activityKey = '' } = options

  // 显示升级弹窗
  const showUpgradeDialog = () => {
    // 客户端升级弹窗配置信息
    const upgradeDialogOptions = getDialogOptionsByName('upgrade')

    const versionPopView = getAnalyticsIdByName('dialog.upgradeDialog.view')
    const versionPopClick = getAnalyticsIdByName('dialog.upgradeDialog.doneClick')
    sendBehavior(versionPopView || 'ac_version_pop_view', { activityKey })

    return showDialog({
      type: DIALOG_TYPE.APP_UPGRAGE,
      title: '版本过低',
      message: '请到应用市场更新您的应用',
      buttonText: deviceInfo.isAndroidHD ? '我知道了' : '立即更新',
      doneCloseDialog: false,
      ...upgradeDialogOptions,
      onDone: () => {
        sendBehavior(versionPopClick || 'ac_version_pop_click', { activityKey })

        // 安卓利用jsbridge完成跳转应用市场
        if (deviceInfo.ios) {
          location.href = KADA_APP_OPEN_IN_APPSTORE
        } else if (!deviceInfo.isAndroidHD) {
          openMarketAppDetail('com.hhdd.kada')
          setTimeout(() => {
            location.href = KADA_APP_DOWNLOAD_URL
          }, 100)
        } else {
          closeWebView()
        }
      }
    })
  }

  // 显示微信打开弹窗
  const showWechatOpenDialog = () => {  // 仅微信支持弹窗配置信息
    const wechatDialogOptions = getDialogOptionsByName('wechatOnly')

    return showDialog({
      type: DIALOG_TYPE.WECHAT_OPEN,
      message: '当前环境不支持<br>请在微信内打开哦',
      doneCloseDialog: false,
      buttonText: '我知道了',
      ...wechatDialogOptions,
      onDone: () => {
        location.href = KADA_APP_DOWNLOAD_URL
      }
    })
  }

  try {
    if (compareVersion(baseVersion)) {
      showUpgradeDialog()

      return false
    }
  } catch (error) {
    // 旧版客户端检测
    return isClientOpen().then(() => {
      showUpgradeDialog()

      return false
    }).catch(() => {
      if (!deviceInfo.wechat) {
        showWechatOpenDialog()

        return false
      }

      return true
    })
  }

  return true
}
