/**
 * KaDa阅读客户端内购买礼包相关逻辑
 *
 * @summary App内购买礼包逻辑
 * @author diaoling <jinjian@hhdd.com>
 */
import {
  checkLogin as checkUserLogin,
  openLogin as openLoginPanel,
  openPayOrderPannel,
  remove as removeWebviewEvent,
  onShow as onWebviewShow,
  close as closeWebView,
  setting,
  refresh
} from '@kada/jsbridge'
import { backToHome } from '@kada/kada-schema/lib/index.esm'
import { compareVersion, deviceInfo } from '@kada/library/src/device'
import { kdCookieShim } from '@kada/cookie-shim/src/cookie-shim'
import {
  DIALOG_TYPE,
  showDialog
} from '../ui/index'
import {
  PAGE_STATUS,
  RESPONSE_CODE_MESSAGE,
  isOpenedWithPageStatus,
  isCanBuyWithPageStatus
} from './page-status'
import {
  getDialogOptionsByName,
  getVoiceByName,
  getAnalyticsIdByName,
  getDialogOptionsWhenStatus,
} from '../scheme/page-config'
import {
  useHookWrap,
  checkPageStatusHook,
  showWhenPageStatusDialogHook,
  showOpenedDialogHook,
  showSuccessDialogHook,
  showRetainDialogHook,
  loginFailHook,
  notAllowBuyHook,
  packageIdErrorHook
} from './hooks'
import { getPageData, sendBehavior, voiceSoundChannel } from './index'
import { promiseDelay } from '@/utils/promisify'
import config from '@/lib/config'
import { logger } from '@/lib/logger'
import { HD_CAN_BACK_RECOMMENT_VERSIONS, DEFAULT_REFRESH_MOUDLES } from './constants'

/**
 * 根据页面状态显示弹窗
 * @param {String} pageStatus
 */
const showWhenPageStatusDialog = useHookWrap(async (pageStatus) => {
  const dialogOpts = getDialogOptionsWhenStatus(pageStatus)
  const canBuy = await isCanBuyWithPageStatus(pageStatus)

  if (dialogOpts) {
    const viewStatId = getAnalyticsIdByName(`dialog.${pageStatus}.view`)
    const clickStatId = getAnalyticsIdByName(`dialog.${pageStatus}.doneClick`)
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    let { showTimes = canBuy ? 'once' : 'always', doneAction, ...showDialogOpts } = dialogOpts

    // 如果未设置，默认子会员跳转至升级会员
    if (typeof doneAction === 'undefined' && pageStatus === PAGE_STATUS.SUBVIP) {
      doneAction = 'openvipcharge'
    }

    return showDialog({
      ...showDialogOpts,
      doneCloseDialog: showTimes === 'once',
      onDone: async () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }

        if (doneAction === 'openvipcharge') {
          // 打开VIP中心升级页面
          location.href = 'kada://openvipcharge'

          webviewShowedId = await onWebviewShow(() => {
            getPageData(true)

            removeWebviewEvent('onShow', webviewShowedId)
            webviewShowedId = 0
          })
        } else {
          if (compareVersion(HD_CAN_BACK_RECOMMENT_VERSIONS) && deviceInfo.isAndroidHD) {
            backToHome({site:'recommond'})
          } else {
            backToHome('book')
          }
        }
      }
    })
  }
}, showWhenPageStatusDialogHook)
/**
 * 显示已经开通弹窗
 * @param {String} pageStatus
 */
const showSuccessDialog = useHookWrap(async () => {
  const successDialogOptions = getDialogOptionsByName('successDialog')

  if (successDialogOptions) {
    const viewStatId = getAnalyticsIdByName('dialog.successDialog.view')
    const clickStatId = getAnalyticsIdByName('dialog.successDialog.doneClick')
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    return showDialog({
      ...successDialogOptions,
      onDone: () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }
        backToHome('book')
      }
    })
  }
}, showSuccessDialogHook)

/**
 * 显示挽留弹窗
 * @param {String} packageId
 * @param {String} pageStatus
 */
const showRetainDialog = useHookWrap(async (packageId, packageType) => {
  const retainDialogOptions = getDialogOptionsByName('retainDialog')

  if (retainDialogOptions) {
    const viewStatId = getAnalyticsIdByName('dialog.retainDialog.view')
    const doneStatId = getAnalyticsIdByName('dialog.retainDialog.doneClick')
    const closeStatId = getAnalyticsIdByName('dialog.retainDialog.closeClick')
    sendBehavior(viewStatId || 'ac_stay_pop_view')

    return showDialog({
      type: DIALOG_TYPE.ERROR,
      title: '活动即将结束，确定离开吗？',
      buttonText: '再看看',
      showCloseButton: true,
      maskClickHide: true,
      ...retainDialogOptions,
      onDone: () => {
        sendBehavior(doneStatId || 'ac_stay_pop_btn_1_click')
        // 再看看打开支付面板
        openPayPanel(packageId, packageType)
      },
      onClose: () => {
        sendBehavior(closeStatId || 'ac_stay_pop_btn_2_click')
      }
    })
  }
}, showRetainDialogHook)

// webview显示事件监听ID
let webviewShowedId = 0

/**
 * 检查接口返回页面数据
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {String} ctx.pageStatus 页面当前状态
 * @param {Boolean} isRefresh 是否为刷新接口
 */
export const checkPageStatus = useHookWrap(_checkPageStatus, checkPageStatusHook)

/**
 * 检查接口返回页面数据
 * @param {Object} ctx 请求处理过程上下文
 * @param {Object} ctx.responseBody 请求返回数据
 * @param {String} ctx.pageStatus 页面当前状态
 * @param {Boolean} isRefresh 是否为刷新接口
 */
async function _checkPageStatus (ctx, isRefresh = false) {
  if (!ctx) {
    throw new Error('context 为必传参数')
  }

  if (webviewShowedId) {
    removeWebviewEvent(webviewShowedId)
    webviewShowedId = 0
  }

  const {
    pageStatus,
    responseBody = {}
  } = ctx
  const canBuy = await isCanBuyWithPageStatus(pageStatus)
  if (!isRefresh) {
    // 页面PV打点
    const statId = getAnalyticsIdByName('pageView')
    const boughtStatId = getAnalyticsIdByName('boughtPageView')
    if (statId) {
      sendBehavior(statId)
    }
    if (boughtStatId) {
      sendBehavior(boughtStatId)
    }
    // 播放页面欢迎音频
    const voiceUrl = getVoiceByName('welcome')

    if (voiceUrl && pageStatus !== PAGE_STATUS.UNKNOWN) {
      voiceSoundChannel.play(voiceUrl)
    }
  }

  if (pageStatus === PAGE_STATUS.NETWORK_ERROR) {
    const { code, msg } = responseBody || {}
    const errorObj = RESPONSE_CODE_MESSAGE[code] || { title: msg || '网络错误，请稍后再试' }
    const dialogOpts = getDialogOptionsByName('dialog.networkError')
    const viewStatId = getAnalyticsIdByName('dialog.networkError.view')
    const clickStatId = getAnalyticsIdByName('dialog.networkError.doneClick')
    if (viewStatId) {
      sendBehavior(viewStatId)
    }

    showDialog({
      type: DIALOG_TYPE.ERROR,
      title: errorObj.title || '网络请求异常',
      message: errorObj.message,
      hideOnMask: false,
      buttonText: '我知道了',
      doneCloseDialog: false,
      ...dialogOpts,
      onDone: () => {
        if (clickStatId) {
          sendBehavior(clickStatId)
        }

        closeWebView()
      }
    })

    return canBuy
  }

  // 根据页面状态显示弹窗
  showWhenPageStatusDialog(pageStatus)

  return canBuy
}

/**
 * 购买过程中登录失败
 */
const loginFail = useHookWrap((isLogin) => isLogin, loginFailHook)

/**
 * 不允许购买的处理函数
 * @param {Boolean} isCanbuy
 * @returns {Boolean}
 */
const notAllowBuy = useHookWrap((canBuy) => canBuy, notAllowBuyHook)

/**
 * 礼包ID错误处理
 */
const packageIdError = useHookWrap((packageId) => {
  throw new Error(`礼包ID：${packageId}不存在`)
}, packageIdErrorHook)

/**
 * 打开登录弹层
 *
 * @param {Object} options 登录弹层相关配置
 * @param {Number} options.loginType 指定优先某种登录方式 0=??? 1=??? 2=微信(v4.1.20)
 * @param {Number} options.skipUserGuide 跳过新用户注册引导 默认为 0不跳过， 1跳过
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址, 默认为 true
 *
 * @returns {Boolean} 是否登录成功
 */
export async function openLogin (options = {}) {
  const { loginHelpVoice = true, ...openLoginPanelOptions } = options

  try {
    // 播放帮助登录语音
    if (loginHelpVoice) {
      const helpVoice = typeof loginHelpVoice === 'string'
        ? loginHelpVoice
        : '//cdn.hhdd.com/frontend/as/e/85e9aab3-9c0d-53b3-a0f6-f90a2d8f86ed.mp3'

      if (helpVoice) {
        voiceSoundChannel.play(helpVoice)
      }
    }

    // 呼起登录
    const loginRes = await openLoginPanel(openLoginPanelOptions)

    // jsbridge调用异常
    if (loginRes.code === -1) {
      logger.error(loginRes)
    }
    if (loginRes.data && loginRes.data.loginStatus > 0) {
      // 更新登录Cookie
      kdCookieShim({
        env: config.env,
        cookie: loginRes.data.cookies
      })
      return true
    }
  } catch (error) {
    logger.error(error)
  }

  return false
}

/**
 * 检查页面是否已经登录
 *
 * @param {Object} options
 * @param {Boolean} options.openLogin 如果未登录，尝试打开登录弹层, 默认为 true
 * @param {Number} options.loginType 指定优先某种登录方式 0=??? 1=??? 2=微信(v4.1.20)
 * @param {Number} options.skipUserGuide 跳过新用户注册引导 默认为 0不跳过， 1跳过
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址
 *
 * @returns {Boolean} 是否已经登录成功
 */
export async function checkLogin (options = {}) {
  const { openLogin: $openLogin = true, ...openLoginOptions } = options
  try {
    const res = await checkUserLogin()
    if (res.data && res.data.loginStatus) {
      // 登录状态
      return true
    }

    if ($openLogin) {
      return openLogin(openLoginOptions)
    }
  } catch (error) {
    logger.error(error)
  }

  return false
}

/**
 * 打开支付面板
 *
 * @param {Number} packageId [必填]礼包ID
 * @param {Object} options 支付参数
 * @param {String} pageStatus 页面状态
 * @param {Number} packageType 礼包类型 默认 5
 *
 * @returns {Boolean} 是否购买成功
 */
async function openPayPanel (packageId, options = {}) {
  const { pageStatus, packageType = 5, refreshMoudles } = options

  if (!packageId) {
    return packageIdError(packageId)
  }

  try {
    // 支付面板显示方式：1、 横屏； 2、竖屏
    let screenOrientation = 2
    if (window.innerWidth > window.innerHeight) {
      screenOrientation = 1
    }
    const payResult = await openPayOrderPannel({ type: packageType, collectId: packageId,  screenOrientation})
    const { code, data } = payResult || {}
    console.log('openPayPanel: data = ', data)
    const status = data && typeof data.payStatus === 'boolean'
      ? Number(data.payStatus)
      : data && data.payStatus
        ? parseInt(data.payStatus, 10)
        : 0

    const paySuccess = status === 1
    // jsbridge调用异常
    if (code === -1) {
      logger.error(payResult)
    }

    if (paySuccess) {
      await promiseDelay(500)
      // 以PV形式刷新接口
      await getPageData(false)

      // 显示已开通弹窗
      showSuccessDialog(pageStatus)

      // 通知客户端刷新相关数据并在绘本首页显示优才计划模块
      setting({ bookPageCourse: 1 })

      // refresh(['course', 'vipinfo', 'readingplan'])
      console.log([...DEFAULT_REFRESH_MOUDLES, ...refreshMoudles])
      refresh([...DEFAULT_REFRESH_MOUDLES, ...refreshMoudles])

      // 播放购买成功音频
      const voiceUrl = getVoiceByName('bought')

      if (voiceUrl) {
        voiceSoundChannel.play(voiceUrl)
      }

      return true
    } else {
      // 显示挽留弹窗
      showRetainDialog(packageId, packageType, pageStatus)
    }

    return paySuccess
  } catch (error) {
    logger.error(error)
  }

  return false
}

/**
 * 礼包支付流程
 *
 * @param {Number} packageId [必填] 礼包ID
 * @param {Object} options
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String} options.pageStatus 页面状态
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址
 * @param {() => Promise<Boolean>} options.refreshPageData 刷新礼包数据
 * @param {(type:String) => Promise<String|Number>} options.getPackageId 获取刷新后礼包ID
 *
 * @return {Boolean} 是否购买成功
 */
export async function payment (packageId, options = {}) {
  const {
    packageType = 5,
    pageStatus,
    loginHelpVoice = true,
    refreshMoudles,
    refreshPageData = () => Promise.resolve(false)
  } = options
  try {
    const isLogin = await checkLogin({
      openLogin: true,
      loginType: 0,
      skipUserGuide: 1,
      loginHelpVoice
    })

    if (!isLogin) {
      return loginFail(isLogin)
    }

    const canBuy = await refreshPageData()
    console.log('payment::refreshPageData canBuy = ', canBuy)

    // 不支持购买
    if (!canBuy) {
      return notAllowBuy(canBuy)
    }

    // 是否可以购买礼包
    if (canBuy) {
      const paySuccess = await openPayPanel(packageId, { packageType, pageStatus, refreshMoudles })
      return paySuccess
    }
  } catch (error) {
    logger.error(error)
  }

  return false
}

/**
 * 显示已经开通弹窗
 * @param {String} pageStatus
 */
const showOpenedDialog = useHookWrap(() => {
  const openedDialogOptions = getDialogOptionsByName('opened')
  const viewStatId = getAnalyticsIdByName('dialog.opened.view')
  const clickStatId = getAnalyticsIdByName('dialog.opened.doneClick')
  if (viewStatId) {
    sendBehavior(viewStatId)
  }

  return showDialog({
    type: DIALOG_TYPE.MESSAGE,
    title: '你已享有该活动所有权益',
    message: '无需参加本活动哦',
    buttonText: '我知道了',
    ...openedDialogOptions,
    onDone: () => {
      if (clickStatId) {
        sendBehavior(clickStatId)
      }
      backToHome('book')
    }
  })
}, showOpenedDialogHook)

/**
 * 购买礼包
 * @param {Number} packageId [必填] 礼包ID
 * @param {Object} options
 * @param {Context} options.context 页面上下文
 * @param {Number} options.packageType 礼包类型默认 5
 * @param {String|Boolean} options.loginHelpVoice 指定播放登录语音，true 播放默认语音 false 不播放语音  或传递语音地址
 * @param {() => Promise<Boolean>} options.refreshPageData 刷新礼包数据
 * @param {(type:String) => Promise<String|Number>} options.getPackageId 获取刷新后礼包ID
 *
 * @returns {Boolean} 是否购买成功
 */
export async function buyPackage (packageId, options = {}) {
  const { context = {}, ...paymentOpts } = options
  const { pageStatus } = context
  const canBuy = await isCanBuyWithPageStatus(pageStatus)
  if (canBuy) {
    return payment(packageId, { pageStatus, ...paymentOpts })
  }
  const isOpened = await isOpenedWithPageStatus(pageStatus)
  console.log('isOpened', isOpened)
  if (isOpened) {
    showOpenedDialog(pageStatus)

    return false
  }

  return false
}
