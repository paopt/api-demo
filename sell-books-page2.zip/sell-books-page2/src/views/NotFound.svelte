<div class="o-not-found">
  <p class="msg">页面未找到</p>
</div>

<style lang="scss">
.o-not-found {
  display: flex;
  width: 100%;
  height: 100%;
  align-items: center;
  justify-content: center;

  .msg {
    font-size: 0.28rem;
    text-align: center;
  }
}
</style>
